"""Launcher copied to DaVinci Resolve's Workspace > Scripts > Utility menu."""

from pathlib import Path
import runpy
import sys


TOOL_DIR = Path(r"C:\Users\Admin\Documents\Davinci Resole")
if str(TOOL_DIR) not in sys.path:
    sys.path.insert(0, str(TOOL_DIR))

context = {}
for injected_name in ("resolve", "fusion", "bmd"):
    if injected_name in globals():
        context[injected_name] = globals()[injected_name]

runpy.run_path(
    str(TOOL_DIR / "davinci_batch_tool.py"),
    run_name="__main__",
    init_globals=context,
)

