$ErrorActionPreference = "Stop"

$toolRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location -LiteralPath $toolRoot
python .\resolve_web_bridge.py
