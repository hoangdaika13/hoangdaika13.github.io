# Copy only the variables for the channel you use into your user environment.
# Do not commit real tokens or passwords into this file.

# Telegram
$env:H_COSMIC_TELEGRAM_TOKEN = "replace-with-bot-token"
$env:H_COSMIC_TELEGRAM_CHAT_ID = "replace-with-chat-id"

# Slack
$env:H_COSMIC_SLACK_WEBHOOK = "https://hooks.slack.com/services/replace/me"

# Email / SMTP
$env:H_COSMIC_SMTP_HOST = "smtp.example.com"
$env:H_COSMIC_SMTP_PORT = "587"
$env:H_COSMIC_SMTP_USER = "sender@example.com"
$env:H_COSMIC_SMTP_PASSWORD = "replace-with-app-password"
$env:H_COSMIC_EMAIL_TO = "recipient@example.com"
