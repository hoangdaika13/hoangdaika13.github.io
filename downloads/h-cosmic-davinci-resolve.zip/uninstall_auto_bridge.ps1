$ErrorActionPreference = "Stop"

$startupDir = [Environment]::GetFolderPath("Startup")
$launcherPath = Join-Path $startupDir "H Cosmic Studio Bridge.cmd"

if (Test-Path -LiteralPath $launcherPath) {
    Remove-Item -LiteralPath $launcherPath -Force
    Write-Host "Da go H Cosmic Auto Bridge khoi Windows Startup."
} else {
    Write-Host "H Cosmic Auto Bridge khong co trong Windows Startup."
}

Write-Host "Bridge dang chay (neu co) se dung sau khi dang xuat hoac khoi dong lai Windows."
