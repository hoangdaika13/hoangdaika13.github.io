from __future__ import annotations

import ctypes
import json
import queue
import threading
import traceback
from datetime import datetime
from pathlib import Path
from typing import Any, Callable

import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from resolve_batch_core import (
    AUDIO_EXTENSIONS,
    IMAGE_EXTENSIONS,
    BatchConfig,
    BatchPlan,
    ProductionEstimate,
    ResolveBatchEngine,
    ResolveError,
    build_action_blueprint,
    connect_resolve,
    discover_files,
    format_duration,
    load_config,
    save_config,
)
from production_runtime import (
    PreflightValidator,
    ProductionCoordinator,
    ProductionProfile,
    load_profiles,
    save_profiles,
)
from resolve_web_bridge import ResolveWebBridge


APP_DIR = Path(__file__).resolve().parent
CONFIG_FILE = APP_DIR / ".davinci_batch_config.json"


class BatchStudioApp:
    def __init__(self, root: tk.Tk, injected_resolve: Any = None) -> None:
        self.root = root
        self.root.title("H Cosmic Studio — DaVinci Batch Production")
        self.root.geometry("1020x820")
        self.root.minsize(900, 720)
        self.resolve = connect_resolve(injected_resolve)
        self.events: queue.Queue[tuple[str, Any]] = queue.Queue()
        self.worker: threading.Thread | None = None
        self.cancel_event = threading.Event()
        self.web_bridge: ResolveWebBridge | None = None
        self.config = load_config(CONFIG_FILE)
        self.vars: dict[str, tk.Variable] = {}
        self.action_buttons: list[ttk.Button] = []
        self._configure_style()
        self._build_ui()
        self._config_to_vars()
        self.root.after(100, self._drain_events)
        self.root.after(250, self.refresh_connection)
        self.root.after(550, self.update_estimate)
        self.root.after(650, self.populate_action_blueprint)
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

    def _configure_style(self) -> None:
        self.root.configure(bg="#060914")
        style = ttk.Style()
        style.theme_use("clam")
        style.configure(".", background="#10162a", foreground="#eaf3ff", fieldbackground="#090e1d")
        style.configure("TFrame", background="#060914")
        style.configure("Card.TFrame", background="#10162a")
        style.configure("TLabel", background="#10162a", foreground="#eaf3ff")
        style.configure("Title.TLabel", background="#060914", foreground="#ffffff", font=("Segoe UI Semibold", 18))
        style.configure("Sub.TLabel", background="#060914", foreground="#8ea1c4")
        style.configure("Status.TLabel", background="#060914", foreground="#39dcff")
        style.configure("Metric.TLabel", background="#0a1021", foreground="#39dcff", font=("Segoe UI Semibold", 11))
        style.configure("MetricSub.TLabel", background="#0a1021", foreground="#8ea1c4", font=("Segoe UI", 8))
        style.configure("TButton", padding=(11, 7), background="#17213c", foreground="#eaf3ff")
        style.map("TButton", background=[("active", "#24345b"), ("disabled", "#10162a")])
        style.configure("Primary.TButton", background="#7c5cff", foreground="#ffffff")
        style.map("Primary.TButton", background=[("active", "#947cff"), ("disabled", "#30285c")])
        style.configure("Danger.TButton", background="#a72f68", foreground="#ffffff")
        style.map("Danger.TButton", background=[("active", "#d23f82"), ("disabled", "#32152a")])
        style.configure("TEntry", padding=6)
        style.configure(
            "TCombobox",
            padding=5,
            fieldbackground="#090e1d",
            background="#17213c",
            foreground="#eaf3ff",
            arrowcolor="#39dcff",
            selectbackground="#27365c",
            selectforeground="#ffffff",
        )
        style.map(
            "TCombobox",
            fieldbackground=[("readonly", "#090e1d"), ("disabled", "#11182b")],
            foreground=[("readonly", "#eaf3ff"), ("disabled", "#607092")],
            selectbackground=[("readonly", "#090e1d")],
            selectforeground=[("readonly", "#eaf3ff")],
        )
        style.configure("TCheckbutton", background="#10162a", foreground="#eaf3ff")
        style.map("TCheckbutton", background=[("active", "#10162a")], foreground=[("active", "#39dcff")])
        style.configure("Horizontal.TProgressbar", troughcolor="#070b18", background="#39dcff")
        style.configure(
            "Cosmic.Treeview",
            background="#080d1d",
            fieldbackground="#080d1d",
            foreground="#dbe8ff",
            rowheight=24,
            bordercolor="#27365c",
        )
        style.configure(
            "Cosmic.Treeview.Heading",
            background="#17213c",
            foreground="#39dcff",
            font=("Segoe UI Semibold", 9),
        )
        style.map("Cosmic.Treeview", background=[("selected", "#382f72")])
        style.configure("TLabelframe", background="#10162a", foreground="#ffffff", bordercolor="#27365c")
        style.configure(
            "TLabelframe.Label",
            background="#10162a",
            foreground="#9f8cff",
            font=("Segoe UI Semibold", 10),
        )

    def _var(self, name: str, kind: type[tk.Variable] = tk.StringVar) -> tk.Variable:
        variable = kind()
        self.vars[name] = variable
        return variable

    def _build_ui(self) -> None:
        outer = ttk.Frame(self.root)
        outer.pack(fill="both", expand=True, padx=18, pady=14)
        self.hero = tk.Canvas(outer, height=112, bg="#060914", highlightthickness=0)
        self.hero.pack(fill="x", pady=(0, 5))
        self.hero.bind("<Configure>", self._draw_cosmic_header)
        status_row = ttk.Frame(outer)
        status_row.pack(fill="x", pady=(6, 0))
        self.status_label = ttk.Label(status_row, text="Đang kiểm tra Resolve…", style="Status.TLabel")
        self.status_label.pack(side="left")
        ttk.Button(status_row, text="Kết nối lại", command=self.refresh_connection).pack(side="right")
        self.bridge_button = ttk.Button(
            status_row,
            text="Website Bridge: Tắt",
            command=self.toggle_web_bridge,
        )
        self.bridge_button.pack(side="right", padx=(0, 8))

        canvas = tk.Canvas(outer, bg="#060914", highlightthickness=0)
        self.main_canvas = canvas
        scrollbar = ttk.Scrollbar(outer, orient="vertical", command=canvas.yview)
        self.content = ttk.Frame(canvas)
        self.content.bind("<Configure>", lambda _event: canvas.configure(scrollregion=canvas.bbox("all")))
        window = canvas.create_window((0, 0), window=self.content, anchor="nw")
        canvas.bind("<Configure>", lambda event: canvas.itemconfigure(window, width=event.width))
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        canvas.bind_all("<MouseWheel>", lambda event: canvas.yview_scroll(int(-event.delta / 120), "units"))

        self._build_sources()
        self._build_timeline_settings()
        self._build_render_settings()
        self._build_action_blueprint()
        self._build_enterprise_settings()
        self._build_production_settings()
        self._build_actions()
        self.root.after(700, lambda: self.main_canvas.yview_moveto(0))

    def _draw_cosmic_header(self, event: Any = None) -> None:
        width = max(800, int(getattr(event, "width", self.hero.winfo_width())))
        self.hero.delete("all")
        self.hero.create_rectangle(0, 0, width, 112, fill="#060914", outline="")
        self.hero.create_oval(width - 310, -155, width + 40, 195, fill="#101b46", outline="")
        self.hero.create_oval(width - 240, -105, width - 20, 115, fill="#171347", outline="")
        for index in range(46):
            x = (index * 137 + 23) % width
            y = (index * 47 + 13) % 104
            radius = 1 if index % 5 else 2
            color = "#39dcff" if index % 7 == 0 else "#7184aa"
            self.hero.create_oval(x, y, x + radius, y + radius, fill=color, outline="")
        self.hero.create_oval(10, 12, 82, 84, fill="#0a1021", outline="#7c5cff", width=2)
        self.hero.create_oval(17, 19, 75, 77, outline="#39dcff", width=1)
        self.hero.create_text(
            46, 48, text="H", fill="#ffffff", font=("Segoe UI Black", 34)
        )
        self.hero.create_text(
            102, 33, anchor="w", text="H COSMIC STUDIO",
            fill="#ffffff", font=("Segoe UI Semibold", 20)
        )
        self.hero.create_text(
            103, 62, anchor="w",
            text="BATCH PRODUCTION COMMAND CENTER  •  DAVINCI RESOLVE",
            fill="#39dcff", font=("Segoe UI Semibold", 9)
        )
        self.hero.create_text(
            103, 84, anchor="w",
            text="Ảnh  →  hiệu ứng  →  nhạc  →  render nhiều video tự động",
            fill="#8ea1c4", font=("Segoe UI", 9)
        )
        self.hero.create_line(102, 99, width - 20, 99, fill="#27365c")

    def _card(self, title: str) -> ttk.LabelFrame:
        card = ttk.LabelFrame(self.content, text=title, padding=12)
        card.pack(fill="x", pady=(0, 10))
        card.columnconfigure(1, weight=1)
        return card

    def _path_row(
        self,
        parent: ttk.LabelFrame,
        row: int,
        label: str,
        name: str,
        chooser: Callable[[], None],
    ) -> None:
        ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w", padx=(0, 10), pady=5)
        ttk.Entry(parent, textvariable=self._var(name)).grid(row=row, column=1, sticky="ew", pady=5)
        ttk.Button(parent, text="Chọn…", command=chooser).grid(row=row, column=2, padx=(8, 0), pady=5)

    def _build_sources(self) -> None:
        card = self._card("1. Nguồn media")
        self._path_row(card, 0, "Nguồn ảnh / thư mục gốc", "image_source", self._choose_images)
        self._path_row(card, 1, "Video overlay", "overlay_file", self._choose_overlay)
        self._path_row(card, 2, "Thư mục/file nhạc", "music_source", self._choose_music)
        self._path_row(card, 3, "Thư mục xuất", "output_dir", self._choose_output)
        self._path_row(card, 4, "Color Grade (.drx)", "drx_file", self._choose_drx)
        self._path_row(card, 5, "Fusion template (.comp)", "fusion_comp_file", self._choose_fusion)

    def _build_timeline_settings(self) -> None:
        card = self._card("2. Timeline và hiệu ứng")
        ttk.Label(card, text="Tên timeline/video").grid(row=0, column=0, sticky="w", padx=(0, 10), pady=5)
        ttk.Entry(card, textvariable=self._var("timeline_name")).grid(row=0, column=1, columnspan=3, sticky="ew", pady=5)

        ttk.Label(card, text="Khung hình").grid(row=1, column=0, sticky="w", padx=(0, 10), pady=5)
        self.resolution = ttk.Combobox(
            card,
            values=[
                "1920 × 1080 (ngang Full HD)",
                "1080 × 1920 (dọc 9:16)",
                "1080 × 1080 (vuông)",
                "3840 × 2160 (ngang 4K)",
                "2160 × 3840 (dọc 4K)",
                "Tùy chỉnh",
            ],
            state="readonly",
        )
        self.resolution.grid(row=1, column=1, sticky="ew", pady=5)
        self.resolution.bind("<<ComboboxSelected>>", self._resolution_changed)
        size = ttk.Frame(card, style="Card.TFrame")
        size.grid(row=1, column=2, columnspan=2, sticky="e", padx=(8, 0))
        ttk.Entry(size, width=7, textvariable=self._var("width")).pack(side="left")
        ttk.Label(size, text=" × ").pack(side="left")
        ttk.Entry(size, width=7, textvariable=self._var("height")).pack(side="left")

        ttk.Label(card, text="FPS").grid(row=2, column=0, sticky="w", pady=5)
        ttk.Combobox(
            card, textvariable=self._var("fps"), values=["23.976", "24", "25", "30", "50", "60"], width=12
        ).grid(row=2, column=1, sticky="w", pady=5)
        ttk.Label(card, text="Giây / ảnh").grid(row=2, column=2, sticky="e", padx=(20, 8), pady=5)
        ttk.Spinbox(card, from_=0.2, to=120, increment=0.1, textvariable=self._var("still_seconds"), width=10).grid(
            row=2, column=3, sticky="w", pady=5
        )

        ttk.Label(card, text="Cách lấp khung").grid(row=3, column=0, sticky="w", pady=5)
        ttk.Combobox(
            card,
            textvariable=self._var("scaling"),
            values=[
                "Fill (đầy khung)",
                "Fit (không cắt ảnh)",
                "Crop",
                "Stretch",
                "Dùng thiết lập project",
            ],
            state="readonly",
        ).grid(row=3, column=1, sticky="ew", pady=5)
        ttk.Label(card, text="Zoom tĩnh").grid(row=3, column=2, sticky="e", padx=(20, 8), pady=5)
        ttk.Spinbox(card, from_=0.1, to=10, increment=0.01, textvariable=self._var("zoom"), width=10).grid(
            row=3, column=3, sticky="w", pady=5
        )

        ttk.Label(card, text="Chuyển động").grid(row=4, column=0, sticky="w", pady=5)
        ttk.Combobox(
            card,
            textvariable=self._var("motion"),
            values=["Không", "Zoom in", "Zoom out", "Pan trái → phải", "Pan phải → trái"],
            state="readonly",
        ).grid(row=4, column=1, sticky="ew", pady=5)
        ttk.Label(card, text="Blend overlay").grid(row=4, column=2, sticky="e", padx=(20, 8), pady=5)
        ttk.Combobox(
            card,
            textvariable=self._var("overlay_blend"),
            values=["Screen", "Normal", "Add", "Overlay", "Soft Light", "Lighten", "Multiply", "Linear Dodge"],
            state="readonly",
            width=15,
        ).grid(row=4, column=3, sticky="w", pady=5)

        ttk.Label(card, text="Opacity overlay (%)").grid(row=5, column=0, sticky="w", pady=5)
        ttk.Spinbox(
            card, from_=0, to=100, increment=0.5, textvariable=self._var("overlay_opacity"), width=12
        ).grid(row=5, column=1, sticky="w", pady=5)
        ttk.Checkbutton(card, text="Lặp nhạc tới hết video", variable=self._var("loop_audio", tk.BooleanVar)).grid(
            row=5, column=2, columnspan=2, sticky="w", padx=(20, 0), pady=5
        )

    def _build_render_settings(self) -> None:
        card = self._card("3. Workflow và render")
        ttk.Label(card, text="Workflow").grid(row=0, column=0, sticky="w", padx=(0, 10), pady=5)
        ttk.Combobox(
            card,
            textvariable=self._var("workflow"),
            values=["Trực tiếp", "2 giai đoạn (giống video)"],
            state="readonly",
        ).grid(row=0, column=1, sticky="ew", pady=5)
        ttk.Label(card, text="Render preset").grid(row=0, column=2, sticky="e", padx=(20, 8), pady=5)
        self.preset_combo = ttk.Combobox(card, textvariable=self._var("render_preset"), values=[""], width=24)
        self.preset_combo.grid(row=0, column=3, sticky="ew", pady=5)

        ttk.Label(card, text="Format").grid(row=1, column=0, sticky="w", pady=5)
        ttk.Combobox(
            card, textvariable=self._var("render_format"), values=["mp4", "mov"], width=12
        ).grid(row=1, column=1, sticky="w", pady=5)
        ttk.Label(card, text="Codec").grid(row=1, column=2, sticky="e", padx=(20, 8), pady=5)
        ttk.Combobox(
            card, textvariable=self._var("render_codec"), values=["H264", "H265"], width=16
        ).grid(row=1, column=3, sticky="w", pady=5)

        ttk.Label(card, text="Bitrate (Kb/s)").grid(row=2, column=0, sticky="w", pady=5)
        ttk.Entry(card, textvariable=self._var("bitrate_kbps"), width=14).grid(row=2, column=1, sticky="w", pady=5)
        ttk.Checkbutton(
            card, text="Cho phép ghi đè file cùng tên", variable=self._var("replace_existing", tk.BooleanVar)
        ).grid(row=2, column=2, columnspan=2, sticky="w", padx=(20, 0), pady=5)
        ttk.Checkbutton(
            card,
            text="Xóa timeline trung gian sau khi hoàn tất",
            variable=self._var("cleanup_temp_timelines", tk.BooleanVar),
        ).grid(row=3, column=2, columnspan=2, sticky="w", padx=(20, 0), pady=5)

    def _build_action_blueprint(self) -> None:
        card = self._card("4. Human Action Blueprint")
        toolbar = ttk.Frame(card, style="Card.TFrame")
        toolbar.grid(row=0, column=0, columnspan=4, sticky="ew", pady=(0, 8))
        ttk.Checkbutton(
            toolbar,
            text="Ghi chi tiết từng clip/segment",
            variable=self._var("detailed_actions", tk.BooleanVar),
        ).pack(side="left")
        ttk.Label(toolbar, text="Delay quan sát (ms):").pack(side="left", padx=(18, 6))
        ttk.Combobox(
            toolbar,
            textvariable=self._var("action_delay_ms"),
            values=["0", "100", "250", "500", "1000"],
            width=7,
        ).pack(side="left")
        ttk.Button(toolbar, text="Nạp blueprint", command=self.populate_action_blueprint).pack(
            side="left", padx=(14, 6)
        )
        ttk.Button(toolbar, text="Xuất checklist JSON", command=self.export_action_blueprint).pack(
            side="left"
        )
        columns = ("no", "status", "page", "action", "detail")
        self.action_tree = ttk.Treeview(
            card,
            columns=columns,
            show="headings",
            height=13,
            style="Cosmic.Treeview",
        )
        headings = {
            "no": "#",
            "status": "Trạng thái",
            "page": "Trang",
            "action": "Hành động con",
            "detail": "Chi tiết / giá trị",
        }
        widths = {"no": 42, "status": 100, "page": 100, "action": 240, "detail": 480}
        for column in columns:
            self.action_tree.heading(column, text=headings[column])
            self.action_tree.column(column, width=widths[column], anchor="w")
        self.action_tree.grid(row=1, column=0, columnspan=4, sticky="nsew")
        tree_scroll = ttk.Scrollbar(card, orient="vertical", command=self.action_tree.yview)
        tree_scroll.grid(row=1, column=4, sticky="ns")
        self.action_tree.configure(yscrollcommand=tree_scroll.set)
        card.rowconfigure(1, weight=1)
        self.action_rows: list[str] = []

    def populate_action_blueprint(self) -> None:
        config = self._vars_to_config()
        for item in self.action_tree.get_children():
            self.action_tree.delete(item)
        self.action_rows.clear()
        for index, step in enumerate(build_action_blueprint(config), 1):
            if not step["enabled"]:
                continue
            row_id = self.action_tree.insert(
                "",
                "end",
                values=(
                    f"{index:02d}",
                    "○ Chờ",
                    step["page"],
                    step["action"],
                    step["detail"],
                ),
            )
            self.action_rows.append(row_id)

    def record_action_event(self, event: dict[str, Any]) -> None:
        status_map = {
            "running": "◌ Đang chạy",
            "done": "✓ Xong",
            "error": "✕ Lỗi",
            "pending": "○ Chờ",
        }
        status = status_map.get(event.get("status", "pending"), event.get("status", ""))
        self.action_tree.insert(
            "",
            "end",
            values=(
                len(self.action_tree.get_children()) + 1,
                status,
                event.get("page", "Resolve"),
                event.get("action", event.get("code", "")),
                f"{event.get('code', '')} · {event.get('detail', '')}",
            ),
        )
        children = self.action_tree.get_children()
        if children:
            self.action_tree.see(children[-1])
        # Keep the visual log bounded during overnight runs.
        if len(children) > 2000:
            self.action_tree.delete(children[0])

    def export_action_blueprint(self) -> None:
        config = self._vars_to_config()
        path = filedialog.asksaveasfilename(
            title="Lưu Human Action Blueprint",
            defaultextension=".json",
            filetypes=[("JSON", "*.json")],
            initialfile="human_action_blueprint.json",
        )
        if not path:
            return
        payload = {
            "config": config.to_dict(),
            "steps": build_action_blueprint(config),
        }
        Path(path).write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        self._log(f"Đã xuất checklist chi tiết: {path}")

    def _build_enterprise_settings(self) -> None:
        card = self._card("5. Enterprise Production Runtime")

        ttk.Label(card, text="Template timeline").grid(
            row=0, column=0, sticky="w", padx=(0, 10), pady=5
        )
        self.template_combo = ttk.Combobox(
            card,
            textvariable=self._var("template_timeline_name"),
            values=[""],
        )
        self.template_combo.grid(row=0, column=1, sticky="ew", pady=5)
        ttk.Label(card, text="Placeholder track").grid(
            row=0, column=2, sticky="e", padx=(20, 8), pady=5
        )
        ttk.Spinbox(
            card,
            from_=1,
            to=32,
            textvariable=self._var("template_track_index"),
            width=8,
        ).grid(row=0, column=3, sticky="w", pady=5)

        ttk.Checkbutton(
            card,
            text="Dùng nhiều profile",
            variable=self._var("use_profiles", tk.BooleanVar),
        ).grid(row=1, column=0, sticky="w", pady=5)
        ttk.Entry(card, textvariable=self._var("profiles_file")).grid(
            row=1, column=1, sticky="ew", pady=5
        )
        profile_buttons = ttk.Frame(card, style="Card.TFrame")
        profile_buttons.grid(row=1, column=2, columnspan=2, sticky="e")
        ttk.Button(
            profile_buttons, text="Chọn profile…", command=self._choose_profiles
        ).pack(side="left", padx=(0, 6))
        ttk.Button(
            profile_buttons, text="Tạo profile mẫu", command=self._create_sample_profiles
        ).pack(side="left")

        ttk.Checkbutton(
            card,
            text="Checkpoint/Resume",
            variable=self._var("resume_enabled", tk.BooleanVar),
        ).grid(row=2, column=0, sticky="w", pady=5)
        retry_row = ttk.Frame(card, style="Card.TFrame")
        retry_row.grid(row=2, column=1, sticky="w")
        ttk.Label(retry_row, text="Retry:").pack(side="left")
        ttk.Spinbox(
            retry_row, from_=0, to=10,
            textvariable=self._var("max_retries"), width=5
        ).pack(side="left", padx=(5, 12))
        ttk.Label(retry_row, text="Backoff (s):").pack(side="left")
        ttk.Spinbox(
            retry_row, from_=0, to=300,
            textvariable=self._var("retry_backoff_seconds"), width=6
        ).pack(side="left", padx=(5, 0))
        ttk.Label(card, text="Watchdog (phút)").grid(
            row=2, column=2, sticky="e", padx=(20, 8), pady=5
        )
        ttk.Spinbox(
            card, from_=0, to=240,
            textvariable=self._var("stall_timeout_minutes"), width=8
        ).grid(row=2, column=3, sticky="w", pady=5)

        ttk.Checkbutton(
            card,
            text="Hẹn giờ bắt đầu",
            variable=self._var("schedule_enabled", tk.BooleanVar),
        ).grid(row=3, column=0, sticky="w", pady=5)
        ttk.Entry(card, textvariable=self._var("schedule_start")).grid(
            row=3, column=1, sticky="ew", pady=5
        )
        ttk.Label(card, text="YYYY-MM-DD HH:MM", foreground="#8ea1c4").grid(
            row=3, column=2, sticky="w", padx=(8, 0), pady=5
        )
        batch_row = ttk.Frame(card, style="Card.TFrame")
        batch_row.grid(row=3, column=3, sticky="e")
        ttk.Label(batch_row, text="Batch:").pack(side="left")
        ttk.Spinbox(
            batch_row, from_=1, to=500,
            textvariable=self._var("batch_size"), width=6
        ).pack(side="left", padx=(5, 10))
        ttk.Label(batch_row, text="Nghỉ (s):").pack(side="left")
        ttk.Spinbox(
            batch_row, from_=0, to=86400,
            textvariable=self._var("pause_between_batches_seconds"), width=7
        ).pack(side="left", padx=(5, 0))

        ttk.Checkbutton(
            card,
            text="Hậu kiểm sâu: decode frame cuối",
            variable=self._var("deep_verify", tk.BooleanVar),
        ).grid(row=4, column=0, sticky="w", pady=5)
        verify_row = ttk.Frame(card, style="Card.TFrame")
        verify_row.grid(row=4, column=1, sticky="w")
        ttk.Label(verify_row, text="Sai số duration (s):").pack(side="left")
        ttk.Spinbox(
            verify_row, from_=0.1, to=30, increment=0.1,
            textvariable=self._var("duration_tolerance_seconds"), width=6
        ).pack(side="left", padx=(5, 0))
        ttk.Label(card, text="File trung gian").grid(
            row=4, column=2, sticky="e", padx=(20, 8), pady=5
        )
        ttk.Combobox(
            card,
            textvariable=self._var("intermediate_policy"),
            values=["keep", "delete_verified", "zip_then_delete"],
            state="readonly",
            width=18,
        ).grid(row=4, column=3, sticky="w", pady=5)

        ttk.Label(card, text="Thông báo").grid(
            row=5, column=0, sticky="w", pady=5
        )
        ttk.Combobox(
            card,
            textvariable=self._var("notification_channel"),
            values=["none", "telegram", "slack", "email"],
            state="readonly",
            width=16,
        ).grid(row=5, column=1, sticky="w", pady=5)
        ttk.Checkbutton(
            card, text="Báo thành công",
            variable=self._var("notify_success", tk.BooleanVar)
        ).grid(row=5, column=2, sticky="e", padx=(20, 8), pady=5)
        ttk.Checkbutton(
            card, text="Báo lỗi",
            variable=self._var("notify_failure", tk.BooleanVar)
        ).grid(row=5, column=3, sticky="w", pady=5)

        safety = ttk.Frame(card, style="Card.TFrame")
        safety.grid(row=6, column=0, columnspan=4, sticky="ew", pady=(4, 8))
        ttk.Label(safety, text="Tự dừng khi GPU ≥").pack(side="left")
        ttk.Spinbox(
            safety, from_=50, to=110,
            textvariable=self._var("gpu_temperature_limit_c"), width=6
        ).pack(side="left", padx=(5, 4))
        ttk.Label(safety, text="°C hoặc ổ đĩa còn dưới").pack(side="left")
        ttk.Spinbox(
            safety, from_=1, to=1000, increment=1,
            textvariable=self._var("minimum_free_disk_gb"), width=7
        ).pack(side="left", padx=(5, 4))
        ttk.Label(safety, text="GB").pack(side="left")
        ttk.Checkbutton(
            safety,
            text="Chuyển output đạt chuẩn vào _verified",
            variable=self._var("move_verified_outputs", tk.BooleanVar),
        ).pack(side="right")

        dashboard = tk.Frame(
            card,
            bg="#080d1d",
            highlightbackground="#27365c",
            highlightthickness=1,
        )
        dashboard.grid(row=7, column=0, columnspan=4, sticky="ew", pady=(5, 0))
        self.dashboard_vars: dict[str, tk.StringVar] = {}
        dashboard_items = [
            ("current", "JOB HIỆN TẠI", "—"),
            ("progress", "HOÀN TẤT / LỖI", "0 / 0"),
            ("eta", "ETA", "—"),
            ("speed", "TỐC ĐỘ", "0 job/h"),
            ("gpu", "GPU", "—"),
            ("disk", "Ổ ĐĨA", "—"),
        ]
        for index, (key, label, initial) in enumerate(dashboard_items):
            dashboard.columnconfigure(index, weight=1)
            cell = tk.Frame(dashboard, bg="#080d1d")
            cell.grid(row=0, column=index, sticky="ew", padx=8, pady=7)
            variable = tk.StringVar(value=initial)
            self.dashboard_vars[key] = variable
            tk.Label(
                cell, textvariable=variable, bg="#080d1d", fg="#39dcff",
                font=("Segoe UI Semibold", 9),
            ).pack(anchor="w")
            tk.Label(
                cell, text=label, bg="#080d1d", fg="#6f82a7",
                font=("Segoe UI", 7),
            ).pack(anchor="w")

    def _choose_profiles(self) -> None:
        path = filedialog.askopenfilename(
            title="Chọn production profiles",
            filetypes=[("JSON", "*.json"), ("Tất cả", "*.*")],
        )
        if path:
            self.vars["profiles_file"].set(path)
            self.vars["use_profiles"].set(True)

    def _create_sample_profiles(self) -> None:
        path = filedialog.asksaveasfilename(
            title="Tạo production profiles mẫu",
            defaultextension=".json",
            filetypes=[("JSON", "*.json")],
            initialfile="production_profiles.json",
        )
        if not path:
            return
        profiles = [
            ProductionProfile(
                name="TikTok",
                width=1080,
                height=1920,
                fps=30,
                render_format="mp4",
                render_codec="H264",
                bitrate_kbps=18000,
                suffix="TikTok",
                priority=10,
            ),
            ProductionProfile(
                name="YouTube",
                width=1920,
                height=1080,
                fps=30,
                render_format="mp4",
                render_codec="H265",
                bitrate_kbps=30000,
                suffix="YouTube",
                priority=20,
            ),
        ]
        save_profiles(path, profiles)
        self.vars["profiles_file"].set(path)
        self.vars["use_profiles"].set(True)
        self._log(f"Đã tạo profile mẫu: {path}")

    def _build_production_settings(self) -> None:
        card = self._card("6. Sản xuất hàng loạt dài hạn")
        ttk.Checkbutton(
            card,
            text="Mỗi thư mục con trong nguồn ảnh = một video",
            variable=self._var("multi_folder_mode", tk.BooleanVar),
            command=self.update_estimate,
        ).grid(row=0, column=0, columnspan=2, sticky="w", pady=4)
        ttk.Checkbutton(
            card,
            text="Bỏ qua video đã tồn tại trong thư mục xuất",
            variable=self._var("skip_existing", tk.BooleanVar),
        ).grid(row=0, column=2, columnspan=2, sticky="w", padx=(20, 0), pady=4)
        ttk.Checkbutton(
            card,
            text="Giữ máy không tự ngủ trong lúc sản xuất",
            variable=self._var("prevent_sleep", tk.BooleanVar),
        ).grid(row=1, column=0, columnspan=2, sticky="w", pady=4)
        ttk.Button(
            card, text="Cập nhật ước tính", command=self.update_estimate
        ).grid(row=1, column=3, sticky="e", pady=4)

        metrics = ttk.Frame(card, style="Card.TFrame")
        metrics.grid(row=2, column=0, columnspan=4, sticky="ew", pady=(10, 2))
        for column in range(4):
            metrics.columnconfigure(column, weight=1)
        self.metric_vars: dict[str, tk.StringVar] = {}
        metric_defs = [
            ("videos", "VIDEO", "0"),
            ("images", "ẢNH", "0"),
            ("duration", "THỜI LƯỢNG", "00:00:00"),
            ("storage", "DUNG LƯỢNG DỰ KIẾN", "0 GB"),
        ]
        for column, (key, label, initial) in enumerate(metric_defs):
            panel = tk.Frame(
                metrics,
                bg="#0a1021",
                highlightbackground="#27365c",
                highlightthickness=1,
            )
            panel.grid(row=0, column=column, sticky="ew", padx=(0 if column == 0 else 5, 0))
            value_var = tk.StringVar(value=initial)
            self.metric_vars[key] = value_var
            ttk.Label(panel, textvariable=value_var, style="Metric.TLabel").pack(
                anchor="w", padx=10, pady=(8, 0)
            )
            ttk.Label(panel, text=label, style="MetricSub.TLabel").pack(
                anchor="w", padx=10, pady=(0, 8)
            )
        self.disk_label = ttk.Label(
            card,
            text="Chọn nguồn ảnh và thư mục xuất để tính tải sản xuất.",
        )
        self.disk_label.grid(row=3, column=0, columnspan=4, sticky="w", pady=(7, 0))

    def _build_actions(self) -> None:
        card = self._card("7. Mission control")
        row_one = ttk.Frame(card, style="Card.TFrame")
        row_one.grid(row=0, column=0, columnspan=4, sticky="ew")
        row_two = ttk.Frame(card, style="Card.TFrame")
        row_two.grid(row=1, column=0, columnspan=4, sticky="ew")
        buttons = [
            ttk.Button(row_one, text="PRECHECK", command=self.start_preflight),
            ttk.Button(row_one, text="Quét & xem kế hoạch", command=self.preview_plan),
            ttk.Button(row_one, text="Chỉ tạo timeline", command=lambda: self.start_action("build")),
            ttk.Button(row_one, text="Tạo + đưa vào Queue", command=lambda: self.start_action("queue")),
            ttk.Button(
                row_two, text="Làm toàn bộ + render",
                style="Primary.TButton", command=lambda: self.start_action("render")
            ),
            ttk.Button(row_two, text="Tiếp tục phiên", command=self.resume_run),
        ]
        for button in buttons[:4]:
            button.pack(side="left", padx=(0, 8), pady=(0, 10))
        for button in buttons[4:]:
            button.pack(side="left", padx=(0, 8), pady=(0, 10))
        self.action_buttons.extend(buttons)
        self.cancel_button = ttk.Button(
            row_two,
            text="Hủy phiên",
            style="Danger.TButton",
            state="disabled",
            command=self.cancel_run,
        )
        self.cancel_button.pack(side="right", pady=(0, 10))
        self.progressbar = ttk.Progressbar(card, mode="determinate", maximum=100)
        self.progressbar.grid(row=2, column=0, columnspan=4, sticky="ew", pady=(0, 8))
        self.progress_text = ttk.Label(card, text="Sẵn sàng")
        self.progress_text.grid(row=3, column=0, columnspan=4, sticky="w")
        self.log_box = tk.Text(
            card,
            height=10,
            bg="#050814",
            fg="#c9d9f5",
            insertbackground="#ffffff",
            selectbackground="#493b91",
            relief="flat",
            wrap="word",
            font=("Consolas", 9),
        )
        self.log_box.grid(row=4, column=0, columnspan=4, sticky="nsew", pady=(8, 0))
        card.rowconfigure(4, weight=1)

    def _choose_images(self) -> None:
        path = filedialog.askdirectory(title="Chọn thư mục ảnh")
        if path:
            self.vars["image_source"].set(path)

    def _choose_overlay(self) -> None:
        path = filedialog.askopenfilename(
            title="Chọn video overlay",
            filetypes=[("Video", "*.mp4 *.mov *.mxf *.avi *.mkv *.webm"), ("Tất cả", "*.*")],
        )
        if path:
            self.vars["overlay_file"].set(path)

    def _choose_music(self) -> None:
        path = filedialog.askdirectory(title="Chọn thư mục nhạc")
        if not path:
            file_path = filedialog.askopenfilename(
                title="Hoặc chọn một file nhạc",
                filetypes=[("Audio", "*.mp3 *.wav *.flac *.m4a *.aac *.aif *.aiff *.ogg")],
            )
            path = file_path
        if path:
            self.vars["music_source"].set(path)

    def _choose_output(self) -> None:
        path = filedialog.askdirectory(title="Chọn thư mục xuất")
        if path:
            self.vars["output_dir"].set(path)

    def _choose_drx(self) -> None:
        path = filedialog.askopenfilename(
            title="Chọn Color Grade DRX",
            filetypes=[("DaVinci Grade", "*.drx"), ("Tất cả", "*.*")],
        )
        if path:
            self.vars["drx_file"].set(path)

    def _choose_fusion(self) -> None:
        path = filedialog.askopenfilename(
            title="Chọn Fusion composition",
            filetypes=[("Fusion composition", "*.comp *.setting"), ("Tất cả", "*.*")],
        )
        if path:
            self.vars["fusion_comp_file"].set(path)

    def _resolution_changed(self, _event: Any = None) -> None:
        mapping = {
            "1920 × 1080 (ngang Full HD)": (1920, 1080),
            "1080 × 1920 (dọc 9:16)": (1080, 1920),
            "1080 × 1080 (vuông)": (1080, 1080),
            "3840 × 2160 (ngang 4K)": (3840, 2160),
            "2160 × 3840 (dọc 4K)": (2160, 3840),
        }
        if self.resolution.get() in mapping:
            width, height = mapping[self.resolution.get()]
            self.vars["width"].set(str(width))
            self.vars["height"].set(str(height))

    def _config_to_vars(self) -> None:
        for name, variable in self.vars.items():
            if hasattr(self.config, name):
                variable.set(getattr(self.config, name))
        dimensions = (self.config.width, self.config.height)
        labels = {
            (1920, 1080): "1920 × 1080 (ngang Full HD)",
            (1080, 1920): "1080 × 1920 (dọc 9:16)",
            (1080, 1080): "1080 × 1080 (vuông)",
            (3840, 2160): "3840 × 2160 (ngang 4K)",
            (2160, 3840): "2160 × 3840 (dọc 4K)",
        }
        self.resolution.set(labels.get(dimensions, "Tùy chỉnh"))

    def _vars_to_config(self) -> BatchConfig:
        def as_float(name: str, fallback: float) -> float:
            try:
                return float(str(self.vars[name].get()).replace(",", "."))
            except ValueError:
                return fallback

        def as_int(name: str, fallback: int) -> int:
            try:
                return int(float(str(self.vars[name].get()).replace(",", ".")))
            except ValueError:
                return fallback

        config = BatchConfig(
            image_source=str(self.vars["image_source"].get()),
            overlay_file=str(self.vars["overlay_file"].get()),
            music_source=str(self.vars["music_source"].get()),
            output_dir=str(self.vars["output_dir"].get()),
            timeline_name=str(self.vars["timeline_name"].get()),
            width=as_int("width", 1920),
            height=as_int("height", 1080),
            fps=as_float("fps", 24),
            still_seconds=as_float("still_seconds", 5),
            scaling=str(self.vars["scaling"].get()),
            zoom=as_float("zoom", 1),
            motion=str(self.vars["motion"].get()),
            overlay_blend=str(self.vars["overlay_blend"].get()),
            overlay_opacity=as_float("overlay_opacity", 85.5),
            workflow=str(self.vars["workflow"].get()),
            render_preset=str(self.vars["render_preset"].get()),
            render_format=str(self.vars["render_format"].get()),
            render_codec=str(self.vars["render_codec"].get()),
            bitrate_kbps=as_int("bitrate_kbps", 25000),
            replace_existing=bool(self.vars["replace_existing"].get()),
            loop_audio=bool(self.vars["loop_audio"].get()),
            cleanup_temp_timelines=bool(self.vars["cleanup_temp_timelines"].get()),
            multi_folder_mode=bool(self.vars["multi_folder_mode"].get()),
            skip_existing=bool(self.vars["skip_existing"].get()),
            prevent_sleep=bool(self.vars["prevent_sleep"].get()),
            detailed_actions=bool(self.vars["detailed_actions"].get()),
            action_delay_ms=as_int("action_delay_ms", 0),
            drx_file=str(self.vars["drx_file"].get()),
            fusion_comp_file=str(self.vars["fusion_comp_file"].get()),
            resume_enabled=bool(self.vars["resume_enabled"].get()),
            deep_verify=bool(self.vars["deep_verify"].get()),
            duration_tolerance_seconds=as_float("duration_tolerance_seconds", 1.0),
            max_retries=as_int("max_retries", 2),
            retry_backoff_seconds=as_float("retry_backoff_seconds", 2.0),
            template_timeline_name=str(self.vars["template_timeline_name"].get()),
            template_track_index=as_int("template_track_index", 1),
            use_profiles=bool(self.vars["use_profiles"].get()),
            profiles_file=str(self.vars["profiles_file"].get()),
            schedule_enabled=bool(self.vars["schedule_enabled"].get()),
            schedule_start=str(self.vars["schedule_start"].get()),
            batch_size=as_int("batch_size", 25),
            pause_between_batches_seconds=as_int(
                "pause_between_batches_seconds", 0
            ),
            stall_timeout_minutes=as_int("stall_timeout_minutes", 30),
            notification_channel=str(self.vars["notification_channel"].get()),
            notify_success=bool(self.vars["notify_success"].get()),
            notify_failure=bool(self.vars["notify_failure"].get()),
            intermediate_policy=str(self.vars["intermediate_policy"].get()),
            move_verified_outputs=bool(self.vars["move_verified_outputs"].get()),
            gpu_temperature_limit_c=as_int("gpu_temperature_limit_c", 88),
            minimum_free_disk_gb=as_float("minimum_free_disk_gb", 5.0),
        )
        self.config = config
        save_config(CONFIG_FILE, config)
        return config

    def refresh_connection(self) -> None:
        self.resolve = connect_resolve(self.resolve)
        if not self.resolve:
            self.status_label.configure(
                text="● Chưa kết nối — chạy từ Workspace > Scripts hoặc bật External scripting = Local",
                foreground="#ffb84d",
            )
            self._log("Chưa kết nối được Resolve. UI vẫn dùng được để chuẩn bị tùy chọn.")
            return
        try:
            engine = ResolveBatchEngine(self.resolve)
            snapshot = engine.snapshot()
            self.status_label.configure(
                text=f"● Đã kết nối Resolve {snapshot['version']} · Project: {snapshot['project']}",
                foreground="#53e6a8",
            )
            self.preset_combo.configure(values=[""] + sorted(snapshot["presets"]))
            self.template_combo.configure(values=[""] + sorted(snapshot.get("timelines", [])))
            if not self.vars["fps"].get():
                self.vars["fps"].set(str(snapshot["fps"]))
            self._log(
                f"Kết nối thành công: {snapshot['project']} / "
                f"{snapshot['timeline'] or 'chưa có timeline'}."
            )
        except Exception as exc:
            self.status_label.configure(text=f"● Lỗi kết nối: {exc}", foreground="#ff5c9f")

    def preview_plan(self) -> None:
        config = self._vars_to_config()
        errors = config.validate(require_output=False)
        if errors:
            messagebox.showerror("Thiếu thông tin", "\n".join(errors))
            return
        estimate = self.update_estimate()
        if config.multi_folder_mode:
            groups = estimate.groups if estimate else []
            self._log("PHIÊN SẢN XUẤT: " + (estimate.summary(config.fps) if estimate else ""))
            self._log("Thứ tự video: " + ", ".join(path.name for path in groups[:12]))
            if len(groups) > 12:
                self._log(f"… và {len(groups) - 12} video còn lại.")
        else:
            plan = BatchPlan.from_config(config)
            self._log("KẾ HOẠCH: " + plan.summary(config.fps))
            self._log("Thứ tự ảnh: " + ", ".join(path.name for path in plan.images[:12]))
            if len(plan.images) > 12:
                self._log(f"… và {len(plan.images) - 12} ảnh còn lại.")
        if estimate:
            self.progress_text.configure(text=estimate.summary(config.fps))

    def update_estimate(self) -> ProductionEstimate | None:
        try:
            config = self._vars_to_config()
            estimate = ProductionEstimate.from_config(config)
            profile_count = (
                len(load_profiles(config.profiles_file))
                if config.use_profiles and config.profiles_file
                else 1
            )
            profile_count = max(1, profile_count)
            self.metric_vars["videos"].set(str(estimate.video_count * profile_count))
            self.metric_vars["images"].set(str(estimate.image_count * profile_count))
            self.metric_vars["duration"].set(
                format_duration(estimate.total_frames * profile_count, config.fps)
            )
            self.metric_vars["storage"].set(
                ProductionEstimate.format_bytes(estimate.estimated_bytes * profile_count)
            )
            disk_ok = (
                estimate.free_bytes == 0
                or estimate.free_bytes > estimate.estimated_bytes * profile_count * 1.15
            )
            disk_state = "Đủ dung lượng dự kiến" if disk_ok else "CẢNH BÁO: có thể thiếu dung lượng"
            self.disk_label.configure(
                text=(
                    f"{disk_state} · Trống {ProductionEstimate.format_bytes(estimate.free_bytes)} · "
                    f"Workflow: {config.workflow}"
                ),
                foreground="#53e6a8" if disk_ok else "#ff5c9f",
            )
            return estimate
        except Exception as exc:
            self._log(f"Không tính được tải sản xuất: {exc}")
            return None

    def resume_run(self) -> None:
        self.vars["resume_enabled"].set(True)
        self._log("RESUME: sẽ đọc manifest và bỏ qua các job đã được xác minh.")
        self.start_action("render")

    def toggle_web_bridge(self) -> None:
        if self.web_bridge and self.web_bridge.running:
            if self.web_bridge.busy and not messagebox.askyesno(
                "Dừng Website Bridge",
                "Website đang chạy một tác vụ. Dừng bridge sẽ yêu cầu hủy an toàn. Tiếp tục?",
            ):
                return
            self.web_bridge.stop()
            self.web_bridge = None
            self.bridge_button.configure(text="Website Bridge: Tắt")
            self._log("Website Bridge đã dừng.")
            return
        self.resolve = connect_resolve(self.resolve)
        if not self.resolve:
            messagebox.showerror(
                "Chưa kết nối Resolve",
                "Hãy mở Resolve trước khi bật kết nối website.",
            )
            return
        try:
            self.web_bridge = ResolveWebBridge(resolve=self.resolve)
            host, port, key = self.web_bridge.start()
        except Exception as exc:
            self.web_bridge = None
            messagebox.showerror("Website Bridge", str(exc))
            return
        self.bridge_button.configure(text="Website Bridge: Đang bật")
        self._log(
            f"WEBSITE BRIDGE: http://{host}:{port} · mã ghép nối {key}"
        )
        messagebox.showinfo(
            "Kết nối nhhoang13all.xyz",
            (
                f"Bridge đang chạy tại http://{host}:{port}\n\n"
                f"Mã ghép nối: {key}\n\n"
                "Mở mục Davinci Resolve trên website và nhập mã này. "
                "Không chia sẻ mã khi bridge đang bật."
            ),
        )

    def _on_close(self) -> None:
        if self.web_bridge:
            self.web_bridge.stop()
            self.web_bridge = None
        self.root.destroy()

    def start_preflight(self) -> None:
        if self.worker and self.worker.is_alive():
            messagebox.showinfo("Đang chạy", "Tool đang thực hiện một tác vụ.")
            return
        config = self._vars_to_config()
        errors = config.validate(require_output=True)
        if errors:
            messagebox.showerror("Thiếu thông tin", "\n".join(errors))
            return
        self.resolve = connect_resolve(self.resolve)
        if not self.resolve:
            messagebox.showerror(
                "Chưa kết nối Resolve",
                "PRECHECK cần Resolve để đối chiếu FPS, timeline và codec.",
            )
            return
        self._set_busy(True)
        self.cancel_event.clear()
        for row_id in self.action_tree.get_children():
            self.action_tree.delete(row_id)
        self.progressbar["value"] = 0
        self.progress_text.configure(text="PRECHECK đang chạy…")

        def work() -> None:
            try:
                engine = ResolveBatchEngine(self.resolve)
                coordinator = ProductionCoordinator(
                    engine,
                    should_cancel=self.cancel_event.is_set,
                )
                jobs = coordinator.plan_jobs(config)
                validator = PreflightValidator()
                blocked = 0
                warnings = 0
                reports: list[dict[str, Any]] = []
                for index, job in enumerate(jobs, 1):
                    if self.cancel_event.is_set():
                        raise RuntimeError("Đã hủy PRECHECK.")
                    snapshot = engine.snapshot()
                    codecs = engine.project.GetRenderCodecs(job.config.render_format) or {}
                    snapshot["codecs"] = list(codecs.values())
                    images = discover_files(str(job.source), IMAGE_EXTENSIONS)
                    audio = discover_files(job.config.music_source, AUDIO_EXTENSIONS)
                    overlay = Path(job.config.overlay_file) if job.config.overlay_file else None
                    report = validator.validate(
                        job.config, images, audio, overlay, snapshot
                    )
                    reports.append({
                        "job": job.id,
                        "profile": job.profile.name,
                        "report": report.to_dict(),
                    })
                    blocked += int(report.blocked)
                    warnings += report.warnings
                    for check in report.checks:
                        self.events.put(("action", {
                            "code": check.code,
                            "status": "error" if check.level == "BLOCKED" else (
                                "running" if check.level == "WARNING" else "done"
                            ),
                            "page": "Preflight",
                            "action": check.title,
                            "detail": f"{job.id} · {check.level} · {check.detail}",
                        }))
                    self.events.put((
                        "progress",
                        (index / max(1, len(jobs)), f"PRECHECK {index}/{len(jobs)}"),
                    ))
                report_path = (
                    Path(config.output_dir)
                    / f"preflight_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
                )
                report_path.write_text(
                    json.dumps({"jobs": reports}, ensure_ascii=False, indent=2),
                    encoding="utf-8",
                )
                self.events.put(("preflight_done", {
                    "jobs": len(jobs),
                    "blocked": blocked,
                    "warnings": warnings,
                    "report_path": str(report_path),
                }))
            except Exception as exc:
                self.events.put(("error", (str(exc), traceback.format_exc())))

        self.worker = threading.Thread(target=work, daemon=True)
        self.worker.start()

    def start_action(self, action: str) -> None:
        if self.worker and self.worker.is_alive():
            messagebox.showinfo("Đang chạy", "Tool đang thực hiện một tác vụ.")
            return
        if self.web_bridge and self.web_bridge.busy:
            messagebox.showinfo(
                "Website đang điều khiển",
                "Website Bridge đang chạy một tác vụ. Hãy chờ hoàn tất hoặc hủy từ website.",
            )
            return
        config = self._vars_to_config()
        # Enterprise runtime always needs output_dir for manifests and reports,
        # even when the requested action only builds timelines.
        require_output = True
        errors = config.validate(require_output=require_output)
        if errors:
            messagebox.showerror("Thiếu thông tin", "\n".join(errors))
            return
        self.resolve = connect_resolve(self.resolve)
        if not self.resolve:
            messagebox.showerror(
                "Chưa kết nối Resolve",
                "Hãy mở DaVinci Resolve rồi chạy tool từ Workspace > Scripts > Utility.\n\n"
                "Nếu chạy file run_tool.py độc lập: vào Preferences > System > General, "
                "đặt External scripting using = Local rồi khởi động lại Resolve.",
            )
            return
        self._set_busy(True)
        self.cancel_event.clear()
        for row_id in self.action_tree.get_children():
            self.action_tree.delete(row_id)
        self.progressbar["value"] = 0
        self._log(f"BẮT ĐẦU: {action} · workflow {config.workflow}")

        def work() -> None:
            sleep_guard_active = False
            try:
                if config.prevent_sleep and hasattr(ctypes, "windll"):
                    ctypes.windll.kernel32.SetThreadExecutionState(0x80000001)
                    sleep_guard_active = True
                    self.events.put(("log", "Đã bật chế độ giữ máy thức trong phiên sản xuất."))
                engine = ResolveBatchEngine(
                    self.resolve,
                    log=lambda text: self.events.put(("log", text)),
                    progress=lambda value, text: self.events.put(("progress", (value, text))),
                    should_cancel=self.cancel_event.is_set,
                    action=lambda event: self.events.put(("action", event))
                    if config.detailed_actions
                    else None,
                )
                coordinator = ProductionCoordinator(
                    engine,
                    on_event=lambda event: self.events.put(("action", event)),
                    on_dashboard=lambda snapshot: self.events.put(("dashboard", snapshot)),
                    should_cancel=self.cancel_event.is_set,
                )
                result = coordinator.run(config, action)
                self.events.put(("done", result))
            except Exception as exc:
                self.events.put(("error", (str(exc), traceback.format_exc())))
            finally:
                if sleep_guard_active:
                    ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)
                    self.events.put(("log", "Đã trả chế độ nguồn điện về bình thường."))

        self.worker = threading.Thread(target=work, daemon=True)
        self.worker.start()

    def _set_busy(self, busy: bool) -> None:
        for button in self.action_buttons:
            button.configure(state="disabled" if busy else "normal")
        self.cancel_button.configure(state="normal" if busy else "disabled")

    def cancel_run(self) -> None:
        if self.worker and self.worker.is_alive():
            self.cancel_event.set()
            self.cancel_button.configure(state="disabled")
            self.progress_text.configure(text="Đang yêu cầu dừng an toàn…")
            self._log("ĐÃ YÊU CẦU HỦY: tool sẽ dừng ở điểm an toàn gần nhất.")

    def _log(self, text: str) -> None:
        self.log_box.insert("end", text.rstrip() + "\n")
        self.log_box.see("end")

    @staticmethod
    def _format_span(seconds: float) -> str:
        if not seconds or seconds < 0:
            return "—"
        value = int(seconds)
        hours, remainder = divmod(value, 3600)
        minutes, secs = divmod(remainder, 60)
        return f"{hours:02d}:{minutes:02d}:{secs:02d}"

    def _update_dashboard(self, snapshot: dict[str, Any]) -> None:
        self.dashboard_vars["current"].set(snapshot.get("current_job") or "—")
        self.dashboard_vars["progress"].set(
            f"{snapshot.get('completed_jobs', 0)} / {snapshot.get('failed_jobs', 0)}"
        )
        self.dashboard_vars["eta"].set(
            self._format_span(float(snapshot.get("eta_seconds", 0) or 0))
        )
        self.dashboard_vars["speed"].set(
            f"{float(snapshot.get('jobs_per_hour', 0) or 0):.1f} job/h"
        )
        temperature = float(snapshot.get("gpu_temperature_c", 0) or 0)
        utilization = float(snapshot.get("gpu_utilization", 0) or 0)
        memory = float(snapshot.get("gpu_memory_mb", 0) or 0)
        self.dashboard_vars["gpu"].set(
            f"{utilization:.0f}% · {temperature:.0f}°C · {memory:.0f} MB"
            if temperature
            else "Không đọc được"
        )
        disk = int(snapshot.get("disk_free_bytes", 0) or 0)
        self.dashboard_vars["disk"].set(
            f"{disk / 1024**3:.1f} GB trống" if disk else "—"
        )

    def _drain_events(self) -> None:
        try:
            while True:
                kind, payload = self.events.get_nowait()
                if kind == "log":
                    self._log(str(payload))
                elif kind == "action":
                    self.record_action_event(payload)
                elif kind == "progress":
                    value, text = payload
                    self.progressbar["value"] = max(0, min(100, float(value) * 100))
                    self.progress_text.configure(text=str(text))
                elif kind == "dashboard":
                    self._update_dashboard(payload)
                elif kind == "preflight_done":
                    self._set_busy(False)
                    blocked = payload.get("blocked", 0)
                    warnings = payload.get("warnings", 0)
                    status = "BLOCKED" if blocked else (
                        "WARNING" if warnings else "PASS"
                    )
                    self.progressbar["value"] = 100
                    self.progress_text.configure(
                        text=(
                            f"PRECHECK → {status} · {payload.get('jobs', 0)} job · "
                            f"{blocked} blocked · {warnings} warning"
                        )
                    )
                    self._log(
                        f"PRECHECK → {status}. Báo cáo: {payload.get('report_path')}"
                    )
                    messagebox.showinfo(
                        "Preflight Validator",
                        (
                            f"Trạng thái: {status}\n"
                            f"Job: {payload.get('jobs', 0)}\n"
                            f"Blocked: {blocked}\n"
                            f"Warning: {warnings}\n"
                            f"Báo cáo: {payload.get('report_path')}"
                        ),
                    )
                elif kind == "done":
                    self._set_busy(False)
                    self.progressbar["value"] = 100
                    self.progress_text.configure(text="Hoàn tất")
                    result_count = len(payload.get("results", [])) or 1
                    failure_count = len(payload.get("failures", []))
                    report_path = payload.get("report_path", "")
                    self._log(
                        f"HOÀN TẤT: {result_count} video · "
                        f"{failure_count} lỗi · timeline {payload.get('timeline')}"
                    )
                    if report_path:
                        self._log(f"Báo cáo: {report_path}")
                    messagebox.showinfo(
                        "Hoàn tất",
                        f"Video xử lý: {result_count}\n"
                        f"Lỗi: {failure_count}\n"
                        f"Render jobs: {len(payload.get('jobs', []))}\n"
                        f"Báo cáo: {report_path or 'không tạo'}",
                    )
                elif kind == "error":
                    self._set_busy(False)
                    message, details = payload
                    self.progress_text.configure(text="Có lỗi")
                    self._log("LỖI: " + message)
                    self._log(details)
                    messagebox.showerror("DaVinci Batch Studio", message)
        except queue.Empty:
            pass
        self.root.after(100, self._drain_events)


def main() -> None:
    root = tk.Tk()
    injected = globals().get("resolve")
    BatchStudioApp(root, injected_resolve=injected)
    root.mainloop()


if __name__ == "__main__":
    main()
