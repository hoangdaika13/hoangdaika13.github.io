$ErrorActionPreference = "Stop"

$toolRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$bridgeScript = Join-Path $toolRoot "resolve_web_bridge.py"
$pythonw = (Get-Command pythonw.exe -ErrorAction Stop).Source
$startupDir = [Environment]::GetFolderPath("Startup")
$launcherPath = Join-Path $startupDir "H Cosmic Studio Bridge.cmd"

$launcher = @"
@echo off
start "" "$pythonw" "$bridgeScript" --background
"@
[System.IO.File]::WriteAllText(
    $launcherPath,
    $launcher,
    [System.Text.UTF8Encoding]::new($false)
)

$bridgeOnline = $false
try {
    $response = Invoke-WebRequest `
        -Uri "http://127.0.0.1:8765/api/ping" `
        -UseBasicParsing `
        -TimeoutSec 2
    $bridgeOnline = $response.StatusCode -eq 200
} catch {
    $bridgeOnline = $false
}

if (-not $bridgeOnline) {
    Start-Process `
        -FilePath $pythonw `
        -ArgumentList @("`"$bridgeScript`"", "--background") `
        -WindowStyle Hidden
    Start-Sleep -Seconds 2
}

Write-Host "H Cosmic Auto Bridge da duoc bat."
Write-Host "Tu bay gio, chi can mo website; bridge se tu tim DaVinci Resolve."
Write-Host "Startup: $launcherPath"
