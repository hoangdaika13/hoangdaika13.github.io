from __future__ import annotations

import importlib
import json
import math
import os
import re
import shutil
import subprocess
import sys
import time
from dataclasses import asdict, dataclass, fields, replace
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Iterable, Optional


IMAGE_EXTENSIONS = {
    ".jpg", ".jpeg", ".png", ".webp", ".tif", ".tiff", ".bmp", ".dpx", ".exr"
}
AUDIO_EXTENSIONS = {
    ".mp3", ".wav", ".flac", ".m4a", ".aac", ".aif", ".aiff", ".ogg"
}
VIDEO_EXTENSIONS = {
    ".mp4", ".mov", ".mxf", ".avi", ".mkv", ".webm"
}

SCALING_VALUES = {
    "Dùng thiết lập project": 0,
    "Crop": 1,
    "Fit (không cắt ảnh)": 2,
    "Fill (đầy khung)": 3,
    "Stretch": 4,
}

COMPOSITE_VALUES = {
    "Normal": 0,
    "Add": 1,
    "Multiply": 4,
    "Screen": 5,
    "Overlay": 6,
    "Soft Light": 8,
    "Lighten": 10,
    "Linear Dodge": 19,
}

ACTION_PAGE_BY_PREFIX = {
    "SYS": "System",
    "PLAN": "Mission Control",
    "MEDIA": "Media Pool",
    "EDIT": "Edit",
    "INSP": "Inspector",
    "COLOR": "Color",
    "FUSION": "Fusion",
    "STAGE1": "Deliver",
    "STAGE2": "Edit",
    "DELIVER": "Deliver",
    "QUEUE": "Render Queue",
    "VERIFY": "Mission Control",
    "REPORT": "Mission Control",
    "TEMPLATE": "Edit",
    "WATCHDOG": "Dashboard",
    "HEALTH": "Dashboard",
    "CHECKPOINT": "Mission Control",
    "PROFILE": "Mission Control",
    "PREFLIGHT": "Preflight",
    "SCHEDULER": "Scheduler",
    "GRAPH": "Action Graph",
    "RETRY": "Action Graph",
    "POST": "Postflight",
    "INTERMEDIATE": "Mission Control",
    "NOTIFY": "Notification",
}


def natural_key(value: str | Path) -> list[Any]:
    text = Path(value).name if isinstance(value, Path) else str(value)
    return [int(part) if part.isdigit() else part.casefold()
            for part in re.split(r"(\d+)", text)]


def discover_files(source: str, extensions: set[str]) -> list[Path]:
    if not source.strip():
        return []
    path = Path(source).expanduser()
    if path.is_file():
        return [path.resolve()] if path.suffix.casefold() in extensions else []
    if not path.is_dir():
        return []
    files = [
        item.resolve()
        for item in path.iterdir()
        if item.is_file() and item.suffix.casefold() in extensions
    ]
    return sorted(files, key=natural_key)


def discover_image_groups(source: str, multi_folder: bool) -> list[Path]:
    root = Path(source).expanduser()
    if not root.is_dir():
        return []
    if not multi_folder:
        return [root.resolve()] if discover_files(str(root), IMAGE_EXTENSIONS) else []
    groups = [
        child.resolve()
        for child in root.iterdir()
        if child.is_dir() and discover_files(str(child), IMAGE_EXTENSIONS)
    ]
    return sorted(groups, key=natural_key)


def safe_name(value: str, fallback: str = "output") -> str:
    cleaned = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", value).strip(" .")
    return cleaned or fallback


def parse_timecode_frames(value: Any, fps: float) -> int:
    if value is None:
        return 0
    if isinstance(value, (int, float)):
        return max(0, int(value))
    text = str(value).strip()
    if not text:
        return 0
    if text.isdigit():
        return int(text)
    parts = text.replace(";", ":").split(":")
    try:
        numbers = [float(part) for part in parts]
    except ValueError:
        return 0
    if len(numbers) == 4:
        hours, minutes, seconds, frames = numbers
        return max(0, int(round((hours * 3600 + minutes * 60 + seconds) * fps + frames)))
    if len(numbers) == 3:
        hours, minutes, seconds = numbers
        return max(0, int(round((hours * 3600 + minutes * 60 + seconds) * fps)))
    if len(numbers) == 2:
        minutes, seconds = numbers
        return max(0, int(round((minutes * 60 + seconds) * fps)))
    return max(0, int(round(numbers[0] * fps)))


def format_duration(frames: int, fps: float) -> str:
    seconds = frames / fps if fps else 0
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    remaining = seconds % 60
    return f"{hours:02d}:{minutes:02d}:{remaining:05.2f}"


@dataclass
class BatchConfig:
    image_source: str = ""
    overlay_file: str = ""
    music_source: str = ""
    output_dir: str = ""
    timeline_name: str = "PN_kenh_trang_BATCH"
    width: int = 1920
    height: int = 1080
    fps: float = 24.0
    still_seconds: float = 5.0
    scaling: str = "Fill (đầy khung)"
    zoom: float = 1.0
    motion: str = "Không"
    overlay_blend: str = "Screen"
    overlay_opacity: float = 85.5
    workflow: str = "Trực tiếp"
    render_preset: str = ""
    render_format: str = "mp4"
    render_codec: str = "H264"
    bitrate_kbps: int = 25000
    replace_existing: bool = False
    loop_audio: bool = True
    cleanup_temp_timelines: bool = False
    multi_folder_mode: bool = False
    skip_existing: bool = True
    prevent_sleep: bool = True
    detailed_actions: bool = True
    action_delay_ms: int = 0
    drx_file: str = ""
    fusion_comp_file: str = ""
    resume_enabled: bool = True
    deep_verify: bool = True
    duration_tolerance_seconds: float = 1.0
    max_retries: int = 2
    retry_backoff_seconds: float = 2.0
    template_timeline_name: str = ""
    template_mode: str = "Replace V1 placeholders"
    template_track_index: int = 1
    use_profiles: bool = False
    profiles_file: str = ""
    schedule_enabled: bool = False
    schedule_start: str = ""
    batch_size: int = 25
    pause_between_batches_seconds: int = 0
    stall_timeout_minutes: int = 30
    notification_channel: str = "none"
    notify_success: bool = True
    notify_failure: bool = True
    intermediate_policy: str = "keep"
    move_verified_outputs: bool = False
    gpu_temperature_limit_c: int = 88
    minimum_free_disk_gb: float = 5.0

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "BatchConfig":
        allowed = {field.name for field in fields(cls)}
        return cls(**{key: value for key, value in payload.items() if key in allowed})

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @property
    def frames_per_image(self) -> int:
        return max(1, int(round(float(self.fps) * float(self.still_seconds))))

    def validate(self, require_output: bool = False) -> list[str]:
        errors: list[str] = []
        groups = discover_image_groups(self.image_source, self.multi_folder_mode)
        if not groups:
            if self.multi_folder_mode:
                errors.append("Không tìm thấy thư mục con nào chứa ảnh hợp lệ.")
            else:
                errors.append("Không tìm thấy ảnh hợp lệ trong nguồn ảnh.")
        if self.overlay_file and not Path(self.overlay_file).is_file():
            errors.append("File video hiệu ứng không tồn tại.")
        if self.drx_file and not Path(self.drx_file).is_file():
            errors.append("File Color Grade .drx không tồn tại.")
        if self.fusion_comp_file and not Path(self.fusion_comp_file).is_file():
            errors.append("File Fusion template .comp không tồn tại.")
        if self.use_profiles and not Path(self.profiles_file).is_file():
            errors.append("Đã bật nhiều profile nhưng file profile không tồn tại.")
        if self.music_source and not discover_files(self.music_source, AUDIO_EXTENSIONS):
            errors.append("Không tìm thấy file nhạc hợp lệ.")
        if require_output and not self.output_dir.strip():
            errors.append("Chưa chọn thư mục xuất.")
        if self.width < 16 or self.height < 16:
            errors.append("Độ phân giải không hợp lệ.")
        if self.fps <= 0 or self.still_seconds <= 0:
            errors.append("FPS và thời lượng ảnh phải lớn hơn 0.")
        if not (0 <= self.overlay_opacity <= 100):
            errors.append("Opacity phải nằm trong khoảng 0–100.")
        if not (0.1 <= self.zoom <= 100):
            errors.append("Zoom phải nằm trong khoảng 0.1–100.")
        if self.max_retries < 0 or self.batch_size < 1:
            errors.append("Retry phải ≥ 0 và batch size phải ≥ 1.")
        return errors


def build_action_blueprint(config: BatchConfig) -> list[dict[str, Any]]:
    steps: list[dict[str, Any]] = []

    def add(code: str, page: str, action: str, detail: str, enabled: bool = True) -> None:
        api_by_prefix = {
            "SYS": "DaVinciResolveScript.scriptapp / ProjectManager",
            "PLAN": "Path scan / BatchPlan",
            "MEDIA": "MediaPool.GetRootFolder / AddSubFolder / MediaStorage.AddItemListToMediaPool",
            "EDIT": "MediaPool.CreateEmptyTimeline / AppendToTimeline",
            "INSP": "TimelineItem.SetProperty",
            "COLOR": "TimelineItem.ApplyGradeFromDRX",
            "FUSION": "TimelineItem.AddFusionComp / ImportFusionComp",
            "STAGE1": "Project.SetCurrentTimeline / AddRenderJob",
            "STAGE2": "MediaPool.AppendToTimeline",
            "DELIVER": "Project.LoadRenderPreset / SetRenderSettings",
            "QUEUE": "Project.AddRenderJob / StartRendering / GetRenderJobStatus",
            "VERIFY": "Project.GetRenderJobStatus / filesystem check",
            "REPORT": "JSON manifest writer",
            "TEMPLATE": "Timeline.DuplicateTimeline / TimelineItem.AddTake",
            "CHECKPOINT": "ManifestStore.load / atomic os.replace",
            "PROFILE": "ProductionProfile.apply / job planner",
            "PREFLIGHT": "FFprobe / filesystem / Resolve project snapshot",
            "SCHEDULER": "QueueScheduler / priority and batch planner",
            "GRAPH": "ActionGraphExecutor",
            "RETRY": "Per-node retry / backoff / rollback",
            "HEALTH": "nvidia-smi / shutil.disk_usage / render watchdog",
            "POST": "FFprobe / FFmpeg last-frame decode",
            "INTERMEDIATE": "IntermediateManager",
            "NOTIFY": "Telegram / Slack webhook / SMTP",
        }
        prefix = code.split(".", 1)[0]
        steps.append({
            "code": code,
            "page": page,
            "action": action,
            "detail": (
                f"Human: {page} > {action} | "
                f"API: {api_by_prefix.get(prefix, 'Resolve Scripting API')} | {detail}"
            ),
            "enabled": enabled,
        })

    add(
        "CHECKPOINT.01", "Mission Control", "Đọc manifest từng job",
        "Phân loại pending/running/stage_1_rendered/verified/failed và tìm action cuối.",
        config.resume_enabled,
    )
    add(
        "PROFILE.01", "Mission Control", "Nạp production profiles",
        "Nhân nhóm ảnh theo profile, áp preset/overlay/nhạc/resolution/output và sắp priority.",
        config.use_profiles,
    )
    add("PREFLIGHT.01", "Preflight", "Xác minh toàn bộ ảnh", "FFprobe từng ảnh, kiểm tra tên trùng, ký tự và hướng ảnh.")
    add("PREFLIGHT.02", "Preflight", "Xác minh overlay và nhạc", "Kiểm tra stream, FPS và thời lượng đủ hoặc có thể lặp.")
    add("PREFLIGHT.03", "Preflight", "Đối chiếu project Resolve", "So FPS, resolution, codec, DRX và Fusion comp.")
    add("PREFLIGHT.04", "Preflight", "Kiểm tra output và dung lượng", "Tính dung lượng dự kiến, phát hiện output trùng và trả PASS/WARNING/BLOCKED.")
    add(
        "SCHEDULER.01", "Scheduler", "Chờ lịch và chia batch",
        f"Batch {config.batch_size} job · nghỉ {config.pause_between_batches_seconds} giây giữa lô.",
        config.schedule_enabled or config.batch_size > 0,
    )
    add("GRAPH.01", "Action Graph", "Mở graph cho từng video", "PRECHECK → PRODUCE → VERIFY → INTERMEDIATE/NOTIFY.")
    add(
        "RETRY.01", "Action Graph", "Áp retry/backoff/rollback",
        f"Tối đa {config.max_retries} retry · backoff {config.retry_backoff_seconds:g} giây.",
    )
    add("SYS.01", "System", "Kết nối DaVinci Resolve", "Tìm Resolve đang mở qua Scripting API.")
    add("SYS.02", "Project Manager", "Đọc project hiện tại", "Xác nhận project, timeline, FPS và độ phân giải.")
    add("PLAN.01", "Mission Control", "Quét nguồn ảnh", "Lọc định dạng ảnh và sắp xếp tên tự nhiên.")
    add("PLAN.02", "Mission Control", "Lập danh sách video", "Mỗi thư mục con là một video." if config.multi_folder_mode else "Toàn bộ ảnh tạo thành một video.")
    add("PLAN.03", "Mission Control", "Kiểm tra dung lượng", "Ước tính thời lượng, bitrate và dung lượng output.")
    add("MEDIA.01", "Media", "Tạo bin ảnh", "Tạo bin mới dưới Media Pool; không đụng bin có sẵn.")
    add("MEDIA.02", "Media", "Import ảnh", "Đưa từng ảnh vào Media Pool theo đúng thứ tự.")
    add("MEDIA.03", "Media", "Tạo bin overlay", "Chỉ thực hiện khi có video overlay.", bool(config.overlay_file))
    add("MEDIA.04", "Media", "Import overlay", "Nhập clip hiệu ứng dùng trên V2.", bool(config.overlay_file))
    add("MEDIA.05", "Media", "Tạo bin nhạc", "Chỉ thực hiện khi có nhạc.", bool(config.music_source))
    add("MEDIA.06", "Media", "Import nhạc", "Nhập và sắp xếp danh sách nhạc.", bool(config.music_source))
    add("EDIT.01", "Edit", "Tạo timeline mới", f"{config.width}×{config.height} · {config.fps} fps.")
    add(
        "TEMPLATE.01",
        "Edit",
        "Clone template timeline",
        config.template_timeline_name or "Không sử dụng template.",
        bool(config.template_timeline_name),
    )
    add(
        "TEMPLATE.02",
        "Edit",
        "Replace V1 placeholders",
        f"Track V{config.template_track_index} · giữ nguyên node/Fusion/title/transition.",
        bool(config.template_timeline_name),
    )
    add("EDIT.02", "Edit", "Tạo/kiểm tra track V1", "Track ảnh hoặc clip đã render.")
    add("EDIT.03", "Edit", "Đưa từng ảnh lên V1", f"Mỗi ảnh dài {config.still_seconds:g} giây.")
    add("INSP.01", "Inspector", "Đặt Scaling", config.scaling)
    add("INSP.02", "Inspector", "Đặt Zoom X/Y", f"{config.zoom:g}")
    add("COLOR.01", "Color", "Áp Color Grade DRX", config.drx_file or "Không dùng", bool(config.drx_file))
    add("FUSION.01", "Fusion", "Import Fusion composition", config.fusion_comp_file or "Không dùng", bool(config.fusion_comp_file))
    add("FUSION.02", "Fusion", "Tạo keyframe chuyển động", config.motion, config.motion != "Không")
    add("EDIT.04", "Edit", "Tạo/kiểm tra track V2", "Track overlay.", bool(config.overlay_file))
    add("EDIT.05", "Edit", "Lặp overlay tới hết hình", "Trim và đặt từng đoạn đúng record frame.", bool(config.overlay_file))
    add("INSP.03", "Inspector", "Đặt Composite Mode", config.overlay_blend, bool(config.overlay_file))
    add("INSP.04", "Inspector", "Đặt Opacity overlay", f"{config.overlay_opacity:g}%", bool(config.overlay_file))
    add("EDIT.06", "Edit", "Tạo/kiểm tra track A1", "Track nhạc nền.", bool(config.music_source))
    add("EDIT.07", "Edit", "Đưa nhạc vào A1", "Nối tuần tự và trim đoạn cuối.", bool(config.music_source))
    add("EDIT.08", "Edit", "Lặp nhạc", "Lặp playlist tới hết video.", bool(config.music_source and config.loop_audio))
    if config.workflow.startswith("2 giai đoạn"):
        add("STAGE1.01", "Deliver", "Tạo timeline cho từng ảnh", "Mỗi ảnh + overlay là một timeline trung gian.")
        add("STAGE1.02", "Deliver", "Đặt In/Out từng timeline", "Giới hạn đúng số frame/ảnh.")
        add("STAGE1.03", "Deliver", "Đặt tên file trung gian", "Số thứ tự + tên ảnh.")
        add("STAGE1.04", "Render Queue", "Thêm từng job trung gian", "Single Clip mode.")
        add("STAGE1.05", "Render Queue", "Start Render", "Theo dõi toàn bộ job trung gian.")
        add("STAGE2.01", "Media", "Import clip trung gian", "Kiểm tra đủ file và giữ đúng thứ tự.")
        add("STAGE2.02", "Edit", "Tạo timeline video tổng", "Đưa clip trung gian lên V1 và nhạc lên A1.")
    add("DELIVER.01", "Deliver", "Tải Render Preset", config.render_preset or "Dùng thiết lập tùy chỉnh.")
    add("DELIVER.02", "Deliver", "Chọn format và codec", f"{config.render_format} / {config.render_codec}")
    add("DELIVER.03", "Deliver", "Đặt bitrate", f"{config.bitrate_kbps:,} Kb/s")
    add("DELIVER.04", "Deliver", "Đặt tên và thư mục xuất", f"{config.timeline_name} → {config.output_dir or '(chưa chọn)'}")
    add("DELIVER.05", "Deliver", "Đặt Mark In/Out", "Chỉ render đúng phần có hình.")
    add("QUEUE.01", "Render Queue", "Add to Render Queue", "Tạo job từ timeline hiện tại.")
    add("QUEUE.02", "Render Queue", "Start Render", "Chỉ chạy khi chọn Làm toàn bộ + render.")
    add("QUEUE.03", "Render Queue", "Theo dõi phần trăm", "Kiểm tra Complete/Failed/Cancelled.")
    add(
        "HEALTH.01", "Dashboard", "Watchdog render trực tiếp",
        (
            f"Dừng nếu stall {config.stall_timeout_minutes} phút, GPU ≥ "
            f"{config.gpu_temperature_limit_c}°C hoặc ổ đĩa < {config.minimum_free_disk_gb:g} GB."
        ),
    )
    add("POST.01", "Postflight", "Kiểm tra file và kích thước", "Output phải tồn tại và lớn hơn ngưỡng tối thiểu.")
    add("POST.02", "Postflight", "Kiểm tra video/audio stream", "FFprobe xác nhận stream bắt buộc.")
    add("POST.03", "Postflight", "Đối chiếu resolution/FPS/duration", f"Sai số duration tối đa {config.duration_tolerance_seconds:g} giây.")
    add(
        "POST.04", "Postflight", "Decode frame cuối",
        "Dùng FFmpeg đọc frame cuối để phát hiện file cụt/hỏng.",
        config.deep_verify,
    )
    add("POST.05", "Postflight", "Phân loại output", "Chuyển file sang _retry, _failed hoặc _verified theo kết quả.")
    add(
        "INTERMEDIATE.01", "Mission Control", "Áp chính sách file trung gian",
        config.intermediate_policy,
        config.workflow.startswith("2 giai đoạn"),
    )
    add(
        "NOTIFY.01", "Notification", "Gửi thông báo từ xa",
        config.notification_channel,
        config.notification_channel != "none",
    )
    add("CHECKPOINT.02", "Mission Control", "Ghi checkpoint cuối job", "Ghi nguyên tử status, last_action, attempt, output và lỗi.")
    add("REPORT.01", "Mission Control", "Lưu báo cáo phiên", "Ghi kết quả, manifest và dashboard vào enterprise_report JSON.")
    return steps


@dataclass
class BatchPlan:
    images: list[Path]
    audio: list[Path]
    overlay: Optional[Path]
    frames_per_image: int
    total_frames: int

    @classmethod
    def from_config(cls, config: BatchConfig) -> "BatchPlan":
        images = discover_files(config.image_source, IMAGE_EXTENSIONS)
        audio = discover_files(config.music_source, AUDIO_EXTENSIONS)
        overlay = Path(config.overlay_file).resolve() if config.overlay_file else None
        frames_per_image = config.frames_per_image
        return cls(
            images=images,
            audio=audio,
            overlay=overlay,
            frames_per_image=frames_per_image,
            total_frames=len(images) * frames_per_image,
        )

    def summary(self, fps: float) -> str:
        overlay_text = self.overlay.name if self.overlay else "không dùng"
        return (
            f"{len(self.images)} ảnh · {len(self.audio)} file nhạc · "
            f"overlay: {overlay_text} · "
            f"{self.frames_per_image} frame/ảnh · "
            f"tổng {format_duration(self.total_frames, fps)}"
        )


@dataclass
class ProductionEstimate:
    video_count: int
    image_count: int
    total_frames: int
    estimated_bytes: int
    free_bytes: int
    groups: list[Path]

    @classmethod
    def from_config(cls, config: BatchConfig) -> "ProductionEstimate":
        groups = discover_image_groups(config.image_source, config.multi_folder_mode)
        image_count = sum(
            len(discover_files(str(group), IMAGE_EXTENSIONS))
            for group in groups
        )
        total_frames = image_count * config.frames_per_image
        seconds = total_frames / config.fps if config.fps else 0
        # Render bitrate is in Kb/s. Add 192 Kb/s audio and 12% container/variance.
        estimated_bytes = int(seconds * (config.bitrate_kbps + 192) * 1000 / 8 * 1.12)
        if config.workflow.startswith("2 giai đoạn"):
            estimated_bytes *= 2
        probe = Path(config.output_dir or config.image_source or ".").expanduser()
        while not probe.exists() and probe.parent != probe:
            probe = probe.parent
        try:
            free_bytes = shutil.disk_usage(probe).free
        except OSError:
            free_bytes = 0
        return cls(
            video_count=len(groups),
            image_count=image_count,
            total_frames=total_frames,
            estimated_bytes=estimated_bytes,
            free_bytes=free_bytes,
            groups=groups,
        )

    @staticmethod
    def format_bytes(value: int) -> str:
        size = float(max(0, value))
        for unit in ("B", "KB", "MB", "GB", "TB"):
            if size < 1024 or unit == "TB":
                return f"{size:.1f} {unit}"
            size /= 1024
        return f"{size:.1f} TB"

    def summary(self, fps: float) -> str:
        return (
            f"{self.video_count} video · {self.image_count} ảnh · "
            f"{format_duration(self.total_frames, fps)} · "
            f"ước tính {self.format_bytes(self.estimated_bytes)} · "
            f"ổ đĩa trống {self.format_bytes(self.free_bytes)}"
        )


def load_config(path: Path) -> BatchConfig:
    try:
        return BatchConfig.from_dict(json.loads(path.read_text(encoding="utf-8")))
    except (OSError, ValueError, TypeError):
        return BatchConfig()


def save_config(path: Path, config: BatchConfig) -> None:
    path.write_text(
        json.dumps(config.to_dict(), ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def _add_resolve_module_paths() -> None:
    roots = [
        Path(os.environ.get("PROGRAMDATA", r"C:\ProgramData"))
        / "Blackmagic Design/DaVinci Resolve/Support/Developer/Scripting/Modules",
        Path(r"C:\ProgramData\Blackmagic Design\DaVinci Resolve\Support\Developer\Scripting\Modules"),
    ]
    for root in roots:
        text = str(root)
        if root.is_dir() and text not in sys.path:
            sys.path.insert(0, text)
    os.environ.setdefault(
        "RESOLVE_SCRIPT_API",
        r"C:\ProgramData\Blackmagic Design\DaVinci Resolve\Support\Developer\Scripting",
    )
    os.environ.setdefault(
        "RESOLVE_SCRIPT_LIB",
        r"C:\Program Files\Blackmagic Design\DaVinci Resolve\fusionscript.dll",
    )


def connect_resolve(preferred: Any = None) -> Any:
    if preferred:
        return preferred
    _add_resolve_module_paths()
    try:
        module = importlib.import_module("DaVinciResolveScript")
        return module.scriptapp("Resolve")
    except Exception:
        return None


class ResolveError(RuntimeError):
    pass


class ResolveBatchEngine:
    def __init__(
        self,
        resolve: Any,
        log: Optional[Callable[[str], None]] = None,
        progress: Optional[Callable[[float, str], None]] = None,
        should_cancel: Optional[Callable[[], bool]] = None,
        action: Optional[Callable[[dict[str, Any]], None]] = None,
    ) -> None:
        self.resolve = resolve
        self.log = log or (lambda _message: None)
        self.progress = progress or (lambda _value, _message: None)
        self.should_cancel = should_cancel or (lambda: False)
        self.action = action or (lambda _event: None)
        self._action_delay_ms = 0
        self._stall_timeout_minutes = 30
        self._gpu_temperature_limit_c = 0.0
        self._minimum_free_disk_bytes = 0
        self._health_output_dir: Optional[Path] = None
        self._last_health_check_at = 0.0
        if not resolve:
            raise ResolveError(
                "Chưa kết nối được DaVinci Resolve. Hãy mở Resolve và chạy tool từ "
                "Workspace > Scripts, hoặc bật External scripting = Local."
            )
        self.project_manager = resolve.GetProjectManager()
        self.project = self.project_manager.GetCurrentProject() if self.project_manager else None
        if not self.project:
            raise ResolveError("DaVinci Resolve chưa mở project.")
        self.media_pool = self.project.GetMediaPool()
        self.storage = resolve.GetMediaStorage()
        self._emit_action("SYS.01", "done", "Scripting API đã kết nối.")
        self._emit_action("SYS.02", "done", f"Project hiện tại: {self.project.GetName()}.")

    def _emit_action(self, code: str, status: str, detail: str = "") -> None:
        prefix = code.split(".", 1)[0]
        self.action({
            "code": code,
            "status": status,
            "detail": detail,
            "page": ACTION_PAGE_BY_PREFIX.get(prefix, "Resolve"),
            "action": code,
        })
        if status == "done" and self._action_delay_ms > 0:
            time.sleep(self._action_delay_ms / 1000.0)

    def _configure_runtime_guards(self, config: BatchConfig) -> None:
        self._action_delay_ms = max(0, int(config.action_delay_ms))
        self._stall_timeout_minutes = max(0, int(config.stall_timeout_minutes))
        self._gpu_temperature_limit_c = max(
            0.0, float(getattr(config, "gpu_temperature_limit_c", 0) or 0)
        )
        self._minimum_free_disk_bytes = max(
            0,
            int(float(getattr(config, "minimum_free_disk_gb", 0) or 0) * 1024**3),
        )
        output_dir = str(getattr(config, "output_dir", "") or "").strip()
        self._health_output_dir = Path(output_dir) if output_dir else None
        self._last_health_check_at = 0.0

    def _runtime_health_error(self) -> str:
        """Return a blocking health error, throttled to one check every 5 seconds."""
        now = time.monotonic()
        if now - self._last_health_check_at < 5.0:
            return ""
        self._last_health_check_at = now

        if self._minimum_free_disk_bytes > 0 and self._health_output_dir:
            disk_path = self._health_output_dir
            while not disk_path.exists() and disk_path != disk_path.parent:
                disk_path = disk_path.parent
            try:
                free_bytes = shutil.disk_usage(disk_path).free
                if free_bytes < self._minimum_free_disk_bytes:
                    return (
                        f"Ổ đĩa chỉ còn {free_bytes / 1024**3:.2f} GB, thấp hơn "
                        f"ngưỡng {self._minimum_free_disk_bytes / 1024**3:.2f} GB."
                    )
            except OSError:
                pass

        if self._gpu_temperature_limit_c > 0:
            try:
                result = subprocess.run(
                    [
                        "nvidia-smi",
                        "--query-gpu=temperature.gpu",
                        "--format=csv,noheader,nounits",
                    ],
                    capture_output=True,
                    text=True,
                    timeout=3,
                    check=False,
                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                )
                temperatures = [
                    float(line.strip().split()[0])
                    for line in result.stdout.splitlines()
                    if line.strip()
                ]
                if temperatures and max(temperatures) >= self._gpu_temperature_limit_c:
                    return (
                        f"GPU đạt {max(temperatures):.0f}°C, bằng hoặc vượt "
                        f"ngưỡng {self._gpu_temperature_limit_c:.0f}°C."
                    )
            except (OSError, subprocess.SubprocessError, ValueError):
                pass
        return ""

    def snapshot(self) -> dict[str, Any]:
        timeline = self.project.GetCurrentTimeline()
        return {
            "version": self.resolve.GetVersionString(),
            "project": self.project.GetName(),
            "timeline": timeline.GetName() if timeline else "",
            "width": int(float(self.project.GetSetting("timelineResolutionWidth") or 1920)),
            "height": int(float(self.project.GetSetting("timelineResolutionHeight") or 1080)),
            "fps": float(self.project.GetSetting("timelineFrameRate") or 24),
            "presets": list(self.project.GetRenderPresetList() or []),
            "formats": dict(self.project.GetRenderFormats() or {}),
            "timelines": [
                self.project.GetTimelineByIndex(index).GetName()
                for index in range(1, self.project.GetTimelineCount() + 1)
            ],
        }

    def _unique_timeline_name(self, requested: str) -> str:
        existing = {
            self.project.GetTimelineByIndex(index).GetName()
            for index in range(1, self.project.GetTimelineCount() + 1)
        }
        base = safe_name(requested, "BATCH")
        if base not in existing:
            return base
        number = 2
        while f"{base}_{number}" in existing:
            number += 1
        return f"{base}_{number}"

    def _find_timeline(self, name: str) -> Any:
        if not name:
            return None
        for index in range(1, self.project.GetTimelineCount() + 1):
            timeline = self.project.GetTimelineByIndex(index)
            if timeline and timeline.GetName() == name:
                return timeline
        return None

    def _create_timeline(self, name: str, config: BatchConfig) -> Any:
        existing_timeline = self._find_timeline(safe_name(name, "BATCH"))
        if config.resume_enabled and existing_timeline:
            self.project.SetCurrentTimeline(existing_timeline)
            self._emit_action(
                "RESUME.TIMELINE", "done",
                f"Tái sử dụng timeline hiện có: {existing_timeline.GetName()}."
            )
            return existing_timeline
        unique_name = self._unique_timeline_name(name)
        template = self._find_timeline(config.template_timeline_name)
        if config.template_timeline_name and not template:
            raise ResolveError(
                f"Không tìm thấy template timeline: {config.template_timeline_name}"
            )
        timeline = (
            template.DuplicateTimeline(unique_name)
            if template
            else self.media_pool.CreateEmptyTimeline(unique_name)
        )
        if not timeline:
            raise ResolveError(f"Không tạo được timeline: {unique_name}")
        self.project.SetCurrentTimeline(timeline)
        settings = {
            "timelineResolutionWidth": str(config.width),
            "timelineResolutionHeight": str(config.height),
            "timelineFrameRate": str(config.fps),
            "timelinePlaybackFrameRate": str(config.fps),
        }
        for key, value in settings.items():
            try:
                if not timeline.SetSetting(key, value):
                    current = timeline.GetSetting(key)
                    if str(current) != str(value):
                        self.log(f"Cảnh báo: Resolve không nhận {key}={value}; đang dùng {current}.")
            except Exception:
                self.log(f"Cảnh báo: không đặt được {key}={value}.")
        self.log(f"Đã tạo timeline: {unique_name}")
        self._emit_action(
            "EDIT.01", "done",
            (
                f"Timeline {unique_name} · clone từ {config.template_timeline_name}."
                if template
                else f"Timeline {unique_name} · {config.width}×{config.height} · {config.fps} fps."
            )
        )
        return timeline

    def _ensure_track(self, timeline: Any, track_type: str, count: int) -> None:
        while timeline.GetTrackCount(track_type) < count:
            if not timeline.AddTrack(track_type):
                raise ResolveError(f"Không tạo được track {track_type} {count}.")

    def _make_bin(self, label: str) -> Any:
        root = self.media_pool.GetRootFolder()
        bin_name = safe_name(label, "Batch Media")
        folder = next(
            (
                item for item in (root.GetSubFolderList() or [])
                if item.GetName() == bin_name
            ),
            None,
        )
        reused = bool(folder)
        if not folder:
            folder = self.media_pool.AddSubFolder(root, bin_name)
        if not folder:
            folder = root
        self.media_pool.SetCurrentFolder(folder)
        self._emit_action(
            "MEDIA.BIN", "done",
            f"Media Pool bin: {bin_name} ({'tái sử dụng' if reused else 'đã tạo'})."
        )
        return folder

    def _media_by_path(self, folder: Any) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for clip in list(folder.GetClipList() or []):
            properties = clip.GetClipProperty() or {}
            file_path = properties.get("File Path") or properties.get("FilePath")
            if file_path:
                result[os.path.normcase(os.path.abspath(str(file_path)))] = clip
        for child in list(folder.GetSubFolderList() or []):
            result.update(self._media_by_path(child))
        return result

    def _import(self, paths: Iterable[Path], label: str) -> list[Any]:
        path_list = [str(path) for path in paths]
        if not path_list:
            return []
        self._make_bin(label)
        existing = self._media_by_path(self.media_pool.GetRootFolder())
        missing_paths = [
            path for path in path_list
            if os.path.normcase(os.path.abspath(path)) not in existing
        ]
        self._emit_action(
            "MEDIA.IMPORT", "running",
            f"{len(path_list) - len(missing_paths)} file đã có · import {len(missing_paths)} file mới vào {label}."
        )
        clips = self.storage.AddItemListToMediaPool(missing_paths) if missing_paths else []
        if not clips:
            clips = self.media_pool.ImportMedia(missing_paths) if missing_paths else []
        clips = list(clips or [])
        if len(clips) != len(missing_paths):
            self.log(f"Cảnh báo: yêu cầu {len(missing_paths)} media mới, Resolve nhập được {len(clips)}.")
        self._emit_action("MEDIA.IMPORT", "done", f"Đã import {len(clips)}/{len(missing_paths)} file mới.")
        clip_by_path: dict[str, Any] = {}
        clip_by_path.update(existing)
        for clip in clips:
            properties = clip.GetClipProperty() or {}
            file_path = properties.get("File Path") or properties.get("FilePath")
            if file_path:
                clip_by_path[os.path.normcase(os.path.abspath(str(file_path)))] = clip
        ordered: list[Any] = []
        for index, path in enumerate(path_list):
            key = os.path.normcase(os.path.abspath(path))
            ordered.append(clip_by_path.get(key) or (clips[index] if index < len(clips) else None))
        return [clip for clip in ordered if clip is not None]

    @staticmethod
    def _clip_frames(clip: Any, fps: float, fallback: int) -> int:
        properties = clip.GetClipProperty() or {}
        for key in ("Frames", "Frame Count"):
            frames = parse_timecode_frames(properties.get(key), fps)
            if frames > 0:
                return frames
        for key in ("Duration", "End TC"):
            frames = parse_timecode_frames(properties.get(key), fps)
            if frames > 0:
                return frames
        return fallback

    def _append_images(
        self,
        timeline: Any,
        image_clips: list[Any],
        config: BatchConfig,
    ) -> list[Any]:
        self._ensure_track(timeline, "video", 1)
        existing_v1 = list(timeline.GetItemListInTrack("video", 1) or [])
        if (
            config.resume_enabled
            and not config.template_timeline_name
            and len(existing_v1) == len(image_clips)
            and existing_v1
        ):
            self._emit_action(
                "RESUME.V1", "done",
                f"V1 đã có đúng {len(existing_v1)} clip; không append trùng."
            )
            return existing_v1
        if config.template_timeline_name and config.template_mode == "Replace V1 placeholders":
            track_index = max(1, int(config.template_track_index))
            placeholders = list(timeline.GetItemListInTrack("video", track_index) or [])
            if len(placeholders) < len(image_clips):
                raise ResolveError(
                    f"Template chỉ có {len(placeholders)} placeholder trên V{track_index}, "
                    f"nhưng job cần {len(image_clips)} ảnh."
                )
            self._emit_action(
                "TEMPLATE.REPLACE", "running",
                f"Thay {len(image_clips)} placeholder trên V{track_index} bằng Take Selector."
            )
            items: list[Any] = []
            for index, (placeholder, clip) in enumerate(
                zip(placeholders, image_clips), 1
            ):
                if not placeholder.AddTake(
                    clip, 0, config.frames_per_image - 1
                ):
                    raise ResolveError(f"Không AddTake được ảnh {index} vào template.")
                take_index = int(placeholder.GetTakesCount() or 0)
                if take_index <= 0 or not placeholder.SelectTakeByIndex(take_index):
                    raise ResolveError(f"Không chọn được take mới cho ảnh {index}.")
                if not placeholder.FinalizeTake():
                    raise ResolveError(f"Không finalize được take cho ảnh {index}.")
                items.append(placeholder)
                self._emit_action(
                    "TEMPLATE.REPLACE", "done",
                    f"Placeholder {index}/{len(image_clips)} → {clip.GetName()}."
                )
            for unused in placeholders[len(image_clips):]:
                unused.SetClipEnabled(False)
            self._emit_action(
                "TEMPLATE.REPLACE", "done",
                f"Giữ nguyên effect, node, title và transition của {len(items)} placeholder."
            )
            return items

        self._emit_action("EDIT.03", "running", f"Đang đặt {len(image_clips)} ảnh lên V1.")
        items: list[Any] = []
        for index, clip in enumerate(image_clips, 1):
            appended = list(self.media_pool.AppendToTimeline([{
                "mediaPoolItem": clip,
                "startFrame": 0,
                "endFrame": config.frames_per_image - 1,
                "mediaType": 1,
                "trackIndex": 1,
            }] or []) or [])
            if not appended:
                raise ResolveError(f"Không thêm được ảnh thứ {index} vào V1.")
            items.append(appended[0])
            self._emit_action(
                "EDIT.03", "done",
                f"Ảnh {index}/{len(image_clips)}: {appended[0].GetName()}."
            )
        scaling = SCALING_VALUES.get(config.scaling, 3)
        for item in items:
            item.SetProperty("Scaling", scaling)
            self._emit_action("INSP.01", "done", f"{item.GetName()} · Scaling={config.scaling}.")
            if abs(config.zoom - 1.0) > 0.0001:
                item.SetProperty("ZoomX", config.zoom)
                item.SetProperty("ZoomY", config.zoom)
                self._emit_action("INSP.02", "done", f"{item.GetName()} · Zoom={config.zoom:g}.")
            if config.drx_file:
                try:
                    item.ApplyGradeFromDRX(config.drx_file, 0)
                    self._emit_action("COLOR.01", "done", f"DRX áp dụng cho {item.GetName()}.")
                except Exception as exc:
                    self._emit_action("COLOR.01", "error", str(exc))
                    self.log(f"Cảnh báo: không áp dụng được DRX cho {item.GetName()}: {exc}")
            if config.fusion_comp_file:
                try:
                    item.ImportFusionComp(config.fusion_comp_file)
                    self._emit_action("FUSION.01", "done", f"Fusion áp dụng cho {item.GetName()}.")
                except Exception as exc:
                    self._emit_action("FUSION.01", "error", str(exc))
                    self.log(f"Cảnh báo: không import được Fusion comp cho {item.GetName()}: {exc}")
            if config.motion != "Không":
                self._apply_motion(item, config.frames_per_image, config.motion)
        self._emit_action("EDIT.03", "done", f"Hoàn tất {len(items)} ảnh trên V1.")
        return items

    def _apply_motion(self, item: Any, duration: int, motion: str) -> None:
        try:
            comp = item.AddFusionComp()
            if not comp:
                raise RuntimeError("AddFusionComp trả về None")
            tools = comp.GetToolList(False) or {}
            media_in = next(
                (tool for tool in tools.values()
                 if (tool.GetAttrs() or {}).get("TOOLS_RegID") == "MediaIn"),
                None,
            )
            media_out = next(
                (tool for tool in tools.values()
                 if (tool.GetAttrs() or {}).get("TOOLS_RegID") == "MediaOut"),
                None,
            )
            if not media_in or not media_out:
                raise RuntimeError("Không tìm thấy MediaIn/MediaOut")
            transform = comp.AddTool("Transform")
            transform.ConnectInput("Input", media_in)
            media_out.ConnectInput("Input", transform)
            start = 0
            end = max(1, duration - 1)
            if motion == "Zoom in":
                transform.Size[start] = 1.0
                transform.Size[end] = 1.12
            elif motion == "Zoom out":
                transform.Size[start] = 1.12
                transform.Size[end] = 1.0
            elif motion == "Pan trái → phải":
                transform.Size[start] = 1.08
                transform.Size[end] = 1.08
                transform.Center[start] = {1: 0.46, 2: 0.5}
                transform.Center[end] = {1: 0.54, 2: 0.5}
            elif motion == "Pan phải → trái":
                transform.Size[start] = 1.08
                transform.Size[end] = 1.08
                transform.Center[start] = {1: 0.54, 2: 0.5}
                transform.Center[end] = {1: 0.46, 2: 0.5}
            self._emit_action("FUSION.02", "done", f"{motion} · {duration} frame.")
        except Exception as exc:
            self._emit_action("FUSION.02", "error", str(exc))
            self.log(f"Cảnh báo: không áp dụng được chuyển động cho {item.GetName()}: {exc}")

    def _append_overlay(
        self,
        timeline: Any,
        overlay_clip: Any,
        total_frames: int,
        config: BatchConfig,
    ) -> list[Any]:
        if not overlay_clip or total_frames <= 0:
            return []
        self._ensure_track(timeline, "video", 2)
        existing_v2 = list(timeline.GetItemListInTrack("video", 2) or [])
        if config.resume_enabled and existing_v2:
            self._emit_action(
                "RESUME.V2", "done",
                f"V2 đã có {len(existing_v2)} đoạn; không append overlay trùng."
            )
            return existing_v2
        self._emit_action("EDIT.05", "running", f"Lặp overlay trên V2 trong {total_frames} frame.")
        source_frames = self._clip_frames(
            overlay_clip, config.fps, config.frames_per_image
        )
        source_frames = max(1, source_frames)
        timeline_start = int(timeline.GetStartFrame())
        infos: list[dict[str, Any]] = []
        offset = 0
        while offset < total_frames:
            segment = min(source_frames, total_frames - offset)
            infos.append({
                "mediaPoolItem": overlay_clip,
                "startFrame": 0,
                "endFrame": segment - 1,
                "mediaType": 1,
                "trackIndex": 2,
                "recordFrame": timeline_start + offset,
            })
            offset += segment
        items = list(self.media_pool.AppendToTimeline(infos) or [])
        blend = COMPOSITE_VALUES.get(config.overlay_blend, 5)
        for item in items:
            item.SetProperty("CompositeMode", blend)
            item.SetProperty("Opacity", float(config.overlay_opacity))
            item.SetProperty("Scaling", 3)
            self._emit_action("INSP.03", "done", f"Composite={config.overlay_blend}.")
            self._emit_action("INSP.04", "done", f"Opacity={config.overlay_opacity:g}%.")
        if len(items) != len(infos):
            self.log(f"Cảnh báo: overlay thêm được {len(items)}/{len(infos)} đoạn.")
        self._emit_action("EDIT.05", "done", f"Đã đặt {len(items)} đoạn overlay trên V2.")
        return items

    def _append_audio(
        self,
        timeline: Any,
        audio_clips: list[Any],
        total_frames: int,
        config: BatchConfig,
    ) -> list[Any]:
        if not audio_clips or total_frames <= 0:
            return []
        self._ensure_track(timeline, "audio", 1)
        existing_a1 = list(timeline.GetItemListInTrack("audio", 1) or [])
        if config.resume_enabled and existing_a1:
            self._emit_action(
                "RESUME.A1", "done",
                f"A1 đã có {len(existing_a1)} đoạn; không append nhạc trùng."
            )
            return existing_a1
        self._emit_action("EDIT.07", "running", f"Nối {len(audio_clips)} file nhạc trên A1.")
        timeline_start = int(timeline.GetStartFrame())
        infos: list[dict[str, Any]] = []
        offset = 0
        index = 0
        maximum_segments = max(100, len(audio_clips) * 100)
        while offset < total_frames and index < maximum_segments:
            clip = audio_clips[index % len(audio_clips)]
            available = self._clip_frames(clip, config.fps, total_frames)
            segment = min(max(1, available), total_frames - offset)
            infos.append({
                "mediaPoolItem": clip,
                "startFrame": 0,
                "endFrame": segment - 1,
                "mediaType": 2,
                "trackIndex": 1,
                "recordFrame": timeline_start + offset,
            })
            offset += segment
            index += 1
            if not config.loop_audio and index >= len(audio_clips):
                break
        items = list(self.media_pool.AppendToTimeline(infos) or [])
        if offset < total_frames:
            self.log("Cảnh báo: nhạc ngắn hơn video và tùy chọn lặp nhạc đang tắt.")
        self._emit_action("EDIT.07", "done", f"Đã đặt {len(items)} đoạn nhạc trên A1.")
        return items

    def _resolve_format_codec(self, config: BatchConfig) -> tuple[str, str]:
        requested_format = config.render_format or "mp4"
        requested_codec = config.render_codec or "H264"
        codecs = self.project.GetRenderCodecs(requested_format) or {}
        available_values = [str(value) for value in codecs.values()]
        if requested_codec in available_values:
            return requested_format, requested_codec
        target = requested_codec.replace(".", "").replace(" ", "").casefold()
        for description, value in codecs.items():
            haystack = f"{description}{value}".replace(".", "").replace(" ", "").casefold()
            if target in haystack:
                return requested_format, str(value)
        if available_values:
            fallback = available_values[0]
            self.log(f"Codec {requested_codec} không có; dùng {fallback}.")
            return requested_format, fallback
        return requested_format, requested_codec

    def _find_pending_render_job(
        self,
        target_dir: Path,
        custom_name: str,
    ) -> str:
        """Find the same unfinished queue item so resume does not create duplicates."""
        expected_dir = os.path.normcase(os.path.abspath(str(target_dir)))
        expected_name = safe_name(custom_name).casefold()
        for job in list(self.project.GetRenderJobList() or []):
            job_id = str(
                job.get("JobId")
                or job.get("JobID")
                or job.get("RenderJobId")
                or ""
            )
            if not job_id:
                continue
            status = self.project.GetRenderJobStatus(job_id) or {}
            state = str(status.get("JobStatus", "")).casefold()
            if state in {"complete", "completed", "failed", "cancelled", "canceled"}:
                continue
            job_dir = str(job.get("TargetDir") or "")
            if job_dir and os.path.normcase(os.path.abspath(job_dir)) != expected_dir:
                continue
            candidate_names = {
                str(job.get("CustomName") or "").casefold(),
                str(job.get("RenderJobName") or "").casefold(),
                Path(str(job.get("OutputFilename") or "")).stem.casefold(),
            }
            if expected_name in candidate_names:
                return job_id
        return ""

    def _queue_render(
        self,
        timeline: Any,
        config: BatchConfig,
        target_dir: Path,
        custom_name: str,
        total_frames: int,
    ) -> str:
        self._emit_action("DELIVER.01", "running", f"Preset: {config.render_preset or 'custom'}.")
        self.project.SetCurrentTimeline(timeline)
        if config.render_preset:
            if not self.project.LoadRenderPreset(config.render_preset):
                self.log(f"Cảnh báo: không tải được preset {config.render_preset}.")
        render_format, codec = self._resolve_format_codec(config)
        if not self.project.SetCurrentRenderFormatAndCodec(render_format, codec):
            raise ResolveError(f"Không đặt được format/codec: {render_format}/{codec}")
        self.project.SetCurrentRenderMode(1)
        target_dir.mkdir(parents=True, exist_ok=True)
        start = int(timeline.GetStartFrame())
        settings = {
            "SelectAllFrames": False,
            "MarkIn": start,
            "MarkOut": start + max(1, total_frames) - 1,
            "TargetDir": str(target_dir.resolve()),
            "CustomName": safe_name(custom_name),
            "ExportVideo": True,
            "ExportAudio": True,
            "FormatWidth": int(config.width),
            "FormatHeight": int(config.height),
            "FrameRate": float(config.fps),
            "VideoQuality": max(1, int(config.bitrate_kbps)),
            "AudioCodec": "aac",
            "AudioSampleRate": 48000,
            "NetworkOptimization": True,
            "ReplaceExistingFilesInPlace": bool(config.replace_existing),
        }
        if not self.project.SetRenderSettings(settings):
            raise ResolveError("Resolve từ chối render settings.")
        self._emit_action(
            "DELIVER.02", "done",
            f"{render_format}/{codec} · {config.width}×{config.height} · {config.fps} fps."
        )
        self._emit_action("DELIVER.03", "done", f"Bitrate {config.bitrate_kbps:,} Kb/s.")
        self._emit_action("DELIVER.04", "done", f"{target_dir} / {custom_name}.")
        self._emit_action("DELIVER.05", "done", f"{start} → {start + max(1, total_frames) - 1}.")
        if config.resume_enabled:
            existing_job_id = self._find_pending_render_job(target_dir, custom_name)
            if existing_job_id:
                self.log(f"Tái sử dụng Render Queue job: {custom_name}")
                self._emit_action(
                    "RESUME.QUEUE", "done",
                    f"Job {existing_job_id} đã có trong queue · {custom_name}."
                )
                return existing_job_id
        job_id = self.project.AddRenderJob()
        if not job_id:
            raise ResolveError("Không thêm được job vào Render Queue.")
        self.log(f"Đã đưa vào Render Queue: {custom_name}")
        self._emit_action("QUEUE.01", "done", f"Job {job_id} · {custom_name}.")
        return str(job_id)

    def _wait_for_jobs(self, job_ids: list[str], label: str) -> None:
        if not job_ids:
            return
        if not self.project.StartRendering(job_ids, False):
            raise ResolveError("Không khởi động được Render Queue.")
        self._emit_action("QUEUE.02", "running", f"Bắt đầu {len(job_ids)} job.")
        last_progress = -1.0
        last_progress_at = time.monotonic()
        while True:
            if self.should_cancel():
                self.project.StopRendering()
                raise ResolveError("Đã hủy theo yêu cầu. Các timeline và job đã tạo vẫn được giữ lại.")
            health_error = self._runtime_health_error()
            if health_error:
                self.project.StopRendering()
                self._emit_action("HEALTH.STOP", "error", health_error)
                raise ResolveError(f"Watchdog an toàn đã dừng render: {health_error}")
            statuses = [self.project.GetRenderJobStatus(job_id) or {} for job_id in job_ids]
            complete = 0
            failed: list[str] = []
            percentages: list[float] = []
            for index, status in enumerate(statuses):
                state = str(status.get("JobStatus", "")).casefold()
                percent = float(status.get("CompletionPercentage", 0) or 0)
                percentages.append(percent)
                if state in {"complete", "completed"}:
                    complete += 1
                elif state in {"failed", "cancelled", "canceled"}:
                    failed.append(job_ids[index])
            overall = sum(percentages) / max(1, len(percentages))
            if overall > last_progress + 0.05:
                last_progress = overall
                last_progress_at = time.monotonic()
            elif (
                self._stall_timeout_minutes > 0
                and time.monotonic() - last_progress_at
                > self._stall_timeout_minutes * 60
            ):
                self.project.StopRendering()
                self._emit_action(
                    "WATCHDOG.STALL", "error",
                    f"Render không tiến triển trong {self._stall_timeout_minutes} phút."
                )
                raise ResolveError(
                    f"Watchdog dừng render vì không tiến triển trong "
                    f"{self._stall_timeout_minutes} phút."
                )
            self.progress(overall / 100.0, f"{label}: {complete}/{len(job_ids)} · {overall:.0f}%")
            if failed:
                self.project.StopRendering()
                self._emit_action(
                    "QUEUE.FAIL", "error",
                    f"{len(failed)} job báo lỗi; đã dừng các job còn lại."
                )
                raise ResolveError(f"Render thất bại ở {len(failed)} job.")
            if complete == len(job_ids):
                break
            if not self.project.IsRenderingInProgress():
                incomplete = len(job_ids) - complete
                if incomplete:
                    raise ResolveError(f"Render dừng khi còn {incomplete} job chưa xong.")
                break
            time.sleep(0.75)
        self.progress(1.0, f"{label}: hoàn tất")
        self._emit_action("QUEUE.03", "done", f"{label}: {len(job_ids)} job hoàn tất.")

    def build_direct(
        self,
        config: BatchConfig,
        queue_render: bool = False,
        start_render: bool = False,
    ) -> dict[str, Any]:
        self._configure_runtime_guards(config)
        errors = config.validate(require_output=queue_render)
        if errors:
            raise ResolveError("\n".join(errors))
        plan = BatchPlan.from_config(config)
        self.log(f"Kế hoạch: {plan.summary(config.fps)}")
        image_clips = self._import(plan.images, f"{config.timeline_name} - Images")
        if len(image_clips) != len(plan.images):
            raise ResolveError("Không nhập đủ ảnh; dừng để tránh sai thứ tự.")
        overlay_clip = None
        if plan.overlay:
            imported = self._import([plan.overlay], f"{config.timeline_name} - Overlay")
            overlay_clip = imported[0] if imported else None
            if not overlay_clip:
                raise ResolveError("Không nhập được video overlay.")
        audio_clips = self._import(plan.audio, f"{config.timeline_name} - Music")
        if len(audio_clips) != len(plan.audio):
            raise ResolveError("Không nhập đủ file nhạc; dừng để tránh timeline thiếu audio.")
        timeline = self._create_timeline(config.timeline_name, config)
        self.progress(0.15, "Đang thêm ảnh")
        self._append_images(timeline, image_clips, config)
        self.progress(0.45, "Đang thêm overlay")
        template_has_v2 = (
            bool(config.template_timeline_name)
            and timeline.GetTrackCount("video") >= 2
            and bool(timeline.GetItemListInTrack("video", 2))
        )
        if template_has_v2:
            self._emit_action(
                "TEMPLATE.V2", "done",
                "Template đã có nội dung V2; không thêm overlay trùng."
            )
        else:
            self._append_overlay(timeline, overlay_clip, plan.total_frames, config)
        self.progress(0.65, "Đang thêm nhạc")
        template_has_a1 = (
            bool(config.template_timeline_name)
            and timeline.GetTrackCount("audio") >= 1
            and bool(timeline.GetItemListInTrack("audio", 1))
        )
        if template_has_a1:
            self._emit_action(
                "TEMPLATE.A1", "done",
                "Template đã có nội dung A1; không thêm nhạc trùng."
            )
        else:
            self._append_audio(timeline, audio_clips, plan.total_frames, config)
        job_ids: list[str] = []
        if queue_render:
            job_ids.append(self._queue_render(
                timeline,
                config,
                Path(config.output_dir),
                config.timeline_name,
                plan.total_frames,
            ))
        self.project_manager.SaveProject()
        if start_render:
            self._wait_for_jobs(job_ids, "Render video tổng")
        self.project.SetCurrentTimeline(timeline)
        self.progress(1.0, "Hoàn tất")
        return {
            "timeline": timeline.GetName(),
            "jobs": job_ids,
            "total_frames": plan.total_frames,
            "expected_output": str(
                Path(config.output_dir) / f"{safe_name(config.timeline_name)}.{config.render_format}"
            ) if queue_render else "",
        }

    def build_two_stage(
        self,
        config: BatchConfig,
        start_render: bool = True,
    ) -> dict[str, Any]:
        self._configure_runtime_guards(config)
        if not start_render:
            raise ResolveError(
                "Chế độ 2 giai đoạn cần render file trung gian. "
                "Hãy dùng nút “Làm toàn bộ + render”."
            )
        errors = config.validate(require_output=True)
        if errors:
            raise ResolveError("\n".join(errors))
        plan = BatchPlan.from_config(config)
        self.log(f"Kế hoạch 2 giai đoạn: {plan.summary(config.fps)}")
        output_dir = Path(config.output_dir)
        intermediate_dir = output_dir / f"_batch_clips_{safe_name(config.timeline_name)}"
        image_clips = self._import(plan.images, f"{config.timeline_name} - Source Images")
        if len(image_clips) != len(plan.images):
            raise ResolveError("Không nhập đủ ảnh; dừng để tránh sai thứ tự.")
        overlay_clip = None
        if plan.overlay:
            overlay_items = self._import([plan.overlay], f"{config.timeline_name} - Overlay")
            overlay_clip = overlay_items[0] if overlay_items else None
            if not overlay_clip:
                raise ResolveError("Không nhập được video overlay.")
        temp_timelines: list[Any] = []
        intermediate_jobs: list[str] = []
        expected_outputs: list[Path] = []
        extension = str((self.project.GetRenderFormats() or {}).get(config.render_format, config.render_format))
        extension = extension.lstrip(".") or "mp4"
        for index, (path, clip) in enumerate(zip(plan.images, image_clips), 1):
            output_name = f"{index:03d}_{safe_name(path.stem)}"
            expected_output = intermediate_dir / f"{output_name}.{extension}"
            expected_outputs.append(expected_output)
            if (
                config.resume_enabled
                and expected_output.is_file()
                and expected_output.stat().st_size > 100 * 1024
            ):
                self._emit_action(
                    "RESUME.STAGE1", "done",
                    f"Clip trung gian đã có: {expected_output.name}; bỏ qua Stage 1."
                )
                continue
            self.progress(
                0.35 * (index - 1) / max(1, len(plan.images)),
                f"Tạo clip {index}/{len(plan.images)}",
            )
            timeline_name = f"__BATCH_{safe_name(config.timeline_name)}_{index:03d}"
            timeline = self._create_timeline(timeline_name, config)
            temp_timelines.append(timeline)
            self._append_images(timeline, [clip], config)
            self._append_overlay(timeline, overlay_clip, config.frames_per_image, config)
            intermediate_jobs.append(self._queue_render(
                timeline,
                config,
                intermediate_dir,
                output_name,
                config.frames_per_image,
            ))
        self.project_manager.SaveProject()
        if intermediate_jobs:
            self._wait_for_jobs(intermediate_jobs, "Render clip trung gian")
        missing = [path for path in expected_outputs if not path.is_file()]
        if missing:
            candidates = discover_files(str(intermediate_dir), VIDEO_EXTENSIONS)
            if len(candidates) == len(expected_outputs):
                expected_outputs = candidates
            else:
                raise ResolveError(
                    f"Render xong nhưng thiếu {len(missing)} file trung gian trong {intermediate_dir}."
                )
        rendered_clips = self._import(
            expected_outputs, f"{config.timeline_name} - Rendered Clips"
        )
        if len(rendered_clips) != len(expected_outputs):
            raise ResolveError("Không nhập đủ clip trung gian để ghép video tổng.")
        audio_clips = self._import(plan.audio, f"{config.timeline_name} - Music")
        if len(audio_clips) != len(plan.audio):
            raise ResolveError("Không nhập đủ file nhạc; dừng để tránh timeline thiếu audio.")
        final_timeline = self._create_timeline(config.timeline_name, config)
        final_items = self._append_images(final_timeline, rendered_clips, config)
        if len(final_items) != len(rendered_clips):
            raise ResolveError("Không ghép đủ clip trung gian vào timeline tổng.")
        template_has_a1 = (
            bool(config.template_timeline_name)
            and final_timeline.GetTrackCount("audio") >= 1
            and bool(final_timeline.GetItemListInTrack("audio", 1))
        )
        if not template_has_a1:
            self._append_audio(final_timeline, audio_clips, plan.total_frames, config)
        final_job = self._queue_render(
            final_timeline,
            config,
            output_dir,
            config.timeline_name,
            plan.total_frames,
        )
        self.project_manager.SaveProject()
        self._wait_for_jobs([final_job], "Render video tổng")
        if config.cleanup_temp_timelines and temp_timelines:
            if self.media_pool.DeleteTimelines(temp_timelines):
                self.log(f"Đã xóa {len(temp_timelines)} timeline trung gian do tool tạo.")
        self.project.SetCurrentTimeline(final_timeline)
        self.project_manager.SaveProject()
        self.progress(1.0, "Hoàn tất toàn bộ")
        return {
            "timeline": final_timeline.GetName(),
            "jobs": intermediate_jobs + [final_job],
            "intermediate_dir": str(intermediate_dir),
            "total_frames": plan.total_frames,
            "expected_output": str(
                output_dir / f"{safe_name(config.timeline_name)}.{config.render_format}"
            ),
        }

    def build_production(self, config: BatchConfig, action: str) -> dict[str, Any]:
        self._configure_runtime_guards(config)
        groups = discover_image_groups(config.image_source, config.multi_folder_mode)
        if not groups:
            raise ResolveError("Không tìm thấy nhóm ảnh để sản xuất.")
        if len(groups) == 1 and not config.multi_folder_mode:
            if config.workflow.startswith("2 giai đoạn"):
                if action != "render":
                    raise ResolveError(
                        "Workflow 2 giai đoạn chỉ chạy bằng nút “Làm toàn bộ + render”."
                    )
                return self.build_two_stage(config, start_render=True)
            return self.build_direct(
                config,
                queue_render=action in {"queue", "render"},
                start_render=action == "render",
            )

        if config.workflow.startswith("2 giai đoạn") and action != "render":
            raise ResolveError(
                "Sản xuất nhiều thư mục bằng workflow 2 giai đoạn cần nút "
                "“Làm toàn bộ + render”."
            )

        results: list[dict[str, Any]] = []
        queued_jobs: list[str] = []
        skipped: list[str] = []
        failures: list[dict[str, str]] = []
        total_groups = len(groups)
        prefix = safe_name(config.timeline_name, "BATCH")
        for index, group in enumerate(groups, 1):
            if self.should_cancel():
                raise ResolveError("Đã hủy trước khi bắt đầu video tiếp theo.")
            name = f"{prefix}_{safe_name(group.name)}"
            child = replace(
                config,
                image_source=str(group),
                timeline_name=name,
                multi_folder_mode=False,
            )
            expected = Path(config.output_dir) / f"{name}.{config.render_format}"
            if action in {"queue", "render"} and config.skip_existing and expected.is_file():
                skipped.append(str(expected))
                self.log(f"Bỏ qua file đã có: {expected.name}")
                continue
            self.progress(
                (index - 1) / max(1, total_groups),
                f"Video {index}/{total_groups}: {group.name}",
            )
            self.log(f"=== VIDEO {index}/{total_groups}: {group.name} ===")
            try:
                if child.workflow.startswith("2 giai đoạn"):
                    result = self.build_two_stage(child, start_render=True)
                else:
                    result = self.build_direct(
                        child,
                        queue_render=action in {"queue", "render"},
                        start_render=False,
                    )
                    queued_jobs.extend(result.get("jobs", []))
                results.append(result)
            except Exception as exc:
                failures.append({"group": str(group), "error": str(exc)})
                self.log(f"Lỗi video {group.name}: {exc}")
                if child.workflow.startswith("2 giai đoạn"):
                    continue

        if action == "render" and queued_jobs:
            self._wait_for_jobs(queued_jobs, f"Render {len(results)} video")

        report = {
            "created_at": datetime.now().isoformat(timespec="seconds"),
            "project": self.project.GetName(),
            "workflow": config.workflow,
            "action": action,
            "videos_total": total_groups,
            "videos_completed": len(results),
            "skipped": skipped,
            "failures": failures,
            "results": results,
        }
        report_path = None
        if config.output_dir:
            report_path = (
                Path(config.output_dir)
                / f"batch_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            )
            report_path.parent.mkdir(parents=True, exist_ok=True)
            report_path.write_text(
                json.dumps(report, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
            self.log(f"Đã lưu báo cáo phiên chạy: {report_path.name}")
        self.progress(1.0, "Hoàn tất phiên sản xuất")
        return {
            "timeline": results[-1].get("timeline", "") if results else "",
            "jobs": queued_jobs,
            "results": results,
            "skipped": skipped,
            "failures": failures,
            "report_path": str(report_path) if report_path else "",
        }
