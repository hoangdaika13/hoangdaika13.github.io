$ErrorActionPreference = "Stop"

$toolRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$source = Join-Path $toolRoot "resolve_menu_launcher.py"
$scriptDir = Join-Path $env:APPDATA "Blackmagic Design\DaVinci Resolve\Support\Fusion\Scripts\Utility"
$target = Join-Path $scriptDir "H Cosmic Studio.py"

New-Item -ItemType Directory -Path $scriptDir -Force | Out-Null
Copy-Item -LiteralPath $source -Destination $target -Force

Write-Host "Installed: $target"
Write-Host "In Resolve, open Workspace > Scripts > Utility > H Cosmic Studio."
Write-Host "If the item is not visible, restart DaVinci Resolve once."
