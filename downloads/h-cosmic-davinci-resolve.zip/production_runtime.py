from __future__ import annotations

import json
import math
import os
import re
import shutil
import smtplib
import subprocess
import time
import urllib.request
import zipfile
from dataclasses import asdict, dataclass, field, replace
from datetime import datetime
from email.message import EmailMessage
from pathlib import Path
from typing import Any, Callable, Iterable, Optional


IMAGE_EXTENSIONS = {
    ".jpg", ".jpeg", ".png", ".webp", ".tif", ".tiff", ".bmp", ".dpx", ".exr"
}
AUDIO_EXTENSIONS = {
    ".mp3", ".wav", ".flac", ".m4a", ".aac", ".aif", ".aiff", ".ogg"
}
INVALID_WINDOWS_NAME = re.compile(r'[<>:"/\\|?*\x00-\x1f]')


def utc_now() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def natural_key(value: str | Path) -> list[Any]:
    return [
        int(part) if part.isdigit() else part.casefold()
        for part in re.split(r"(\d+)", Path(value).name)
    ]


def atomic_write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    os.replace(temporary, path)


def parse_fraction(value: str | None) -> float:
    if not value:
        return 0.0
    text = str(value)
    if "/" in text:
        numerator, denominator = text.split("/", 1)
        try:
            return float(numerator) / float(denominator)
        except (ValueError, ZeroDivisionError):
            return 0.0
    try:
        return float(text)
    except ValueError:
        return 0.0


@dataclass
class MediaInfo:
    path: str
    exists: bool
    size: int = 0
    duration: float = 0.0
    width: int = 0
    height: int = 0
    fps: float = 0.0
    video_streams: int = 0
    audio_streams: int = 0
    format_name: str = ""
    error: str = ""


class MediaProbe:
    def __init__(
        self,
        ffprobe_path: str = "ffprobe",
        ffmpeg_path: str = "ffmpeg",
        timeout_seconds: int = 30,
    ) -> None:
        self.ffprobe_path = ffprobe_path
        self.ffmpeg_path = ffmpeg_path
        self.timeout_seconds = timeout_seconds

    def probe(self, path: str | Path) -> MediaInfo:
        media_path = Path(path)
        if not media_path.is_file():
            return MediaInfo(path=str(media_path), exists=False, error="File không tồn tại.")
        command = [
            self.ffprobe_path,
            "-v", "error",
            "-show_entries",
            "format=duration,format_name,size:stream=index,codec_type,width,height,avg_frame_rate,r_frame_rate",
            "-of", "json",
            str(media_path),
        ]
        try:
            result = subprocess.run(
                command,
                capture_output=True,
                text=True,
                timeout=self.timeout_seconds,
                check=False,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
        except (OSError, subprocess.TimeoutExpired) as exc:
            return MediaInfo(
                path=str(media_path),
                exists=True,
                size=media_path.stat().st_size,
                error=str(exc),
            )
        if result.returncode != 0:
            return MediaInfo(
                path=str(media_path),
                exists=True,
                size=media_path.stat().st_size,
                error=result.stderr.strip() or "FFprobe không đọc được file.",
            )
        try:
            payload = json.loads(result.stdout)
        except json.JSONDecodeError as exc:
            return MediaInfo(
                path=str(media_path),
                exists=True,
                size=media_path.stat().st_size,
                error=f"FFprobe JSON lỗi: {exc}",
            )
        streams = payload.get("streams", [])
        videos = [stream for stream in streams if stream.get("codec_type") == "video"]
        audios = [stream for stream in streams if stream.get("codec_type") == "audio"]
        first_video = videos[0] if videos else {}
        format_info = payload.get("format", {})
        try:
            duration = float(format_info.get("duration") or 0)
        except (ValueError, TypeError):
            duration = 0.0
        return MediaInfo(
            path=str(media_path),
            exists=True,
            size=int(format_info.get("size") or media_path.stat().st_size),
            duration=duration,
            width=int(first_video.get("width") or 0),
            height=int(first_video.get("height") or 0),
            fps=parse_fraction(
                first_video.get("avg_frame_rate") or first_video.get("r_frame_rate")
            ),
            video_streams=len(videos),
            audio_streams=len(audios),
            format_name=str(format_info.get("format_name") or ""),
        )

    def decode_last_frame(self, path: str | Path) -> tuple[bool, str]:
        command = [
            self.ffmpeg_path,
            "-v", "error",
            "-sseof", "-1",
            "-i", str(path),
            "-frames:v", "1",
            "-f", "null",
            "-",
        ]
        try:
            result = subprocess.run(
                command,
                capture_output=True,
                text=True,
                timeout=self.timeout_seconds,
                check=False,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
        except (OSError, subprocess.TimeoutExpired) as exc:
            return False, str(exc)
        return result.returncode == 0, result.stderr.strip()


@dataclass
class CheckResult:
    code: str
    level: str
    title: str
    detail: str
    file: str = ""

    @property
    def blocking(self) -> bool:
        return self.level == "BLOCKED"


@dataclass
class PreflightReport:
    status: str
    checks: list[CheckResult]
    created_at: str = field(default_factory=utc_now)

    @property
    def blocked(self) -> bool:
        return self.status == "BLOCKED"

    @property
    def warnings(self) -> int:
        return sum(check.level == "WARNING" for check in self.checks)

    def to_dict(self) -> dict[str, Any]:
        return {
            "status": self.status,
            "created_at": self.created_at,
            "checks": [asdict(check) for check in self.checks],
        }


class PreflightValidator:
    def __init__(self, probe: Optional[MediaProbe] = None) -> None:
        self.probe = probe or MediaProbe()

    @staticmethod
    def _result(
        checks: list[CheckResult],
        code: str,
        level: str,
        title: str,
        detail: str,
        file: str = "",
    ) -> None:
        checks.append(CheckResult(code, level, title, detail, file))

    def validate(
        self,
        config: Any,
        images: Iterable[Path],
        audio: Iterable[Path],
        overlay: Optional[Path],
        project_snapshot: Optional[dict[str, Any]] = None,
    ) -> PreflightReport:
        checks: list[CheckResult] = []
        image_paths = list(images)
        audio_paths = list(audio)
        if not image_paths:
            self._result(checks, "PF.IMG.NONE", "BLOCKED", "Nguồn ảnh", "Không có ảnh hợp lệ.")
        else:
            self._result(
                checks, "PF.IMG.COUNT", "PASS", "Số lượng ảnh",
                f"Tìm thấy {len(image_paths)} ảnh."
            )

        names: dict[str, list[str]] = {}
        invalid_names: list[str] = []
        unreadable: list[str] = []
        orientations: set[str] = set()
        for path in image_paths:
            names.setdefault(path.name.casefold(), []).append(str(path))
            if INVALID_WINDOWS_NAME.search(path.name):
                invalid_names.append(path.name)
            info = self.probe.probe(path)
            if info.error or info.video_streams == 0:
                unreadable.append(path.name)
            elif info.width and info.height:
                orientations.add("landscape" if info.width >= info.height else "portrait")

        duplicates = [items for items in names.values() if len(items) > 1]
        self._result(
            checks,
            "PF.IMG.READ",
            "BLOCKED" if unreadable else "PASS",
            "Khả năng đọc ảnh",
            f"Không đọc được: {', '.join(unreadable[:10])}" if unreadable else "Tất cả ảnh đọc được.",
        )
        self._result(
            checks,
            "PF.IMG.DUP",
            "WARNING" if duplicates else "PASS",
            "Tên ảnh trùng",
            f"{len(duplicates)} nhóm trùng tên." if duplicates else "Không có tên trùng.",
        )
        self._result(
            checks,
            "PF.IMG.NAME",
            "BLOCKED" if invalid_names else "PASS",
            "Tên file Windows",
            f"Tên không hợp lệ: {', '.join(invalid_names[:10])}" if invalid_names else "Tên file hợp lệ.",
        )
        self._result(
            checks,
            "PF.IMG.ORIENTATION",
            "WARNING" if len(orientations) > 1 else "PASS",
            "Hướng ảnh",
            "Ảnh ngang và dọc đang trộn lẫn." if len(orientations) > 1 else f"Hướng ảnh: {next(iter(orientations), 'không xác định')}.",
        )

        if overlay:
            overlay_info = self.probe.probe(overlay)
            overlay_level = "BLOCKED" if overlay_info.error or overlay_info.video_streams == 0 else "PASS"
            overlay_detail = overlay_info.error or (
                f"{overlay_info.width}×{overlay_info.height} · "
                f"{overlay_info.duration:.2f}s · {overlay_info.fps:.3f} fps"
            )
            self._result(checks, "PF.OVERLAY", overlay_level, "Video overlay", overlay_detail, str(overlay))
            if (
                not overlay_info.error
                and overlay_info.duration > 0
                and overlay_info.duration < float(config.still_seconds)
            ):
                self._result(
                    checks, "PF.OVERLAY.LENGTH", "WARNING", "Độ dài overlay",
                    "Overlay ngắn hơn thời lượng mỗi ảnh; tool sẽ lặp overlay.", str(overlay)
                )
        else:
            self._result(checks, "PF.OVERLAY", "PASS", "Video overlay", "Không sử dụng overlay.")

        total_audio_duration = 0.0
        audio_errors: list[str] = []
        for path in audio_paths:
            info = self.probe.probe(path)
            if info.error or info.audio_streams == 0:
                audio_errors.append(path.name)
            total_audio_duration += info.duration
        expected_duration = len(image_paths) * float(config.still_seconds)
        self._result(
            checks,
            "PF.AUDIO.READ",
            "BLOCKED" if audio_errors else "PASS",
            "Khả năng đọc nhạc",
            f"Không đọc được: {', '.join(audio_errors[:10])}" if audio_errors else f"{len(audio_paths)} file · {total_audio_duration:.1f}s.",
        )
        if audio_paths and total_audio_duration < expected_duration:
            self._result(
                checks,
                "PF.AUDIO.LENGTH",
                "PASS" if config.loop_audio else "WARNING",
                "Độ dài nhạc",
                (
                    f"Nhạc {total_audio_duration:.1f}s < video {expected_duration:.1f}s; "
                    + ("tool sẽ lặp playlist." if config.loop_audio else "phần cuối có thể không có nhạc.")
                ),
            )

        snapshot = project_snapshot or {}
        project_fps = float(snapshot.get("fps") or 0)
        fps_match = not project_fps or math.isclose(project_fps, float(config.fps), abs_tol=0.01)
        self._result(
            checks,
            "PF.PROJECT.FPS",
            "PASS" if fps_match else "BLOCKED",
            "FPS project",
            f"Project {project_fps:g} fps · cấu hình {config.fps:g} fps." if project_fps else "Không đọc được FPS project.",
        )
        project_width = int(snapshot.get("width") or 0)
        project_height = int(snapshot.get("height") or 0)
        resolution_match = (
            not project_width
            or (project_width == int(config.width) and project_height == int(config.height))
        )
        self._result(
            checks,
            "PF.PROJECT.RES",
            "PASS" if resolution_match else "WARNING",
            "Độ phân giải project",
            (
                f"Project {project_width}×{project_height} · cấu hình "
                f"{config.width}×{config.height}."
            ) if project_width else "Không đọc được độ phân giải project.",
        )

        available_codecs = snapshot.get("codecs", [])
        codec_match = (
            not available_codecs
            or str(config.render_codec) in {str(codec) for codec in available_codecs}
        )
        self._result(
            checks,
            "PF.CODEC",
            "PASS" if codec_match else "BLOCKED",
            "Codec render",
            f"{config.render_format}/{config.render_codec}"
            + ("" if codec_match else " không có trong Resolve hiện tại."),
        )

        for code, label, file_path, extensions in (
            ("PF.DRX", "Color Grade", getattr(config, "drx_file", ""), {".drx"}),
            ("PF.FUSION", "Fusion template", getattr(config, "fusion_comp_file", ""), {".comp", ".setting"}),
        ):
            if not file_path:
                self._result(checks, code, "PASS", label, "Không sử dụng.")
            else:
                path = Path(file_path)
                valid = path.is_file() and path.suffix.casefold() in extensions
                self._result(
                    checks, code, "PASS" if valid else "BLOCKED", label,
                    str(path) if valid else "File thiếu hoặc sai phần mở rộng.", str(path)
                )

        output_dir = Path(config.output_dir) if config.output_dir else None
        if not output_dir:
            self._result(checks, "PF.OUTPUT", "BLOCKED", "Thư mục xuất", "Chưa chọn thư mục xuất.")
        else:
            output_dir.mkdir(parents=True, exist_ok=True)
            usage = shutil.disk_usage(output_dir)
            estimated = int(
                expected_duration
                * (int(config.bitrate_kbps) + 192)
                * 1000
                / 8
                * (2.2 if str(config.workflow).startswith("2 giai") else 1.2)
            )
            enough = usage.free > estimated * 1.15
            self._result(
                checks,
                "PF.DISK",
                "PASS" if enough else "BLOCKED",
                "Dung lượng ổ đĩa",
                f"Cần khoảng {estimated / 1024**3:.2f} GB · trống {usage.free / 1024**3:.2f} GB.",
                str(output_dir),
            )
            expected_output = output_dir / f"{config.timeline_name}.{config.render_format}"
            self._result(
                checks,
                "PF.OUTPUT.EXISTS",
                "WARNING" if expected_output.exists() else "PASS",
                "Output đã tồn tại",
                str(expected_output) if expected_output.exists() else "Chưa có file trùng tên.",
                str(expected_output),
            )

        status = "BLOCKED" if any(check.level == "BLOCKED" for check in checks) else (
            "WARNING" if any(check.level == "WARNING" for check in checks) else "PASS"
        )
        return PreflightReport(status=status, checks=checks)


@dataclass
class PostflightResult:
    status: str
    path: str
    checks: list[CheckResult]
    media: Optional[MediaInfo] = None
    created_at: str = field(default_factory=utc_now)

    @property
    def verified(self) -> bool:
        return self.status == "VERIFIED"

    def to_dict(self) -> dict[str, Any]:
        return {
            "status": self.status,
            "path": self.path,
            "created_at": self.created_at,
            "checks": [asdict(check) for check in self.checks],
            "media": asdict(self.media) if self.media else None,
        }


class PostflightVerifier:
    def __init__(self, probe: Optional[MediaProbe] = None) -> None:
        self.probe = probe or MediaProbe(timeout_seconds=60)

    def verify(
        self,
        path: str | Path,
        expected_width: int,
        expected_height: int,
        expected_fps: float,
        expected_duration: float,
        require_audio: bool,
        deep_decode: bool = True,
        duration_tolerance_seconds: float = 1.0,
    ) -> PostflightResult:
        output = Path(path)
        checks: list[CheckResult] = []
        if not output.is_file():
            checks.append(CheckResult("VF.FILE", "BLOCKED", "File output", "File không tồn tại.", str(output)))
            return PostflightResult("FAILED", str(output), checks)
        minimum_bytes = max(1024, int(max(0.0, expected_duration) * 1000))
        size_ok = output.stat().st_size >= minimum_bytes
        checks.append(CheckResult(
            "VF.SIZE", "PASS" if size_ok else "BLOCKED", "Kích thước file",
            (
                f"{output.stat().st_size / 1024**2:.2f} MB · "
                f"ngưỡng {minimum_bytes / 1024**2:.2f} MB"
            ),
            str(output)
        ))
        info = self.probe.probe(output)
        if info.error:
            checks.append(CheckResult("VF.PROBE", "BLOCKED", "FFprobe", info.error, str(output)))
            return PostflightResult("FAILED", str(output), checks, info)
        checks.append(CheckResult(
            "VF.VIDEO", "PASS" if info.video_streams else "BLOCKED", "Video stream",
            f"{info.video_streams} stream.", str(output)
        ))
        checks.append(CheckResult(
            "VF.AUDIO",
            "PASS" if (not require_audio or info.audio_streams > 0) else "BLOCKED",
            "Audio stream",
            f"{info.audio_streams} stream.", str(output),
        ))
        resolution_ok = info.width == expected_width and info.height == expected_height
        checks.append(CheckResult(
            "VF.RES", "PASS" if resolution_ok else "BLOCKED", "Độ phân giải",
            f"Thực tế {info.width}×{info.height} · dự kiến {expected_width}×{expected_height}.",
            str(output),
        ))
        fps_ok = math.isclose(info.fps, expected_fps, abs_tol=0.05)
        checks.append(CheckResult(
            "VF.FPS", "PASS" if fps_ok else "BLOCKED", "FPS",
            f"Thực tế {info.fps:.3f} · dự kiến {expected_fps:.3f}.", str(output)
        ))
        duration_ok = abs(info.duration - expected_duration) <= duration_tolerance_seconds
        checks.append(CheckResult(
            "VF.DURATION", "PASS" if duration_ok else "BLOCKED", "Thời lượng",
            f"Thực tế {info.duration:.3f}s · dự kiến {expected_duration:.3f}s.", str(output)
        ))
        if deep_decode:
            decoded, error = self.probe.decode_last_frame(output)
            checks.append(CheckResult(
                "VF.LAST_FRAME", "PASS" if decoded else "BLOCKED", "Decode frame cuối",
                "Đọc được frame cuối." if decoded else error, str(output)
            ))
        status = "VERIFIED" if all(not check.blocking for check in checks) else "FAILED"
        return PostflightResult(status, str(output), checks, info)


@dataclass
class ManifestEvent:
    timestamp: str
    action: str
    status: str
    detail: str = ""


@dataclass
class JobManifest:
    job: str
    source: str
    profile: str
    output: str
    status: str = "pending"
    last_action: str = ""
    attempt: int = 0
    error: str = ""
    created_at: str = field(default_factory=utc_now)
    updated_at: str = field(default_factory=utc_now)
    history: list[ManifestEvent] = field(default_factory=list)
    result: dict[str, Any] = field(default_factory=dict)
    preflight: dict[str, Any] = field(default_factory=dict)
    postflight: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "JobManifest":
        history = [
            event if isinstance(event, ManifestEvent) else ManifestEvent(**event)
            for event in payload.get("history", [])
        ]
        accepted = {
            key: value
            for key, value in payload.items()
            if key in cls.__dataclass_fields__ and key != "history"
        }
        return cls(**accepted, history=history)

    def record(self, action: str, status: str, detail: str = "") -> None:
        self.last_action = action
        self.status = status
        self.updated_at = utc_now()
        self.history.append(ManifestEvent(self.updated_at, action, status, detail))

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        return payload


class ManifestStore:
    def __init__(self, output_dir: str | Path) -> None:
        self.root = Path(output_dir) / ".hcosmic" / "manifests"
        self.root.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def _filename(job: str) -> str:
        safe = re.sub(r"[^A-Za-z0-9._-]+", "_", job).strip("._") or "job"
        return safe + ".json"

    def path_for(self, job: str) -> Path:
        return self.root / self._filename(job)

    def load(self, job: str) -> Optional[JobManifest]:
        path = self.path_for(job)
        if not path.is_file():
            return None
        try:
            return JobManifest.from_dict(json.loads(path.read_text(encoding="utf-8")))
        except (OSError, ValueError, TypeError):
            return None

    def save(self, manifest: JobManifest) -> Path:
        path = self.path_for(manifest.job)
        atomic_write_json(path, manifest.to_dict())
        return path

    def all(self) -> list[JobManifest]:
        manifests: list[JobManifest] = []
        for path in sorted(self.root.glob("*.json"), key=natural_key):
            try:
                manifests.append(JobManifest.from_dict(json.loads(path.read_text(encoding="utf-8"))))
            except (OSError, ValueError, TypeError):
                continue
        return manifests


@dataclass
class ActionNode:
    id: str
    label: str
    run: Callable[[dict[str, Any]], Any]
    prerequisites: tuple[str, ...] = ()
    verify: Optional[Callable[[dict[str, Any], Any], bool]] = None
    rollback: Optional[Callable[[dict[str, Any], Any], None]] = None
    max_retries: int = 0
    retry_backoff_seconds: float = 1.0
    fatal: bool = True
    enabled: bool = True


@dataclass
class GraphResult:
    status: str
    outputs: dict[str, Any]
    failed_node: str = ""
    error: str = ""


class ActionGraphExecutor:
    def __init__(
        self,
        manifest_store: ManifestStore,
        on_event: Optional[Callable[[dict[str, Any]], None]] = None,
        should_cancel: Optional[Callable[[], bool]] = None,
    ) -> None:
        self.manifest_store = manifest_store
        self.on_event = on_event or (lambda _event: None)
        self.should_cancel = should_cancel or (lambda: False)

    def _emit(self, node: ActionNode, status: str, detail: str = "", attempt: int = 0) -> None:
        self.on_event({
            "code": node.id,
            "action": node.label,
            "page": "Action Graph",
            "status": status,
            "detail": detail,
            "attempt": attempt,
        })

    def execute(
        self,
        nodes: list[ActionNode],
        context: dict[str, Any],
        manifest: JobManifest,
    ) -> GraphResult:
        outputs: dict[str, Any] = {}
        completed: set[str] = set()
        pending = [node for node in nodes if node.enabled]
        while pending:
            progressed = False
            for node in list(pending):
                if not set(node.prerequisites).issubset(completed):
                    continue
                if self.should_cancel():
                    manifest.record(node.id, "cancelled", "Người dùng yêu cầu dừng.")
                    self.manifest_store.save(manifest)
                    return GraphResult("CANCELLED", outputs, node.id, "Đã hủy.")
                progressed = True
                pending.remove(node)
                last_error: Optional[Exception] = None
                for attempt in range(1, node.max_retries + 2):
                    manifest.attempt += 1
                    manifest.record(node.id, "running", f"Lần thử {attempt}.")
                    self.manifest_store.save(manifest)
                    self._emit(node, "running", f"Lần thử {attempt}.", attempt)
                    result: Any = None
                    try:
                        result = node.run(context)
                        if node.verify and not node.verify(context, result):
                            raise RuntimeError(f"Verify của node {node.id} không đạt.")
                        outputs[node.id] = result
                        context["outputs"] = outputs
                        completed.add(node.id)
                        manifest.record(node.id, "done", f"Hoàn tất lần thử {attempt}.")
                        self.manifest_store.save(manifest)
                        self._emit(node, "done", "Hoàn tất.", attempt)
                        last_error = None
                        break
                    except Exception as exc:
                        last_error = exc
                        manifest.error = str(exc)
                        manifest.record(node.id, "retrying" if attempt <= node.max_retries else "failed", str(exc))
                        self.manifest_store.save(manifest)
                        self._emit(
                            node,
                            "running" if attempt <= node.max_retries else "error",
                            str(exc),
                            attempt,
                        )
                        if node.rollback:
                            try:
                                node.rollback(context, result)
                            except Exception as rollback_error:
                                self._emit(node, "error", f"Rollback lỗi: {rollback_error}", attempt)
                        if attempt <= node.max_retries:
                            time.sleep(node.retry_backoff_seconds * attempt)
                if last_error is not None:
                    if node.fatal:
                        return GraphResult("FAILED", outputs, node.id, str(last_error))
                    completed.add(node.id)
            if not progressed:
                blocked = ", ".join(node.id for node in pending)
                error = f"Action graph có dependency không thể giải quyết: {blocked}"
                manifest.record("GRAPH", "failed", error)
                self.manifest_store.save(manifest)
                return GraphResult("FAILED", outputs, "GRAPH", error)
        return GraphResult("COMPLETED", outputs)


@dataclass
class ProductionProfile:
    name: str
    enabled: bool = True
    width: Optional[int] = None
    height: Optional[int] = None
    fps: Optional[float] = None
    render_format: Optional[str] = None
    render_codec: Optional[str] = None
    bitrate_kbps: Optional[int] = None
    overlay_file: Optional[str] = None
    music_source: Optional[str] = None
    output_dir: Optional[str] = None
    render_preset: Optional[str] = None
    workflow: Optional[str] = None
    suffix: str = ""
    priority: int = 100

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "ProductionProfile":
        accepted = {
            key: value
            for key, value in payload.items()
            if key in cls.__dataclass_fields__
        }
        return cls(**accepted)

    def apply(self, config: Any) -> Any:
        updates: dict[str, Any] = {}
        for field_name in (
            "width", "height", "fps", "render_format", "render_codec",
            "bitrate_kbps", "overlay_file", "music_source", "output_dir",
            "render_preset", "workflow",
        ):
            value = getattr(self, field_name)
            if value is not None and value != "":
                updates[field_name] = value
        return replace(config, **updates)


def load_profiles(path: str | Path) -> list[ProductionProfile]:
    profile_path = Path(path)
    if not profile_path.is_file():
        return []
    payload = json.loads(profile_path.read_text(encoding="utf-8"))
    if isinstance(payload, dict):
        payload = payload.get("profiles", [])
    return [
        ProductionProfile.from_dict(item)
        for item in payload
        if isinstance(item, dict) and item.get("enabled", True)
    ]


def save_profiles(path: str | Path, profiles: list[ProductionProfile]) -> None:
    target = Path(path)
    atomic_write_json(target, {"profiles": [asdict(profile) for profile in profiles]})


@dataclass
class SchedulerSettings:
    enabled: bool = False
    start_at: str = ""
    batch_size: int = 25
    pause_between_batches_seconds: int = 0


class QueueScheduler:
    def __init__(
        self,
        settings: SchedulerSettings,
        on_tick: Optional[Callable[[dict[str, Any]], None]] = None,
        should_cancel: Optional[Callable[[], bool]] = None,
    ) -> None:
        self.settings = settings
        self.on_tick = on_tick or (lambda _event: None)
        self.should_cancel = should_cancel or (lambda: False)

    def wait_until_start(self) -> None:
        if not self.settings.enabled or not self.settings.start_at.strip():
            return
        try:
            target = datetime.fromisoformat(self.settings.start_at.strip())
            if target.tzinfo is None:
                target = target.astimezone()
        except ValueError as exc:
            raise ValueError("Lịch bắt đầu phải có dạng YYYY-MM-DD HH:MM.") from exc
        while True:
            if self.should_cancel():
                raise RuntimeError("Đã hủy trong lúc chờ lịch.")
            remaining = (target - datetime.now().astimezone()).total_seconds()
            if remaining <= 0:
                return
            self.on_tick({
                "type": "schedule",
                "remaining_seconds": remaining,
                "message": f"Chờ lịch: còn {int(remaining)} giây.",
            })
            time.sleep(min(1.0, remaining))

    def batches(self, jobs: list[Any]) -> Iterable[list[Any]]:
        size = max(1, int(self.settings.batch_size))
        for index in range(0, len(jobs), size):
            yield jobs[index:index + size]
            if (
                index + size < len(jobs)
                and self.settings.pause_between_batches_seconds > 0
            ):
                end = time.monotonic() + self.settings.pause_between_batches_seconds
                while time.monotonic() < end:
                    if self.should_cancel():
                        raise RuntimeError("Đã hủy giữa hai batch.")
                    time.sleep(min(1.0, end - time.monotonic()))


@dataclass
class DashboardSnapshot:
    total_jobs: int
    completed_jobs: int
    failed_jobs: int
    skipped_jobs: int
    current_job: str
    elapsed_seconds: float
    eta_seconds: float
    jobs_per_hour: float
    gpu_utilization: float = 0.0
    gpu_memory_mb: float = 0.0
    gpu_temperature_c: float = 0.0
    disk_free_bytes: int = 0

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


class DashboardTracker:
    def __init__(self, total_jobs: int, output_dir: str | Path) -> None:
        self.total_jobs = total_jobs
        self.output_dir = Path(output_dir)
        self.started = time.monotonic()
        self.completed = 0
        self.failed = 0
        self.skipped = 0
        self.current = ""

    @staticmethod
    def _gpu_metrics() -> tuple[float, float, float]:
        command = [
            "nvidia-smi",
            "--query-gpu=utilization.gpu,memory.used,temperature.gpu",
            "--format=csv,noheader,nounits",
        ]
        try:
            result = subprocess.run(
                command,
                capture_output=True,
                text=True,
                timeout=3,
                check=False,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            first = result.stdout.strip().splitlines()[0]
            utilization, memory, temperature = [
                float(value.strip()) for value in first.split(",")[:3]
            ]
            return utilization, memory, temperature
        except (OSError, ValueError, IndexError, subprocess.TimeoutExpired):
            return 0.0, 0.0, 0.0

    def snapshot(self) -> DashboardSnapshot:
        elapsed = max(0.001, time.monotonic() - self.started)
        finished = self.completed + self.failed + self.skipped
        rate_per_second = finished / elapsed if finished else 0.0
        eta = (
            (self.total_jobs - finished) / rate_per_second
            if rate_per_second > 0
            else 0.0
        )
        gpu_util, gpu_memory, gpu_temp = self._gpu_metrics()
        try:
            disk_free = shutil.disk_usage(self.output_dir).free
        except OSError:
            disk_free = 0
        return DashboardSnapshot(
            total_jobs=self.total_jobs,
            completed_jobs=self.completed,
            failed_jobs=self.failed,
            skipped_jobs=self.skipped,
            current_job=self.current,
            elapsed_seconds=elapsed,
            eta_seconds=eta,
            jobs_per_hour=rate_per_second * 3600,
            gpu_utilization=gpu_util,
            gpu_memory_mb=gpu_memory,
            gpu_temperature_c=gpu_temp,
            disk_free_bytes=disk_free,
        )


@dataclass
class NotificationSettings:
    channel: str = "none"
    notify_success: bool = True
    notify_failure: bool = True


class NotificationManager:
    def __init__(self, settings: NotificationSettings) -> None:
        self.settings = settings

    @staticmethod
    def _post_json(url: str, payload: dict[str, Any]) -> None:
        request = urllib.request.Request(
            url,
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(request, timeout=15) as response:
            if response.status >= 400:
                raise RuntimeError(f"HTTP {response.status}")

    def send(self, title: str, message: str, success: bool) -> None:
        if self.settings.channel == "none":
            return
        if success and not self.settings.notify_success:
            return
        if not success and not self.settings.notify_failure:
            return
        channel = self.settings.channel.casefold()
        if channel == "slack":
            webhook = os.environ.get("H_COSMIC_SLACK_WEBHOOK", "")
            if not webhook:
                raise RuntimeError("Thiếu biến H_COSMIC_SLACK_WEBHOOK.")
            self._post_json(webhook, {"text": f"*{title}*\n{message}"})
        elif channel == "telegram":
            token = os.environ.get("H_COSMIC_TELEGRAM_TOKEN", "")
            chat_id = os.environ.get("H_COSMIC_TELEGRAM_CHAT_ID", "")
            if not token or not chat_id:
                raise RuntimeError(
                    "Thiếu H_COSMIC_TELEGRAM_TOKEN hoặc H_COSMIC_TELEGRAM_CHAT_ID."
                )
            url = f"https://api.telegram.org/bot{token}/sendMessage"
            self._post_json(url, {"chat_id": chat_id, "text": f"{title}\n{message}"})
        elif channel == "email":
            host = os.environ.get("H_COSMIC_SMTP_HOST", "")
            port = int(os.environ.get("H_COSMIC_SMTP_PORT", "587"))
            user = os.environ.get("H_COSMIC_SMTP_USER", "")
            password = os.environ.get("H_COSMIC_SMTP_PASSWORD", "")
            recipient = os.environ.get("H_COSMIC_EMAIL_TO", "")
            if not all((host, user, password, recipient)):
                raise RuntimeError("Thiếu cấu hình SMTP trong biến môi trường H_COSMIC_*.")
            mail = EmailMessage()
            mail["Subject"] = title
            mail["From"] = user
            mail["To"] = recipient
            mail.set_content(message)
            with smtplib.SMTP(host, port, timeout=15) as server:
                server.starttls()
                server.login(user, password)
                server.send_message(mail)
        else:
            raise ValueError(f"Kênh thông báo không hỗ trợ: {self.settings.channel}")


class IntermediateManager:
    POLICIES = {"keep", "delete_verified", "zip_then_delete"}

    def __init__(self, output_dir: str | Path, policy: str = "keep") -> None:
        self.output_dir = Path(output_dir).resolve()
        self.policy = policy if policy in self.POLICIES else "keep"

    def _validated_target(self, path: str | Path) -> Path:
        target = Path(path).resolve()
        if self.output_dir not in target.parents:
            raise RuntimeError("Thư mục trung gian nằm ngoài thư mục output.")
        if not target.name.startswith("_batch_clips_"):
            raise RuntimeError("Chỉ quản lý thư mục trung gian do H Cosmic tạo.")
        return target

    def apply(self, path: str | Path, verified: bool) -> dict[str, Any]:
        if not path or self.policy == "keep" or not verified:
            return {"policy": self.policy, "action": "kept", "path": str(path)}
        target = self._validated_target(path)
        if not target.is_dir():
            return {"policy": self.policy, "action": "missing", "path": str(target)}
        if self.policy == "delete_verified":
            shutil.rmtree(target)
            return {"policy": self.policy, "action": "deleted", "path": str(target)}
        archive = target.with_suffix(".zip")
        with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as bundle:
            for file in target.rglob("*"):
                if file.is_file():
                    bundle.write(file, file.relative_to(target.parent))
        shutil.rmtree(target)
        return {
            "policy": self.policy,
            "action": "archived_and_deleted",
            "path": str(target),
            "archive": str(archive),
        }


@dataclass
class ProductionJob:
    id: str
    source: Path
    profile: ProductionProfile
    config: Any
    output: Path


class ProductionCoordinator:
    def __init__(
        self,
        engine: Any,
        on_event: Optional[Callable[[dict[str, Any]], None]] = None,
        on_dashboard: Optional[Callable[[dict[str, Any]], None]] = None,
        should_cancel: Optional[Callable[[], bool]] = None,
    ) -> None:
        self.engine = engine
        self.on_event = on_event or (lambda _event: None)
        self.on_dashboard = on_dashboard or (lambda _snapshot: None)
        self.should_cancel = should_cancel or (lambda: False)
        self.preflight = PreflightValidator()
        self.postflight = PostflightVerifier()
        self._base_engine_progress = getattr(
            engine, "progress", lambda _value, _message: None
        )

    def _emit(self, code: str, status: str, detail: str, page: str = "Production") -> None:
        self.on_event({
            "code": code,
            "status": status,
            "detail": detail,
            "page": page,
            "action": code,
        })

    def _profiles(self, config: Any) -> list[ProductionProfile]:
        if getattr(config, "use_profiles", False) and getattr(config, "profiles_file", ""):
            profiles = load_profiles(config.profiles_file)
            if profiles:
                return profiles
        return [ProductionProfile(
            name="Default",
            width=config.width,
            height=config.height,
            fps=config.fps,
            render_format=config.render_format,
            render_codec=config.render_codec,
            bitrate_kbps=config.bitrate_kbps,
            overlay_file=config.overlay_file,
            render_preset=config.render_preset,
            workflow=config.workflow,
        )]

    def plan_jobs(self, config: Any) -> list[ProductionJob]:
        from resolve_batch_core import discover_image_groups, safe_name

        groups = discover_image_groups(config.image_source, config.multi_folder_mode)
        profiles = self._profiles(config)
        jobs: list[ProductionJob] = []
        multiple_groups = len(groups) > 1 or config.multi_folder_mode
        multiple_profiles = len(profiles) > 1
        for group in groups:
            for profile in profiles:
                child = profile.apply(config)
                parts = [safe_name(config.timeline_name)]
                if multiple_groups:
                    parts.append(safe_name(group.name))
                if multiple_profiles:
                    parts.append(safe_name(profile.suffix or profile.name))
                name = "_".join(part for part in parts if part)
                child = replace(
                    child,
                    image_source=str(group),
                    timeline_name=name,
                    multi_folder_mode=False,
                )
                output = Path(child.output_dir) / f"{name}.{child.render_format}"
                jobs.append(ProductionJob(
                    id=name,
                    source=group,
                    profile=profile,
                    config=child,
                    output=output,
                ))
        ids = [job.id.casefold() for job in jobs]
        outputs = [
            os.path.normcase(os.path.abspath(str(job.output)))
            for job in jobs
        ]
        if len(ids) != len(set(ids)):
            raise ValueError(
                "Các profile tạo job trùng tên. Hãy đặt suffix khác nhau."
            )
        if len(outputs) != len(set(outputs)):
            raise ValueError(
                "Các profile tạo output trùng đường dẫn. Hãy đổi suffix hoặc output_dir."
            )
        return sorted(
            jobs,
            key=lambda job: (
                int(job.profile.priority),
                natural_key(job.source),
                natural_key(job.id),
            ),
        )

    def _project_snapshot(self, config: Any) -> dict[str, Any]:
        snapshot = self.engine.snapshot()
        try:
            codecs = self.engine.project.GetRenderCodecs(config.render_format) or {}
            snapshot["codecs"] = list(codecs.values())
        except Exception:
            snapshot["codecs"] = []
        return snapshot

    def _run_engine(self, job: ProductionJob, action: str) -> dict[str, Any]:
        child = job.config
        if str(child.workflow).startswith("2 giai"):
            if action != "render":
                raise RuntimeError("Workflow 2 giai đoạn cần hành động render.")
            return self.engine.build_two_stage(child, start_render=True)
        return self.engine.build_direct(
            child,
            queue_render=action in {"queue", "render"},
            start_render=action == "render",
        )

    @staticmethod
    def _quarantine(path: Path, folder_name: str, job_id: str) -> Optional[Path]:
        if not path.is_file():
            return None
        target_dir = path.parent / folder_name
        target_dir.mkdir(parents=True, exist_ok=True)
        target = target_dir / f"{job_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}{path.suffix}"
        counter = 2
        while target.exists():
            target = target_dir / (
                f"{job_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{counter}{path.suffix}"
            )
            counter += 1
        shutil.move(str(path), str(target))
        return target

    @staticmethod
    def _move_verified(path: Path) -> Optional[Path]:
        if not path.is_file():
            return None
        target_dir = path.parent / "_verified"
        target_dir.mkdir(parents=True, exist_ok=True)
        target = target_dir / path.name
        if target.exists():
            target = target_dir / (
                f"{path.stem}_{datetime.now().strftime('%Y%m%d_%H%M%S')}{path.suffix}"
            )
        shutil.move(str(path), str(target))
        return target

    def run(self, config: Any, action: str) -> dict[str, Any]:
        from resolve_batch_core import AUDIO_EXTENSIONS, IMAGE_EXTENSIONS, discover_files

        jobs = self.plan_jobs(config)
        if not jobs:
            raise RuntimeError("Không có job sản xuất.")
        output_dir = Path(config.output_dir)
        store = ManifestStore(output_dir)
        tracker = DashboardTracker(len(jobs), output_dir)
        last_live_dashboard_at = 0.0

        def live_engine_progress(value: float, message: str) -> None:
            nonlocal last_live_dashboard_at
            self._base_engine_progress(value, message)
            now = time.monotonic()
            if now - last_live_dashboard_at < 5.0 and value < 1.0:
                return
            last_live_dashboard_at = now
            current_job = tracker.current
            if current_job:
                tracker.current = f"{current_job} · {message}"
            self.on_dashboard(tracker.snapshot().to_dict())
            tracker.current = current_job

        if hasattr(self.engine, "progress"):
            self.engine.progress = live_engine_progress
        scheduler = QueueScheduler(
            SchedulerSettings(
                enabled=getattr(config, "schedule_enabled", False),
                start_at=getattr(config, "schedule_start", ""),
                batch_size=getattr(config, "batch_size", 25),
                pause_between_batches_seconds=getattr(
                    config, "pause_between_batches_seconds", 0
                ),
            ),
            on_tick=lambda event: self.on_event({
                "code": "SCHEDULER.WAIT",
                "status": "running",
                "detail": event["message"],
                "page": "Scheduler",
                "action": "Chờ lịch bắt đầu",
            }),
            should_cancel=self.should_cancel,
        )
        notifier = NotificationManager(NotificationSettings(
            channel=getattr(config, "notification_channel", "none"),
            notify_success=getattr(config, "notify_success", True),
            notify_failure=getattr(config, "notify_failure", True),
        ))
        scheduler.wait_until_start()
        session_results: list[dict[str, Any]] = []

        for batch_index, batch in enumerate(scheduler.batches(jobs), 1):
            self._emit(
                "SCHEDULER.BATCH",
                "running",
                f"Batch {batch_index}: {len(batch)} job.",
                "Scheduler",
            )
            for job in batch:
                if self.should_cancel():
                    raise RuntimeError("Đã hủy phiên sản xuất.")
                tracker.current = job.id
                health = tracker.snapshot()
                self.on_dashboard(health.to_dict())
                temperature_limit = float(
                    getattr(config, "gpu_temperature_limit_c", 88)
                )
                minimum_disk = float(
                    getattr(config, "minimum_free_disk_gb", 5.0)
                ) * 1024**3
                if (
                    health.gpu_temperature_c > 0
                    and health.gpu_temperature_c >= temperature_limit
                ):
                    self._emit(
                        "HEALTH.GPU",
                        "error",
                        f"GPU {health.gpu_temperature_c:.0f}°C ≥ giới hạn {temperature_limit:.0f}°C.",
                        "Dashboard",
                    )
                    raise RuntimeError("Tự dừng vì nhiệt độ GPU vượt giới hạn.")
                if health.disk_free_bytes and health.disk_free_bytes < minimum_disk:
                    self._emit(
                        "HEALTH.DISK",
                        "error",
                        (
                            f"Ổ đĩa còn {health.disk_free_bytes / 1024**3:.2f} GB "
                            f"< giới hạn {minimum_disk / 1024**3:.2f} GB."
                        ),
                        "Dashboard",
                    )
                    raise RuntimeError("Tự dừng vì dung lượng ổ đĩa dưới ngưỡng an toàn.")
                existing = store.load(job.id)
                manifest = existing or JobManifest(
                    job=job.id,
                    source=str(job.source),
                    profile=job.profile.name,
                    output=str(job.output),
                )
                if existing and existing.status == "failed":
                    job.config = replace(job.config, replace_existing=True)
                if (
                    getattr(config, "resume_enabled", True)
                    and existing
                    and existing.status in {"verified", "completed"}
                    and Path(existing.output).is_file()
                ):
                    job.output = Path(existing.output)
                    tracker.skipped += 1
                    self._emit("RESUME.SKIP", "done", f"{job.id} đã hoàn tất; bỏ qua.")
                    self.on_dashboard(tracker.snapshot().to_dict())
                    session_results.append({"job": job.id, "status": "skipped"})
                    continue

                images = discover_files(str(job.source), IMAGE_EXTENSIONS)
                audio = discover_files(job.config.music_source, AUDIO_EXTENSIONS)
                overlay = Path(job.config.overlay_file) if job.config.overlay_file else None
                if (
                    getattr(config, "skip_existing", True)
                    and job.output.is_file()
                    and not existing
                    and action == "render"
                ):
                    existing_check = self.postflight.verify(
                        job.output,
                        expected_width=int(job.config.width),
                        expected_height=int(job.config.height),
                        expected_fps=float(job.config.fps),
                        expected_duration=len(images) * float(job.config.still_seconds),
                        require_audio=bool(audio),
                        deep_decode=getattr(job.config, "deep_verify", True),
                        duration_tolerance_seconds=float(
                            getattr(job.config, "duration_tolerance_seconds", 1.0)
                        ),
                    )
                    if existing_check.verified:
                        manifest.postflight = existing_check.to_dict()
                        manifest.record(
                            "RESUME.EXISTING", "verified",
                            "Output có sẵn đã vượt qua hậu kiểm; bỏ qua render."
                        )
                        store.save(manifest)
                        tracker.skipped += 1
                        session_results.append({
                            "job": job.id,
                            "status": "skipped_verified_existing",
                            "output": str(job.output),
                            "manifest": str(store.path_for(job.id)),
                        })
                        self._emit(
                            "RESUME.EXISTING", "done",
                            f"{job.id}: output có sẵn đã được FFprobe xác minh."
                        )
                        self.on_dashboard(tracker.snapshot().to_dict())
                        continue
                    quarantined = self._quarantine(
                        job.output, "_retry", job.id
                    )
                    self._emit(
                        "RESUME.EXISTING", "running",
                        f"Output có sẵn không đạt; chuyển vào {quarantined} và render lại."
                    )
                preflight_report: Optional[PreflightReport] = None
                engine_result: dict[str, Any] = {}
                postflight_result: Optional[PostflightResult] = None

                def run_preflight(_context: dict[str, Any]) -> PreflightReport:
                    nonlocal preflight_report
                    preflight_report = self.preflight.validate(
                        job.config,
                        images,
                        audio,
                        overlay,
                        self._project_snapshot(job.config),
                    )
                    manifest.preflight = preflight_report.to_dict()
                    store.save(manifest)
                    self._emit(
                        "PRECHECK",
                        "error" if preflight_report.blocked else "done",
                        f"{job.id}: {preflight_report.status} · {preflight_report.warnings} warning.",
                        "Preflight",
                    )
                    return preflight_report

                def run_production(_context: dict[str, Any]) -> dict[str, Any]:
                    nonlocal engine_result
                    engine_result = self._run_engine(job, action)
                    manifest.result = engine_result
                    if str(job.config.workflow).startswith("2 giai"):
                        manifest.record("PRODUCE", "stage_1_rendered", "Đã hoàn tất pipeline 2 giai đoạn.")
                    store.save(manifest)
                    return engine_result

                def rollback_production(
                    _context: dict[str, Any],
                    _result: Any,
                ) -> None:
                    try:
                        if self.engine.project.IsRenderingInProgress():
                            self.engine.project.StopRendering()
                    except Exception:
                        pass
                    if action == "render":
                        partial = Path(
                            engine_result.get("expected_output") or job.output
                        )
                        quarantined = self._quarantine(
                            partial, "_retry", job.id
                        )
                        if quarantined:
                            self._emit(
                                "PRODUCE.ROLLBACK",
                                "running",
                                f"Rollback: chuyển output dở vào {quarantined}.",
                                "Action Graph",
                            )
                    job.config = replace(
                        job.config,
                        replace_existing=True,
                        resume_enabled=True,
                    )

                def run_verify(_context: dict[str, Any]) -> PostflightResult:
                    nonlocal postflight_result, engine_result
                    if action != "render":
                        postflight_result = PostflightResult(
                            "SKIPPED", str(job.output),
                            [CheckResult("VF.SKIP", "PASS", "Hậu kiểm", f"Action={action}; chưa render.")]
                        )
                    else:
                        if postflight_result and not postflight_result.verified:
                            failed_path = Path(
                                engine_result.get("expected_output") or job.output
                            )
                            quarantined = self._quarantine(
                                failed_path, "_retry", job.id
                            )
                            if quarantined:
                                self._emit(
                                    "VERIFY.RETRY",
                                    "running",
                                    f"Đã chuyển file lỗi vào {quarantined}; render lại.",
                                    "Postflight",
                                )
                            job.config = replace(
                                job.config,
                                replace_existing=True,
                                resume_enabled=True,
                            )
                            engine_result = self._run_engine(job, action)
                        actual_output = Path(
                            engine_result.get("expected_output") or job.output
                        )
                        postflight_result = self.postflight.verify(
                            actual_output,
                            expected_width=int(job.config.width),
                            expected_height=int(job.config.height),
                            expected_fps=float(job.config.fps),
                            expected_duration=len(images) * float(job.config.still_seconds),
                            require_audio=bool(audio),
                            deep_decode=getattr(job.config, "deep_verify", True),
                            duration_tolerance_seconds=float(
                                getattr(job.config, "duration_tolerance_seconds", 1.0)
                            ),
                        )
                    manifest.postflight = postflight_result.to_dict()
                    store.save(manifest)
                    return postflight_result

                def run_intermediate(_context: dict[str, Any]) -> dict[str, Any]:
                    path = engine_result.get("intermediate_dir", "")
                    verified = bool(
                        postflight_result
                        and postflight_result.status in {"VERIFIED", "SKIPPED"}
                    )
                    return IntermediateManager(
                        job.config.output_dir,
                        getattr(config, "intermediate_policy", "keep"),
                    ).apply(path, verified)

                def run_notify(_context: dict[str, Any]) -> bool:
                    success = bool(
                        postflight_result
                        and postflight_result.status in {"VERIFIED", "SKIPPED"}
                    )
                    notifier.send(
                        f"H Cosmic Studio · {'Hoàn tất' if success else 'Lỗi'}",
                        f"Job: {job.id}\nOutput: {job.output}\nStatus: {postflight_result.status if postflight_result else 'unknown'}",
                        success=success,
                    )
                    return True

                retries = max(0, int(getattr(config, "max_retries", 2)))
                backoff = max(0.0, float(getattr(config, "retry_backoff_seconds", 2.0)))
                nodes = [
                    ActionNode(
                        "PRECHECK", "Preflight Validator", run_preflight,
                        verify=lambda _ctx, report: not report.blocked,
                        max_retries=0,
                    ),
                    ActionNode(
                        "PRODUCE", "DaVinci production pipeline", run_production,
                        prerequisites=("PRECHECK",),
                        verify=lambda _ctx, result: bool(result),
                        rollback=rollback_production,
                        max_retries=retries,
                        retry_backoff_seconds=backoff,
                    ),
                    ActionNode(
                        "VERIFY", "FFprobe postflight", run_verify,
                        prerequisites=("PRODUCE",),
                        verify=lambda _ctx, result: result.status in {"VERIFIED", "SKIPPED"},
                        max_retries=retries if action == "render" else 0,
                        retry_backoff_seconds=backoff,
                    ),
                    ActionNode(
                        "INTERMEDIATE", "Intermediate file policy", run_intermediate,
                        prerequisites=("VERIFY",),
                        max_retries=1,
                        retry_backoff_seconds=backoff,
                        fatal=False,
                    ),
                    ActionNode(
                        "NOTIFY", "Remote notification", run_notify,
                        prerequisites=("VERIFY",),
                        max_retries=1,
                        retry_backoff_seconds=backoff,
                        fatal=False,
                        enabled=getattr(config, "notification_channel", "none") != "none",
                    ),
                ]
                executor = ActionGraphExecutor(
                    store,
                    on_event=self.on_event,
                    should_cancel=self.should_cancel,
                )
                graph_result = executor.execute(nodes, {"job": job}, manifest)
                if graph_result.status == "COMPLETED":
                    if (
                        action == "render"
                        and getattr(config, "move_verified_outputs", False)
                    ):
                        verified_path = self._move_verified(Path(
                            engine_result.get("expected_output") or job.output
                        ))
                        if verified_path:
                            job.output = verified_path
                            manifest.output = str(verified_path)
                            self._emit(
                                "VERIFY.ARCHIVE",
                                "done",
                                f"Output đạt chuẩn → {verified_path}.",
                                "Postflight",
                            )
                    manifest.record(
                        "SESSION",
                        "verified" if action == "render" else "completed",
                        "Job hoàn tất.",
                    )
                    manifest.error = ""
                    tracker.completed += 1
                elif graph_result.status == "CANCELLED":
                    manifest.record("SESSION", "cancelled", graph_result.error)
                    store.save(manifest)
                    raise RuntimeError("Đã hủy phiên sản xuất.")
                else:
                    manifest.record("SESSION", "failed", graph_result.error)
                    if action == "render":
                        latest_output = Path(
                            engine_result.get("expected_output") or job.output
                        )
                        quarantined = self._quarantine(
                            latest_output, "_failed", job.id
                        )
                        if quarantined:
                            self._emit(
                                "VERIFY.FAILED",
                                "error",
                                f"Đã chuyển output lỗi cuối vào {quarantined}.",
                                "Postflight",
                            )
                    tracker.failed += 1
                    try:
                        notifier.send(
                            "H Cosmic Studio · Job lỗi",
                            (
                                f"Job: {job.id}\n"
                                f"Node: {graph_result.failed_node}\n"
                                f"Lỗi: {graph_result.error}"
                            ),
                            success=False,
                        )
                    except Exception as notify_error:
                        self._emit(
                            "NOTIFY.FAILURE",
                            "error",
                            f"Không gửi được thông báo lỗi: {notify_error}",
                            "Notification",
                        )
                store.save(manifest)
                result_payload = {
                    "job": job.id,
                    "status": manifest.status,
                    "output": str(job.output),
                    "failed_node": graph_result.failed_node,
                    "error": graph_result.error,
                    "manifest": str(store.path_for(job.id)),
                }
                session_results.append(result_payload)
                self.on_dashboard(tracker.snapshot().to_dict())

        final_snapshot = tracker.snapshot()
        report = {
            "created_at": utc_now(),
            "action": action,
            "jobs": session_results,
            "dashboard": final_snapshot.to_dict(),
        }
        report_path = output_dir / f"enterprise_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        atomic_write_json(report_path, report)
        if hasattr(self.engine, "progress"):
            self.engine.progress = self._base_engine_progress
        return {
            "timeline": "",
            "jobs": [result["job"] for result in session_results],
            "results": session_results,
            "failures": [result for result in session_results if result["status"] == "failed"],
            "report_path": str(report_path),
            "dashboard": final_snapshot.to_dict(),
        }
