from __future__ import annotations

import ctypes
import hmac
import json
import os
import secrets
import sys
import threading
import time
import traceback
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Optional
from urllib.parse import urlparse

from production_runtime import PreflightValidator, ProductionCoordinator
from resolve_batch_core import (
    AUDIO_EXTENSIONS,
    IMAGE_EXTENSIONS,
    BatchConfig,
    ResolveBatchEngine,
    connect_resolve,
    discover_files,
    load_config,
    save_config,
)


APP_DIR = Path(__file__).resolve().parent
DEFAULT_CONFIG_FILE = APP_DIR / ".davinci_batch_config.json"
DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = 8765
MAX_REQUEST_BYTES = 2 * 1024 * 1024
AUTO_CONNECT_PROTOCOL = "h-cosmic-auto-v2"
RESOLVE_PROBE_INTERVAL_SECONDS = 2.0
ALLOWED_ORIGINS = {
    "https://nhhoang13all.xyz",
    "https://www.nhhoang13all.xyz",
    "http://localhost:3000",
    "http://localhost:4000",
    "http://127.0.0.1:3000",
    "http://127.0.0.1:4000",
}


def origin_allowed(origin: str) -> bool:
    return not origin or origin in ALLOWED_ORIGINS


class BridgeRuntime:
    def __init__(
        self,
        resolve: Any = None,
        config_file: Path = DEFAULT_CONFIG_FILE,
        access_key: str = "",
    ) -> None:
        self.resolve = resolve
        self.config_file = config_file
        self.access_key = (
            access_key
            or os.environ.get("H_COSMIC_BRIDGE_KEY", "")
            or secrets.token_hex(4)
        ).upper()
        self.lock = threading.RLock()
        self.cancel_event = threading.Event()
        self.worker: Optional[threading.Thread] = None
        self.task = ""
        self.progress = 0.0
        self.progress_text = "Sẵn sàng"
        self.dashboard: dict[str, Any] = {}
        self.result: dict[str, Any] = {}
        self.error = ""
        self.events: list[dict[str, Any]] = []
        self.sequence = 0
        self.last_resolve_probe = 0.0
        self.last_resolve_connected = bool(resolve)

    def _event(self, kind: str, payload: Any) -> None:
        with self.lock:
            self.sequence += 1
            self.events.append({
                "id": self.sequence,
                "at": datetime.now().astimezone().isoformat(timespec="seconds"),
                "kind": kind,
                "payload": payload,
            })
            self.events = self.events[-1000:]

    def _progress(self, value: float, text: str) -> None:
        with self.lock:
            self.progress = max(0.0, min(1.0, float(value)))
            self.progress_text = str(text)
        self._event("progress", {"value": self.progress, "text": text})

    def _dashboard(self, snapshot: dict[str, Any]) -> None:
        with self.lock:
            self.dashboard = dict(snapshot)
        self._event("dashboard", snapshot)

    def _action(self, event: dict[str, Any]) -> None:
        self._event("action", event)

    def _log(self, message: str) -> None:
        self._event("log", str(message))

    @property
    def busy(self) -> bool:
        return bool(self.worker and self.worker.is_alive())

    def config(self) -> BatchConfig:
        return load_config(self.config_file)

    def update_config(self, payload: dict[str, Any]) -> BatchConfig:
        config = BatchConfig.from_dict(payload)
        save_config(self.config_file, config)
        self._event("config", {"message": "Đã lưu cấu hình từ website."})
        return config

    def _resolve_instance(self) -> Any:
        if not self.refresh_resolve_connection(force=True):
            raise RuntimeError(
                "Chưa kết nối DaVinci Resolve. Hãy mở Resolve và bật "
                "Preferences > System > General > External scripting using > Local."
            )
        return self.resolve

    def refresh_resolve_connection(self, force: bool = False) -> bool:
        now = time.monotonic()
        with self.lock:
            if (
                not force
                and now - self.last_resolve_probe < RESOLVE_PROBE_INTERVAL_SECONDS
            ):
                return bool(self.resolve)
            self.last_resolve_probe = now

        candidate = self.resolve
        connected = False
        if candidate:
            try:
                connected = bool(candidate.GetProjectManager())
            except Exception:
                connected = False
        if not connected:
            candidate = connect_resolve()
            if candidate:
                try:
                    connected = bool(candidate.GetProjectManager())
                except Exception:
                    connected = False

        with self.lock:
            self.resolve = candidate if connected else None
            changed = connected != self.last_resolve_connected
            self.last_resolve_connected = connected
        if changed:
            self._event(
                "resolve",
                {
                    "connected": connected,
                    "message": (
                        "Đã tự động kết nối DaVinci Resolve."
                        if connected
                        else "DaVinci Resolve đã ngắt; bridge tiếp tục chờ."
                    ),
                },
            )
        return connected

    def status(self, after: int = 0) -> dict[str, Any]:
        resolve_connected = self.refresh_resolve_connection()
        with self.lock:
            events = [event for event in self.events if event["id"] > after]
            return {
                "bridge": "online",
                "resolve_connected": resolve_connected,
                "resolve_state": "ready" if resolve_connected else "waiting",
                "auto_connect": True,
                "busy": self.busy,
                "task": self.task,
                "progress": self.progress,
                "progress_text": self.progress_text,
                "dashboard": dict(self.dashboard),
                "result": dict(self.result),
                "error": self.error,
                "events": events[-300:],
                "last_event_id": self.sequence,
            }

    def _start(self, task: str, target: Any) -> None:
        with self.lock:
            if self.busy:
                raise RuntimeError(f"Bridge đang chạy tác vụ {self.task}.")
            self.cancel_event.clear()
            self.task = task
            self.progress = 0.0
            self.progress_text = f"Đang bắt đầu {task}"
            self.dashboard = {}
            self.result = {}
            self.error = ""

        def run() -> None:
            try:
                target()
            except Exception as exc:
                with self.lock:
                    self.error = str(exc)
                    self.progress_text = "Có lỗi"
                self._event("error", {
                    "message": str(exc),
                    "details": traceback.format_exc(),
                })
            finally:
                with self.lock:
                    self.task = ""

        self.worker = threading.Thread(
            target=run,
            name=f"h-cosmic-{task}",
            daemon=True,
        )
        self.worker.start()

    def start_preflight(self, payload: dict[str, Any]) -> None:
        config = self.update_config(payload)
        errors = config.validate(require_output=True)
        if errors:
            raise ValueError("\n".join(errors))

        def work() -> None:
            engine = ResolveBatchEngine(
                self._resolve_instance(),
                log=self._log,
                progress=self._progress,
                should_cancel=self.cancel_event.is_set,
                action=self._action,
            )
            coordinator = ProductionCoordinator(
                engine,
                on_event=self._action,
                on_dashboard=self._dashboard,
                should_cancel=self.cancel_event.is_set,
            )
            jobs = coordinator.plan_jobs(config)
            validator = PreflightValidator()
            reports: list[dict[str, Any]] = []
            blocked = 0
            warnings = 0
            for index, job in enumerate(jobs, 1):
                if self.cancel_event.is_set():
                    raise RuntimeError("Đã hủy PRECHECK.")
                snapshot = engine.snapshot()
                codecs = engine.project.GetRenderCodecs(
                    job.config.render_format
                ) or {}
                snapshot["codecs"] = list(codecs.values())
                images = discover_files(str(job.source), IMAGE_EXTENSIONS)
                audio = discover_files(job.config.music_source, AUDIO_EXTENSIONS)
                overlay = (
                    Path(job.config.overlay_file)
                    if job.config.overlay_file
                    else None
                )
                report = validator.validate(
                    job.config,
                    images,
                    audio,
                    overlay,
                    snapshot,
                )
                reports.append({
                    "job": job.id,
                    "profile": job.profile.name,
                    "report": report.to_dict(),
                })
                blocked += int(report.blocked)
                warnings += report.warnings
                for check in report.checks:
                    self._action({
                        "code": check.code,
                        "status": (
                            "error"
                            if check.level == "BLOCKED"
                            else "running"
                            if check.level == "WARNING"
                            else "done"
                        ),
                        "page": "Preflight",
                        "action": check.title,
                        "detail": f"{job.id} · {check.level} · {check.detail}",
                    })
                self._progress(
                    index / max(1, len(jobs)),
                    f"PRECHECK {index}/{len(jobs)}",
                )
            report_path = (
                Path(config.output_dir)
                / f"preflight_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            )
            report_path.write_text(
                json.dumps({"jobs": reports}, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
            with self.lock:
                self.result = {
                    "type": "preflight",
                    "jobs": len(jobs),
                    "blocked": blocked,
                    "warnings": warnings,
                    "status": (
                        "BLOCKED"
                        if blocked
                        else "WARNING"
                        if warnings
                        else "PASS"
                    ),
                    "report_path": str(report_path),
                }
                self.progress = 1.0
                self.progress_text = (
                    f"PRECHECK {self.result['status']} · {len(jobs)} job"
                )
            self._event("done", self.result)

        self._start("preflight", work)

    def start_run(self, action: str, payload: dict[str, Any]) -> None:
        if action not in {"build", "queue", "render"}:
            raise ValueError("Action phải là build, queue hoặc render.")
        config = self.update_config(payload)
        errors = config.validate(require_output=True)
        if errors:
            raise ValueError("\n".join(errors))

        def work() -> None:
            sleep_guard_active = False
            try:
                if config.prevent_sleep and hasattr(ctypes, "windll"):
                    ctypes.windll.kernel32.SetThreadExecutionState(0x80000001)
                    sleep_guard_active = True
                    self._log("Đã bật chế độ giữ Windows thức.")
                engine = ResolveBatchEngine(
                    self._resolve_instance(),
                    log=self._log,
                    progress=self._progress,
                    should_cancel=self.cancel_event.is_set,
                    action=self._action,
                )
                coordinator = ProductionCoordinator(
                    engine,
                    on_event=self._action,
                    on_dashboard=self._dashboard,
                    should_cancel=self.cancel_event.is_set,
                )
                result = coordinator.run(config, action)
                with self.lock:
                    self.result = result
                    self.progress = 1.0
                    self.progress_text = "Hoàn tất"
                self._event("done", result)
            finally:
                if sleep_guard_active:
                    ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)
                    self._log("Đã trả chế độ nguồn điện về bình thường.")

        self._start(action, work)

    def cancel(self) -> None:
        self.cancel_event.set()
        try:
            resolve = self._resolve_instance()
            project_manager = resolve.GetProjectManager()
            project = project_manager.GetCurrentProject() if project_manager else None
            if project and project.IsRenderingInProgress():
                project.StopRendering()
        except Exception:
            pass
        self._event("cancel", {"message": "Đã yêu cầu dừng an toàn."})


class ResolveWebBridge:
    def __init__(
        self,
        resolve: Any = None,
        host: str = DEFAULT_HOST,
        port: int = DEFAULT_PORT,
        access_key: str = "",
    ) -> None:
        if host not in {"127.0.0.1", "localhost"}:
            raise ValueError("Bridge chỉ được bind vào loopback.")
        self.host = host
        self.port = int(port)
        self.runtime = BridgeRuntime(resolve=resolve, access_key=access_key)
        self.server: Optional[ThreadingHTTPServer] = None
        self.thread: Optional[threading.Thread] = None

    @property
    def access_key(self) -> str:
        return self.runtime.access_key

    @property
    def busy(self) -> bool:
        return self.runtime.busy

    @property
    def running(self) -> bool:
        return bool(self.server and self.thread and self.thread.is_alive())

    def start(self) -> tuple[str, int, str]:
        if self.running:
            return self.host, self.port, self.access_key
        runtime = self.runtime

        class Handler(BaseHTTPRequestHandler):
            server_version = "HCosmicBridge/1.0"

            def log_message(self, _format: str, *_args: Any) -> None:
                return

            def _origin(self) -> str:
                return str(self.headers.get("Origin") or "")

            def _cors(self) -> bool:
                origin = self._origin()
                if origin:
                    self.send_header("Access-Control-Allow-Origin", origin)
                    self.send_header("Vary", "Origin")
                self.send_header(
                    "Access-Control-Allow-Headers",
                    "Content-Type, X-H-Cosmic-Key, X-H-Cosmic-Auto-Connect",
                )
                self.send_header(
                    "Access-Control-Allow-Methods",
                    "GET, POST, OPTIONS",
                )
                self.send_header("Access-Control-Allow-Private-Network", "true")
                return True

            def _json(self, status: int, payload: Any) -> None:
                if not origin_allowed(self._origin()):
                    status = 403
                    payload = {"error": "Origin is not allowed."}
                body = json.dumps(
                    payload,
                    ensure_ascii=False,
                    default=str,
                ).encode("utf-8")
                self.send_response(status)
                self._cors()
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Cache-Control", "no-store")
                self.send_header("X-Content-Type-Options", "nosniff")
                self.end_headers()
                self.wfile.write(body)

            def _authorized(self) -> bool:
                provided = str(self.headers.get("X-H-Cosmic-Key") or "").upper()
                return bool(provided) and hmac.compare_digest(
                    provided,
                    runtime.access_key,
                )

            def _auto_claim_allowed(self) -> bool:
                origin = self._origin()
                protocol = str(
                    self.headers.get("X-H-Cosmic-Auto-Connect") or ""
                )
                return (
                    bool(origin)
                    and origin in ALLOWED_ORIGINS
                    and hmac.compare_digest(protocol, AUTO_CONNECT_PROTOCOL)
                )

            def _payload(self) -> dict[str, Any]:
                length = int(self.headers.get("Content-Length") or 0)
                if length < 0 or length > MAX_REQUEST_BYTES:
                    raise ValueError("Request quá lớn.")
                raw = self.rfile.read(length) if length else b"{}"
                value = json.loads(raw.decode("utf-8"))
                if not isinstance(value, dict):
                    raise ValueError("Payload phải là JSON object.")
                return value

            def do_OPTIONS(self) -> None:
                origin = self._origin()
                if not origin_allowed(origin):
                    self._json(403, {"error": "Origin is not allowed."})
                    return
                self.send_response(204)
                self._cors()
                self.send_header("Content-Length", "0")
                self.end_headers()

            def do_GET(self) -> None:
                parsed = urlparse(self.path)
                if parsed.path == "/api/ping":
                    self._json(200, {
                        "bridge": "online",
                        "version": 2,
                        "auto_connect": True,
                    })
                    return
                if not self._authorized():
                    self._json(401, {"error": "Mã ghép nối không đúng."})
                    return
                try:
                    if parsed.path == "/api/health":
                        resolve_connected = runtime.refresh_resolve_connection()
                        self._json(200, {
                            "bridge": "online",
                            "version": 2,
                            "auto_connect": True,
                            "resolve_connected": resolve_connected,
                            "resolve_state": (
                                "ready" if resolve_connected else "waiting"
                            ),
                            "busy": runtime.busy,
                        })
                    elif parsed.path == "/api/config":
                        self._json(200, runtime.config().to_dict())
                    elif parsed.path == "/api/status":
                        after = 0
                        for part in parsed.query.split("&"):
                            if part.startswith("after="):
                                after = max(0, int(part.split("=", 1)[1] or 0))
                        self._json(200, runtime.status(after))
                    else:
                        self._json(404, {"error": "Endpoint không tồn tại."})
                except Exception as exc:
                    self._json(500, {"error": str(exc)})

            def do_POST(self) -> None:
                parsed = urlparse(self.path)
                if parsed.path == "/api/claim":
                    if not self._auto_claim_allowed():
                        self._json(403, {
                            "error": "Yêu cầu tự động kết nối không hợp lệ.",
                        })
                        return
                    self._json(200, {
                        "paired": True,
                        "access_key": runtime.access_key,
                        "expires_with_bridge": True,
                        "version": 2,
                    })
                    return
                if not self._authorized():
                    self._json(401, {"error": "Mã ghép nối không đúng."})
                    return
                try:
                    payload = self._payload()
                    if parsed.path == "/api/config":
                        config = runtime.update_config(payload.get("config", payload))
                        self._json(200, {"saved": True, "config": config.to_dict()})
                    elif parsed.path == "/api/preflight":
                        runtime.start_preflight(payload.get("config", payload))
                        self._json(202, {"started": True, "task": "preflight"})
                    elif parsed.path == "/api/run":
                        runtime.start_run(
                            str(payload.get("action") or ""),
                            payload.get("config") or {},
                        )
                        self._json(202, {
                            "started": True,
                            "task": payload.get("action"),
                        })
                    elif parsed.path == "/api/cancel":
                        runtime.cancel()
                        self._json(200, {"cancelled": True})
                    else:
                        self._json(404, {"error": "Endpoint không tồn tại."})
                except (ValueError, json.JSONDecodeError) as exc:
                    self._json(400, {"error": str(exc)})
                except RuntimeError as exc:
                    self._json(409, {"error": str(exc)})
                except Exception as exc:
                    self._json(500, {"error": str(exc)})

        self.server = ThreadingHTTPServer((self.host, self.port), Handler)
        self.port = int(self.server.server_address[1])
        self.server.daemon_threads = True
        self.thread = threading.Thread(
            target=self.server.serve_forever,
            name="h-cosmic-web-bridge",
            daemon=True,
        )
        self.thread.start()
        return self.host, self.port, self.access_key

    def stop(self) -> None:
        if not self.server:
            return
        self.runtime.cancel()
        self.server.shutdown()
        self.server.server_close()
        if self.thread and self.thread.is_alive():
            self.thread.join(timeout=3)
        self.server = None
        self.thread = None


def main() -> None:
    background = "--background" in sys.argv
    bridge = ResolveWebBridge(resolve=connect_resolve())
    try:
        host, port, key = bridge.start()
    except OSError as exc:
        if background and getattr(exc, "winerror", None) == 10048:
            return
        raise
    if not background:
        print("H Cosmic Studio Web Bridge")
        print(f"Endpoint: http://{host}:{port}")
        print(f"Mã ghép nối dự phòng: {key}")
        print("Website sẽ tự động kết nối; không cần nhập mã.")
    try:
        while bridge.running:
            threading.Event().wait(1)
    except KeyboardInterrupt:
        pass
    finally:
        bridge.stop()


if __name__ == "__main__":
    main()
