# H Cosmic Studio — DaVinci Batch Production

Tool UI tự động hóa quy trình trong video quay màn hình:

1. Nhập và sắp xếp ảnh theo tên tự nhiên (`p2` đứng trước `p10`).
2. Tạo timeline, đặt thời lượng cho toàn bộ ảnh.
3. Lặp video hiệu ứng trên V2, đặt blend mode và opacity.
4. Thêm/lặp danh sách nhạc tới hết video.
5. Đưa job vào Render Queue hoặc tự render.
6. Tùy chọn workflow 2 giai đoạn: render từng ảnh có hiệu ứng, nhập lại clip, ghép nhạc và render video tổng.

Giao diện sử dụng hệ màu vũ trụ với logo chữ **H**, bảng Mission Control và các chỉ số tải sản xuất.

## Human Action Blueprint

Mục **Human Action Blueprint** hiển thị quy trình theo đúng thứ tự một editor thao tác trên Resolve:

```text
System → Project Manager → Media Pool → Edit → Inspector → Color/Fusion
→ Deliver → Render Queue → Verify → Report
```

Mỗi bước có:

- Trang Resolve tương ứng.
- Hành động con cụ thể.
- Giá trị đang dùng: duration, scaling, opacity, blend mode, bitrate, Mark In/Out.
- Đường dẫn thao tác “Human: Edit > V1 > …”.
- API thực thi phía sau, ví dụ `MediaPool.AppendToTimeline`, `TimelineItem.SetProperty`, `Project.AddRenderJob`.
- Trạng thái `Chờ`, `Đang chạy`, `Xong` hoặc `Lỗi`.

Có thể bật `Ghi chi tiết từng clip/segment` để thấy từng ảnh, từng đoạn overlay và từng đoạn nhạc trong lúc chạy. Nút `Xuất checklist JSON` tạo blueprint độc lập để audit hoặc làm tài liệu SOP.

Tool dùng DaVinci Resolve Scripting API, không click theo tọa độ màn hình nên không bị sai khi đổi độ phân giải hoặc bố cục UI.

## Cách mở được khuyến nghị

Chạy PowerShell:

```powershell
.\install_menu_script.ps1
```

Sau đó trong DaVinci Resolve chọn:

`Workspace > Scripts > Utility > H Cosmic Studio`

Nếu menu chưa hiện, khởi động lại Resolve một lần.

## Kết nối website nhhoang13all.xyz

Website có mục lớn **Davinci Resolve** tại:

`https://nhhoang13all.xyz/#/davinci-resolve`

### Kết nối tự động, không cần bấm nút

Chạy một lần:

```powershell
.\install_auto_bridge.ps1
```

Installer thêm H Cosmic Auto Bridge vào Windows Startup và khởi động bridge ngay. Từ lần sau:

1. Mở DaVinci Resolve và project cần sản xuất.
2. Mở `https://nhhoang13all.xyz/#/davinci-resolve`.
3. Website tự tìm bridge, tự ghép nối và tự nhận Resolve đang chạy.
4. Chạy **PRECHECK**, sau đó chọn **Build timeline**, **Queue**, **Render** hoặc **Resume**.

Không cần mở H Cosmic Studio hoặc nhập pairing code. Nếu website được mở trước Resolve, bridge giữ trạng thái chờ và tự kết nối sau khi Resolve khởi động.

Bridge chỉ lắng nghe trên `127.0.0.1`, không mở cổng ra Internet. Endpoint tự ghép nối chỉ trả mã phiên cho origin chính xác `nhhoang13all.xyz`; mã chỉ được giữ trong `sessionStorage` và tự hết hiệu lực khi bridge khởi động lại.

Có thể chạy bridge có cửa sổ để chẩn đoán:

```powershell
.\start_web_bridge.ps1
```

Gỡ tự khởi động:

```powershell
.\uninstall_auto_bridge.ps1
```

## Chạy độc lập

Mở DaVinci Resolve và project cần làm. Trong Resolve vào:

`Preferences > System > General > External scripting using > Local`

Khởi động lại Resolve, sau đó chạy:

```powershell
python .\run_tool.py
```

## Các nút

- **PRECHECK**: chạy toàn bộ kiểm tra đầu vào, project, codec, FPS, dung lượng và output; chưa sửa Media Pool hay timeline.
- **Quét & xem kế hoạch**: kiểm tra số ảnh, nhạc, overlay, thứ tự và tổng thời lượng; chưa sửa project.
- **Chỉ tạo timeline**: tạo timeline hoàn chỉnh, chưa thêm job render.
- **Tạo + đưa vào Queue**: tạo timeline và thêm job vào Render Queue, chưa bấm Start Render.
- **Làm toàn bộ + render**: tạo, queue và render tự động.
- **Tiếp tục phiên**: đọc manifest và tiếp tục đúng job/action chưa hoàn thành.
- **Hủy phiên**: dừng render ở điểm an toàn, giữ checkpoint để tiếp tục sau.

## Hai workflow

- **Trực tiếp**: ảnh + overlay + nhạc được ghép ngay trong một timeline. Nhanh và ít tốn dung lượng.
- **2 giai đoạn (giống video)**: mỗi ảnh được render thành clip trung gian có overlay, sau đó các clip được ghép với nhạc và render video tổng. Các file trung gian nằm trong `_batch_clips_<tên timeline>` ở thư mục xuất.

Tool chỉ tạo bin/timeline/job mới. Tool không xóa media hay timeline có sẵn. Tùy chọn xóa timeline trung gian chỉ tác động các timeline `__BATCH_...` do chính lượt chạy hiện tại tạo.

## Sản xuất nhiều video trong vài tiếng

Bật **Mỗi thư mục con trong nguồn ảnh = một video**, sau đó tổ chức nguồn như sau:

```text
Nguon_Anh/
├── Video_001/
│   ├── p01.png
│   └── p02.png
├── Video_002/
│   ├── p01.png
│   └── p02.png
└── Video_003/
    └── ...
```

Tool sẽ tạo tên output theo mẫu:

```text
<tên timeline>_Video_001.mp4
<tên timeline>_Video_002.mp4
<tên timeline>_Video_003.mp4
```

Các tính năng dành cho phiên chạy dài:

- Ước tính tổng số video, số ảnh, thời lượng và dung lượng trước khi chạy.
- Chia lô 1–500 job, có thời gian nghỉ giữa các lô và lịch bắt đầu ban đêm.
- Cảnh báo trước và tự dừng trong khi render nếu dung lượng/GPU vượt ngưỡng an toàn.
- Output đã tồn tại chỉ được bỏ qua sau khi vượt qua FFprobe hậu kiểm.
- Tạm giữ Windows không tự ngủ trong lúc sản xuất và khôi phục khi kết thúc.
- Nút **Hủy phiên** dừng render tại điểm an toàn; timeline và job đã tạo vẫn được giữ.
- Ghi `enterprise_report_YYYYMMDD_HHMMSS.json` trong thư mục xuất để kiểm tra toàn phiên.

## Enterprise Runtime đã tích hợp

### P0 — an toàn và có thể tiếp tục

- **Checkpoint/Resume**: mỗi tổ hợp video + profile có một manifest tại
  `<output>/.hcosmic/manifests/<job>.json`. Manifest được ghi nguyên tử sau mỗi action,
  có `status`, `last_action`, `attempt`, lỗi, preflight, postflight và lịch sử sự kiện.
- **Preflight Validator**: kiểm tra ảnh hỏng, trùng tên, ký tự không hợp lệ, ảnh ngang/dọc
  lẫn nhau, nhạc/overlay thiếu thời lượng, codec, FPS và resolution của project, DRX/COMP,
  output cũ và dung lượng ổ đĩa. Kết quả là `PASS`, `WARNING` hoặc `BLOCKED`.
- **FFprobe Postflight**: xác nhận file tồn tại, kích thước tối thiểu, video/audio stream,
  resolution, FPS, duration và tùy chọn decode frame cuối. File lỗi được cách ly vào
  `_retry` hoặc `_failed`; file đạt chuẩn có thể chuyển vào `_verified`.
- **Retry từng bước**: `PRODUCE` và `VERIFY` có số lần retry/backoff riêng. Lỗi một video
  được ghi manifest rồi chuyển sang video tiếp theo.

Ví dụ manifest:

```json
{
  "job": "Video_023__TikTok",
  "status": "stage_1_rendered",
  "last_action": "PRODUCE",
  "output": "D:/Output/Video_023_TikTok.mp4",
  "attempt": 1
}
```

### P1 — Action Graph, template và nhiều profile

Mỗi job chạy qua graph:

```text
PRECHECK
  └─ PRODUCE (retry)
       └─ VERIFY (retry + quarantine)
            ├─ INTERMEDIATE (keep/delete/zip)
            └─ NOTIFY
```

Mỗi node có điều kiện đầu vào, trạng thái, hàm xác minh, retry/backoff và chính sách lỗi.
Manifest được lưu sau từng lần chạy node nên tool biết action nào được phép chạy lại.

Với **Template Timeline**, hãy tạo sẵn một timeline trong Resolve:

- V1 chứa đủ placeholder theo số ảnh, theo đúng thứ tự.
- V2 chứa overlay/effect nếu muốn giữ nguyên.
- A1/A2 chứa nhạc, voice hoặc audio mix mẫu.
- Có thể giữ Color node, Fusion composition, title, subtitle và transition.

Chọn tên template trong UI. Tool duplicate template, dùng `AddTake` để thay media trên V1,
giữ effect/node/transition và vô hiệu hóa placeholder thừa. Nếu template đã có V2/A1,
tool không chèn overlay hoặc audio trùng.

Để xuất nhiều nền tảng trong một phiên, bật **Dùng nhiều profile** và chọn
[`production_profiles.example.json`](./production_profiles.example.json). Mỗi profile có:

- `name`, `priority`, `suffix`;
- `width`, `height`, `fps`;
- `render_format`, `render_codec`, `bitrate_kbps`, `render_preset`;
- `overlay_file`, `music_source`, `output_dir`, `workflow`.

Giá trị rỗng được kế thừa từ UI chính. Job được sắp theo `priority`, rồi theo tên nguồn.
Một `Video_001` có thể tạo `Video_001_TikTok.mp4` và `Video_001_YouTube.mp4`.

### P2 — dashboard, thông báo và file trung gian

Dashboard hiển thị job hiện tại, số hoàn tất/lỗi, ETA, job/giờ, GPU, nhiệt độ và dung lượng
còn lại. Trong khi Resolve render, số liệu được làm mới khoảng 5 giây/lần.

Chọn kênh `telegram`, `slack` hoặc `email`; thông tin nhạy cảm chỉ đọc từ biến môi trường,
không ghi vào file cấu hình. Sao chép và điền mẫu
[`notification_env.example.ps1`](./notification_env.example.ps1), sau đó chạy nó trong
terminal trước khi mở tool.

Chính sách file trung gian:

- `keep`: giữ nguyên.
- `delete_verified`: chỉ xóa sau khi output đã được xác minh.
- `zip_then_delete`: nén ZIP rồi xóa thư mục trung gian.

Tool chỉ cho phép chính sách xóa/nén tác động vào thư mục `_batch_clips_*` nằm trực tiếp
trong thư mục output.

## Quy trình vận hành khuyến nghị

1. Mở project Resolve và chọn đúng template/preset.
2. Chọn nguồn, output và profile; bấm **PRECHECK**.
3. Chỉ tiếp tục khi không còn `BLOCKED`; xem warning trước khi chạy đêm.
4. Bấm **Làm toàn bộ + render** hoặc đặt lịch bắt đầu.
5. Theo dõi dashboard; khi Windows/Resolve bị gián đoạn, mở lại tool và bấm
   **Tiếp tục phiên**.
6. Sau phiên chạy, kiểm tra `enterprise_report_*.json`, `.hcosmic/manifests/`,
   `_verified/`, `_retry/` và `_failed/`.

## Lưu ý kỹ thuật

- Cần `ffprobe` và `ffmpeg` trong `PATH` để preflight/hậu kiểm sâu hoạt động đầy đủ.
- FPS timeline của project Resolve thường không thể đổi an toàn sau khi timeline đã có;
  mismatch FPS được đánh dấu `BLOCKED`.
- Resolve xử lý Render Queue tuần tự trong project hiện tại. Tool chia job theo lô nhưng
  không chạy nhiều render Resolve song song.
- Watchdog stall, GPU và dung lượng có thể gọi `StopRendering`; manifest và timeline vẫn
  được giữ để resume.
- Retry được giới hạn; tool không lặp vô hạn.

Chạy kiểm thử:

```powershell
python -m unittest discover -s tests -v
```
