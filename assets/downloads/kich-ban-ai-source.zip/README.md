# Neon Script Studio - Python App

Bản desktop app Python dùng `tkinter`, không cần package ngoài.

## Chạy app

Nếu máy đã cài Python:

```powershell
python .\neon_script_studio.py
```

Hoặc double-click:

```text
run_app.bat
```

Trên máy Codex hiện tại, Python không nằm trên PATH, nên dùng:

```text
run_with_codex_python.bat
```

## Chức năng

- GUI desktop màu neon, sidebar có cuộn để không bị mất phần Gemini.
- Có icon app riêng phong cách neon chữ `HH` cho title bar, taskbar và bản EXE.
- Sidebar chỉ giữ phần cấu hình: preset, audience/tone/niche, Gemini/model/ngôn ngữ/chế độ viết/chế độ trích video.
- Tab `Biên tập` và `Gemini Writer` đã được gom theo workflow: `Nguồn Video`, `Nguồn Text`, `Nguồn URL`, `Viết AI`, `Kiểm tra`, `Xuất/Lưu`.
- Người mới chỉ cần đi từ trái sang phải: chọn nguồn -> viết bằng Gemini -> kiểm tra/dịch/so sánh -> xuất file.
- Mặc định tối ưu cho kịch bản kể chuyện, người xem 40+.
- Preset `Storytelling 40+` cho câu chuyện gia đình, hôn nhân, tuổi trung niên, nhân quả, tình người.
- Paste transcript/kịch bản gốc và bản nháp mới.
- Nhập kịch bản có sẵn từ `.txt`, `.md`, `.srt`, `.vtt`, `.docx`, `.json`, `.csv`.
- Dán kịch bản trực tiếp từ clipboard, tự làm sạch timestamp/phụ đề/dòng trùng.
- Có nút `Đọc và viết lại ngay` để Gemini đọc kịch bản có sẵn rồi tạo bản mới mạnh hơn.
- Output viết lại chính chỉ trả về kịch bản hoàn chỉnh dạng đoạn văn, không trả outline/bảng/timestamp/ghi chú.
- Sau khi AI viết xong, app tự tạo `Tên câu chuyện / Title YouTube` dưới 100 ký tự bằng ngôn ngữ nguồn/kịch bản gốc, phù hợp nội dung câu chuyện và dùng làm tên dự án/xuất file. Có thể bấm `Tạo title YouTube` để tạo lại sau khi sửa draft.
- Có checkbox `Gemini chọn title hay nhất`: nếu bật, app vẫn tạo title local ngay rồi gọi Gemini chạy nền để chọn 1 title YouTube hấp dẫn nhất bằng đúng ngôn ngữ nguồn và thêm nhiều phương án dự phòng. Khi bật `Test không gọi API` hoặc `Chỉ dùng cache`, title vẫn dùng local để không tốn quota.
- Có tab `Bản dịch` để dịch kiểm tra cả kịch bản gốc và bản đã viết lại.
- Có tab `Tóm tắt` để xem tóm tắt kịch bản gốc, tóm tắt bản AI đã viết lại và báo cáo so sánh trực quan.
- Tóm tắt mặc định ưu tiên tiếng Việt có dấu để dễ đọc. Nếu nguồn là Nhật/Trung/Hàn/Anh/Đức/Pháp, app sẽ gọi Gemini tạo tóm tắt tiếng Việt trực tiếp, không cần chờ dịch nguyên văn toàn bộ kịch bản.
- Tóm tắt có thêm mục `Diễn biến chi tiết theo trình tự`, lấy đều từ đầu, giữa và cuối kịch bản để tránh chỉ tóm tắt đoạn mở đầu.
- Tóm tắt chạy local rất nhanh khi text đã là tiếng Việt; với text nước ngoài, nút `Tóm tắt tiếng Việt + so sánh` dùng Gemini để tóm tắt thẳng sang tiếng Việt. Có nút `Tóm tắt raw / không dịch` nếu muốn xem tóm tắt theo nguyên ngôn ngữ gốc.
- Báo cáo tóm tắt hiển thị độ dài voice, ý chính, beat chính, chủ đề chung, chủ đề bản AI thêm mới, chủ đề bản gốc bị giảm và gợi ý chỉnh sửa.
- Có tùy chọn `Tự dịch kiểm tra sau khi viết`; mặc định bật.
- `Ngôn ngữ dịch kiểm tra` bị khóa cứng là `Tiếng Việt có dấu`; app không cho đổi để tránh Gemini/cache trả sai ngôn ngữ.
- Phần dịch kiểm tra tự kiểm tra độ phủ nội dung. Với kịch bản dài, app dịch theo nhiều phần nội bộ để tránh lỗi Gemini chỉ trả đoạn đầu; output vẫn streaming nên dịch đến đâu hiện đến đó trong tab `Bản dịch`.
- Nếu cache cũ hoặc Gemini trả bản dịch quá ngắn so với nguồn, app tự bỏ kết quả đó và dịch lại đầy đủ theo từng phần.
- Stream bản dịch được gom buffer trước khi đẩy lên UI để giảm lag khi kịch bản dài.
- Khi bấm `Hủy tác vụ`, app mở khóa giao diện ngay để chạy tác vụ mới, đóng kết nối Gemini đang stream nếu có và bỏ qua toàn bộ kết quả trả về muộn từ tác vụ cũ.
- Nếu Gemini/cache trả nhầm tiếng Hàn/Nhật/Trung hoặc còn ký tự ngoại ngữ trong bản dịch tiếng Việt, app sẽ bỏ qua kết quả sai hoặc tự dịch lại bằng chế độ ép tiếng Việt.
- Khi dịch cả kịch bản gốc và bản mới, app ưu tiên dịch `bản đã viết lại` trước rồi mới dịch kịch bản gốc để tránh 2 request Gemini lớn chạy song song gây đứng/quota nghẽn.
- Nếu bản đã viết lại đã cùng ngôn ngữ kiểm tra, app đưa thẳng nội dung vào ô kiểm tra, không gọi Gemini để dịch lại.
- Có `Test không gọi API`: dùng để bấm thử Writer, Tóm tắt, Bản dịch, Chat, Huấn luyện và Batch text/URL mà không gọi Gemini, tránh đốt quota khi test giao diện/luồng xử lý.
- Có `Chỉ dùng cache, không gọi API mới`: nếu tác vụ chưa có cache, app dừng sớm và báo rõ thay vì tiếp tục gọi Gemini. Dùng chế độ này khi quota gần hết hoặc đang debug nhiều lần.
- Ô `Thời lượng` hiểu `50` là 50 phút; có thể nhập `40-50'` hoặc `40-50 phút`.
- App tự tính độ dài mục tiêu theo ngôn ngữ đầu ra: tiếng Việt/Anh/Đức/Pháp dùng từ/phút, tiếng Nhật/Trung/Hàn dùng ký tự/phút.
- Ví dụ `50` với Tiếng Việt khoảng 6.500-7.500 từ; với Tiếng Nhật khoảng 15.000-18.000 ký tự Nhật.
- Dòng meta trên bản nháp sẽ báo bản mới đang khoảng bao nhiêu phút và còn thiếu/dài hơn bao nhiêu so với mục tiêu.
- Có nút `Xử lý 1 chạm`: làm sạch nguồn, phân tích, gọi Gemini viết lại.
- Có nút `Tạo 3 phiên bản`: Gemini tạo 3 hướng kể chuyện, chấm điểm, chọn bản thắng và viết full script.
- Có `Batch text không giới hạn`: chọn cả thư mục kịch bản, app tự viết lại hàng loạt theo thứ tự từng file.
- Batch tự xuất mỗi kịch bản thành `.txt`, `.md`, `.docx`, `.json`.
- Có `Story score 40+` để chấm kịch bản theo hook, đồng cảm, mâu thuẫn, reveal, bài học và CTA mềm.
- Có `Xuất TXT/DOCX` cho kịch bản hiện tại.
- Có nhiều chế độ viết lại riêng cho kịch bản kể chuyện: kể chuyện 40+, đời thường chậm sâu, drama gia đình, mẹ chồng nàng dâu, hôn nhân tan vỡ, con cái vô tâm, tuổi già cô đơn, bí mật gia đình, di chúc/tài sản, nhân quả báo ứng, lá thư/cuộc gọi cuối, hàng xóm/tình người, nghị lực tuổi trung niên, tình yêu muộn, nỗi oan được giải, kể chuyện dài tập, các mode viết lại 100% chỉ giữ ý tưởng lõi, đổi nhân vật/bối cảnh/plot twist/tuyến truyện, đổi mạnh 70-80%, dịch + localize, giữ cảm xúc, review/bán hàng, storytelling cinematic.
- Có nút `Gợi ý 40+` để xem nhanh đề xuất người xem, tone, niche, CTA và công thức kể chuyện.
- Phân tích số từ, thời lượng, keyword, mở đầu/kết, beat structure.
- Tạo prompt viết lại.
- Gọi Gemini API trực tiếp bằng `urllib`, không bị CORS của trình duyệt.
- Có streaming output: Gemini viết đến đâu app hiện chữ đến đó, giảm cảm giác bị treo.
- Có cache Gemini: cùng một kịch bản/cấu hình thì lần sau dùng lại kết quả, tiết kiệm API.
- Bản dịch kiểm tra cũng dùng cache nếu bật `Dùng cache để tiết kiệm API`.
- Nếu Gemini trả lỗi `429 RESOURCE_EXHAUSTED`, nghĩa là API key đã vượt quota/rate limit tạm thời. Khi tác vụ đang chờ quota, có thể dán API key mới rồi bấm `Áp dụng API key mới`; app sẽ tự thử lại bằng key mới mà không cần hủy tác vụ.
- Mặc định dùng model nhanh `gemini-3.1-flash-lite`; có combobox chọn model nhanh khác.
- Có chế độ tốc độ Gemini:
  - `Siêu nhanh - kịch bản kể chuyện`: output gọn hơn, giảm thinking, phù hợp viết draft nhanh.
  - `Nhanh cân bằng - chất lượng tốt`: cân bằng tốc độ và độ kỹ.
  - `Kỹ hơn - nhiều phân tích hơn`: chậm hơn nhưng nhiều phân tích hơn.
- Hỗ trợ nguồn đa ngôn ngữ: Trung, Nhật, Hàn, Anh Mỹ, Anh Anh, Đức, Pháp hoặc tự nhận diện.
- Chọn ngôn ngữ đầu ra.
- Training profile để "dạy" style kênh bằng prompt-profile.
- Profile AI luôn được ép trả bằng tiếng Việt có dấu; cache profile sai ngôn ngữ sẽ bị bỏ qua.
- Sidebar có ô `Ý tưởng riêng / kho trend`: dán ý tưởng riêng hoặc bấm `Nạp trend`, AI huấn luyện và Gemini Writer sẽ đọc để nâng cấp thành hook, trope, reveal, series.
- Tab `Huấn luyện` có `Huấn luyện 1 chạm`, `Tối ưu setup`, `Hướng dẫn nhanh` để người mới dùng không cần nhớ nhiều bước thủ công.
- Tab `Huấn luyện` có `Kho ý tưởng global`: hơn 100 ý tưởng/format gồm kể chuyện 40+, microdrama dọc, documentary, confession/AITA, review storytelling, AI/tech, pháp lý, ẩm thực/ký ức, cùng ý tưởng riêng cho Nhật, Hàn, Mỹ, Trung Quốc.
- Có nút `Thêm luật ý tưởng` để đưa Story Idea Engine + Market Trend Engine vào Locked rules, giúp Gemini tự chọn thị trường, trope, bối cảnh, cliffhanger và tạo nhiều ý tưởng mới khi viết kịch bản.
- Bản dịch kiểm tra luôn ép `Tiếng Việt` có dấu; nếu cache cũ còn tiếng Hàn/Nhật/Trung hoặc còn ký tự ngoại ngữ, app tự bỏ cache và dịch lại.
- Chọn video local và trích kịch bản tự động bằng Gemini Files API.
- Có `Batch folder video`: chọn cả thư mục video, app tự upload và trích transcript/kịch bản hàng loạt.
- Batch video xuất mỗi video thành `.txt`, `.md`, `.docx`, `.json` để dùng tiếp cho batch viết lại kịch bản.
- Có `Batch URL -> viết lại`: dán hoặc nhập danh sách URL, app tự đọc từng nguồn và viết lại kịch bản hàng loạt.
- URL bài viết/trang web/PDF dùng Gemini URL Context; YouTube URL công khai dùng Gemini Video Understanding.
- Có tab `URL Results` để xem toàn bộ kết quả sau batch URL, chọn riêng URL số 3/số 5... rồi copy hoặc đưa vào draft.
- Nếu ô nguồn chỉ có nhiều URL mà bấm `Gemini viết` hoặc `Đọc và viết lại ngay`, app tự chuyển sang Batch URL để không chỉ viết 1 bản.
- Khi xử lý video có progress bar, phần trăm upload, thời gian chạy và nút hủy tác vụ.
- Có 3 chế độ trích video:
  - `Nhanh - ưu tiên lời thoại`: nhanh nhất, ít visual, dùng media resolution thấp và output ngắn hơn.
  - `Cân bằng - lời thoại + visual chính`: phù hợp đa số video.
  - `Chi tiết - transcript + visual đầy đủ`: chậm hơn, dùng khi cần đọc nhiều chữ/visual trong video.
- Nếu xử lý lại cùng video trong một phiên app, app dùng lại file URI đã upload để không phải upload lại.
- Gemini mode:
  - Chọn video và trích kịch bản.
  - Nhập kịch bản có sẵn.
  - Phân tích video gốc.
  - Tạo kịch bản hay hơn.
  - Viết lại kịch bản có sẵn.
  - Nâng cấp draft.
- Chấm similarity hoạt động với cả draft và Gemini output.
- Tab `Độ giống` có nút `So sánh ngay`: app tự lấy draft, nếu draft trống thì lấy Gemini output, và hiển thị độ giống theo phần trăm.
- Nếu đã có bản dịch kiểm tra, phần `Độ giống` sẽ ưu tiên so sánh bằng bản dịch để dùng tốt hơn với nguồn Nhật/Trung/Hàn/Anh và bản mới tiếng Việt.
- Báo cáo độ giống có điểm rủi ro 0-100, word n-gram, char n-gram cho Nhật/Trung/Hàn, cụm 5-7 từ bị lặp và câu/đoạn gần giống.
- Retention planner và scene map.
- Lưu project local vào `%USERPROFILE%\.neon_script_studio`.
- Import/export JSON và export Markdown.

## Batch mode

1. Bấm `Batch text không giới hạn`.
2. Chọn thư mục chứa file `.txt`, `.md`, `.srt`, `.vtt`, `.docx`, `.json`, `.csv`.
3. App tự tạo thư mục output dạng:

```text
neon_batch_output_YYYYMMDD_HHMMSS
```

Mỗi file được xuất thành:

```text
ten_file_rewritten.txt
ten_file_rewritten.md
ten_file_rewritten.docx
ten_file_rewritten.json
```

Ngoài ra có `_batch_summary.md` và `_batch_summary.json` để xem file nào thành công, file nào lỗi, story score và similarity risk.

## Batch video

1. Bấm `Batch folder video` hoặc `Batch video folder`.
2. Chọn thư mục chứa video `.mp4`, `.mov`, `.avi`, `.webm`, `.wmv`, `.3gp`...
3. App xử lý tuần tự từng video để giảm lỗi quota `429`.
4. Output nằm trong thư mục:

```text
neon_video_transcripts_YYYYMMDD_HHMMSS
```

Mỗi video được xuất thành:

```text
ten_video_transcript.txt
ten_video_transcript.md
ten_video_transcript.docx
ten_video_transcript.json
```

Ngoài ra có `_video_batch_summary.md` và `_video_batch_summary.json`. Sau khi batch video xong, app sẽ đưa transcript của video cuối cùng vào ô `Kịch bản gốc / transcript` để bạn có thể kiểm tra nhanh hoặc viết lại tiếp.

## Batch URL

1. Dán danh sách URL vào ô `Kịch bản gốc / transcript`, mỗi dòng một URL, hoặc bấm `Nhập danh sách URL`.
2. Bấm `Batch URL -> viết lại` hoặc `Batch URL`.
3. Chọn thư mục output.
4. App xử lý tuần tự từng URL:
   - YouTube URL công khai: Gemini đọc video trực tiếp bằng Video Understanding.
   - Trang web/PDF/text công khai: Gemini đọc bằng URL Context.
   - Sau đó app viết lại thành kịch bản mới theo cấu hình audience/tone/niche/CTA hiện tại.
   - Link YouTube có tham số dài như `&pp=...` sẽ được app tự rút gọn về dạng `https://www.youtube.com/watch?v=VIDEO_ID` trước khi gửi Gemini.
   - App kiểm tra video ID YouTube phải đủ 11 ký tự; link bị copy thiếu ký tự sẽ bị báo lỗi ngay trước khi gọi Gemini.
   - Với YouTube, app gửi payload tối giản giống tài liệu Gemini: chỉ có `file_uri` của YouTube và prompt, không gửi MIME hay `mediaResolution`.

Output nằm trong thư mục:

```text
neon_url_rewrites_YYYYMMDD_HHMMSS
```

Mỗi URL được xuất thành:

```text
*_source.txt
*_source.md
*_rewritten.txt
*_rewritten.md
*_rewritten.docx
*_rewritten.json
*_url_meta.json
```

Ngoài ra có `_url_batch_summary.md` và `_url_batch_summary.json`. URL phải là link công khai. Link cần đăng nhập, paywall, private/unlisted YouTube hoặc file video/audio trực tiếp có thể không đọc được. Với file video/audio trực tiếp, hãy tải file về rồi dùng `Batch folder video`.

Nếu gặp lỗi `Gemini video API 400`, nghĩa là Gemini không nhận URL đó như một video YouTube public hoặc video bị giới hạn. App đã tự thử URL YouTube sạch và payload tối giản; nếu vẫn lỗi, hãy kiểm tra video có public không, không phải private/unlisted, không bị giới hạn khu vực/tuổi, đổi model sang `gemini-3.5-flash` hoặc `gemini-2.5-flash`, hoặc tải video về rồi dùng `Batch folder video`.

Sau khi batch URL xong, mở tab `URL Results`:

- Chọn dòng URL cần lấy, ví dụ URL số 3.
- Bấm `Dùng URL đã chọn làm draft` để đưa đúng nguồn và kịch bản đã viết lại của URL đó sang tab `Biên tập`.
- Bấm `Copy kịch bản đã chọn` nếu chỉ muốn lấy riêng kịch bản của URL đó.
- URL 1, URL 2 vẫn được lưu trong danh sách và file output, nhưng không bị đưa vào draft nếu bạn không chọn.

## Bản dịch kiểm tra

Sau khi viết lại xong, nếu bật `Tự dịch kiểm tra sau khi viết`, app sẽ gọi Gemini thêm một lần để dịch:

- Kịch bản gốc.
- Kịch bản đã viết lại.

Hai bản dịch nằm ở tab `Bản dịch`, giúp bạn kiểm tra xem bản mới có giữ đúng ý, nhân vật, cảm xúc và sự kiện chính hay không. Bản dịch sẽ hiện dần trong lúc Gemini đang trả stream. Với kịch bản dài, app tự chia nội bộ thành nhiều phần để dịch đủ toàn bộ, rồi ghép lại thành một bản dịch liền mạch. Nếu Gemini hoặc cache trả bản dịch quá ngắn so với nguồn, app tự bỏ kết quả đó và dịch lại đầy đủ. Nếu cả kịch bản gốc và bản mới đều cần dịch, app ưu tiên dịch bản đã viết lại trước rồi mới dịch kịch bản gốc để tránh 2 request lớn chạy song song gây chậm/quota nghẽn. Nếu bản đã viết lại đã cùng ngôn ngữ kiểm tra, app không gọi Gemini cho phần đó mà hiển thị ngay nội dung hiện có. Nếu không muốn tốn thêm API hoặc muốn nhanh hơn, có thể tắt checkbox này và bấm `Dịch kiểm tra` thủ công khi cần.

## Lưu ý

Đây là prompt-training/profile, không phải fine-tune Gemini thật. App đã hỗ trợ chọn video local để Gemini trích kịch bản. Với video rất dài hoặc file rất lớn, thời gian upload và chi phí token/API có thể tăng đáng kể.

Nếu đã có kịch bản như text, phụ đề hoặc file Word, nên dùng `Nhập file kịch bản` hoặc `Dán kịch bản từ clipboard`. Cách này nhanh hơn video vì app không cần upload và chờ Gemini đọc hình/audio; Gemini chỉ xử lý phần viết lại.

Muốn Gemini trả nhanh nhất, dùng model `gemini-3.1-flash-lite`, tốc độ `Siêu nhanh - kịch bản kể chuyện`, và tránh yêu cầu quá nhiều bảng phân tích. App đã tự cấu hình output ngắn hơn và giảm thinking ở chế độ này.

Nếu gặp `429 RESOURCE_EXHAUSTED`, đó là giới hạn quota/rate limit của Gemini. Nếu tác vụ đang chờ quota, dán API key mới vào sidebar rồi bấm `Áp dụng API key mới`; app sẽ retry tiếp bằng key mới. Ngoài ra nên bật `Dùng cache để tiết kiệm API`, giảm số file batch, hoặc tắt `Tự dịch kiểm tra sau khi viết` nếu chưa cần kiểm tra bản dịch ngay. Nếu dùng thường xuyên, nên nâng quota/billing trong Google AI Studio.

Batch mode gọi Gemini nhiều lần, nên nên bật `Dùng cache để tiết kiệm API`. Nếu đang chạy nhiều file, hãy để app mở cho đến khi progress hoàn tất. Nút `Hủy tác vụ` sẽ mở khóa app ngay để bạn chạy tác vụ mới; request đã gửi lên Gemini có thể vẫn chạy phía server nhưng app sẽ bỏ qua kết quả cũ.

Batch video tốn quota hơn batch text vì phải upload và để Gemini đọc media. Nên dùng chế độ `Nhanh - ưu tiên lời thoại` trước, chia thư mục thành nhiều đợt nhỏ, và tránh chạy 50 video dài một lúc nếu API key đang ở free tier.

Batch URL thường nhanh hơn batch video local vì không cần upload file từ máy. Tuy vậy YouTube URL vẫn tiêu tốn quota đọc video; free tier có giới hạn thời lượng YouTube theo ngày. Trang web/PDF cũng tính token theo nội dung URL mà Gemini đọc được.

Với kịch bản voice dài 40-50 phút, nên nhập `40-50 phút` hoặc `50` ở ô `Thời lượng`. App sẽ tăng `maxOutputTokens` và yêu cầu Gemini mở rộng câu chuyện bằng chi tiết đời thường, nội tâm nhân vật, đối thoại, xung đột, bước ngoặt và chiêm nghiệm để đủ độ dài.

Trong bước sau upload, Gemini có thể mất vài phút để đọc video và sinh transcript. App sẽ hiển thị spinner và thời gian chạy; nếu bấm hủy trong giai đoạn request đã gửi lên server, app sẽ mở khóa giao diện ngay, bỏ qua kết quả trả về muộn và cho phép chạy tác vụ khác.

Muốn nhanh hơn nữa, dùng chế độ `Nhanh - ưu tiên lời thoại`, giảm độ dài video đầu vào hoặc cắt video thành từng đoạn ngắn trước khi đưa vào app.
