@echo off
setlocal
cd /d "%~dp0"
"C:\Users\Admin\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe" neon_script_studio.py
pause
