@echo off
setlocal
cd /d "%~dp0"
python neon_script_studio.py
if errorlevel 1 (
  py neon_script_studio.py
)
pause
