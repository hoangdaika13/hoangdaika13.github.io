#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Kịch bản AI - Python desktop app.

No external packages are required. The app uses Tkinter for the GUI and
urllib for Gemini REST calls.
"""

from __future__ import annotations

import base64
import gc
import json
import math
import mimetypes
import http.client
import hashlib
import difflib
import os
import re
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
import ctypes
from collections import Counter
from dataclasses import asdict, dataclass
from pathlib import Path

if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
    bundle_dir = Path(sys._MEIPASS)
    sys.path.insert(0, str(bundle_dir))
    if hasattr(os, "add_dll_directory"):
        try:
            os.add_dll_directory(str(bundle_dir))
        except OSError:
            pass
    os.environ.setdefault("TCL_LIBRARY", str(bundle_dir / "tcl" / "tcl8.6"))
    os.environ.setdefault("TK_LIBRARY", str(bundle_dir / "tcl" / "tk8.6"))

from tkinter import filedialog, messagebox, scrolledtext
import tkinter as tk
from tkinter import ttk
import xml.etree.ElementTree as ET
from xml.sax.saxutils import escape as xml_escape


APP_NAME = "Kịch bản AI"
APP_ID = "HH.KichBanAI.1"
APP_DIR = Path.home() / ".neon_script_studio"
PROJECTS_FILE = APP_DIR / "projects.json"
SETTINGS_FILE = APP_DIR / "settings.json"
GEMINI_CACHE_FILE = APP_DIR / "gemini_cache.json"
TRAINING_PROFILES_FILE = APP_DIR / "training_profiles.json"
GEMINI_ENDPOINT = "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
GEMINI_STREAM_ENDPOINT = "https://generativelanguage.googleapis.com/v1beta/models/{model}:streamGenerateContent?alt=sse"
GEMINI_UPLOAD_ENDPOINT = "https://generativelanguage.googleapis.com/upload/v1beta/files"
GEMINI_RATE_LIMIT_RETRIES = 4
GEMINI_RATE_LIMIT_FALLBACK_DELAY = 20
GEMINI_RATE_LIMIT_MAX_DELAY = 90
ACTIVE_HTTP_LOCK = threading.Lock()
ACTIVE_HTTP_RESPONSES: set = set()
DEFAULT_REVIEW_LANGUAGE = "Tiếng Việt"
YOUTUBE_TITLE_MAX_CHARS = 100
TEXT_WIDGET_DEFAULT_MAX_CHARS = 300_000
TEXT_WIDGET_FULL_SCRIPT_MAX_CHARS = 1_200_000
TEXT_WIDGET_LOG_MAX_CHARS = 220_000
TEXT_WIDGET_PREVIEW_MAX_CHARS = 90_000
TEXT_WIDGET_SUMMARY_MAX_CHARS = 180_000
GEMINI_CACHE_MAX_ENTRIES = 180
GEMINI_CACHE_MAX_OUTPUT_CHARS = 140_000
CHAT_IMAGE_PREVIEW_MAX_REFS = 8


class TrackedHTTPResponse:
    def __init__(self, response) -> None:
        self._response = response
        with ACTIVE_HTTP_LOCK:
            ACTIVE_HTTP_RESPONSES.add(response)

    def __getattr__(self, name):
        return getattr(self._response, name)

    def __iter__(self):
        return iter(self._response)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def close(self) -> None:
        with ACTIVE_HTTP_LOCK:
            ACTIVE_HTTP_RESPONSES.discard(self._response)
        try:
            self._response.close()
        except Exception:
            pass


def close_active_gemini_responses() -> None:
    with ACTIVE_HTTP_LOCK:
        responses = list(ACTIVE_HTTP_RESPONSES)
        ACTIVE_HTTP_RESPONSES.clear()
    for response in responses:
        try:
            response.close()
        except Exception:
            pass


def resource_path(*parts: str) -> Path:
    if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
        return Path(sys._MEIPASS).joinpath(*parts)
    return Path(__file__).resolve().parent.joinpath(*parts)


def set_windows_app_id() -> None:
    if sys.platform != "win32":
        return
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(APP_ID)
    except Exception:
        pass

try:
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")
except Exception:
    pass


class DATA_BLOB(ctypes.Structure):
    _fields_ = [("cbData", ctypes.c_uint32), ("pbData", ctypes.POINTER(ctypes.c_byte))]


def _bytes_to_blob(data: bytes):
    buffer = ctypes.create_string_buffer(data)
    blob = DATA_BLOB(len(data), ctypes.cast(buffer, ctypes.POINTER(ctypes.c_byte)))
    return blob, buffer


def protect_secret(value: str) -> str:
    if not value or sys.platform != "win32":
        return value or ""
    try:
        in_blob, _buffer = _bytes_to_blob(value.encode("utf-8"))
        out_blob = DATA_BLOB()
        ok = ctypes.windll.crypt32.CryptProtectData(
            ctypes.byref(in_blob),
            None,
            None,
            None,
            None,
            0,
            ctypes.byref(out_blob),
        )
        if not ok:
            return value
        try:
            encrypted = ctypes.string_at(out_blob.pbData, out_blob.cbData)
            return "dpapi:" + base64.b64encode(encrypted).decode("ascii")
        finally:
            ctypes.windll.kernel32.LocalFree(ctypes.cast(out_blob.pbData, ctypes.c_void_p))
    except Exception:
        return value or ""


def unprotect_secret(value: str) -> str:
    if not value:
        return ""
    if not value.startswith("dpapi:") or sys.platform != "win32":
        return value
    try:
        raw = base64.b64decode(value.split(":", 1)[1])
        in_blob, _buffer = _bytes_to_blob(raw)
        out_blob = DATA_BLOB()
        ok = ctypes.windll.crypt32.CryptUnprotectData(
            ctypes.byref(in_blob),
            None,
            None,
            None,
            None,
            0,
            ctypes.byref(out_blob),
        )
        if not ok:
            return ""
        try:
            decrypted = ctypes.string_at(out_blob.pbData, out_blob.cbData)
            return decrypted.decode("utf-8", errors="replace")
        finally:
            ctypes.windll.kernel32.LocalFree(ctypes.cast(out_blob.pbData, ctypes.c_void_p))
    except Exception:
        return ""


WORD_RE = re.compile(r"[\wÀ-ỹ一-龥ぁ-んァ-ン가-힣]+", re.UNICODE)
CJK_CHAR_RE = re.compile(r"[\u4e00-\u9fff\u3040-\u30ff\uac00-\ud7a3]")
HAN_RE = re.compile(r"[\u4e00-\u9fff]")
JAPANESE_RE = re.compile(r"[\u3040-\u30ff]")
KOREAN_RE = re.compile(r"[\uac00-\ud7a3]")
LATIN_WORD_RE = re.compile(r"[a-z0-9À-ỹ_]", re.IGNORECASE)
SENTENCE_SPLIT_RE = re.compile(r"(?<=[.!?…。！？])\s*|\n+")
URL_RE = re.compile(r"https?://[^\s<>'\"）)\]}]+", re.IGNORECASE)
VIETNAMESE_MARK_RE = re.compile(r"[àáảãạăắằẳẵặâấầẩẫậèéẻẽẹêếềểễệìíỉĩịòóỏõọôốồổỗộơớờởỡợùúủũụưứừửữựỳýỷỹỵđ]", re.IGNORECASE)
VIETNAMESE_COMMON_RE = re.compile(
    r"\b(của|và|là|một|những|người|không|được|trong|với|cho|khi|đã|này|"
    r"bạn|tôi|ông|bà|anh|chị|con|mẹ|cha|gia đình|cuộc đời|câu chuyện)\b",
    re.IGNORECASE,
)

STOPWORDS = {
    "anh",
    "ai",
    "ban",
    "bạn",
    "bang",
    "bằng",
    "bi",
    "bị",
    "boi",
    "bởi",
    "cac",
    "các",
    "cai",
    "cái",
    "can",
    "cần",
    "cho",
    "co",
    "có",
    "con",
    "cua",
    "của",
    "cung",
    "cùng",
    "da",
    "đã",
    "dang",
    "đang",
    "de",
    "để",
    "den",
    "đến",
    "di",
    "đi",
    "do",
    "đó",
    "duoc",
    "được",
    "em",
    "gi",
    "gì",
    "hay",
    "hon",
    "hơn",
    "khi",
    "khong",
    "không",
    "la",
    "là",
    "lai",
    "lại",
    "len",
    "lên",
    "mot",
    "một",
    "nay",
    "này",
    "neu",
    "nếu",
    "nhu",
    "như",
    "nhung",
    "nhưng",
    "những",
    "nguoi",
    "người",
    "o",
    "ở",
    "ra",
    "rang",
    "rằng",
    "roi",
    "rồi",
    "sau",
    "se",
    "sẽ",
    "the",
    "thể",
    "thi",
    "thì",
    "toi",
    "tôi",
    "trong",
    "tu",
    "từ",
    "va",
    "và",
    "vao",
    "vào",
    "ve",
    "về",
    "vi",
    "vì",
    "voi",
    "với",
}

PRESETS = {
    "Storytelling 40+": {
        "platform": "YouTube",
        "duration": "8-12 phút",
        "audience": "Nam nữ 40-65 tuổi, đã trải qua gia đình, hôn nhân, con cái, công việc và các biến cố đời sống; thích câu chuyện chân thật, dễ đồng cảm, có bài học cuối",
        "tone": "Ấm áp, chậm vừa, chân thật, giàu cảm xúc nhưng không sến; kể chuyện đời thường, có cao trào, có chiêm nghiệm và kết thúc để lại dư âm",
        "niche": "Kể chuyện đời sống / gia đình / hôn nhân / tuổi trung niên / lòng hiếu thảo / tình người / bài học nhân sinh",
        "cta": "Nếu câu chuyện này làm bạn nhớ đến ai, hãy để lại một lời bình luận hoặc chia sẻ trải nghiệm của bạn.",
        "target_change": 78,
        "script_rewrite_mode": "Kể chuyện 40+ - nhanh và cảm xúc",
        "gemini_speed_mode": "Siêu nhanh - kịch bản kể chuyện",
    },
    "YouTube Pro": {
        "platform": "YouTube",
        "duration": "6-10 phút",
        "audience": "Người xem đại chúng, cần giải thích rõ nhưng không dài dòng",
        "tone": "Tự nhiên, có chiều sâu, storytelling rõ, mỗi đoạn có payoff",
        "niche": "Giáo dục / kinh doanh / phát triển bản thân",
        "cta": "Bình luận trải nghiệm và đăng ký kênh",
        "target_change": 75,
        "script_rewrite_mode": "Giữ cảm xúc - tăng retention",
        "gemini_speed_mode": "Nhanh cân bằng - chất lượng tốt",
    },
    "Shorts Viral": {
        "platform": "TikTok/Reels",
        "duration": "45-90 giây",
        "audience": "Người xem mobile, thích nội dung ngắn và có insight nhanh",
        "tone": "Nhanh, gây tò mò, nhiều cut, câu ngắn, hook mạnh",
        "niche": "Short-form education / reaction / story",
        "cta": "Follow để xem phần tiếp theo",
        "target_change": 80,
        "script_rewrite_mode": "Mini drama nhiều tập - cliffhanger dày",
        "gemini_speed_mode": "Siêu nhanh - kịch bản kể chuyện",
    },
    "Documentary": {
        "platform": "YouTube",
        "duration": "8-15 phút",
        "audience": "Người xem thích documentary, case study và phân tích",
        "tone": "Điện ảnh, bí ẩn, có tension, mỗi phần có reveal mới",
        "niche": "Documentary / true story / history",
        "cta": "Đăng ký kênh nếu muốn xem case tiếp theo",
        "target_change": 85,
        "script_rewrite_mode": "True story documentary - kể như hồ sơ",
        "gemini_speed_mode": "Nhanh cân bằng - chất lượng tốt",
    },
    "Review bán hàng": {
        "platform": "YouTube",
        "duration": "3-6 phút",
        "audience": "Người đang cần quyết định mua hoặc so sánh sản phẩm",
        "tone": "Rành mạch, thực tế, tập trung lợi ích và phản đối của người mua",
        "niche": "Review sản phẩm / affiliate / SaaS",
        "cta": "Xem link và để lại câu hỏi trong bình luận",
        "target_change": 70,
        "script_rewrite_mode": "Review/bán hàng - tăng chuyển đổi",
        "gemini_speed_mode": "Nhanh cân bằng - chất lượng tốt",
    },
    "YouTube truyện dài 40+": {
        "platform": "YouTube",
        "duration": "40-60 phút",
        "audience": "Nam nữ 40-70 tuổi, thích nghe truyện dài có nhiều lớp cảnh, nhiều biến cố gia đình, cảm xúc chậm sâu và bài học cuối",
        "tone": "Chậm vừa, giàu cảm xúc, từng trải, nhiều cảnh đời thường, có đoạn lắng và cao trào rõ",
        "niche": "YouTube truyện dài / gia đình / hôn nhân / tuổi già / nhân quả / tình người",
        "cta": "Nếu câu chuyện này chạm đến bạn, hãy để lại một lời bình luận để chia sẻ góc nhìn của mình.",
        "target_change": 82,
        "script_rewrite_mode": "YouTube longform 60 phút - nhiều lớp cảnh",
        "gemini_speed_mode": "Nhanh cân bằng - chất lượng tốt",
    },
    "Drama gia đình": {
        "platform": "YouTube",
        "duration": "15-25 phút",
        "audience": "Người xem thích drama gia đình, mâu thuẫn hôn nhân, con cái, tài sản, mẹ chồng nàng dâu và những cú lật cảm xúc",
        "tone": "Căng vừa đủ, đối thoại mạnh, cao trào rõ, có hối hận và bài học nhân sinh",
        "niche": "Drama gia đình / hôn nhân / con cái / tài sản / bí mật trong nhà",
        "cta": "Bạn nghĩ ai đúng ai sai trong câu chuyện này? Hãy bình luận quan điểm của bạn.",
        "target_change": 82,
        "script_rewrite_mode": "Drama gia đình - cao trào mạnh",
        "gemini_speed_mode": "Nhanh cân bằng - chất lượng tốt",
    },
    "Cha mẹ già / báo hiếu": {
        "platform": "YouTube",
        "duration": "20-35 phút",
        "audience": "Người xem 40+ quan tâm gia đình, chữ hiếu, tuổi già, con cái vô tâm và những điều muộn màng",
        "tone": "Day dứt, chậm vừa, chân thật, nhiều chi tiết nhỏ khiến người nghe nghẹn lại",
        "niche": "Cha mẹ già / báo hiếu / tuổi già cô đơn / con cái vô tâm / bài học gia đình",
        "cta": "Nếu còn cha mẹ bên cạnh, bạn muốn nói điều gì với họ hôm nay?",
        "target_change": 82,
        "script_rewrite_mode": "Cha mẹ già bị bỏ rơi - day dứt",
        "gemini_speed_mode": "Nhanh cân bằng - chất lượng tốt",
    },
    "Con dâu bị oan": {
        "platform": "YouTube",
        "duration": "15-30 phút",
        "audience": "Người xem thích câu chuyện mẹ chồng nàng dâu, nỗi oan, định kiến gia đình và khoảnh khắc sự thật được phơi bày",
        "tone": "Cảm xúc, có ấm ức, có cao trào giải oan, không biến nhân vật thành phản diện một chiều",
        "niche": "Con dâu bị oan / mẹ chồng nàng dâu / gia đình chồng / sự thật bị che giấu",
        "cta": "Nếu là bạn, bạn sẽ im lặng chịu đựng hay nói ra sự thật?",
        "target_change": 84,
        "script_rewrite_mode": "Con dâu bị oan - lật lại sự thật",
        "gemini_speed_mode": "Nhanh cân bằng - chất lượng tốt",
    },
    "True Crime gia đình": {
        "platform": "YouTube",
        "duration": "20-40 phút",
        "audience": "Người xem thích hồ sơ thật, bí mật gia đình, sự thật bị che giấu và cách kể có tension nhưng tôn trọng nhân vật",
        "tone": "Căng, bình tĩnh, có không khí điều tra, không khai thác bạo lực rẻ tiền",
        "niche": "True crime gia đình / bí mật thị trấn / hồ sơ lạnh / documentary kể chuyện",
        "cta": "Bạn nghĩ dấu hiệu bất thường đầu tiên nằm ở đâu? Hãy để lại bình luận.",
        "target_change": 86,
        "script_rewrite_mode": "Mỹ true crime family - gia đình hoàn hảo sụp đổ",
        "gemini_speed_mode": "Kỹ hơn - nhiều phân tích hơn",
    },
    "Podcast kể chuyện": {
        "platform": "Podcast video",
        "duration": "30-60 phút",
        "audience": "Người nghe thích truyện dài dễ nghe, ít cần nhìn màn hình, có chiều sâu cảm xúc và nhịp kể thư giãn",
        "tone": "Chậm, sâu, rõ câu, nhiều suy ngẫm, chuyển cảnh mượt, không quá ồn ào",
        "niche": "Podcast truyện / tâm sự gia đình / confession / chuyện đời thật",
        "cta": "Nếu bạn từng trải qua điều tương tự, hãy chia sẻ câu chuyện của mình ở phần bình luận.",
        "target_change": 80,
        "script_rewrite_mode": "Podcast kể chuyện - chậm, sâu, dễ nghe",
        "gemini_speed_mode": "Nhanh cân bằng - chất lượng tốt",
    },
    "Series nhiều tập": {
        "platform": "YouTube",
        "duration": "8-15 phút",
        "audience": "Người xem thích câu chuyện nhiều tập, có cliffhanger, bí mật kéo dài và nhân vật quay lại ở tập sau",
        "tone": "Nhanh hơn truyện dài, nhiều open loop, mỗi đoạn có mini reveal và câu kéo tiếp",
        "niche": "Series truyện / mini drama / cliffhanger / bí mật gia đình nhiều tập",
        "cta": "Bạn muốn tập sau đi theo hướng nào? Hãy bình luận dự đoán của bạn.",
        "target_change": 88,
        "script_rewrite_mode": "Mini drama nhiều tập - cliffhanger dày",
        "gemini_speed_mode": "Siêu nhanh - kịch bản kể chuyện",
    },
    "Nhật healing story": {
        "platform": "YouTube",
        "duration": "15-30 phút",
        "audience": "Người xem thích truyện Nhật nhẹ nhàng, chữa lành, đời thường, có nỗi buồn đẹp và bài học tinh tế",
        "tone": "Yên tĩnh, tinh tế, ít ồn ào, giàu chi tiết mùa, món đồ cũ, ga tàu, căn hộ nhỏ",
        "niche": "Nhật Bản đời thường / iyashikei / người già cô đơn / lá thư cuối / hàng xóm",
        "cta": "Có chi tiết nào trong câu chuyện khiến bạn nhớ mãi không?",
        "target_change": 82,
        "script_rewrite_mode": "Nhật healing mystery - yên bình nhưng đau",
        "gemini_speed_mode": "Nhanh cân bằng - chất lượng tốt",
    },
    "Hàn melodrama": {
        "platform": "YouTube",
        "duration": "15-35 phút",
        "audience": "Người xem thích melodrama Hàn, gia đình, thân phận, tài phiệt, trả giá và những cảnh đối thoại cảm xúc mạnh",
        "tone": "Cao trào, nhiều nước mắt, đối thoại rõ, có trả giá nhưng vẫn có chiều sâu tình thân",
        "niche": "Hàn Quốc melodrama / chaebol / thân phận / ly hôn chữa lành / công lý muộn",
        "cta": "Bạn nghĩ nhân vật chính nên tha thứ hay rời đi?",
        "target_change": 86,
        "script_rewrite_mode": "Hàn Quốc melodrama - gia đình + trả giá",
        "gemini_speed_mode": "Nhanh cân bằng - chất lượng tốt",
    },
    "Trung short drama": {
        "platform": "YouTube",
        "duration": "10-25 phút",
        "audience": "Người xem thích short drama Trung Quốc, thân phận ẩn, tổng tài, gia đấu, trả thù, vả mặt và lật vị thế",
        "tone": "Nhanh, nhiều cú kéo, rõ thân phận, có màn đối đầu và payoff mạnh",
        "niche": "Trung Quốc short drama / CEO / gia đấu / nữ chính báo thù / tráo thân phận",
        "cta": "Bạn muốn nhân vật chính tha thứ hay trả lại công bằng đến cùng?",
        "target_change": 88,
        "script_rewrite_mode": "Trung Quốc CEO short drama - thân phận + đổi đời",
        "gemini_speed_mode": "Siêu nhanh - kịch bản kể chuyện",
    },
    "Mỹ suburb secret": {
        "platform": "YouTube",
        "duration": "15-30 phút",
        "audience": "Người xem thích bí mật khu phố, gia đình hoàn hảo sụp đổ, hàng xóm kỳ lạ và twist kiểu Mỹ",
        "tone": "Suspense, rõ cảnh, có chi tiết lạ, bí mật mở dần nhưng vẫn giàu cảm xúc gia đình",
        "niche": "Mỹ suburb secret / true crime family / neighbor from hell / single mom comeback",
        "cta": "Bạn có từng thấy một khu phố tưởng yên bình nhưng đầy bí mật không?",
        "target_change": 86,
        "script_rewrite_mode": "Mỹ suburb secret - bí mật thị trấn nhỏ",
        "gemini_speed_mode": "Nhanh cân bằng - chất lượng tốt",
    },
    "Pháp true crime": {
        "platform": "YouTube",
        "duration": "15-35 phút",
        "audience": "Người xem thích điều tra tinh tế, hồ sơ lạnh, bí mật gia đình nhiều năm và không khí tâm lý kiểu Pháp",
        "tone": "Bình tĩnh, tinh tế, có chất enquête, ít phô trương, nhiều khoảng lặng và quan sát xã hội",
        "niche": "Pháp enquête / true crime / tâm lý gia đình / di sản / tranh luận đạo đức",
        "cta": "Bạn nghĩ chi tiết nào đã bị bỏ qua trong hồ sơ này?",
        "target_change": 86,
        "script_rewrite_mode": "Pháp enquête true crime - hồ sơ lạnh",
        "gemini_speed_mode": "Kỹ hơn - nhiều phân tích hơn",
    },
    "Đức Krimi": {
        "platform": "YouTube",
        "duration": "15-35 phút",
        "audience": "Người xem thích điều tra logic, cold case, tội lỗi quá khứ, gia đình im lặng và màu documentary Đức",
        "tone": "Lạnh, rõ logic, tiết chế cảm xúc, suspense đến từ bằng chứng và sự im lặng",
        "niche": "Đức krimi / cold case / social realist / gia đình im lặng / documentary trauma",
        "cta": "Theo bạn, sự im lặng của gia đình này che giấu điều gì?",
        "target_change": 86,
        "script_rewrite_mode": "Đức krimi cold case - điều tra lạnh",
        "gemini_speed_mode": "Kỹ hơn - nhiều phân tích hơn",
    },
    "Úc mystery": {
        "platform": "YouTube",
        "duration": "15-35 phút",
        "audience": "Người xem thích bí mật vùng xa, thị trấn biển, cộng đồng nhỏ và câu chuyện vừa thật vừa bí ẩn",
        "tone": "Không khí rộng, cô lập, có suspense, đôi khi hài đen nhẹ nhưng vẫn nhân văn",
        "niche": "Úc outback mystery / coastal town secret / hybrid documentary / crime comedy noir",
        "cta": "Bạn nghĩ bí mật trong thị trấn này bắt đầu từ đâu?",
        "target_change": 86,
        "script_rewrite_mode": "Úc outback mystery - vùng xa bí ẩn",
        "gemini_speed_mode": "Nhanh cân bằng - chất lượng tốt",
    },
}

VIDEO_FILE_TYPES = [
    ("Video files", "*.mp4 *.mpeg *.mpg *.mov *.qt *.avi *.flv *.webm *.wmv *.3gp *.3gpp"),
    ("MP4", "*.mp4"),
    ("QuickTime", "*.mov *.qt"),
    ("AVI", "*.avi"),
    ("WebM", "*.webm"),
    ("All files", "*.*"),
]

SCRIPT_FILE_TYPES = [
    ("Script files", "*.txt *.md *.srt *.vtt *.docx *.json *.csv"),
    ("Text", "*.txt *.md"),
    ("Subtitle", "*.srt *.vtt"),
    ("Word document", "*.docx"),
    ("JSON/CSV", "*.json *.csv"),
    ("All files", "*.*"),
]

SCRIPT_SUFFIXES = {".txt", ".md", ".srt", ".vtt", ".docx", ".json", ".csv"}
CHAT_TEXT_SUFFIXES = SCRIPT_SUFFIXES | {".py", ".js", ".ts", ".html", ".css", ".xml", ".yaml", ".yml", ".ini", ".log", ".bat", ".ps1", ".sql"}
CHAT_IMAGE_MIME_TYPES = {"image/png", "image/jpeg", "image/webp", "image/heic", "image/heif"}
CHAT_UPLOAD_MIME_PREFIXES = ("image/", "audio/", "video/", "application/pdf")

TEXT_ENCODINGS = [
    "utf-8-sig",
    "utf-8",
    "cp932",
    "shift_jis",
    "cp949",
    "gb18030",
    "cp1252",
    "utf-16",
    "utf-16-le",
    "utf-16-be",
]

GEMINI_MODEL_OPTIONS = [
    "gemini-3.1-flash-lite",
    "gemini-3.5-flash",
    "gemini-flash-latest",
    "gemini-2.5-flash-lite",
    "gemini-2.5-flash",
]

GEMINI_IMAGE_MODEL_OPTIONS = [
    "gemini-3.1-flash-image",
    "gemini-3-pro-image",
    "gemini-2.5-flash-image",
]

GEMINI_SPEED_MODES = [
    "Siêu nhanh - kịch bản kể chuyện",
    "Nhanh cân bằng - chất lượng tốt",
    "Kỹ hơn - nhiều phân tích hơn",
]

SCRIPT_REWRITE_MODES = [
    "Kể chuyện 40+ - nhanh và cảm xúc",
    "Kể chuyện đời thường - chậm sâu",
    "Drama gia đình - cao trào mạnh",
    "Mẹ chồng nàng dâu - cảm xúc 40+",
    "Hôn nhân tan vỡ - chữa lành",
    "Con cái vô tâm - báo hiếu",
    "Tuổi già cô đơn - lấy nước mắt",
    "Bí mật gia đình - plot twist",
    "Di chúc/tài sản - lòng tham",
    "Nhân quả báo ứng - bài học cuối",
    "Lá thư/cuộc gọi cuối - reveal",
    "Hàng xóm/tình người - ấm áp",
    "Nghị lực tuổi trung niên - vượt biến cố",
    "Tình yêu muộn - nhẹ nhàng sâu",
    "Nỗi oan được giải - catharsis",
    "Kể chuyện dài tập - giữ open loop",
    "Tâm sự confession - như chuyện thật",
    "AITA/đúng sai đạo đức - gây tranh luận",
    "Pháp đình/gia đình kiện tụng - căng thẳng",
    "Bệnh viện/cuộc gọi khẩn - cảm xúc mạnh",
    "Người giúp việc biết bí mật nhà giàu",
    "Cha mẹ già bị bỏ rơi - day dứt",
    "Con dâu bị oan - lật lại sự thật",
    "Tỷ phú ẩn danh thử lòng người thân",
    "Trả thù văn minh - vả mặt nhẹ nhưng thấm",
    "True story documentary - kể như hồ sơ",
    "POV ngôi thứ nhất - nhập vai nhân vật",
    "Nhật Bản đời thường - iyashikei + nhân sinh",
    "Nhật aging society - cô đơn tuổi già",
    "Nhật ga tàu/lá thư cuối - slice of life reveal",
    "Nhật healing mystery - yên bình nhưng đau",
    "Nhật căn hộ nhỏ - bí mật hàng xóm",
    "Hàn Quốc melodrama - gia đình + trả giá",
    "Hàn Quốc chaebol - thừa kế + trả thù",
    "Hàn Quốc makjang - thân phận bị che giấu",
    "Hàn Quốc ly hôn chữa lành - phụ nữ đứng dậy",
    "Hàn Quốc công lý muộn - pháp lý + gia đình",
    "Trung Quốc gia đấu - di sản + thân phận",
    "Trung Quốc CEO short drama - thân phận + đổi đời",
    "Trung Quốc nữ chính báo thù - vả mặt gia tộc",
    "Trung Quốc xuyên không/đổi mệnh - cổ trang hiện đại",
    "Trung Quốc mẹ ruột/mẹ kế - tráo thân phận",
    "Mỹ suburb secret - bí mật thị trấn nhỏ",
    "Mỹ true crime family - gia đình hoàn hảo sụp đổ",
    "Mỹ billionaire romance/revenge - vertical drama",
    "Mỹ single mom comeback - đổi đời cảm xúc",
    "Mỹ neighbor from hell - hàng xóm ám ảnh",
    "Pháp enquête true crime - hồ sơ lạnh",
    "Pháp tâm lý gia đình - bí mật nhiều năm",
    "Pháp tỉnh lẻ/di sản - ký ức và thừa kế",
    "Pháp xã hội đạo đức - tranh luận gia đình",
    "Úc outback mystery - vùng xa bí ẩn",
    "Úc crime comedy noir - hài đen căng thẳng",
    "Úc coastal town secret - thị trấn biển có bí mật",
    "Úc hybrid documentary - người thật + tái hiện",
    "Đức krimi cold case - điều tra lạnh",
    "Đức social realist - nhập cư/bản sắc",
    "Đức gia đình im lặng - tội lỗi quá khứ",
    "Đức documentary trauma - phục hồi bản sắc",
    "Mini drama nhiều tập - cliffhanger dày",
    "YouTube longform 60 phút - nhiều lớp cảnh",
    "Podcast kể chuyện - chậm, sâu, dễ nghe",
    "Dark secret - bí mật đen tối nhưng nhân văn",
    "Wholesome twist - ấm áp bất ngờ",
    "Viết lại 100% - chỉ giữ ý tưởng lõi",
    "Câu chuyện mới 100% - đổi nhân vật/bối cảnh",
    "Plot twist mới 100% - khác tuyến truyện",
    "Drama gia đình 100% - tuyến truyện mới",
    "Confession 100% - đổi toàn bộ sự kiện",
    "Documentary 100% - hồ sơ mới từ insight cũ",
    "Cinematic 100% - bản gốc chỉ là cảm hứng",
    "Series 100% - mở vũ trụ câu chuyện mới",
    "Viết lại mạnh - đổi 70-80%",
    "Dịch + localize + nâng cấp",
    "Giữ cảm xúc - tăng retention",
    "Review/bán hàng - tăng chuyển đổi",
    "Storytelling dài - cinematic",
]

REWRITE_MODE_GUIDANCE = {
    "Kể chuyện 40+ - nhanh và cảm xúc": [
        "Vào chuyện nhanh trong 3-5 câu đầu bằng một biến cố đời thường có cảm xúc.",
        "Giữ nhịp rõ, dễ nghe voice, không dùng slang trẻ hoặc câu quá phức tạp.",
        "Mỗi đoạn cần có một câu kéo tiếp để người xem 40+ muốn nghe đoạn sau.",
    ],
    "Kể chuyện đời thường - chậm sâu": [
        "Ưu tiên không khí đời thường: bữa cơm, sân nhà, bệnh viện, chuyến xe, cuộc gọi, hàng xóm.",
        "Cho nhân vật có khoảng lặng, suy nghĩ và ký ức, tránh drama quá dồn dập.",
        "Cao trào đến từ một chi tiết nhỏ làm thay đổi cách người xem nhìn toàn bộ câu chuyện.",
    ],
    "Drama gia đình - cao trào mạnh": [
        "Dựng mâu thuẫn theo nấc: hiểu lầm nhỏ, xung đột công khai, bí mật bị lộ, lựa chọn cuối.",
        "Tạo nhiều cảnh đối thoại căng nhưng vẫn hợp tuổi 40+, không biến nhân vật thành phản diện một chiều.",
        "Cao trào phải có payoff cảm xúc rõ: hối hận, thức tỉnh, tha thứ hoặc rời đi trong tự trọng.",
    ],
    "Mẹ chồng nàng dâu - cảm xúc 40+": [
        "Tập trung vào định kiến, sĩ diện, khoảng cách thế hệ, bữa cơm gia đình và lời nói gây tổn thương.",
        "Cho cả hai phía có lý do riêng để người xem lớn tuổi thấy đời và thấy mình trong đó.",
        "Kết thúc nên mở ra một bài học về tôn trọng, ranh giới, lòng biết ơn hoặc cách sống chung tử tế.",
    ],
    "Hôn nhân tan vỡ - chữa lành": [
        "Không chỉ kể phản bội hoặc đau khổ; phải có hành trình tự trọng, tỉnh thức và tự chữa lành.",
        "Tăng nội tâm nhân vật bằng ký ức hôn nhân, sự im lặng lâu ngày, điều chưa từng nói ra.",
        "Kết nên cho người xem cảm giác nhẹ lòng: buông bỏ, trưởng thành, hoặc bắt đầu lại đúng cách.",
    ],
    "Con cái vô tâm - báo hiếu": [
        "Tạo đối lập giữa sự hy sinh âm thầm của cha mẹ và sự bận rộn/vô tâm của con cái.",
        "Reveal nên đến từ lá thư, bệnh án, món đồ cũ, người hàng xóm hoặc một cuộc gọi muộn.",
        "Bài học cuối tránh mắng mỏ; hãy khiến người xem tự thấy cần quan tâm cha mẹ khi còn kịp.",
    ],
    "Tuổi già cô đơn - lấy nước mắt": [
        "Khai thác sự cô đơn bằng chi tiết nhỏ: mâm cơm một người, chiếc điện thoại im lặng, căn nhà cũ.",
        "Đừng bi lụy liên tục; xen vài khoảnh khắc ấm áp để cảm xúc có nhịp thở.",
        "Cao trào nên là một hành động muộn màng nhưng đủ làm người xem nghẹn lại.",
    ],
    "Bí mật gia đình - plot twist": [
        "Cài manh mối sớm nhưng không giải thích ngay: tấm ảnh, chiếc chìa khóa, tên người lạ, khoản tiền lạ.",
        "Twist phải làm người xem hiểu lại toàn bộ hành động trước đó của nhân vật.",
        "Sau twist cần có đoạn cảm xúc để câu chuyện không chỉ gây sốc mà còn có dư âm nhân sinh.",
    ],
    "Di chúc/tài sản - lòng tham": [
        "Dựng xung đột tài sản như phép thử nhân cách, không chỉ là tranh giành tiền bạc.",
        "Cho từng nhân vật lộ bản chất qua hành động cụ thể: cách nói chuyện với người già, cách đối xử với anh em.",
        "Kết phải có bài học về lòng tham, tình thân, công bằng hoặc cái giá của sự vô ơn.",
    ],
    "Nhân quả báo ứng - bài học cuối": [
        "Câu chuyện cần có chuỗi nguyên nhân - lựa chọn - hậu quả rõ ràng.",
        "Tránh giọng mê tín cực đoan; viết như bài học đời sống về cách con người trả giá cho lựa chọn của mình.",
        "Kết bằng một câu chiêm nghiệm ngắn, dễ nhớ, hợp người xem trung niên.",
    ],
    "Lá thư/cuộc gọi cuối - reveal": [
        "Dùng lá thư, tin nhắn, cuộc gọi, di vật hoặc lời nhắn cuối làm trục reveal.",
        "Trước reveal cần xây đủ hiểu lầm và tiếc nuối để khoảnh khắc mở thư/cuộc gọi có lực.",
        "Sau reveal phải có phản ứng nội tâm dài hơn: im lặng, hối hận, nhớ lại, rồi quyết định mới.",
    ],
    "Hàng xóm/tình người - ấm áp": [
        "Tập trung vào tình người trong đời thường: giúp nhau lúc bệnh, giữ hộ bí mật, bữa cơm, chuyến xe.",
        "Drama vừa đủ, không làm câu chuyện quá ác liệt; điểm mạnh là sự tử tế âm thầm.",
        "Kết nên để lại cảm giác ấm, biết ơn và muốn chia sẻ trải nghiệm ở bình luận.",
    ],
    "Nghị lực tuổi trung niên - vượt biến cố": [
        "Nhân vật nên đối mặt với mất việc, ly hôn, bệnh tật, nợ nần, con cái xa cách hoặc tuổi già đến gần.",
        "Tạo hành trình từ tuyệt vọng sang đứng dậy bằng những bước nhỏ, thực tế, không quá màu hồng.",
        "Bài học cuối nhấn vào tự trọng, kiên trì, trách nhiệm và quyền được bắt đầu lại.",
    ],
    "Tình yêu muộn - nhẹ nhàng sâu": [
        "Kể chậm, tinh tế, ưu tiên ánh mắt, sự chăm sóc nhỏ, nỗi sợ bị đánh giá và ký ức cũ.",
        "Tránh lãng mạn hóa quá trẻ; tình yêu muộn nên gắn với sự bình yên, đồng hành và chữa lành.",
        "Kết có thể mở, nhưng phải để người xem tin rằng tuổi nào cũng xứng đáng được yêu thương.",
    ],
    "Nỗi oan được giải - catharsis": [
        "Dựng một hiểu lầm hoặc nỗi oan kéo dài khiến nhân vật chịu thiệt thòi trong im lặng.",
        "Cài bằng chứng/reveal từng chút để người xem vừa thương vừa chờ ngày sự thật sáng tỏ.",
        "Cao trào phải tạo cảm giác giải tỏa mạnh: lời xin lỗi, sự công nhận, hoặc nhân vật lấy lại phẩm giá.",
    ],
    "Kể chuyện dài tập - giữ open loop": [
        "Chia câu chuyện thành nhiều chặng rõ, mỗi chặng có mini-hook, mini-conflict và mini-payoff.",
        "Cuối mỗi phần lớn cần một câu mở vòng mới để hợp video dài hoặc series nhiều tập.",
        "Không giải quyết mọi thứ quá sớm; giữ một bí mật/trăn trở chạy xuyên suốt đến gần cuối.",
    ],
    "Tâm sự confession - như chuyện thật": [
        "Viết như lời kể thật của một người từng trải, có ngập ngừng, tự vấn và chi tiết đời sống rất cụ thể.",
        "Xung đột nên đến từ điều khó nói: hôn nhân, gia đình, tiền bạc, lỗi lầm cũ hoặc bí mật bị chôn lâu năm.",
        "Giữ giọng chân thật, không quá kịch; cảm xúc tăng nhờ sự thành thật và những câu thú nhận đau lòng.",
    ],
    "AITA/đúng sai đạo đức - gây tranh luận": [
        "Dựng tình huống khiến người xem phải tự hỏi ai đúng ai sai, mỗi phía đều có lý lẽ riêng.",
        "Cài các lựa chọn đạo đức khó: hiếu thảo hay ranh giới cá nhân, tình thân hay công bằng, tha thứ hay tự trọng.",
        "Kết nên mở đủ để kéo bình luận, nhưng vẫn có payoff cảm xúc và bài học rõ.",
    ],
    "Pháp đình/gia đình kiện tụng - căng thẳng": [
        "Dùng cấu trúc hồ sơ: nguyên đơn, bị đơn, bằng chứng, lời khai, bí mật bị lộ, phán quyết hoặc thỏa thuận cuối.",
        "Tăng sức căng bằng giấy tờ, di chúc, quyền nuôi dưỡng, tài sản, khoản nợ hoặc lời khai nhân chứng.",
        "Không sa vào thuật ngữ pháp lý phức tạp; kể dễ hiểu, tập trung cảm xúc gia đình sau sự thật.",
    ],
    "Bệnh viện/cuộc gọi khẩn - cảm xúc mạnh": [
        "Mở bằng tình huống khẩn: cuộc gọi đêm, phòng cấp cứu, bệnh án, ca phẫu thuật hoặc quyết định sinh tử.",
        "Cảm xúc phải đi từ hoang mang, sợ hãi, hối hận đến một sự thật khiến nhân vật thay đổi.",
        "Tránh lạm dụng bi kịch; dùng chi tiết nhỏ trong bệnh viện để tạo nước mắt và bài học.",
    ],
    "Người giúp việc biết bí mật nhà giàu": [
        "Khai thác góc nhìn người đứng ngoài gia đình nhưng nhìn thấy sự thật: người giúp việc, tài xế, y tá, hàng xóm.",
        "Tạo tương phản giữa vẻ hào nhoáng bên ngoài và bí mật đau lòng bên trong căn nhà.",
        "Reveal nên đến từ một hành động tử tế âm thầm hoặc một bằng chứng nhỏ bị bỏ quên.",
    ],
    "Cha mẹ già bị bỏ rơi - day dứt": [
        "Đặt cha/mẹ già vào tình huống bị lãng quên: viện dưỡng lão, căn nhà cũ, sinh nhật vắng con, cuộc gọi không ai nghe.",
        "Không chỉ trách con cái; cho thấy áp lực đời sống nhưng vẫn làm nổi bật sự vô tâm và cái giá muộn màng.",
        "Kết phải khiến người xem muốn gọi về cho cha mẹ hoặc suy nghĩ về chữ hiếu.",
    ],
    "Con dâu bị oan - lật lại sự thật": [
        "Dựng định kiến gia đình chồng, lời đồn, sự im lặng chịu đựng và một bằng chứng lật lại mọi thứ.",
        "Cho con dâu có phẩm giá và lựa chọn, không chỉ là nạn nhân khóc lóc.",
        "Cao trào nên là khoảnh khắc sự thật được nói ra trước cả nhà, tạo catharsis mạnh.",
    ],
    "Tỷ phú ẩn danh thử lòng người thân": [
        "Dùng motif ẩn danh/thử lòng nhưng phải hợp lý, không khoe giàu lố hoặc phi thực tế.",
        "Xung đột là cách người thân đối xử khi tưởng nhân vật nghèo/yếu thế, rồi bị soi lại nhân cách.",
        "Kết tập trung vào bài học về lòng người, không chỉ vả mặt bằng tiền.",
    ],
    "Trả thù văn minh - vả mặt nhẹ nhưng thấm": [
        "Nhân vật không trả thù độc ác; họ chọn bằng chứng, im lặng, rời đi hoặc thành công để đáp lại.",
        "Cảm giác thỏa mãn đến từ sự tự trọng và công bằng, không từ làm nhục quá đà.",
        "Payoff cần rõ: người sai nhận hậu quả, người chịu thiệt lấy lại phẩm giá.",
    ],
    "True story documentary - kể như hồ sơ": [
        "Viết như một hồ sơ câu chuyện có trình tự: bối cảnh, nhân vật, sự kiện chính, dấu hiệu bất thường, bước ngoặt, kết luận.",
        "Giọng kể bình tĩnh, có cảm giác điều tra, nhưng vẫn giàu cảm xúc ở các khoảnh khắc nhân vật.",
        "Nếu có chi tiết không chắc, dùng cách kể trung tính, không khẳng định như sự thật tuyệt đối.",
    ],
    "POV ngôi thứ nhất - nhập vai nhân vật": [
        "Kể bằng ngôi tôi nhất quán, để người nghe cảm thấy đang nghe chính nhân vật thú nhận.",
        "Tăng nội tâm, suy nghĩ chưa nói ra, cảm giác tội lỗi, sợ hãi, hy vọng hoặc tự trọng.",
        "Không nhảy góc nhìn tùy tiện; mọi thông tin ngoài tầm biết của nhân vật phải được biết qua lời kể, thư, cuộc gọi hoặc người khác.",
    ],
    "Nhật Bản đời thường - iyashikei + nhân sinh": [
        "Ưu tiên nhịp chậm, chi tiết mùa, bữa ăn, căn hộ nhỏ, ga tàu, bệnh viện, hàng xóm và sự tử tế lặng lẽ.",
        "Drama vừa phải; cảm xúc đến từ khoảng lặng, món đồ cũ, lời xin lỗi muộn hoặc một cử chỉ chăm sóc.",
        "Kết để lại dư âm chữa lành, hợp khán giả thích câu chuyện đời thường Nhật.",
    ],
    "Nhật aging society - cô đơn tuổi già": [
        "Tập trung vào người già sống một mình, con cái xa cách, viện dưỡng lão, căn nhà cũ, sinh nhật vắng người thân.",
        "Cảm xúc đến từ chi tiết nhỏ và sự im lặng dài, không cần drama quá lớn.",
        "Kết nên có một hành động muộn màng, một lời xin lỗi hoặc một món đồ cũ khiến người xem nghẹn lại.",
    ],
    "Nhật ga tàu/lá thư cuối - slice of life reveal": [
        "Dùng ga tàu, chuyến xe cuối, hộp thư, lá thư cũ hoặc món đồ bỏ quên làm trục câu chuyện.",
        "Nhịp kể nhẹ và giàu hình ảnh, từng chút hé lộ quan hệ giữa nhân vật.",
        "Reveal cuối nên nhỏ nhưng thấm: một lời hứa, một hiểu lầm, một lần gặp muộn hoặc một sự hy sinh lặng lẽ.",
    ],
    "Nhật healing mystery - yên bình nhưng đau": [
        "Mở bằng không khí yên bình nhưng cài một điều lệch nhẹ khiến người xem tò mò.",
        "Bí mật không cần sốc, nhưng phải làm người xem hiểu lại sự tử tế hoặc im lặng của nhân vật.",
        "Kết chữa lành, có dư âm buồn đẹp và một bài học nhân sinh tinh tế.",
    ],
    "Nhật căn hộ nhỏ - bí mật hàng xóm": [
        "Bối cảnh là chung cư/căn hộ nhỏ, hàng xóm ít nói, tiếng động lạ, thư nhầm hoặc món quà đặt trước cửa.",
        "Tạo bí mật đời thường qua những quan sát nhỏ, không biến thành kinh dị nặng.",
        "Twist nên mở ra sự cô đơn, lòng tốt hoặc một quá khứ mà cả khu nhà không ai biết.",
    ],
    "Hàn Quốc melodrama - gia đình + trả giá": [
        "Tăng mâu thuẫn gia đình, thân phận, hy sinh, sự im lặng và cái giá của tham vọng hoặc vô tâm.",
        "Cao trào cần có đối thoại mạnh, nước mắt và sự thật được phơi bày đúng lúc.",
        "Kết có thể vừa đau vừa ấm, nhấn vào trách nhiệm, tình thân và sự trả giá.",
    ],
    "Hàn Quốc chaebol - thừa kế + trả thù": [
        "Dùng gia đình tài phiệt, quyền thừa kế, con riêng, hôn nhân sắp đặt hoặc bí mật thân phận làm trục.",
        "Tăng đối thoại căng, quyền lực trong gia đình, sự nhục nhã công khai và cú lật bằng bằng chứng.",
        "Payoff phải thỏa mãn nhưng vẫn có cảm xúc: người yếu thế lấy lại danh dự, người tham vọng trả giá.",
    ],
    "Hàn Quốc makjang - thân phận bị che giấu": [
        "Khai thác tráo con, mẹ ruột/mẹ nuôi, bí mật huyết thống, phản bội gia đình và sự thật bị chôn nhiều năm.",
        "Nhịp drama dày, reveal nhiều lớp nhưng phải rõ để người nghe không rối.",
        "Cao trào là khoảnh khắc thân phận bị phơi bày trước gia đình hoặc xã hội.",
    ],
    "Hàn Quốc ly hôn chữa lành - phụ nữ đứng dậy": [
        "Trục chính là người phụ nữ sau phản bội/ly hôn/mất mát tự đứng dậy bằng công việc, tình bạn hoặc tự trọng.",
        "Không chỉ đau khổ; cần có hành trình hồi phục, chọn ranh giới và lấy lại tiếng nói.",
        "Kết nên đem lại cảm giác trưởng thành, bình yên và một cơ hội mới.",
    ],
    "Hàn Quốc công lý muộn - pháp lý + gia đình": [
        "Kết hợp gia đình, hồ sơ pháp lý, bằng chứng bị giấu và một nỗi oan lâu năm.",
        "Tạo nhịp điều tra cảm xúc: nhân chứng, camera, hồ sơ bệnh viện, lời khai cũ.",
        "Payoff là công lý đến muộn, lời xin lỗi hoặc sự thật giải phóng nhân vật.",
    ],
    "Trung Quốc gia đấu - di sản + thân phận": [
        "Dùng motif gia đình lớn, tài sản, thân phận bị che giấu, con riêng, di chúc hoặc quyền thừa kế.",
        "Xung đột nhiều tầng: thể diện, quyền lực trong nhà, lời hứa cũ, sự hy sinh bị hiểu lầm.",
        "Kết cần có màn lật thân phận hoặc bằng chứng khiến vị thế nhân vật thay đổi.",
    ],
    "Trung Quốc CEO short drama - thân phận + đổi đời": [
        "Dùng nhịp short drama: thân phận bị che giấu, tổng tài/CEO, hợp đồng hôn nhân, hiểu lầm và vả mặt.",
        "Mỗi đoạn phải có một cú kéo: bị coi thường, lộ kỹ năng, bằng chứng, nhân vật quyền lực xuất hiện.",
        "Kết có payoff mạnh về thân phận/đổi đời nhưng không quá lố nếu target là longform kể chuyện.",
    ],
    "Trung Quốc nữ chính báo thù - vả mặt gia tộc": [
        "Nữ chính bị coi thường, bị phản bội hoặc bị cướp công, sau đó trở lại bằng năng lực và bằng chứng.",
        "Tăng cảnh đối đầu gia tộc, lời mỉa mai, sự im lặng chiến lược và cú lật có tính thỏa mãn.",
        "Không để báo thù độc ác vô lý; nhấn vào tự trọng, công bằng và trả giá.",
    ],
    "Trung Quốc xuyên không/đổi mệnh - cổ trang hiện đại": [
        "Có thể dùng motif đổi mệnh/xuyên không/nhớ lại kiếp trước như công cụ tạo tuyến mới.",
        "Tập trung vào lựa chọn khác đi để tránh bi kịch cũ, không chỉ dùng yếu tố kỳ ảo cho vui.",
        "Bối cảnh có thể hiện đại hoặc cổ trang nhẹ, nhưng cảm xúc gia đình/thân phận phải rõ.",
    ],
    "Trung Quốc mẹ ruột/mẹ kế - tráo thân phận": [
        "Khai thác thân phận bị tráo, mẹ ruột/mẹ kế, con bị bỏ rơi, sự thật huyết thống và tài sản gia đình.",
        "Cài bằng chứng từng bước: vòng ngọc, giấy khai sinh, ảnh cũ, bệnh án, người làm chứng.",
        "Cao trào là khoảnh khắc nhân vật được công nhận hoặc chọn rời đi trong tự trọng.",
    ],
    "Mỹ suburb secret - bí mật thị trấn nhỏ": [
        "Bối cảnh nên có khu phố yên bình, hàng xóm lịch sự, gia đình tưởng hoàn hảo nhưng giấu bí mật.",
        "Tạo suspense bằng chi tiết lạ: chiếc hộp, camera cửa, bức thư, hóa đơn, cuộc gọi từ quá khứ.",
        "Kết mở ra sự thật phía sau vẻ bình thường, vừa bất ngờ vừa có cảm xúc gia đình.",
    ],
    "Mỹ true crime family - gia đình hoàn hảo sụp đổ": [
        "Viết như hồ sơ true-crime nhưng không khai thác bạo lực rẻ tiền: timeline, dấu hiệu bất thường, bí mật, hậu quả.",
        "Gia đình/khu phố ban đầu có vẻ hoàn hảo, sau đó từng chi tiết làm lộ sự thật đằng sau.",
        "Giọng kể căng, rõ, có đạo đức kể chuyện; nếu chi tiết không chắc, không khẳng định như sự thật.",
    ],
    "Mỹ billionaire romance/revenge - vertical drama": [
        "Dùng trope vertical drama: billionaire, hợp đồng hôn nhân, thân phận ẩn, phản bội, trả thù và lật vị thế.",
        "Nhịp nhanh, cliffhanger dày, mỗi cảnh có một quyền lực mới hoặc một bí mật mới.",
        "Kết nên thỏa mãn kiểu drama nhưng vẫn giữ cảm xúc nhân vật, không chỉ khoe tiền.",
    ],
    "Mỹ single mom comeback - đổi đời cảm xúc": [
        "Nhân vật chính là mẹ đơn thân/người yếu thế bị coi thường, rồi từng bước đứng dậy bằng năng lực và tình thương.",
        "Tạo cảm xúc bằng áp lực tài chính, con cái, công việc, định kiến và sự giúp đỡ bất ngờ.",
        "Payoff là lấy lại phẩm giá, bảo vệ con và có tương lai mới.",
    ],
    "Mỹ neighbor from hell - hàng xóm ám ảnh": [
        "Dựng conflict hàng xóm: camera, hàng rào, tiếng ồn, thư nặc danh, bí mật khu phố.",
        "Tăng suspense bằng chuỗi sự kiện nhỏ leo thang, không cần quá bạo lực.",
        "Twist cuối phải làm người xem hiểu động cơ thật của hàng xóm hoặc gia đình chính.",
    ],
    "Pháp enquête true crime - hồ sơ lạnh": [
        "Viết theo nhịp enquête: hồ sơ cũ, nhân chứng, chi tiết bị bỏ qua, cuộc điều tra lặng lẽ.",
        "Không khí Pháp nên tinh tế, ít ồn ào, nhiều tâm lý và quan sát xã hội.",
        "Kết không nhất thiết vả mặt mạnh; có thể là sự thật lạnh, một nỗi buồn hoặc công lý muộn.",
    ],
    "Pháp tâm lý gia đình - bí mật nhiều năm": [
        "Tập trung vào đối thoại, khoảng lặng, ký ức gia đình, bí mật bị giấu sau sự lịch sự.",
        "Xung đột nên tinh tế: thừa kế, mẹ con xa cách, ngoại tình cũ, một đứa con bị bỏ rơi.",
        "Payoff đến từ một sự thật khiến mọi người phải nhìn lại chính mình.",
    ],
    "Pháp tỉnh lẻ/di sản - ký ức và thừa kế": [
        "Bối cảnh là làng nhỏ, nhà cũ, vườn nho/quán ăn/gia sản, lá thư hoặc di chúc.",
        "Khai thác ký ức, mùi vị, đồ vật, câu chuyện thế hệ và một món nợ tinh thần.",
        "Kết có chất hoài niệm, không cần quá sốc nhưng phải sâu và đẹp.",
    ],
    "Pháp xã hội đạo đức - tranh luận gia đình": [
        "Dựng tình huống có hai luồng quan điểm xã hội/đạo đức: chăm cha mẹ, ly hôn, tiền bạc, danh dự, con cái.",
        "Mỗi nhân vật có lý lẽ riêng, tránh biến ai thành phản diện đơn giản.",
        "Kết mở ra tranh luận nhưng vẫn có đường dây cảm xúc rõ.",
    ],
    "Úc outback mystery - vùng xa bí ẩn": [
        "Bối cảnh vùng xa, trang trại, đường dài, thị trấn nhỏ, thiên nhiên khắc nghiệt hoặc một người mất tích.",
        "Tạo cảm giác rộng, cô lập, ít người biết sự thật, mỗi chi tiết nhỏ đều đáng nghi.",
        "Kết nên gắn bí mật cá nhân với sự khắc nghiệt của môi trường hoặc cộng đồng nhỏ.",
    ],
    "Úc crime comedy noir - hài đen căng thẳng": [
        "Pha căng thẳng với hài đen nhẹ: nhân vật đời thường vướng vào bí mật, tiền bạc, hàng xóm hoặc cảnh sát.",
        "Nhịp kể thông minh, có twist khô khan, không quá bi lụy.",
        "Kết nên vừa bất ngờ vừa có chút chua chát hoặc nhân văn.",
    ],
    "Úc coastal town secret - thị trấn biển có bí mật": [
        "Bối cảnh thị trấn biển, cộng đồng quen nhau, gia đình tưởng bình yên nhưng che giấu một chuyện cũ.",
        "Dùng biển, bến tàu, nhà nghỉ, quán cà phê, mùa du lịch làm chất liệu cảnh.",
        "Reveal nên liên quan đến quá khứ của thị trấn hoặc một mối quan hệ bị che giấu.",
    ],
    "Úc hybrid documentary - người thật + tái hiện": [
        "Viết như documentary lai tái hiện: lời kể, mốc thời gian, chi tiết hiện trường, cảnh tái dựng cảm xúc.",
        "Giữ giọng đáng tin, không phóng đại quá mức, nhưng vẫn có hook và cao trào.",
        "Phù hợp các câu chuyện mất tích, gia đình, cộng đồng nhỏ, hành trình sống sót hoặc phục hồi.",
    ],
    "Đức krimi cold case - điều tra lạnh": [
        "Dùng nhịp krimi: vụ việc cũ, hồ sơ lạnh, điều tra viên/người thân tìm lại manh mối.",
        "Không khí lạnh, logic, ít màu mè; suspense đến từ bằng chứng và sự im lặng của nhân vật.",
        "Kết ưu tiên sự thật, trách nhiệm và hậu quả đạo đức.",
    ],
    "Đức social realist - nhập cư/bản sắc": [
        "Khai thác đời sống thực tế: gia đình nhập cư, thế hệ trẻ/già, công việc, trường học, định kiến hoặc bản sắc.",
        "Xung đột không cần quá melodrama; sức mạnh là tính thật, khó xử và nhân phẩm.",
        "Kết nên mở ra sự thấu hiểu hoặc một lựa chọn trưởng thành.",
    ],
    "Đức gia đình im lặng - tội lỗi quá khứ": [
        "Dựng gia đình nhiều năm không nói về một lỗi lầm, bí mật chiến tranh/di cư/tài sản hoặc người bị bỏ quên.",
        "Nhịp chậm, lạnh, nhiều khoảng lặng và đối thoại kiềm chế.",
        "Reveal phải khiến cả nhà đối diện quá khứ thay vì chỉ tạo sốc.",
    ],
    "Đức documentary trauma - phục hồi bản sắc": [
        "Viết như documentary về chấn thương, mất mát, phục hồi hoặc tìm lại bản sắc cá nhân/gia đình.",
        "Giọng kể tôn trọng, không khai thác nỗi đau quá đà; tập trung vào quá trình hiểu và chữa lành.",
        "Kết có thể trầm, nhưng cần cho người xem cảm giác sự thật đã được gọi tên.",
    ],
    "Mini drama nhiều tập - cliffhanger dày": [
        "Viết theo nhịp tập ngắn nối tiếp: mỗi đoạn có hook, xung đột, mini reveal và câu kéo sang đoạn sau.",
        "Tăng cliffhanger nhưng không làm rối; mỗi 300-500 từ nên có một câu hỏi mới.",
        "Kết hiện tại phải có payoff một phần và mở loop đủ mạnh cho tập sau.",
    ],
    "YouTube longform 60 phút - nhiều lớp cảnh": [
        "Triển khai nhiều lớp cảnh, nhiều tuyến cảm xúc và nhiều bước ngoặt, tránh tóm tắt cốt truyện.",
        "Mỗi phần lớn cần có mở loop, cao trào nhỏ, đoạn lắng và câu nối sang phần sau.",
        "Ưu tiên độ dài, đối thoại, nội tâm, hồi tưởng, chi tiết đời thường và payoff dài hơi.",
    ],
    "Podcast kể chuyện - chậm, sâu, dễ nghe": [
        "Viết như lời kể audio dài: câu rõ, nhịp thở tốt, ít visual phụ thuộc màn hình.",
        "Tăng các đoạn suy ngẫm, liên hệ đời sống và chuyển cảnh mượt để nghe không mệt.",
        "Hook không cần quá sốc, nhưng phải có câu hỏi cảm xúc kéo người nghe ở lại.",
    ],
    "Dark secret - bí mật đen tối nhưng nhân văn": [
        "Bí mật có thể nặng, nhưng cách kể phải nhân văn, không khai thác sốc rẻ tiền.",
        "Tạo cảm giác bất an bằng chi tiết nhỏ, sự im lặng bất thường và những điều nhân vật né tránh.",
        "Kết cần soi vào lựa chọn con người, trách nhiệm và hậu quả, không chỉ gây sốc.",
    ],
    "Wholesome twist - ấm áp bất ngờ": [
        "Cài tình huống tưởng tiêu cực nhưng cuối cùng hé lộ lòng tốt, sự hy sinh hoặc một hiểu lầm đẹp.",
        "Giữ nhịp ấm áp, ít phản diện hóa; twist khiến người xem nhẹ lòng và muốn chia sẻ.",
        "Kết nên có lời chiêm nghiệm mềm, phù hợp kênh kể chuyện gia đình/tình người.",
    ],
    "Viết lại 100% - chỉ giữ ý tưởng lõi": [
        "Chỉ giữ chủ đề, cảm xúc lõi và bài học nhân sinh; thay toàn bộ hook, tuyến sự kiện, ví dụ, câu thoại, reveal và kết.",
        "Không đi theo thứ tự tình tiết của bản gốc. Hãy tự dựng outline mới trước khi viết thành văn.",
        "Mục tiêu độ giống dưới 15-20%; bản mới phải đọc như một kịch bản độc lập, không phải bản viết lại từng đoạn.",
    ],
    "Câu chuyện mới 100% - đổi nhân vật/bối cảnh": [
        "Đổi nhân vật chính, nghề nghiệp, gia đình, nơi xảy ra chuyện, thời điểm và quan hệ giữa các nhân vật.",
        "Giữ lại bài học/cảm xúc nền nhưng tạo chuỗi sự kiện mới hoàn toàn.",
        "Không dùng lại cảnh đặc trưng, vật chứng, lá thư/cuộc gọi/di chúc nếu đó là trục chính của bản gốc; thay bằng một cơ chế reveal khác.",
    ],
    "Plot twist mới 100% - khác tuyến truyện": [
        "Tạo một cú twist mới, khác bản gốc cả nguyên nhân lẫn cách reveal.",
        "Cài manh mối mới từ đầu để twist hợp lý, không dùng lại manh mối hoặc chi tiết nhận diện của nguồn.",
        "Sau twist phải có payoff cảm xúc mới: hối hận, công nhận, tha thứ, rời đi hoặc một lựa chọn nhân văn.",
    ],
    "Drama gia đình 100% - tuyến truyện mới": [
        "Chỉ giữ cảm xúc lõi về gia đình; đổi toàn bộ nhân vật, quan hệ, nguyên nhân xung đột, bối cảnh và cao trào.",
        "Tạo tuyến drama mới có nấc thang căng thẳng rõ, không đi lại trật tự tình tiết của nguồn.",
        "Kết phải có payoff mới: lời xin lỗi, chia tay, tha thứ, trả giá hoặc thức tỉnh.",
    ],
    "Confession 100% - đổi toàn bộ sự kiện": [
        "Biến insight nguồn thành một lời thú nhận hoàn toàn mới, đổi toàn bộ sự kiện và chi tiết nhận diện.",
        "Ngôi kể, bí mật, lỗi lầm và bài học phải mới, chỉ giữ cảm xúc nền.",
        "Đọc lên phải giống một câu chuyện người thật khác kể, không giống bản gốc.",
    ],
    "Documentary 100% - hồ sơ mới từ insight cũ": [
        "Dùng insight nguồn để dựng một hồ sơ/case mới hoàn toàn với timeline, nhân vật và bằng chứng khác.",
        "Không dùng lại vật chứng, twist, cảnh mở hoặc kết của nguồn.",
        "Giọng kể có chất điều tra/documentary, nhưng vẫn cần cảm xúc và bài học cuối.",
    ],
    "Cinematic 100% - bản gốc chỉ là cảm hứng": [
        "Xem bản gốc như mood/cảm hứng, không như outline. Dựng lại câu chuyện bằng cảnh mở, biểu tượng, xung đột và cao trào mới.",
        "Tăng chất điện ảnh trong ngôn ngữ kể voice: không khí, vật thể biểu tượng, nhịp im lặng, hồi tưởng, cảnh đối thoại.",
        "Không sao chép cấu trúc đoạn hoặc nhịp reveal của nguồn; bản mới phải có đường dây cảm xúc riêng.",
    ],
    "Series 100% - mở vũ trụ câu chuyện mới": [
        "Biến ý tưởng lõi thành tập đầu của một series mới, có nhân vật, bí mật và xung đột dài hơi riêng.",
        "Kết tập phải có payoff đủ thỏa mãn nhưng vẫn để lại open loop tự nhiên cho tập sau.",
        "Không dùng lại tuyến truyện cũ; chỉ giữ thông điệp nền rồi mở rộng thành thế giới câu chuyện mới.",
    ],
    "Viết lại mạnh - đổi 70-80%": [
        "Giữ ý tưởng lõi nhưng thay hook, trình tự, ví dụ, nhân vật phụ, cách reveal và CTA.",
        "Tránh mô phỏng nhịp câu hoặc cấu trúc đoạn của nguồn.",
        "Ưu tiên bản mới có cảm giác như một kịch bản độc lập, không phải bản paraphrase.",
    ],
    "Dịch + localize + nâng cấp": [
        "Không dịch sát; chuyển văn hóa, tuổi tác, quan hệ gia đình, cách xưng hô và bối cảnh cho người xem đầu ra.",
        "Giữ sự kiện/cảm xúc chính nhưng thay ví dụ, ẩn dụ, lời thoại và nhịp kể cho tự nhiên.",
        "Nếu bản gốc là Nhật/Trung/Hàn/Anh/Đức/Pháp, cần viết như một kịch bản bản địa hóa, không còn mùi dịch.",
    ],
    "Giữ cảm xúc - tăng retention": [
        "Giữ nỗi đau/cảm xúc lõi của nguồn nhưng thêm open loop, câu kéo tiếp và chuyển cảnh có nhịp.",
        "Mỗi 45-60 giây cần có một lý do mới để người xem tiếp tục nghe.",
        "Cắt phần lặp, thay bằng chi tiết cảm xúc mới hoặc hành động cụ thể của nhân vật.",
    ],
    "Review/bán hàng - tăng chuyển đổi": [
        "Dùng cấu trúc vấn đề - hậu quả - giải pháp - bằng chứng - phản đối - CTA.",
        "Giữ giọng đáng tin, thực tế, không thổi phồng quá mức.",
        "CTA phải rõ nhưng không ép, phù hợp người đang cân nhắc mua hoặc so sánh.",
    ],
    "Storytelling dài - cinematic": [
        "Dựng như phim: cảnh mở, không khí, vật thể biểu tượng, nhịp camera tưởng tượng, cao trào và hậu vị.",
        "Tăng visual cue nhưng không biến output thành storyboard; vẫn là kịch bản đọc voice hoàn chỉnh.",
        "Nhịp dài cần có nhiều cảnh nối tiếp, hồi tưởng, đối thoại, nội tâm và twist vừa đủ.",
    ],
}

VOICE_WPM_MIN = 130
VOICE_WPM_MAX = 150
VOICE_PROFILES = {
    "default": {"unit": "từ", "min_rate": 130, "max_rate": 150, "token_factor": 2.1},
    "english": {"unit": "từ tiếng Anh", "min_rate": 130, "max_rate": 160, "token_factor": 1.8},
    "european": {"unit": "từ", "min_rate": 125, "max_rate": 155, "token_factor": 2.0},
    "japanese": {"unit": "ký tự Nhật", "min_rate": 300, "max_rate": 360, "token_factor": 1.6},
    "chinese": {"unit": "ký tự Trung", "min_rate": 250, "max_rate": 320, "token_factor": 1.5},
    "korean": {"unit": "ký tự Hàn", "min_rate": 260, "max_rate": 330, "token_factor": 1.6},
}

VIDEO_MIME_BY_SUFFIX = {
    ".mp4": "video/mp4",
    ".mpeg": "video/mpeg",
    ".mpg": "video/mpg",
    ".mov": "video/quicktime",
    ".qt": "video/quicktime",
    ".avi": "video/avi",
    ".flv": "video/x-flv",
    ".webm": "video/webm",
    ".wmv": "video/wmv",
    ".3gp": "video/3gpp",
    ".3gpp": "video/3gpp",
}

SAMPLE_SCRIPT = """Bạn có bao giờ tự hỏi vì sao có những người làm việc rất nhiều nhưng kết quả vẫn không tiến lên?
Vấn đề không nằm ở việc họ lười. Vấn đề là họ đang đổ năng lượng vào những việc không tạo ra đòn bẩy.
Trong video này, tôi sẽ chỉ ra ba sai lầm khiến lịch làm việc trông có vẻ bận rộn nhưng thực ra lại đang kéo bạn đi vòng tròn.
Sai lầm đầu tiên là bắt đầu ngày bằng việc trả lời tin nhắn. Khi bạn mở email, chat và mạng xã hội trước, bạn cho người khác quyền quyết định sự tập trung của mình.
Sai lầm thứ hai là không có một đầu ra rõ ràng cho mỗi buổi làm việc. Nếu bạn chỉ ghi "làm marketing" vào lịch, não nào cũng không biết cần kết thúc ở đâu.
Sai lầm thứ ba là nghĩ rằng thêm giờ làm sẽ giải quyết mọi thứ. Nhưng nếu hệ thống sai, thêm thời gian chỉ làm sai nhanh hơn.
Cách sửa rất đơn giản: chọn một việc tạo tác động lớn nhất trong ngày, định nghĩa đầu ra trong một câu, và làm nó trước khi mở bất kỳ kênh phản hồi nào.
Nếu bạn làm điều này trong bảy ngày, bạn sẽ thấy lịch làm việc nhẹ hơn nhưng kết quả rõ hơn."""


@dataclass
class Beat:
    index: int
    word_count: int
    first_sentence: str
    keywords: list[str]
    text: str


@dataclass
class Analysis:
    word_count: int
    estimated_minutes: float
    sentence_count: int
    top_keywords: list[str]
    opening: list[str]
    closing: list[str]
    beats: list[Beat]


def normalize_words(text: str) -> list[str]:
    tokens: list[str] = []
    for word in WORD_RE.findall(text.lower()):
        if CJK_CHAR_RE.search(word) and not LATIN_WORD_RE.search(word) and len(word) > 3:
            tokens.extend(CJK_CHAR_RE.findall(word))
        else:
            tokens.append(word)
    return tokens


def content_words(text: str) -> list[str]:
    return [word for word in normalize_words(text) if (len(word) > 2 or CJK_CHAR_RE.fullmatch(word)) and word not in STOPWORDS]


def language_profile_key(language: str = "", text: str = "") -> str:
    value = (language or "").lower()
    if "nhật" in value or "japanese" in value:
        return "japanese"
    if "trung" in value or "chinese" in value:
        return "chinese"
    if "hàn" in value or "korean" in value:
        return "korean"
    if "anh" in value or "english" in value:
        return "english"
    if any(item in value for item in ("đức", "pháp", "german", "french")):
        return "european"
    if text:
        cjk_count = len(CJK_CHAR_RE.findall(text))
        latin_words = len([word for word in WORD_RE.findall(text) if LATIN_WORD_RE.search(word)])
        if cjk_count >= 120 and cjk_count > latin_words * 3:
            # Auto-detect rough script type only for display/estimation when language is unknown.
            japanese_chars = len(re.findall(r"[\u3040-\u30ff]", text))
            korean_chars = len(re.findall(r"[\uac00-\ud7a3]", text))
            if korean_chars > cjk_count * 0.4:
                return "korean"
            if japanese_chars > cjk_count * 0.15:
                return "japanese"
            return "chinese"
    return "default"


def text_script_stats(text: str) -> dict:
    korean = len(KOREAN_RE.findall(text or ""))
    japanese = len(JAPANESE_RE.findall(text or ""))
    han = len(HAN_RE.findall(text or ""))
    cjk = korean + japanese + han
    latin_words = len([word for word in WORD_RE.findall(text or "") if LATIN_WORD_RE.search(word) and not CJK_CHAR_RE.search(word)])
    return {
        "korean": korean,
        "japanese": japanese,
        "han": han,
        "cjk": cjk,
        "latin_words": latin_words,
    }


def text_looks_like_language(text: str, language: str) -> bool:
    clean = (text or "").strip()
    if not clean:
        return False
    if "việt" in (language or "").lower():
        return text_looks_like_vietnamese_with_diacritics(clean)
    key = language_profile_key(language)
    stats = text_script_stats(clean)
    total_letters = max(stats["cjk"] + stats["latin_words"], 1)
    if key == "korean":
        return stats["korean"] >= 30 and stats["korean"] >= total_letters * 0.35
    if key == "japanese":
        return stats["japanese"] >= 20 and stats["japanese"] >= total_letters * 0.12
    if key == "chinese":
        return stats["han"] >= 40 and stats["japanese"] < 20 and stats["korean"] < 20
    if key in {"default", "english", "european"}:
        if stats["korean"] >= 20 or stats["japanese"] >= 20:
            return False
        if stats["han"] >= 80 and stats["han"] > stats["latin_words"]:
            return False
        return stats["latin_words"] >= 20 or len(clean) < 120
    return True


def text_looks_like_vietnamese_with_diacritics(text: str) -> bool:
    clean = (text or "").strip()
    if not clean:
        return False
    stats = text_script_stats(clean)
    if stats["korean"] >= 1 or stats["japanese"] >= 1:
        return False
    if stats["han"] >= 1:
        return False
    latin_words = max(stats["latin_words"], 1)
    mark_count = len(VIETNAMESE_MARK_RE.findall(clean))
    common_count = len(VIETNAMESE_COMMON_RE.findall(clean))
    if len(clean) < 120:
        return mark_count >= 1 or common_count >= 2
    return mark_count >= max(3, round(latin_words * 0.025)) or (
        mark_count >= 1 and common_count >= max(5, round(latin_words * 0.04))
    )


def language_mismatch_warning(text: str, language: str) -> str:
    if "việt" in (language or "").lower():
        stats = text_script_stats(text)
        if stats["korean"] >= 1:
            return "kết quả còn chữ Hàn, chưa phải 100% tiếng Việt"
        if stats["japanese"] >= 1:
            return "kết quả còn chữ Nhật, chưa phải 100% tiếng Việt"
        if stats["han"] >= 1:
            return "kết quả còn chữ Trung/Hán, chưa phải 100% tiếng Việt"
        if text_looks_like_vietnamese_with_diacritics(text):
            return ""
        return "kết quả chưa phải tiếng Việt có dấu rõ ràng"
    if text_looks_like_language(text, language):
        return ""
    stats = text_script_stats(text)
    if stats["korean"] >= 20:
        return "kết quả còn nhiều chữ Hàn"
    if stats["japanese"] >= 20:
        return "kết quả còn nhiều chữ Nhật"
    if stats["han"] >= 80:
        return "kết quả còn nhiều chữ Trung/Hán"
    return "kết quả có vẻ chưa đúng ngôn ngữ yêu cầu"


def valid_vietnamese_training_profile(text: str) -> bool:
    return len((text or "").strip()) >= 200 and text_looks_like_language(text, "Tiếng Việt")


def voice_profile(language: str = "", text: str = "") -> dict:
    return VOICE_PROFILES[language_profile_key(language, text)]


def voice_unit_count(text: str, language: str = "") -> int:
    profile_key = language_profile_key(language, text)
    if profile_key in {"japanese", "chinese", "korean"}:
        cjk_count = len(CJK_CHAR_RE.findall(text))
        latin_words = len([word for word in WORD_RE.findall(text) if LATIN_WORD_RE.search(word) and not CJK_CHAR_RE.search(word)])
        return cjk_count + latin_words
    return len(normalize_words(text))


def estimated_voice_minutes(text: str, language: str = "") -> float:
    units = voice_unit_count(text, language)
    profile = voice_profile(language, text)
    if not units:
        return 0.0
    average_rate = (profile["min_rate"] + profile["max_rate"]) / 2
    return round(units / average_rate, 1)


def estimated_voice_range_text(unit_count: int, language: str = "", text: str = "") -> str:
    if unit_count <= 0:
        return "0.0 phút"
    profile = voice_profile(language, text)
    low = unit_count / profile["max_rate"]
    high = unit_count / profile["min_rate"]
    if abs(low - high) < 0.15:
        return f"{round((low + high) / 2, 1):g} phút"
    return f"{round(low, 1):g}-{round(high, 1):g} phút"


def split_sentences(text: str) -> list[str]:
    parts = [part.strip() for part in SENTENCE_SPLIT_RE.split(text) if part.strip()]
    cleaned: list[str] = []
    for part in parts:
        if len(normalize_words(part)) <= 42:
            cleaned.append(part)
            continue
        chunks = [chunk.strip() for chunk in re.split(r"[,;:]\s+", part) if chunk.strip()]
        cleaned.extend(chunks if len(chunks) > 1 else [part])
    return cleaned


def trim_sentence(sentence: str, max_words: int = 22) -> str:
    words = sentence.split()
    if len(words) <= 1 and len(sentence) > max_words * 6:
        return sentence[: max_words * 6].rstrip(",.;:、。！？") + "..."
    if len(words) <= max_words:
        return sentence
    return " ".join(words[:max_words]).rstrip(",.;:") + "..."


def top_keywords(text: str, limit: int = 12) -> list[str]:
    counts = Counter(content_words(text))
    return [word for word, _ in counts.most_common(limit)]


def chunk_sentences(sentences: list[str], target_words: int = 120) -> list[list[str]]:
    chunks: list[list[str]] = []
    current: list[str] = []
    current_words = 0
    for sentence in sentences:
        wc = len(normalize_words(sentence))
        if current and current_words + wc > target_words:
            chunks.append(current)
            current = []
            current_words = 0
        current.append(sentence)
        current_words += wc
    if current:
        chunks.append(current)
    return chunks


def analyze_script(text: str) -> Analysis:
    words = normalize_words(text)
    sentences = split_sentences(text)
    beats: list[Beat] = []
    for index, chunk in enumerate(chunk_sentences(sentences), start=1):
        chunk_text = " ".join(chunk)
        beats.append(
            Beat(
                index=index,
                word_count=len(normalize_words(chunk_text)),
                first_sentence=trim_sentence(chunk[0] if chunk else ""),
                keywords=top_keywords(chunk_text, 5),
                text=chunk_text,
            )
        )
    return Analysis(
        word_count=len(words),
        estimated_minutes=estimated_voice_minutes(text),
        sentence_count=len(sentences),
        top_keywords=top_keywords(text, 16),
        opening=[trim_sentence(sentence) for sentence in sentences[:3]],
        closing=[trim_sentence(sentence) for sentence in sentences[-3:]],
        beats=beats,
    )


def extractive_summary_sentences(text: str, limit: int = 7) -> list[str]:
    sentences = [sentence.strip() for sentence in split_sentences(text) if sentence.strip()]
    if not sentences:
        return []
    keyword_scores = Counter(content_words(text))
    ranked: list[tuple[float, int, str]] = []
    total = max(len(sentences), 1)
    for index, sentence in enumerate(sentences):
        words = content_words(sentence)
        surface_len = len(normalized_surface(sentence))
        if not words and surface_len < 18:
            continue
        score = sum(keyword_scores.get(word, 0) for word in words)
        if index < 3:
            score += 6
        if index >= total - 3:
            score += 4
        if 12 <= len(normalize_words(sentence)) <= 48 or surface_len >= 45:
            score += 3
        ranked.append((score, index, sentence))
    if not ranked:
        return [trim_sentence(sentence, 36) for sentence in sentences[:limit]]
    selected = sorted(ranked, reverse=True)[:limit]
    selected_indexes = sorted(index for _score, index, _sentence in selected)
    summary: list[str] = []
    seen = set()
    for index in selected_indexes:
        sentence = trim_sentence(sentences[index], 42)
        key = normalized_surface(sentence)[:80]
        if key and key not in seen:
            summary.append(sentence)
            seen.add(key)
    return summary[:limit]


def story_beats_summary(text: str, limit: int = 8) -> list[str]:
    analysis = analyze_script(text)
    lines: list[str] = []
    for beat in analysis.beats[:limit]:
        keywords = ", ".join(beat.keywords[:5]) or "ý chính trong đoạn"
        first = trim_sentence(beat.first_sentence, 24)
        lines.append(f"- Beat {beat.index}: {keywords} | {first}")
    return lines


def summary_detail_limit(text: str, language: str = "") -> int:
    units = voice_unit_count(text, language)
    if units >= 6500:
        return 30
    if units >= 4000:
        return 24
    if units >= 2200:
        return 18
    if units >= 1000:
        return 14
    return 10


def best_timeline_sentence(candidates: list[str], global_scores: Counter) -> str:
    if not candidates:
        return ""
    ranked: list[tuple[float, int, str]] = []
    for index, sentence in enumerate(candidates):
        words = content_words(sentence)
        surface_len = len(normalized_surface(sentence))
        if not words and surface_len < 20:
            continue
        score = sum(global_scores.get(word, 0) for word in words)
        if index == 0:
            score += 2.5
        if any(mark in sentence for mark in ("\"", "“", "”", "「", "」", "『", "』")):
            score += 2
        if 12 <= len(normalize_words(sentence)) <= 70 or surface_len >= 45:
            score += 2
        ranked.append((score, -index, sentence))
    if not ranked:
        return candidates[0]
    return max(ranked)[2]


def detailed_timeline_summary(text: str, language: str = "", limit: int | None = None) -> list[str]:
    clean = (text or "").strip()
    sentences = [sentence.strip() for sentence in split_sentences(clean) if sentence.strip()]
    if not sentences:
        return []
    limit = limit or summary_detail_limit(clean, language)
    if len(sentences) <= limit:
        return [trim_sentence(sentence, 60) for sentence in sentences]
    global_scores = Counter(content_words(clean))
    chunk_size = max(1, math.ceil(len(sentences) / limit))
    items: list[str] = []
    seen = set()
    for start in range(0, len(sentences), chunk_size):
        chunk = sentences[start : start + chunk_size]
        sentence = trim_sentence(best_timeline_sentence(chunk, global_scores), 64)
        key = normalized_surface(sentence)[:100]
        if sentence and key not in seen:
            items.append(sentence)
            seen.add(key)
        if len(items) >= limit:
            break
    return items


def script_summary_markdown(text: str, title: str, language: str = "") -> str:
    clean = (text or "").strip()
    if not clean:
        return f"# {title}\n\nChưa có nội dung."
    analysis = analyze_script(clean)
    units = voice_unit_count(clean, language)
    profile = voice_profile(language, clean)
    detail_limit = summary_detail_limit(clean, language)
    summary_lines = extractive_summary_sentences(clean, min(12, max(7, detail_limit // 2)))
    timeline_lines = detailed_timeline_summary(clean, language, detail_limit)
    opening = analysis.opening[:2] or ["N/A"]
    closing = analysis.closing[-2:] or ["N/A"]
    return "\n".join(
        [
            f"# {title}",
            "",
            "## Thông số nhanh",
            f"- Độ dài: {format_int_vn(units)} {profile['unit']} | voice khoảng {estimated_voice_range_text(units, language, clean)}",
            f"- Số câu/đoạn: {analysis.sentence_count}",
            f"- Từ khóa/chủ đề nổi bật: {', '.join(analysis.top_keywords[:14]) or 'N/A'}",
            "",
            "## Hook / mở đầu",
            *[f"- {item}" for item in opening],
            "",
            "## Tóm tắt nội dung",
            *[f"- {item}" for item in summary_lines],
            "",
            "## Diễn biến chi tiết theo trình tự",
            *[f"- {index}. {item}" for index, item in enumerate(timeline_lines, start=1)],
            "",
            "## Cấu trúc beat chính",
            *(story_beats_summary(clean, min(18, detail_limit)) or ["- Chưa đủ dữ liệu để tách beat."]),
            "",
            "## Kết / payoff",
            *[f"- {item}" for item in closing],
        ]
    )


def summary_comparison_markdown(source: str, rewritten: str, source_language: str = "", target_language: str = "") -> str:
    source = (source or "").strip()
    rewritten = (rewritten or "").strip()
    if not source or not rewritten:
        return "# So sánh tóm tắt\n\nCần có cả kịch bản gốc và bản AI viết lại."
    source_units = voice_unit_count(source, source_language)
    rewritten_units = voice_unit_count(rewritten, target_language)
    source_profile = voice_profile(source_language, source)
    rewritten_profile = voice_profile(target_language, rewritten)
    source_keywords = set(top_keywords(source, 22))
    rewritten_keywords = set(top_keywords(rewritten, 22))
    shared = sorted(source_keywords & rewritten_keywords)[:12]
    added = sorted(rewritten_keywords - source_keywords)[:12]
    reduced = sorted(source_keywords - rewritten_keywords)[:12]
    length_delta = rewritten_units - source_units
    if source_units:
        length_ratio = round(rewritten_units / source_units * 100)
        length_note = f"{length_delta:+,}".replace(",", ".") + f" {rewritten_profile['unit']} | bằng khoảng {length_ratio}% so với bản gốc"
    else:
        length_note = "N/A"
    source_summary = extractive_summary_sentences(source, 5)
    rewritten_summary = extractive_summary_sentences(rewritten, 5)
    local_report = score_similarity(source, rewritten)
    similarity = local_report.get("similarity_percent", 0)
    if rewritten_units < source_units:
        recommendation = "Bản mới đang ngắn hơn bản gốc; nếu muốn video dài hơn, nên tăng thời lượng hoặc chạy nâng cấp draft."
    elif similarity >= 42:
        recommendation = "Bản mới còn khá gần bản gốc; nên đổi thêm hook, thứ tự reveal, ví dụ và lời thoại."
    elif not added:
        recommendation = "Bản mới đã khác hơn, nhưng chưa thấy nhiều chủ đề mới; có thể thêm chi tiết đời thường hoặc twist phụ."
    else:
        recommendation = "Bản mới có thay đổi đủ để kiểm tra tiếp bằng Độ giống và bản dịch kiểm tra."
    return "\n".join(
        [
            "# So sánh tóm tắt trực quan",
            "",
            "## Độ dài",
            f"- Gốc: {format_int_vn(source_units)} {source_profile['unit']} | voice {estimated_voice_range_text(source_units, source_language, source)}",
            f"- Bản AI: {format_int_vn(rewritten_units)} {rewritten_profile['unit']} | voice {estimated_voice_range_text(rewritten_units, target_language, rewritten)}",
            f"- Chênh lệch: {length_note}",
            "",
            "## Ý chính bản gốc",
            *[f"- {item}" for item in source_summary],
            "",
            "## Ý chính bản AI",
            *[f"- {item}" for item in rewritten_summary],
            "",
            "## Chủ đề chung",
            f"- {', '.join(shared) if shared else 'Không phát hiện nhiều từ khóa chung rõ ràng.'}",
            "",
            "## Chủ đề/chi tiết bản AI thêm mới",
            f"- {', '.join(added) if added else 'Chưa thấy nhiều chủ đề mới nổi bật.'}",
            "",
            "## Chủ đề bản gốc bị giảm hoặc biến mất",
            f"- {', '.join(reduced) if reduced else 'Không có dấu hiệu bỏ sót chủ đề lớn theo keyword local.'}",
            "",
            "## Độ giống local",
            f"- Ước tính: {similarity}% | rủi ro {str(local_report.get('risk', 'unknown')).upper()}",
            "",
            "## Gợi ý",
            f"- {recommendation}",
        ]
    )


DIRECT_SUMMARY_SOURCE_MARKER = "<<<SOURCE_SUMMARY>>>"
DIRECT_SUMMARY_REWRITTEN_MARKER = "<<<REWRITTEN_SUMMARY>>>"
DIRECT_SUMMARY_COMPARISON_MARKER = "<<<COMPARISON>>>"


def compact_text_for_summary(text: str, max_chars: int = 70000) -> str:
    clean = (text or "").strip()
    if len(clean) <= max_chars:
        return clean
    head_chars = max_chars // 3
    middle_chars = max_chars // 3
    tail_chars = max_chars - head_chars - middle_chars
    middle_start = max((len(clean) // 2) - (middle_chars // 2), 0)
    return "\n\n".join(
        [
            clean[:head_chars].strip(),
            "[...Đã rút gọn phần giữa rất dài để tạo tóm tắt nhanh hơn, vẫn giữ mở đầu - giữa - kết...]",
            clean[middle_start : middle_start + middle_chars].strip(),
            "[...Tiếp phần cuối của kịch bản...]",
            clean[-tail_chars:].strip(),
        ]
    )


def direct_summary_generation_settings(config: dict, source: str, rewritten: str) -> dict:
    model = (config.get("gemini_model") or "").lower()
    total_units = voice_unit_count(source, config.get("source_language", "")) + voice_unit_count(rewritten, config.get("target_language", ""))
    max_tokens = 6000
    if total_units >= 10000:
        max_tokens = 9000
    elif total_units >= 5000:
        max_tokens = 7500
    settings = {
        "temperature": 0.25,
        "topP": 0.85,
        "maxOutputTokens": max_tokens,
    }
    if "2.5" in model:
        settings["thinkingConfig"] = {"thinkingBudget": 0}
    elif "gemini-3" in model or "3." in model:
        settings["thinkingConfig"] = {"thinkingLevel": "minimal"}
    return settings


def build_direct_vietnamese_summary_prompt(source: str, rewritten: str, config: dict, strict_retry: bool = False) -> str:
    source_language = "tự nhận diện" if config.get("source_language") == "auto" else config.get("source_language", "tự nhận diện")
    target_language = config.get("target_language", "tự nhận diện")
    source_for_prompt = compact_text_for_summary(source)
    rewritten_for_prompt = compact_text_for_summary(rewritten)
    source_units = voice_unit_count(source, "" if config.get("source_language") == "auto" else config.get("source_language", ""))
    rewritten_units = voice_unit_count(rewritten, config.get("target_language", ""))
    strict_block = ""
    if strict_retry:
        strict_block = """
LẦN THỬ LẠI BẮT BUỘC:
- Kết quả trước đó còn ký tự hoặc câu tiếng Nhật/Hàn/Trung/Anh.
- Lần này phải chuyển toàn bộ sang Tiếng Việt có dấu.
- Tên riêng viết bằng chữ Nhật/Hàn/Trung phải chuyển sang Latin/Việt hóa, không giữ nguyên ký tự gốc.
"""
    return f"""Bạn là biên tập viên Việt Nam chuyên đọc kịch bản đa ngôn ngữ và tạo bản tóm tắt kiểm tra cho người làm video.

Mục tiêu: tạo TÓM TẮT TIẾNG VIỆT CÓ DẤU trực tiếp từ kịch bản gốc và bản AI, không cần dịch nguyên văn toàn bộ kịch bản.

Luật bắt buộc:
- Chỉ trả về Tiếng Việt có dấu. Không để sót câu/ký tự tiếng Nhật, Hàn, Trung, Anh hoặc ngôn ngữ nguồn.
- Không dịch nguyên văn toàn bộ. Chỉ tóm tắt chi tiết, đúng trình tự, đủ các mốc quan trọng để người dùng kiểm tra nhanh.
- Giữ đúng logic, nhân vật, quan hệ, mâu thuẫn, twist, cao trào, kết và bài học.
- Nếu tên riêng ở nguồn là chữ Nhật/Hàn/Trung, hãy chuyển sang dạng Latin/Việt hóa dễ đọc.
- Không thêm markdown ngoài 3 marker bắt buộc bên dưới.
- Phải dùng đúng 3 marker này, không đổi chữ:
{DIRECT_SUMMARY_SOURCE_MARKER}
{DIRECT_SUMMARY_REWRITTEN_MARKER}
{DIRECT_SUMMARY_COMPARISON_MARKER}
{strict_block}

Thông tin nhanh:
- Ngôn ngữ nguồn: {source_language}
- Ngôn ngữ bản AI: {target_language}
- Độ dài nguồn ước tính local: {format_int_vn(source_units)}
- Độ dài bản AI ước tính local: {format_int_vn(rewritten_units)}

Đầu ra bắt buộc:
{DIRECT_SUMMARY_SOURCE_MARKER}
# Tóm tắt kịch bản gốc
## Thông số nhanh
- Ghi ngắn độ dài/voice ước tính bằng tiếng Việt.
## Tóm tắt chi tiết
- 12-30 gạch đầu dòng theo trình tự diễn biến. Kịch bản càng dài thì càng nhiều dòng.
## Nhân vật và xung đột
- Ghi các nhân vật chính, quan hệ, mâu thuẫn, bí mật/reveal.
## Kết và bài học
- Ghi kết thúc và thông điệp chính.

{DIRECT_SUMMARY_REWRITTEN_MARKER}
# Tóm tắt kịch bản AI đã viết lại
## Thông số nhanh
- Ghi ngắn độ dài/voice ước tính bằng tiếng Việt.
## Tóm tắt chi tiết
- 12-30 gạch đầu dòng theo trình tự diễn biến.
## Nhân vật và xung đột
- Ghi các nhân vật chính, quan hệ, mâu thuẫn, bí mật/reveal.
## Kết và bài học
- Ghi kết thúc và thông điệp chính.

{DIRECT_SUMMARY_COMPARISON_MARKER}
# So sánh trực quan
## Giống nhau
- Chủ đề/cảm xúc/nhân vật/logic còn giống.
## Khác nhau
- Hook, bối cảnh, diễn biến, cao trào, kết, CTA đã khác thế nào.
## Bản AI đã nâng cấp gì
- Liệt kê điểm mạnh mới.
## Bản AI còn thiếu gì
- Liệt kê điểm cần sửa.
## Gợi ý nâng cấp tiếp
- 5-8 gợi ý cụ thể để bản AI hay hơn, dễ giữ người xem hơn.

## Kịch bản gốc
```text
{source_for_prompt}
```

## Kịch bản AI đã viết lại
```text
{rewritten_for_prompt}
```"""


def split_direct_vietnamese_summary(output: str) -> tuple[str, str, str]:
    text = (output or "").strip()
    if not text:
        return "", "", ""

    def extract_between(start_marker: str, end_marker: str | None) -> str:
        start = text.find(start_marker)
        if start < 0:
            return ""
        start += len(start_marker)
        end = text.find(end_marker, start) if end_marker else -1
        if end < 0:
            end = len(text)
        return text[start:end].strip()

    source = extract_between(DIRECT_SUMMARY_SOURCE_MARKER, DIRECT_SUMMARY_REWRITTEN_MARKER)
    rewritten = extract_between(DIRECT_SUMMARY_REWRITTEN_MARKER, DIRECT_SUMMARY_COMPARISON_MARKER)
    comparison = extract_between(DIRECT_SUMMARY_COMPARISON_MARKER, None)
    if source and rewritten and comparison:
        return source, rewritten, comparison

    # Fallback for models that remove markers but keep headings.
    heading_pattern = re.compile(r"(?=^#\s*(?:Tóm tắt kịch bản gốc|Tóm tắt kịch bản AI|So sánh trực quan))", re.I | re.M)
    parts = [part.strip() for part in heading_pattern.split(text) if part.strip()]
    if len(parts) >= 3:
        return parts[0], parts[1], "\n\n".join(parts[2:])
    return "", "", text


def direct_vietnamese_summary_valid(output: str) -> bool:
    source, rewritten, comparison = split_direct_vietnamese_summary(output)
    if not source or not rewritten or not comparison:
        return False
    if len(normalize_words(source)) < 60 or len(normalize_words(rewritten)) < 60 or len(normalize_words(comparison)) < 40:
        return False
    return not language_mismatch_warning(output, DEFAULT_REVIEW_LANGUAGE)


TITLE_LOWER_WORDS = {
    "và",
    "của",
    "cho",
    "trong",
    "khi",
    "với",
    "từ",
    "đến",
    "một",
    "những",
    "cả",
    "đã",
}


def smart_vietnamese_title_case(text: str) -> str:
    words = re.split(r"(\s+)", (text or "").strip())
    result: list[str] = []
    visible_index = 0
    for part in words:
        if not part or part.isspace():
            result.append(part)
            continue
        lowered = part.lower()
        if visible_index > 0 and lowered in TITLE_LOWER_WORDS:
            result.append(lowered)
        else:
            result.append(lowered[:1].upper() + lowered[1:])
        visible_index += 1
    return "".join(result).strip()


def clean_youtube_title(title: str, max_chars: int = YOUTUBE_TITLE_MAX_CHARS) -> str:
    cleaned = re.sub(r"^[#\-\d\.\)\s]+", "", (title or "").strip())
    cleaned = cleaned.strip("`\"'“”‘’「」『』[]() ")
    cleaned = re.sub(r"\s+", " ", cleaned)
    cleaned = re.sub(r"\s+([,.;:!?])", r"\1", cleaned)
    cleaned = cleaned.rstrip(" -–—.,;:")
    if len(cleaned) <= max_chars:
        return cleaned
    cut = cleaned[:max_chars].rstrip()
    for sep in (" | ", " - ", ": ", ", ", " "):
        pos = cut.rfind(sep)
        if pos >= 45:
            cut = cut[:pos].rstrip()
            break
    return cut.rstrip(" -–—.,;:")


def detect_title_language_from_text(text: str) -> str:
    sample = text or ""
    if re.search(r"[\u3040-\u30ff]", sample):
        return "Tiếng Nhật"
    if re.search(r"[\uac00-\ud7af]", sample):
        return "Tiếng Hàn"
    if re.search(r"[\u4e00-\u9fff]", sample):
        return "Tiếng Trung"
    lowered = sample.lower()
    if re.search(r"\b(der|die|das|und|nicht|ein|eine|ich|sie|er)\b", lowered):
        return "Tiếng Đức"
    if re.search(r"\b(le|la|les|des|une|avec|pour|dans|elle|mais)\b", lowered):
        return "Tiếng Pháp"
    if re.search(r"[àáạảãâầấậẩẫăằắặẳẵèéẹẻẽêềếệểễìíịỉĩòóọỏõôồốộổỗơờớợởỡùúụủũưừứựửữỳýỵỷỹđ]", lowered):
        return "Tiếng Việt"
    return "Tiếng Anh - Mỹ"


def title_language_from_config(config: dict | None, script: str = "", source: str = "") -> str:
    config = config or {}
    source_language = (config.get("source_language") or "").strip()
    if source_language and source_language.lower() != "auto":
        return source_language
    return detect_title_language_from_text(source or script)


def title_language_is_vietnamese(language: str) -> bool:
    return "việt" in (language or "").lower()


def text_matches_title_language(text: str, language: str) -> bool:
    sample = text or ""
    lowered_language = (language or "").lower()
    if "nhật" in lowered_language:
        return bool(re.search(r"[\u3040-\u30ff]", sample))
    if "hàn" in lowered_language:
        return bool(re.search(r"[\uac00-\ud7af]", sample))
    if "trung" in lowered_language:
        return bool(re.search(r"[\u4e00-\u9fff]", sample))
    if "việt" in lowered_language:
        return bool(re.search(r"[àáạảãâầấậẩẫăằắặẳẵèéẹẻẽêềếệểễìíịỉĩòóọỏõôồốộổỗơờớợởỡùúụủũưừứựửữỳýỵỷỹđ]", sample.lower()))
    if "đức" in lowered_language:
        return bool(re.search(r"\b(der|die|das|und|nicht|ein|eine|ich|sie|er)\b", sample.lower()))
    if "pháp" in lowered_language:
        return bool(re.search(r"\b(le|la|les|des|une|avec|pour|dans|elle|mais)\b", sample.lower()))
    return bool(re.search(r"[A-Za-z]", sample))


def source_language_title_candidates(script: str, source: str = "", language: str = "", max_items: int = 8) -> list[str]:
    script_text = script.strip()
    source_text = source.strip()
    if language and text_matches_title_language(script_text, language):
        text = script_text
    elif language and text_matches_title_language(source_text, language):
        text = source_text
    else:
        text = source_text or script_text
    if not text:
        return []
    chunks = re.split(r"[\r\n。！？!?]+", text)
    candidates: list[str] = []
    seen = set()
    for chunk in chunks:
        candidate = re.sub(r"\s+", " ", chunk).strip(" \t-–—,，。.!?！？:：;；「」『』\"'")
        if len(candidate) < 8:
            continue
        candidate = clean_youtube_title(candidate)
        if not candidate:
            continue
        key = normalized_surface(candidate)
        if key in seen:
            continue
        candidates.append(candidate)
        seen.add(key)
        if len(candidates) >= max_items:
            break
    return candidates


def title_score(title: str) -> int:
    text = (title or "").strip()
    lower = text.lower()
    score = 0
    length = len(text)
    if 45 <= length <= 88:
        score += 20
    elif length <= YOUTUBE_TITLE_MAX_CHARS:
        score += 10
    else:
        score -= 50
    for word in ["bí mật", "sự thật", "cuối cùng", "không ngờ", "cả gia đình", "ân hận", "im lặng", "thức tỉnh"]:
        if word in lower:
            score += 8
    if re.search(r"mẹ|cha|bố|bà|ông|con|vợ|chồng|gia đình", lower):
        score += 10
    if re.search(r"di chúc|lá thư|cuộc gọi|tài sản|bệnh án|tấm ảnh|chiếc hộp|sổ tiết kiệm", lower):
        score += 8
    if any(mark in text for mark in ["!!!", "???"]):
        score -= 10
    return score


def youtube_title_candidates(script: str, source: str = "", config: dict | None = None) -> list[str]:
    title_language = title_language_from_config(config, script, source)
    if not title_language_is_vietnamese(title_language):
        candidates = source_language_title_candidates(script, source, title_language)
        if candidates:
            return candidates
    combined = f"{script}\n\n{source}".lower()
    candidates: list[str] = []

    if re.search(r"di chúc|tài sản|thừa kế|gia sản|sổ tiết kiệm", combined):
        candidates.extend(
            [
                "Tờ Di Chúc Bị Giấu Kín Và Sự Thật Khiến Cả Gia Đình Im Lặng",
                "Ngày Mở Tờ Di Chúc, Những Người Con Mới Hiểu Mẹ Đã Chịu Đựng Gì",
            ]
        )
    if re.search(r"lá thư|bức thư|thư cuối|phong thư", combined):
        candidates.extend(
            [
                "Lá Thư Cuối Cùng Đã Thay Đổi Cả Một Gia Đình",
                "Một Lá Thư Cũ Và Bí Mật Khiến Những Người Con Ân Hận",
            ]
        )
    if re.search(r"cuộc gọi|điện thoại|tin nhắn", combined):
        candidates.extend(
            [
                "Cuộc Gọi Cuối Cùng Khiến Cả Nhà Không Còn Kịp Nói Lời Xin Lỗi",
                "Một Cuộc Gọi Muộn Và Sự Thật Làm Cả Gia Đình Thức Tỉnh",
            ]
        )
    if re.search(r"mẹ|người mẹ|má|mama|母|엄마", combined):
        candidates.extend(
            [
                "Người Mẹ Im Lặng Suốt Nhiều Năm Và Bí Mật Khiến Các Con Ân Hận",
                "Đến Khi Mẹ Rời Đi, Các Con Mới Hiểu Sự Hy Sinh Thầm Lặng",
            ]
        )
    if re.search(r"bà|ông|tuổi già|viện dưỡng|cô đơn|67 tuổi|70 tuổi|老人|할머니", combined):
        candidates.extend(
            [
                "Bà Cụ Bị Lãng Quên Và Sự Thật Khiến Cả Gia Đình Cúi Đầu",
                "Tuổi Già Cô Đơn Và Món Quà Cuối Cùng Làm Con Cháu Thức Tỉnh",
            ]
        )
    if re.search(r"vợ|chồng|hôn nhân|ly hôn|con dâu|mẹ chồng", combined):
        candidates.extend(
            [
                "Ngày Người Vợ Im Lặng Rời Đi, Người Chồng Mới Hiểu Điều Đã Mất",
                "Sau Nhiều Năm Chịu Đựng, Nàng Dâu Khiến Cả Nhà Phải Nhìn Lại",
            ]
        )
    if re.search(r"oan|hiểu lầm|bị đuổi|bị bỏ rơi|phản bội", combined):
        candidates.extend(
            [
                "Người Bị Cả Nhà Hiểu Lầm Và Sự Thật Cuối Cùng Được Sáng Tỏ",
                "Bị Bỏ Rơi Trong Im Lặng, Người Ấy Đã Chọn Cách Khiến Cả Nhà Ân Hận",
            ]
        )

    keywords = [word for word in top_keywords(script or source, 8) if len(word) >= 3]
    keyword = smart_vietnamese_title_case(keywords[0]) if keywords else "Một Bí Mật Gia Đình"
    candidates.extend(
        [
            f"{keyword} Và Bí Mật Khiến Cả Gia Đình Không Thể Quên",
            "Một Bí Mật Được Giấu Kín Và Cái Kết Khiến Ai Cũng Lặng Người",
            "Câu Chuyện Gia Đình Khiến Người Xem 40+ Phải Nghĩ Lại",
        ]
    )

    cleaned: list[str] = []
    seen = set()
    for title in candidates:
        title = clean_youtube_title(smart_vietnamese_title_case(title))
        key = normalized_surface(title)
        if title and key not in seen and len(title) <= YOUTUBE_TITLE_MAX_CHARS:
            cleaned.append(title)
            seen.add(key)
    return sorted(cleaned, key=title_score, reverse=True)


def best_youtube_story_title(script: str, source: str = "", config: dict | None = None) -> str:
    candidates = youtube_title_candidates(script, source, config)
    if not candidates:
        return "Câu Chuyện Khiến Cả Gia Đình Phải Nhìn Lại"
    return clean_youtube_title(candidates[0])


def youtube_title_generation_settings(config: dict) -> dict:
    model = (config.get("gemini_model") or "").lower()
    settings = {
        "temperature": 0.75,
        "topP": 0.9,
        "maxOutputTokens": 1200,
    }
    if "2.5" in model:
        settings["thinkingConfig"] = {"thinkingBudget": 0}
    elif "gemini-3" in model or "3." in model:
        settings["thinkingConfig"] = {"thinkingLevel": "minimal"}
    return settings


def build_youtube_title_prompt(script: str, source: str, config: dict) -> str:
    script_short = compact_text_for_summary(script, max_chars=36000)
    source_short = compact_text_for_summary(source, max_chars=18000) if source else ""
    title_language = title_language_from_config(config, script, source)
    local_candidates = youtube_title_candidates(script, source, config)[:8]
    local_block = "\n".join(f"- {item}" for item in local_candidates) or "- Chưa có"
    audience = config.get("audience", "")
    niche = config.get("niche", "")
    tone = config.get("tone", "")
    return f"""Bạn là chuyên gia đặt tiêu đề YouTube cho video kể chuyện.

Nhiệm vụ: đọc kịch bản AI đã viết lại, chọn 1 tiêu đề YouTube hấp dẫn nhất và tạo thêm các phương án dự phòng.

Luật bắt buộc:
- Chỉ trả về title bằng {title_language}, cùng ngôn ngữ nguồn/kịch bản gốc. Không tự dịch title sang tiếng Việt nếu nguồn không phải tiếng Việt.
- Mỗi tiêu đề phải dưới {YOUTUBE_TITLE_MAX_CHARS} ký tự.
- Title phải chuẩn YouTube: rõ nhân vật/tình huống chính, có lực tò mò/cao trào/cảm xúc, khiến người xem muốn bấm xem.
- Không lấy nguyên câu mở đầu một cách máy móc nếu câu đó chưa đủ hấp dẫn; hãy viết lại thành title tự nhiên, sắc hơn.
- Phù hợp nội dung thật của câu chuyện, không giật tít sai, không bịa nhân vật/sự kiện không có.
- Ưu tiên người xem 40+: cảm xúc, gia đình, bí mật, nhân quả, sự thật, day dứt, bài học.
- Không dùng emoji, hashtag, dấu ngoặc kép, chữ in hoa toàn bộ.
- Không thêm giải thích dài.

Định dạng bắt buộc:
BEST: <tiêu đề hay nhất dưới {YOUTUBE_TITLE_MAX_CHARS} ký tự>
OPTIONS:
1. <tiêu đề>
2. <tiêu đề>
3. <tiêu đề>
4. <tiêu đề>
5. <tiêu đề>
6. <tiêu đề>
7. <tiêu đề>
8. <tiêu đề>

Thông tin kênh:
- Người xem: {audience}
- Niche: {niche}
- Tone: {tone}

Gợi ý local để tham khảo, có thể chọn hoặc viết hay hơn:
{local_block}

## Kịch bản AI đã viết lại
```text
{script_short}
```

## Kịch bản gốc tham khảo
```text
{source_short}
```"""


def parse_youtube_title_output(output: str) -> tuple[str, list[str]]:
    text = (output or "").strip()
    best = ""
    options: list[str] = []
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("```"):
            continue
        if re.match(r"^best\s*[:：-]", line, re.I):
            candidate = re.sub(r"^best\s*[:：-]\s*", "", line, flags=re.I)
            best = clean_youtube_title(candidate)
            continue
        if re.match(r"^options\s*[:：-]?$", line, re.I):
            continue
        candidate = re.sub(r"^\s*(?:[-*•]|\d+[\.\)]|[A-Ha-h][\.\)])\s*", "", line)
        candidate = re.sub(r"^(?:title|tiêu đề)\s*\d*\s*[:：-]\s*", "", candidate, flags=re.I)
        candidate = clean_youtube_title(candidate)
        if candidate and len(candidate) <= YOUTUBE_TITLE_MAX_CHARS:
            options.append(candidate)

    if best and len(best) <= YOUTUBE_TITLE_MAX_CHARS:
        options.insert(0, best)
    cleaned: list[str] = []
    seen = set()
    for title in options:
        key = normalized_surface(title)
        if key and key not in seen:
            cleaned.append(title)
            seen.add(key)
    if not best and cleaned:
        best = sorted(cleaned, key=title_score, reverse=True)[0]
    return best, cleaned[:10]


def title_options_markdown(best: str, options: list[str], source: str = "Gemini") -> str:
    lines = [
        "# Title YouTube",
        "",
        f"- Nguồn tạo: {source}",
        f"- Title chọn: {best or 'N/A'}",
        f"- Độ dài: {len(best) if best else 0}/{YOUTUBE_TITLE_MAX_CHARS} ký tự",
        "",
        "## Phương án",
    ]
    if not options and best:
        options = [best]
    lines.extend(f"{index}. {title} ({len(title)} ký tự)" for index, title in enumerate(options, 1))
    return "\n".join(lines)


def mock_gemini_output(mode: str, source: str, draft: str, config: dict) -> str:
    analysis = analyze_script(source)
    target_language = config.get("target_language", "Tiếng Việt")
    duration = config.get("duration_goal") or config.get("duration") or "tự chọn"
    keywords = ", ".join(analysis.top_keywords[:8]) or "chưa có keyword rõ"
    opening_hint = analysis.opening[0] if analysis.opening else "Nguồn chưa có mở đầu đủ rõ."
    mode_label = {
        "audit": "phân tích",
        "improve": "nâng cấp draft",
        "variants": "tạo phiên bản",
        "script_rewrite": "viết lại kịch bản",
        "generate": "tạo kịch bản",
    }.get(mode, mode)
    if mode == "audit":
        return f"""[CHẾ ĐỘ TEST KHÔNG GỌI API]

# Báo cáo giả lập local
- Tác vụ: {mode_label}
- Ngôn ngữ đầu ra: {target_language}
- Mục tiêu thời lượng: {duration}
- Độ dài nguồn local: {format_int_vn(voice_unit_count(source, config.get("source_language", "")))} đơn vị đọc voice
- Keyword nổi bật: {keywords}

## Gợi ý test
- Tắt `Test không gọi API` để Gemini phân tích thật.
- Khi test liên tục, bật `Chỉ dùng cache, không gọi API mới` để tránh quota.
- Bật cache để các request giống nhau dùng lại kết quả."""

    return f"""[CHẾ ĐỘ TEST KHÔNG GỌI API]

Đây là bản giả lập local để kiểm tra giao diện và luồng xử lý mà không tốn quota Gemini.
Khi tắt chế độ này, Gemini sẽ viết bản thật theo cấu hình hiện tại.

Một buổi chiều yên ắng, nhân vật chính đứng trước một lựa chọn tưởng như rất nhỏ, nhưng lại làm thay đổi toàn bộ cách họ nhìn về gia đình, lòng tự trọng và những điều đã bỏ lỡ. Câu chuyện mở ra bằng một chi tiết đời thường: {trim_sentence(opening_hint, 32)}

Từ đó, mâu thuẫn dần được đẩy lên. Những điều từng bị xem là hiển nhiên bắt đầu lộ ra vết nứt. Người xem được dẫn qua các lớp cảm xúc: sự im lặng, nỗi ân hận, một bí mật chưa từng nói, rồi khoảnh khắc nhân vật buộc phải đối diện với sự thật.

Ở phần giữa, câu chuyện có thể mở rộng bằng đối thoại, hồi tưởng và những cảnh rất đời: một bữa cơm nguội, một cuộc gọi bị bỏ lỡ, một lá thư cũ, hoặc một vật chứng nhỏ khiến tất cả thay đổi. Các keyword local đang nổi bật trong nguồn là: {keywords}.

Đến cao trào, nhân vật nhận ra điều quan trọng không nằm ở việc ai thắng ai thua, mà ở việc còn kịp giữ lại điều gì trước khi quá muộn. Bản test này chưa phải output thật của Gemini, nhưng đủ để kiểm tra tab tóm tắt, độ giống, xuất file, lưu dự án và các nút xử lý.

Nếu dùng để đăng video, hãy tắt `Test không gọi API` và chạy Gemini thật."""


def mock_direct_summary_output(source: str, rewritten: str, config: dict) -> str:
    source_units = voice_unit_count(source, "" if config.get("source_language") == "auto" else config.get("source_language", ""))
    rewritten_units = voice_unit_count(rewritten, config.get("target_language", ""))
    source_voice = estimated_voice_range_text(source_units, config.get("source_language", ""), source)
    rewritten_voice = estimated_voice_range_text(rewritten_units, config.get("target_language", ""), rewritten)
    return f"""{DIRECT_SUMMARY_SOURCE_MARKER}
# Tóm tắt kịch bản gốc
## Thông số nhanh
- Chế độ test không gọi API đang bật, nên app không dịch/tóm tắt thật bằng Gemini.
- Độ dài local: {format_int_vn(source_units)} đơn vị đọc voice | voice khoảng {source_voice}

## Tóm tắt chi tiết
- Đây là bản tóm tắt giả lập để kiểm tra giao diện, không dùng quota.
- App đã nhận được kịch bản gốc và có thể đo độ dài, số câu, keyword local.
- Với nguồn Nhật/Hàn/Trung/Anh/Đức/Pháp, cần tắt chế độ test để Gemini tạo tóm tắt tiếng Việt thật.
- Nếu đang test nhiều lần, hãy bật cache rồi chạy thật một lần; các lần sau dùng cache.

## Nhân vật và xung đột
- Chưa phân tích thật bằng Gemini trong chế độ test.

## Kết và bài học
- Tắt `Test không gọi API` để lấy bản tóm tắt tiếng Việt chuẩn.

{DIRECT_SUMMARY_REWRITTEN_MARKER}
# Tóm tắt kịch bản AI đã viết lại
## Thông số nhanh
- Độ dài local: {format_int_vn(rewritten_units)} đơn vị đọc voice | voice khoảng {rewritten_voice}

## Tóm tắt chi tiết
- App đã nhận được bản AI/draft và có thể chạy tiếp các bước kiểm tra giao diện.
- Bản này dùng để test tab tóm tắt, copy, lưu dự án, xuất Markdown và so sánh local.
- Khi cần kiểm tra nội dung thật, hãy tắt chế độ test và gọi Gemini một lần.

## Nhân vật và xung đột
- Chưa phân tích thật bằng Gemini trong chế độ test.

## Kết và bài học
- Chế độ test giúp tránh lỗi quota khi thao tác liên tục.

{DIRECT_SUMMARY_COMPARISON_MARKER}
# So sánh trực quan
## Giống nhau
- Chế độ test chỉ đo local, chưa đọc hiểu nội dung thật.

## Khác nhau
- Bản AI hiện có {format_int_vn(rewritten_units)} đơn vị đọc voice, bản gốc có {format_int_vn(source_units)}.

## Bản AI đã nâng cấp gì
- Cần tắt chế độ test để Gemini đánh giá nội dung thật.

## Bản AI còn thiếu gì
- Nếu cache chưa có, bật `Chỉ dùng cache` sẽ dừng sớm và không gọi API mới.

## Gợi ý nâng cấp tiếp
- Test giao diện bằng chế độ này.
- Khi đã ổn, tắt test mode và chạy một request thật.
- Giữ `Dùng cache` bật để các lần test sau không đốt quota.
- Tắt `Tự dịch kiểm tra sau khi viết` nếu đang test liên tục."""


def mock_review_translation_text(label: str, text: str, language: str = DEFAULT_REVIEW_LANGUAGE) -> str:
    units = voice_unit_count(text, language)
    voice = estimated_voice_range_text(units, language, text)
    return f"""[CHẾ ĐỘ TEST KHÔNG GỌI API]

Đây không phải bản dịch thật của {label}. App đang bật chế độ test để tránh tốn quota Gemini.

Thông tin local:
- Độ dài ước tính: {format_int_vn(units)} đơn vị đọc voice
- Voice khoảng: {voice}

Tắt `Test không gọi API` rồi bấm dịch lại để Gemini dịch đầy đủ sang tiếng Việt có dấu."""


def ngrams(words: list[str], n: int) -> set[tuple[str, ...]]:
    return {tuple(words[i : i + n]) for i in range(max(0, len(words) - n + 1))}


def jaccard(left: set, right: set) -> float:
    if not left and not right:
        return 0.0
    return len(left & right) / len(left | right)


def repeated_ngrams(original_words: list[str], draft_words: list[str], n: int, limit: int = 12) -> list[str]:
    draft_set = ngrams(draft_words, n)
    seen: set[tuple[str, ...]] = set()
    repeated: list[str] = []
    for index in range(max(0, len(original_words) - n + 1)):
        item = tuple(original_words[index : index + n])
        if item in draft_set and item not in seen:
            seen.add(item)
            repeated.append(" ".join(item))
        if len(repeated) >= limit:
            break
    return repeated


def normalized_surface(text: str) -> str:
    text = text.lower()
    text = re.sub(r"```.*?```", " ", text, flags=re.S)
    text = re.sub(r"#+\s*", " ", text)
    return "".join(WORD_RE.findall(text))


def char_ngrams(text: str, n: int) -> set[str]:
    surface = normalized_surface(text)
    if len(surface) < n:
        return {surface} if surface else set()
    return {surface[index : index + n] for index in range(len(surface) - n + 1)}


def sentence_signature(sentence: str) -> set[str]:
    words = normalize_words(sentence)
    if len(words) >= 5:
        return {" ".join(item) for item in ngrams(words, 3)}
    return char_ngrams(sentence, 5)


def near_sentence_matches(original: str, draft: str, limit: int = 8) -> list[dict]:
    original_sentences = [item for item in split_sentences(original) if len(normalize_words(item)) >= 8 or len(normalized_surface(item)) >= 28]
    draft_sentences = [item for item in split_sentences(draft) if len(normalize_words(item)) >= 8 or len(normalized_surface(item)) >= 28]
    if not original_sentences or not draft_sentences:
        return []
    draft_signatures = [(sentence, sentence_signature(sentence), normalized_surface(sentence)) for sentence in draft_sentences[:260]]
    matches: list[dict] = []
    for source_sentence in original_sentences[:260]:
        source_sig = sentence_signature(source_sentence)
        source_surface = normalized_surface(source_sentence)
        best_score = 0.0
        best_sentence = ""
        for draft_sentence, draft_sig, draft_surface in draft_signatures:
            sig_score = jaccard(source_sig, draft_sig)
            if sig_score < 0.18:
                continue
            ratio = difflib.SequenceMatcher(None, source_surface[:360], draft_surface[:360]).ratio()
            score = max(sig_score, ratio)
            if score > best_score:
                best_score = score
                best_sentence = draft_sentence
        if best_score >= 0.62:
            matches.append(
                {
                    "score": round(best_score, 3),
                    "source": trim_sentence(source_sentence, 30),
                    "draft": trim_sentence(best_sentence, 30),
                }
            )
        if len(matches) >= limit:
            break
    return matches


def risk_recommendations(risk: str) -> list[str]:
    base = [
        "Đổi hook bằng tình huống, câu hỏi hoặc mâu thuẫn mới.",
        "Đảo thứ tự luận điểm để tránh đi theo nhịp gốc.",
        "Thêm ví dụ, mini-story, so sánh trước/sau hoặc checklist riêng.",
        "Viết lại CTA theo mục tiêu kênh và ngữ cảnh video.",
    ]
    if risk == "high":
        return [
            "Bản nháp còn quá gần nguồn. Hãy viết lại từ outline, không nhìn lại nguyên văn.",
            "Xóa hoặc viết lại mọi cụm 5-7 từ bị lặp.",
            "Đổi format thành problem -> stakes -> insight -> method -> payoff.",
            *base,
        ]
    if risk == "medium":
        return [
            "Cần thêm khác biệt ở ví dụ, chuyển cảnh và nhịp câu.",
            "Kiểm tra các cụm 5-7 từ bị lặp và thay bằng cách diễn đạt mới.",
            *base,
        ]
    return ["Mức trùng lặp thấp theo heuristic. Vẫn nên rà thủ công các câu đặc trưng.", *base]


def score_similarity(original: str, draft: str) -> dict:
    original_words = normalize_words(original)
    draft_words = normalize_words(draft)
    if not original_words or not draft_words:
        return {
            "risk": "unknown",
            "risk_score": 0,
            "similarity_percent": 0,
            "source_words": len(original_words),
            "draft_words": len(draft_words),
            "content_word_overlap": 0,
            "bigram_overlap": 0,
            "trigram_overlap": 0,
            "char5_overlap": 0,
            "char9_overlap": 0,
            "repeat5": [],
            "repeat7": [],
            "near_sentences": [],
            "recommendations": ["Cần có đủ kịch bản gốc và bản mới để chấm độ giống."],
        }
    content_overlap = jaccard(set(content_words(original)), set(content_words(draft)))
    bigram_overlap = jaccard(ngrams(original_words, 2), ngrams(draft_words, 2))
    trigram_overlap = jaccard(ngrams(original_words, 3), ngrams(draft_words, 3))
    char5_overlap = jaccard(char_ngrams(original, 5), char_ngrams(draft, 5))
    char9_overlap = jaccard(char_ngrams(original, 9), char_ngrams(draft, 9))
    repeat5 = repeated_ngrams(original_words, draft_words, 5)
    repeat7 = repeated_ngrams(original_words, draft_words, 7)
    near_sentences = near_sentence_matches(original, draft)
    weighted = (
        content_overlap * 18
        + bigram_overlap * 22
        + trigram_overlap * 24
        + char5_overlap * 16
        + char9_overlap * 20
    )
    penalty = min(18, len(repeat5) * 2 + len(repeat7) * 4 + len(near_sentences) * 3)
    similarity_percent = round(min(100, weighted + penalty))
    if similarity_percent >= 42 or repeat7 or len(near_sentences) >= 4:
        risk = "high"
    elif similarity_percent >= 24 or repeat5 or near_sentences:
        risk = "medium"
    else:
        risk = "low"
    return {
        "risk": risk,
        "risk_score": similarity_percent,
        "similarity_percent": similarity_percent,
        "source_words": len(original_words),
        "draft_words": len(draft_words),
        "content_word_overlap": round(content_overlap, 3),
        "bigram_overlap": round(bigram_overlap, 3),
        "trigram_overlap": round(trigram_overlap, 3),
        "char5_overlap": round(char5_overlap, 3),
        "char9_overlap": round(char9_overlap, 3),
        "repeat5": repeat5,
        "repeat7": repeat7,
        "near_sentences": near_sentences,
        "recommendations": risk_recommendations(risk),
    }


def analysis_brief(analysis: Analysis | None) -> str:
    if not analysis:
        return "Chưa có phân tích local."
    beat_lines = []
    for beat in analysis.beats:
        beat_lines.append(f"Beat {beat.index}: {', '.join(beat.keywords) or 'N/A'} | first: {beat.first_sentence}")
    return "\n".join(
        [
            f"Word count: {analysis.word_count}",
            f"Estimated minutes: {analysis.estimated_minutes}",
            f"Top keywords: {', '.join(analysis.top_keywords) or 'N/A'}",
            f"Opening: {' / '.join(analysis.opening) or 'N/A'}",
            f"Closing: {' / '.join(analysis.closing) or 'N/A'}",
            "Beats:",
            "\n".join(beat_lines) or "N/A",
        ]
    )


def build_rewrite_prompt(source: str, analysis: Analysis, config: dict) -> str:
    rewrite_mode = config.get("script_rewrite_mode", "Viết lại mạnh - đổi 70-80%")
    rewrite_guidance = rewrite_mode_guidance_text(rewrite_mode)
    rewrite_contract = rewrite_mode_contract(rewrite_mode)
    rewrite_dominance = rewrite_mode_dominance_rules(rewrite_mode, int(config.get("target_change", 78)))
    beat_lines = [
        f"- Beat {beat.index}: ý chính quanh {', '.join(beat.keywords) or 'chủ đề trong đoạn'}; "
        f'không sao chép câu "{beat.first_sentence}"'
        for beat in analysis.beats
    ]
    return f"""# PROMPT VIẾT LẠI KỊCH BẢN VIDEO

Bạn là biên tập viên kịch bản video chuyên về retention, storytelling và chuyển hóa.
Hãy tạo một kịch bản MỚI dựa trên chủ đề và ý tưởng cấp cao của kịch bản gốc, không paraphrase sát từng câu.

## Mục tiêu
- Nền tảng: {config["platform"]}
- Ngành/chủ đề: {config["niche"] or "tự suy ra từ kịch bản gốc"}
- Đối tượng xem: {config["audience"]}
- Thời lượng mục tiêu: {config["duration"]}
- Tone: {config["tone"]}
- CTA mong muốn: {config["cta"] or "đề xuất CTA phù hợp"}
- Mức độ biến đổi mong muốn: khoảng {config["target_change"]}% về hook, cấu trúc, ví dụ, nhịp câu và cách triển khai.
- Ngôn ngữ đầu ra: {config["target_language"]}
- Chế độ viết lại bắt buộc: {rewrite_mode}

## Luật riêng của chế độ đã chọn
{rewrite_guidance}

{rewrite_contract}

{rewrite_dominance}

## Luật bắt buộc
1. Chỉ giữ lại chủ đề, thông tin thật sự cần thiết và logic cấp cao.
2. Viết hook mới hoàn toàn trong 3-7 giây đầu.
3. Mỗi đoạn thân bài phải có ít nhất một nâng cấp: ví dụ mới, ẩn dụ mới, mini-story, counter-intuitive insight, so sánh trước/sau hoặc checklist hành động.
4. Thêm pattern interrupt mỗi 20-30 giây.
5. Nếu có cụm từ 7 từ liên tiếp giống nguồn, phải viết lại.
6. Nếu thông tin trong nguồn có vẻ là số liệu/sự kiện, đánh dấu [CẦN KIỂM CHỨNG].

## Outline cấp cao rút ra từ nguồn
{chr(10).join(beat_lines) if beat_lines else "- Không tách được beat; hãy tự tạo outline mới từ nguồn."}

## Kịch bản gốc chỉ để tham khảo ý tưởng
```text
{source}
```
"""


def is_story_40plus_config(config: dict) -> bool:
    joined = " ".join(
        [
            config.get("audience", ""),
            config.get("tone", ""),
            config.get("niche", ""),
            config.get("script_rewrite_mode", ""),
        ]
    ).lower()
    return any(marker in joined for marker in ["40", "trung niên", "gia đình", "nhân sinh", "đời sống", "kể chuyện"])


def story_40plus_guidance() -> str:
    return """## Công thức storytelling cho người xem 40+
- Mở bằng một tình huống đời thường nhưng có nút thắt: gia đình, hôn nhân, con cái, tuổi già, hàng xóm, tài sản, lòng hiếu thảo, một quyết định muộn màng.
- Nhịp kể chậm vừa, câu rõ, ít slang, ít meme, không dùng lối nói quá trẻ.
- Tạo đồng cảm trước khi tạo drama: cho người xem hiểu nỗi khổ, sĩ diện, sự im lặng, ký ức hoặc vết thương của nhân vật.
- Mỗi 45-60 giây cần có một câu kéo tiếp: "Nhưng điều bà không ngờ là...", "Đến ngày hôm đó...", "Chỉ một lá thư đã làm mọi thứ thay đổi..."
- Cao trào nên đến từ sự thật bị che giấu, một cuộc gọi, lá thư, di chúc, bệnh tật, sự trở về, lời xin lỗi hoặc lựa chọn cuối cùng.
- Kết nên có bài học rõ nhưng không giáo điều: tình thân, nhân quả, lòng biết ơn, tự trọng, tha thứ, sống tử tế.
- CTA mềm, hợp tuổi 40+: mời chia sẻ trải nghiệm, lời chúc, quan điểm sống; tránh ép follow quá mạnh."""


def rewrite_mode_guidance_text(mode: str) -> str:
    rules = REWRITE_MODE_GUIDANCE.get(mode) or REWRITE_MODE_GUIDANCE["Viết lại mạnh - đổi 70-80%"]
    return "\n".join(f"- {rule}" for rule in rules)


def rewrite_mode_contract(mode: str) -> str:
    return f"""## Hợp đồng bám chế độ
Chế độ người dùng đã chọn: "{mode}".
Đây là luật ưu tiên cao. Nếu preset, training profile hoặc thói quen viết chung xung đột với chế độ này, phải ưu tiên chế độ đã chọn.

Trước khi viết, tự kiểm tra ngầm 5 câu hỏi sau, nhưng không in câu trả lời:
1. Hook mở đầu đã đúng màu của chế độ "{mode}" chưa?
2. Nhân vật, bối cảnh, xung đột, reveal và kết có phục vụ chế độ này không?
3. Có đoạn nào đang kể chung chung, không thể hiện mode không? Nếu có, viết lại đoạn đó.
4. Nếu là mode 100%, bản mới đã đủ khác tuyến truyện, khác cảnh nhận diện và khác cách reveal chưa?
5. Nếu người dùng chỉ nhìn bản mới, họ có nhận ra rõ phong cách của mode đang chọn không?

Không được viết một bản trung tính rồi chỉ thêm vài chi tiết của mode. Toàn bộ kịch bản phải nghiêng rõ về chế độ đã chọn."""


def is_full_rewrite_mode(mode: str) -> bool:
    value = (mode or "").lower()
    return "100%" in value or "hoàn toàn" in value


def rewrite_mode_dominance_rules(mode: str, target_change: int) -> str:
    if is_full_rewrite_mode(mode):
        return f"""## Mức chi phối của chế độ viết lại
Chế độ đang chọn là "{mode}", nên toàn bộ bản mới phải thiên mạnh về chế độ này.
Mục tiêu biến đổi thực tế: 95-100%, cao hơn slider hiện tại ({target_change}%).

Luật 100% khác bản gốc:
- Chỉ giữ 1-3 yếu tố cấp cao: chủ đề, cảm xúc lõi, bài học hoặc lời hứa với người xem.
- Phải đổi nhân vật chính hoặc hoàn cảnh trung tâm nếu có thể.
- Phải đổi bối cảnh, chuỗi sự kiện, cách mở đầu, cách reveal, cao trào và kết.
- Không dùng lại cảnh nhận diện, lời thoại, vật chứng, thứ tự twist, ví dụ, CTA hoặc nhịp kể của bản gốc.
- Nếu bản gốc có lá thư/cuộc gọi/di chúc/bệnh án làm trục reveal, hãy thay bằng cơ chế reveal khác, trừ khi mode được chọn yêu cầu đúng chi tiết đó.
- Viết như một kịch bản mới được lấy cảm hứng từ insight nguồn, không như bản dịch/paraphrase.
- Không được bê lại cùng chuỗi sự kiện rồi chỉ đổi tên nhân vật hoặc đổi vài câu.
- Tự kiểm tra ngầm trước khi trả lời: nếu người xem nhận ra tuyến truyện cũ quá rõ, hãy đổi mạnh hơn."""
    return f"""## Mức chi phối của chế độ viết lại
Chế độ đang chọn là "{mode}", nên ưu tiên rõ ràng phong cách, xung đột, nhịp cảm xúc và cách reveal của chế độ này.
Mức biến đổi mục tiêu: khoảng {target_change}%.

Luật bám mode:
- Hook, nhân vật, bối cảnh, xung đột, reveal, cao trào, kết và CTA đều phải phục vụ chế độ đã chọn.
- Không viết chung chung. Nếu mode là drama gia đình thì tăng mâu thuẫn gia đình; nếu là tuổi già cô đơn thì tăng chi tiết cô đơn; nếu là plot twist thì cài manh mối và bẻ lái rõ.
- Ít nhất 70% cảnh/đoạn phải thể hiện rõ màu của mode đã chọn, không chỉ nhắc mode ở mở đầu/kết.
- Có thể giữ chủ đề/cảm xúc lõi của nguồn, nhưng phải đổi cách triển khai để bản mới có màu riêng của mode."""


def story_40plus_suggestions_text() -> str:
    return """# Gợi ý cấu hình kịch bản kể chuyện cho người xem 40+

## Người xem
- Nam nữ 40-65 tuổi, đã có nhiều trải nghiệm gia đình, hôn nhân, con cái, công việc và tuổi già.
- Thích câu chuyện có thật hoặc có cảm giác rất thật: hàng xóm, mẹ chồng nàng dâu, con cái vô tâm, người già cô đơn, di chúc, bệnh tật, ân nghĩa, báo hiếu.
- Cần cảm xúc rõ, bài học rõ, lời văn dễ hiểu, không quá nhanh, không quá nhiều tiếng lóng.

## Tone nên dùng
- Ấm áp, từng trải, chậm vừa, chân thật, có chiều sâu.
- Có cao trào nhưng không rẻ tiền; lấy nước mắt bằng tình huống và chi tiết đời thường, không bằng câu giật gân.
- Kể như một người từng chứng kiến câu chuyện, tôn trọng nhân vật và người xem.

## Niche phù hợp
- Kể chuyện đời sống, gia đình, hôn nhân, tuổi trung niên, tuổi già, lòng hiếu thảo, nhân quả, tình người.
- Các nhánh dễ kéo view: bí mật gia đình, lá thư cuối đời, đứa con xa nhà, người mẹ bị lãng quên, người chồng im lặng, hàng xóm tốt bụng, di sản và lòng tham.

## CTA hợp nhóm 40+
- "Nếu câu chuyện này làm bạn nhớ đến ai, hãy để lại một lời bình luận."
- "Bạn nghĩ nhân vật nên tha thứ hay rời đi? Hãy chia sẻ quan điểm của bạn."
- "Nếu bạn từng trải qua chuyện tương tự, tôi rất muốn đọc câu chuyện của bạn ở phần bình luận."
- "Hãy gửi câu chuyện này cho một người mà bạn nghĩ cần nghe nó hôm nay."

## Công thức nhanh
1. Hook đời thường có nút thắt.
2. Giới thiệu nhân vật bằng nỗi đau hoặc điều họ đang giấu.
3. Đẩy mâu thuẫn gia đình/xã hội lên từng nấc.
4. Reveal bằng lá thư, cuộc gọi, bệnh án, di chúc, sự trở về hoặc lời thú nhận.
5. Kết bằng bài học nhân sinh và CTA mềm."""


def trend_idea_seed_text(config: dict) -> str:
    audience = config.get("audience", "Người xem 40+")
    niche = config.get("niche", "kể chuyện đời sống / gia đình")
    return f"""# Ý tưởng riêng / trend seed để AI huấn luyện nâng cấp
Người xem chính: {audience}
Niche hiện tại: {niche}

## Trend pack ưu tiên
1. Long-form 40-60 phút: một bí mật gia đình chia thành 5 lớp reveal, mỗi 6-8 phút có twist.
2. Short drama 30-80 tập: mỗi tập 60-120 giây, kết bằng cliffhanger, có thân phận bí mật hoặc bằng chứng mới.
3. Confession/AITA: người kể xưng tôi, kể quyết định gây tranh cãi, cuối hỏi khán giả nên tha thứ hay rời đi.
4. Documentary hồ sơ: timeline, chứng cứ, camera, tin nhắn, nhân chứng, kết bằng bài học nhân văn.
5. Review storytelling: sản phẩm là vật chứng/giải pháp trong câu chuyện, không bán thẳng.
6. AI/tech moral story: AI, camera, deepfake hoặc lịch sử chat làm lộ bí mật, trọng tâm là đạo đức con người.
7. Healing Nhật/Hàn: quán ăn đêm, ga tàu, tiệm sách, căn hộ cũ, món đồ nhỏ, kết lặng nhưng thấm.
8. Workplace revenge: bị cướp công/bị đổ lỗi, bằng chứng xuất hiện ở cao trào.
9. Tài sản/di chúc: tiền chỉ là bề mặt, lòng người và lời hứa cũ mới là câu chuyện.
10. Food memory: món ăn kéo nhân vật về một lời hứa với cha/mẹ/người thân.

## Ý tưởng mẫu để AI phát triển
- Camera trong phòng khách chứng minh người bị nghi oan là người duy nhất bảo vệ gia đình.
- Hộp cơm gửi nhầm mỗi tuần dẫn nhân vật về ký ức của người mẹ đã mất.
- Di chúc bằng video buộc từng người con nghe một sự thật riêng.
- AI khôi phục nhật ký cũ của mẹ, nhưng bí mật trong đó làm cả nhà phải xin lỗi một người.
- Quán ăn đêm cuối phố giữ câu chuyện của những người từng được chủ quán cứu giúp.
- Mã QR trên mộ dẫn tới lời nhắn cuối cùng, người xem đầu tiên lại là kẻ từng phản bội.
- Phiên hòa giải tài sản trở thành nơi cả gia đình nghe một câu xin lỗi muộn.
- Người giúp việc bị đuổi khỏi biệt thự quay lại sau 15 năm với bằng chứng vụ cháy.

## Yêu cầu AI khi dùng ý tưởng này
- Không chép nguyên ý tưởng, hãy nâng cấp thành nhiều tuyến truyện mới.
- Với mỗi ý tưởng, tạo được: hook, nhân vật, nỗi đau, mâu thuẫn, vật chứng, mid twist, cao trào, kết, CTA.
- Ưu tiên biến mỗi ý tưởng thành 3 phiên bản: 40+ long-form, short drama nhiều tập, documentary/confession.
"""


def build_local_training_profile(samples: str, config: dict) -> str:
    analysis = analyze_script(samples)
    top_keywords = ", ".join(analysis.top_keywords[:18]) or "tự suy ra theo từng kịch bản"
    openings = " / ".join(analysis.opening[:3]) or "mở bằng biến cố đời thường có nút thắt"
    closings = " / ".join(analysis.closing[-3:]) or "kết bằng bài học và dư âm cảm xúc"
    custom_ideas = (config.get("custom_story_ideas") or "").strip()
    custom_ideas_section = (
        f"\n## Ý tưởng riêng / trend seed của người dùng\n{custom_ideas}\n"
        "\n## Cách dùng ý tưởng riêng\n"
        "- Khi viết hoặc tạo profile, xem ý tưởng riêng như kho nguyên liệu ưu tiên.\n"
        "- Không chép nguyên văn ý tưởng; phải nâng cấp thành hook, nhân vật, mâu thuẫn, reveal, cao trào, kết và CTA.\n"
        "- Nếu ý tưởng phù hợp, biến thành 3 hướng: long-form 40+, short drama nhiều tập, documentary/confession.\n"
        if custom_ideas
        else ""
    )
    return f"""# CHANNEL TRAINING PROFILE - KỊCH BẢN AI

## Ghi chú quan trọng
Đây là profile huấn luyện bằng prompt, không phải fine-tune model. Khi bật "Dùng profile khi viết", Gemini sẽ dùng profile này như luật phong cách của kênh.

## Định vị kênh
- Nền tảng: {config.get("platform", "YouTube")}
- Người xem chính: {config.get("audience", "Người xem 40+")}
- Niche: {config.get("niche", "Kể chuyện đời sống / gia đình / nhân sinh")}
- Tone mặc định: {config.get("tone", "Chân thật, cảm xúc, dễ hiểu")}
- CTA mặc định: {config.get("cta", "Bình luận trải nghiệm hoặc quan điểm cá nhân")}
{custom_ideas_section}

## Dấu hiệu rút ra từ mẫu
- Độ dài mẫu: {format_int_vn(analysis.word_count)} từ, ước tính {analysis.estimated_minutes} phút.
- Từ khóa/chủ đề lặp lại: {top_keywords}
- Kiểu mở đầu mẫu: {openings}
- Kiểu kết mẫu: {closings}

## Luật phong cách cần giữ
- Viết như một người kể chuyện từng trải, không dùng giọng quá trẻ, không dùng meme/slang khó hiểu.
- Ưu tiên chi tiết đời thường: bữa cơm, cuộc gọi, lá thư, bệnh viện, di chúc, hàng xóm, con cái, tuổi già, ký ức cũ.
- Xây đồng cảm trước khi đẩy drama. Nhân vật cần có nỗi đau, sự im lặng, lựa chọn khó hoặc điều bị hiểu lầm.
- Câu văn rõ, dễ nghe khi voice, nhịp chậm vừa, đoạn văn không quá dài.
- Mỗi 45-60 giây phải có một câu kéo tiếp để giữ chân người xem.
- Cao trào nên đến từ sự thật bị che giấu, lời thú nhận, lá thư, cuộc gọi, bệnh án, sự trở về hoặc hành động báo đáp.
- Kết phải có dư âm nhân sinh: tự trọng, lòng biết ơn, tha thứ, nhân quả, tình thân, sống tử tế.

## Luật khi viết lại
- Không sao chép câu chữ mẫu hoặc kịch bản gốc.
- Chỉ giữ cảm xúc lõi, mô hình câu chuyện, nhịp cảm xúc và bài học.
- Đổi hook, thứ tự reveal, ví dụ, câu thoại, chuyển cảnh và CTA để bản mới khác rõ rệt.
- Nếu nguồn quá ngắn so với thời lượng mục tiêu, mở rộng bằng nội tâm nhân vật, hồi tưởng, đối thoại, cảnh đời thường và đoạn chiêm nghiệm.
- Với nguồn nước ngoài, localize tự nhiên sang ngôn ngữ đầu ra, không dịch máy từng câu.

## Công thức kịch bản ưu tiên
1. Hook bằng một biến cố gần gũi nhưng có bí mật.
2. Giới thiệu nhân vật bằng nỗi đau hoặc điều họ đang chịu đựng.
3. Đẩy mâu thuẫn gia đình/xã hội/tài sản/tình cảm theo từng nấc.
4. Đặt một chi tiết nhỏ làm open loop.
5. Reveal sự thật ở giữa hoặc cuối phần hai.
6. Cao trào bằng lựa chọn khó hoặc lời nói muộn màng.
7. Kết bằng bài học mềm và CTA mời người xem chia sẻ."""


def build_training_profile_prompt(samples: str, config: dict) -> str:
    compact_samples = samples.strip()
    custom_ideas = (config.get("custom_story_ideas") or "").strip()
    if len(compact_samples) > 52000:
        compact_samples = "\n\n".join(
            [
                compact_samples[:18000].strip(),
                "[...đã rút gọn phần giữa để tạo profile nhanh hơn...]",
                compact_samples[len(compact_samples) // 2 - 8000 : len(compact_samples) // 2 + 8000].strip(),
                "[...phần cuối mẫu...]",
                compact_samples[-18000:].strip(),
            ]
        )
    return f"""Bạn là chuyên gia phân tích kênh kể chuyện video và tạo CHANNEL TRAINING PROFILE cho Gemini.

Mục tiêu: đọc các kịch bản mẫu bên dưới và rút ra một profile dùng lại để viết kịch bản mới cùng phong cách, nhưng KHÔNG sao chép câu chữ.

Thông tin dự án:
- Người xem mục tiêu: {config.get("audience", "")}
- Tone mong muốn: {config.get("tone", "")}
- Niche: {config.get("niche", "")}
- CTA mong muốn: {config.get("cta", "")}
- Ngôn ngữ đầu ra chính: {config.get("target_language", "Tiếng Việt")}
- Thời lượng thường dùng: {config.get("duration_goal", config.get("duration", ""))}
- Luật cấm hiện có: {config.get("training_negative_rules", "chưa có")}
- Luật bắt buộc hiện có: {config.get("training_locked_rules", "chưa có")}
- Ý tưởng riêng / trend seed người dùng nhập: {custom_ideas or "chưa có"}

Yêu cầu đầu ra:
1. Viết bằng Tiếng Việt có dấu.
2. Chỉ trả về profile huấn luyện, không giải thích ngoài lề.
3. Profile phải đủ cụ thể để dùng lại khi Gemini viết kịch bản.
4. Nêu rõ:
   - chân dung người xem;
   - chủ đề/niche kênh;
   - tone giọng;
   - nhịp câu, độ dài đoạn, cách chuyển cảnh;
   - cấu trúc mở đầu;
   - cách xây nhân vật;
   - cách đẩy mâu thuẫn;
   - công thức giữ chân 30s/60s/3 phút;
   - kiểu cao trào/reveal;
   - kiểu kết;
   - CTA;
   - các điều phải tránh;
   - dấu hiệu "đúng chất kênh";
   - checklist tự kiểm trước khi xuất;
   - công thức viết lại để khác bản gốc 70-80%;
   - Story Idea Engine: cách tự tạo ý tưởng kịch bản mới hằng ngày;
   - Market Trend Engine: cách chọn thị trường Nhật/Hàn/Mỹ/Trung/Việt, format, trope, bối cảnh và mật độ cliffhanger;
   - 10 mô-típ kịch bản nên ưu tiên;
   - 20 ý tưởng global đa chủ đề, không chỉ giới hạn ở kể chuyện 40+;
   - 10 kiểu nhân vật hợp người xem 40+;
   - 10 cơ chế reveal/twist;
   - 10 mẫu hook ngắn có thể tái dùng;
   - Series Engine: cách biến một ý tưởng thành nhiều tập.
   - Custom Idea Engine: cách nâng cấp ý tưởng riêng của người dùng thành nhiều tuyến kịch bản mạnh hơn.
5. Nhấn mạnh: đây là prompt-training/profile, không phải fine-tune thật.
6. Không trích nguyên văn dài từ mẫu.
7. Nếu kịch bản mẫu là tiếng Hàn/Nhật/Trung/Anh/Đức/Pháp, vẫn phân tích phong cách nhưng PROFILE phải viết bằng tiếng Việt có dấu.
8. Không trả profile bằng ngôn ngữ của mẫu.

Kịch bản mẫu để học phong cách:
```text
{compact_samples}
```"""


def build_training_profile_upgrade_prompt(profile: str, samples: str, config: dict, negative_rules: str, locked_rules: str) -> str:
    compact_samples = samples.strip()
    custom_ideas = (config.get("custom_story_ideas") or "").strip()
    if len(compact_samples) > 42000:
        compact_samples = "\n\n".join(
            [
                compact_samples[:14000].strip(),
                "[...đã rút gọn phần giữa để nâng cấp profile nhanh hơn...]",
                compact_samples[len(compact_samples) // 2 - 7000 : len(compact_samples) // 2 + 7000].strip(),
                "[...phần cuối mẫu...]",
                compact_samples[-14000:].strip(),
            ]
        )
    return f"""Bạn là chuyên gia tối ưu CHANNEL TRAINING PROFILE cho tool viết kịch bản bằng Gemini.

Hãy nâng cấp profile hiện có thành một profile mạnh hơn, rõ luật hơn, dễ dùng hơn khi viết kịch bản kể chuyện video.

Thông tin dự án:
- Người xem mục tiêu: {config.get("audience", "")}
- Tone mong muốn: {config.get("tone", "")}
- Niche: {config.get("niche", "")}
- CTA: {config.get("cta", "")}
- Ngôn ngữ đầu ra: {config.get("target_language", "Tiếng Việt")}
- Mức biến đổi: {config.get("target_change", 78)}%
- Luật cấm hiện có: {negative_rules or "chưa có"}
- Luật bắt buộc hiện có: {locked_rules or "chưa có"}
- Ý tưởng riêng / trend seed người dùng nhập: {custom_ideas or "chưa có"}

Yêu cầu đầu ra:
- Chỉ trả về PROFILE HOÀN CHỈNH đã nâng cấp, không giải thích ngoài lề.
- Viết tiếng Việt có dấu.
- Nếu mẫu hoặc profile cũ có tiếng Hàn/Nhật/Trung/Anh, phải chuyển luật phong cách về tiếng Việt có dấu.
- Không trả profile bằng tiếng Hàn/Nhật/Trung/Anh, trừ tên riêng hoặc ví dụ ngắn cần giữ nguyên.
- Không trích nguyên văn dài từ mẫu.
- Profile phải dùng được ngay trong prompt viết kịch bản.
- Bổ sung rõ các phần:
  1. Chân dung người xem và cảm xúc họ tìm kiếm.
  2. DNA nội dung/kênh: chủ đề, xung đột, nhân vật, giá trị lõi.
  3. Voice fingerprint: nhịp kể, độ dài câu, cách mở đoạn, cách chuyển cảnh.
  4. Retention engine: hook 5 giây, open loop 30-60 giây, mid twist, payoff cuối.
  5. Story framework cho người 40+.
  6. Luật localize nguồn nước ngoài.
  7. Luật chống giống bản gốc 70-80%.
  8. Negative style / điều cấm.
  9. Locked rules / điều bắt buộc.
  10. Checklist tự kiểm trước khi xuất bản.
  11. Story Idea Engine: cách tạo ý tưởng kịch bản mới.
  12. Market Trend Engine: Nhật/Hàn/Mỹ/Trung/Việt nên dùng format, trope, bối cảnh, nhịp cliffhanger nào.
  13. Ngân hàng mô-típ/nhân vật/bối cảnh/vật chứng reveal.
  14. Kho ý tưởng global đa chủ đề: storytelling, documentary, review, công sở, AI/tech, confession, healing, pháp lý, food/travel.
  15. Hook bank: 10 kiểu mở đầu dùng được cho kênh.
  16. Series engine: cách mở rộng một ý tưởng thành nhiều tập.
  17. Custom Idea Engine: lấy ý tưởng riêng của người dùng, nâng cấp thành nhiều hook, trope, bối cảnh, reveal và series.

## Profile hiện có
```text
{profile or "Chưa có profile hiện có."}
```

## Mẫu huấn luyện
```text
{compact_samples or "Chưa có mẫu, hãy nâng cấp dựa trên cấu hình dự án."}
```"""


def training_sample_blocks(samples: str) -> list[str]:
    samples = samples.strip()
    if not samples:
        return []
    parts = re.split(r"^===== MẪU:.*?=====\s*$", samples, flags=re.MULTILINE)
    blocks = [part.strip() for part in parts if part.strip()]
    return blocks or [samples]


def training_profile_quality(profile: str, samples: str = "", negative_rules: str = "", locked_rules: str = "") -> dict:
    profile = profile.strip()
    samples = samples.strip()
    blocks = training_sample_blocks(samples)
    sample_words = len(normalize_words(samples))
    score = 0
    checks: list[tuple[str, bool, int, str]] = [
        ("Có profile đủ dài", len(profile) >= 1200, 12, "Profile còn ngắn; nên có ít nhất 1.200 ký tự."),
        ("Có chân dung người xem", bool(re.search(r"người xem|audience|40|trung niên|tuổi", profile, re.I)), 10, "Thiếu chân dung người xem."),
        ("Có tone giọng", bool(re.search(r"tone|giọng|nhịp|cảm xúc|chân thật", profile, re.I)), 10, "Thiếu tone/nhịp giọng."),
        ("Có niche/chủ đề", bool(re.search(r"niche|chủ đề|gia đình|hôn nhân|đời sống|nhân sinh", profile, re.I)), 9, "Thiếu niche/chủ đề."),
        ("Có cấu trúc mở đầu", bool(re.search(r"mở đầu|hook|biến cố|nút thắt", profile, re.I)), 9, "Thiếu luật mở đầu/hook."),
        ("Có cách xây nhân vật", bool(re.search(r"nhân vật|nỗi đau|hiểu lầm|chịu đựng|lựa chọn", profile, re.I)), 9, "Thiếu luật xây nhân vật."),
        ("Có mâu thuẫn/cao trào", bool(re.search(r"mâu thuẫn|cao trào|reveal|sự thật|bước ngoặt", profile, re.I)), 10, "Thiếu luật đẩy mâu thuẫn/cao trào."),
        ("Có kiểu kết/CTA", bool(re.search(r"kết|CTA|bình luận|bài học|dư âm", profile, re.I)), 9, "Thiếu kiểu kết hoặc CTA."),
        ("Có luật tránh sao chép", bool(re.search(r"không sao chép|không paraphrase|tránh|7 từ|giống", profile, re.I)), 10, "Thiếu luật chống sao chép."),
        ("Có Story Idea Engine", bool(re.search(r"story idea|ý tưởng|mô-típ|motif", profile, re.I)), 3, "Thiếu Story Idea Engine để tạo ý tưởng mới hằng ngày."),
        ("Có Market Trend Engine", bool(re.search(r"thị trường|market|nhật|hàn|mỹ|trung|duanju|webtoon|AITA|micro", profile, re.I)), 3, "Thiếu Market Trend Engine cho Nhật/Hàn/Mỹ/Trung và format global."),
        ("Có mẫu huấn luyện", sample_words >= 800, 6, "Mẫu huấn luyện còn ít; nên có ít nhất 800 từ."),
        ("Có nhiều mẫu", len(blocks) >= 3, 3, "Nên có 3-10 mẫu tốt để profile ổn định hơn."),
        ("Có luật cấm", bool(negative_rules.strip()), 2, "Có thể thêm luật cấm/negative style."),
        ("Có luật bắt buộc", bool(locked_rules.strip()), 1, "Có thể thêm luật bắt buộc/locked rules."),
    ]
    missing: list[str] = []
    passed: list[str] = []
    for label, ok, points, hint in checks:
        if ok:
            score += points
            passed.append(label)
        else:
            missing.append(hint)
    score = min(100, score)
    if score >= 85:
        level = "MẠNH"
    elif score >= 65:
        level = "ỔN"
    elif score >= 45:
        level = "TRUNG BÌNH"
    else:
        level = "YẾU"
    return {
        "score": score,
        "level": level,
        "sample_count": len(blocks),
        "sample_words": sample_words,
        "passed": passed,
        "missing": missing,
    }


def training_quality_report(profile: str, samples: str = "", negative_rules: str = "", locked_rules: str = "") -> str:
    quality = training_profile_quality(profile, samples, negative_rules, locked_rules)
    return "\n".join(
        [
            "# Báo cáo chất lượng Training Profile",
            "",
            f"- Điểm: {quality['score']}/100",
            f"- Mức: {quality['level']}",
            f"- Số mẫu: {quality['sample_count']}",
            f"- Tổng số từ mẫu: {format_int_vn(quality['sample_words'])}",
            "",
            "## Đã đạt",
            "\n".join(f"- {item}" for item in quality["passed"]) or "- Chưa có mục nào rõ.",
            "",
            "## Nên bổ sung",
            "\n".join(f"- {item}" for item in quality["missing"]) or "- Profile đã đủ mạnh.",
        ]
    )


def training_upgrade_suggestions_text(profile: str, samples: str, negative_rules: str, locked_rules: str, config: dict) -> str:
    quality = training_profile_quality(profile, samples, negative_rules, locked_rules)
    sample_blocks = training_sample_blocks(samples)
    sample_words = quality.get("sample_words", 0)
    lines = [
        "# Gợi ý nâng cấp phần Huấn luyện",
        "",
        f"- Điểm profile hiện tại: {quality['score']}/100 - {quality['level']}",
        f"- Số mẫu đang có: {quality['sample_count']} mẫu | {format_int_vn(sample_words)} từ",
        "",
        "## Nên làm ngay",
    ]
    if sample_words < 2500:
        lines.append("- Nạp thêm 3-10 kịch bản thắng nhất của kênh. Mỗi mẫu nên đủ dài, không chỉ là một đoạn ngắn.")
    if len(sample_blocks) < 3:
        lines.append("- Tách mẫu rõ bằng nhiều file hoặc nhiều block, vì 1 mẫu dễ làm Gemini học lệch phong cách.")
    if not negative_rules.strip():
        lines.append("- Thêm Negative style: những kiểu viết tuyệt đối không dùng, ví dụ giật gân rẻ tiền, câu quá trẻ, dịch máy từng câu.")
    if not locked_rules.strip():
        lines.append("- Thêm Locked rules: hook trong 3-7 giây, câu dễ đọc voice, kết có bài học, không giữ cụm 7 từ liên tiếp từ nguồn.")
    if quality["missing"]:
        lines.extend(f"- {item}" for item in quality["missing"][:6])
    if len(lines) <= 9:
        lines.append("- Profile đã khá tốt. Bước tiếp theo là dùng Chat AI để hỏi Gemini kiểm tra profile trên một kịch bản thật.")
    lines.extend(
        [
            "",
            "## Công thức profile mạnh",
            "- 30% mô tả người xem và cảm xúc họ muốn nhận.",
            "- 25% voice fingerprint: nhịp câu, độ dài đoạn, cách chuyển cảnh, cách kể nội tâm.",
            "- 25% story engine: hook, open loop, mid twist, climax, payoff.",
            "- 10% luật chống giống bản gốc.",
            "- 10% checklist tự kiểm và điều cấm.",
            "",
            "## Gợi ý cho kênh hiện tại",
            f"- Người xem: {config.get('audience', '')}",
            f"- Tone: {config.get('tone', '')}",
            f"- Niche: {config.get('niche', '')}",
            "- Nên ưu tiên những chi tiết đời thường mà nhóm 40+ dễ đồng cảm: bữa cơm, con cái, nhà cũ, hàng xóm, bệnh viện, lá thư, di chúc, lời xin lỗi muộn.",
        ]
    )
    return "\n".join(lines)


def training_quick_guide_text(config: dict) -> str:
    return f"""# Hướng dẫn nhanh tab Huấn luyện AI

## Cách dùng dễ nhất
1. Dán hoặc nhập 3-10 kịch bản mẫu thắng nhất vào phần Mẫu huấn luyện.
2. Nếu chưa có mẫu, dán ý tưởng vào ô "Ý tưởng riêng / kho trend" ở sidebar hoặc bấm "Nạp trend".
3. Bấm "Huấn luyện 1 chạm".
4. Nếu có API key, tool sẽ dùng Gemini học/nâng cấp profile. Nếu chưa có API key, tool sẽ tạo profile local để dùng tạm.
5. Bấm "Chấm profile"; nên đạt 80/100 trở lên trước khi batch lớn.
6. Bật "Dùng profile khi viết", rồi quay lại Gemini Writer để viết kịch bản.

## Setup đang dùng
- Người xem: {config.get("audience", "")}
- Tone: {config.get("tone", "")}
- Niche: {config.get("niche", "")}
- Ý tưởng riêng: {"đã có" if (config.get("custom_story_ideas") or "").strip() else "chưa có"}

## Nên nhớ
- Training trong tool này là prompt-profile, không phải fine-tune thật.
- Profile tốt phải có: chân dung người xem, tone, cấu trúc hook, cách xây nhân vật, luật reveal, điều cấm, luật chống giống nguồn và kho ý tưởng.
- Nếu kịch bản nguồn là Nhật/Hàn/Trung/Anh, profile vẫn phải viết bằng tiếng Việt có dấu để bạn dễ kiểm soát.
"""


def training_story_idea_bank_text(config: dict) -> str:
    audience = config.get("audience", "Người xem 40+")
    tone = config.get("tone", "Chân thật, cảm xúc, từng trải")
    niche = config.get("niche", "Kể chuyện đời sống / gia đình / nhân sinh")
    cta = config.get("cta", "Mời người xem bình luận trải nghiệm")
    custom_ideas = (config.get("custom_story_ideas") or "").strip()
    ideas = [
        ("Người mẹ bị con trai bỏ quên trong viện dưỡng lão", "Một chiếc áo len cũ hé lộ số tiền bà âm thầm để dành cho con."),
        ("Người cha im lặng suốt 30 năm", "Ngày con gái ly hôn, ông mới kể vì sao năm xưa ông không giữ mẹ cô lại."),
        ("Bữa cơm cuối trước khi bán nhà", "Các con về để chia tài sản, nhưng thứ khiến họ bật khóc không nằm trong sổ đỏ."),
        ("Người vợ nghèo giữ bí mật của chồng quá cố", "Một cuốn sổ nợ cũ biến kẻ bị khinh thường thành người được cả làng cúi đầu."),
        ("Mẹ chồng khó tính và nàng dâu bị oan", "Camera bệnh viện lật lại sự thật về đêm cả nhà trách nhầm cô."),
        ("Di chúc không chia tiền", "Ông cụ chỉ để lại một chiếc chìa khóa và lời dặn khiến ba người con thay đổi cả đời."),
        ("Người hàng xóm lạ mỗi sáng đều đặt cơm trước cửa", "Khi bà cụ qua đời, cả khu phố mới biết người nhận cơm thật sự là ai."),
        ("Đứa con thành đạt trở về quá muộn", "Một tin nhắn chưa gửi trong điện thoại của mẹ khiến anh không thể ngủ suốt nhiều đêm."),
        ("Người phụ nữ bị chồng bỏ ở tuổi 50", "Ngày ông quay lại xin tha thứ, bà đã có một lựa chọn khiến cả gia đình lặng đi."),
        ("Cô con dâu bị coi là người ngoài", "Một ngày mưa, chính cô là người duy nhất ký giấy phẫu thuật cho mẹ chồng."),
        ("Ông lão bán vé số và tấm ảnh trong ví", "Người mua vé cuối cùng nhận ra ông từng cứu mạng mình 25 năm trước."),
        ("Người chị cả không lấy chồng", "Đến ngày em út cưới, cả nhà mới hiểu vì sao chị giữ mãi một chiếc hộp thiếc."),
        ("Tình yêu muộn ở tuổi 60", "Hai người già bị con cái phản đối, nhưng một bệnh án cũ cho thấy họ từng lỡ nhau cả đời."),
        ("Gia đình tranh nhau một căn nhà cũ", "Người không được chia tài sản lại là người duy nhất giữ lời hứa với cha mẹ."),
        ("Một cuộc gọi nhầm lúc nửa đêm", "Người phụ nữ cô đơn nhận nhầm cuộc gọi và cứu một gia đình khỏi tan vỡ."),
        ("Người chồng tệ bạc trong mắt cả làng", "Sau đám tang, một lá thư chứng minh ông đã âm thầm chịu tiếng xấu để bảo vệ vợ con."),
        ("Cô giúp việc già bị đuổi khỏi biệt thự", "Ngày bà rời đi, đứa trẻ trong nhà mới nói ra bí mật khiến người lớn xấu hổ."),
        ("Người mẹ kế bị ghét suốt 20 năm", "Một cuốn băng ghi âm cũ cho thấy bà từng đánh đổi danh dự để nuôi con riêng của chồng."),
        ("Đứa con nuôi trở về trong ngày giỗ", "Cả nhà nghĩ anh đến đòi phần, nhưng thứ anh mang tới là món nợ ân nghĩa."),
        ("Người cha nghèo đến dự đám cưới con gái", "Chiếc phong bì mỏng khiến nhà trai cười nhạo, cho đến khi họ đọc tờ giấy bên trong."),
        ("Bà cụ nhặt ve chai và căn nhà mặt phố", "Người cháu xấu hổ vì bà, cho tới ngày luật sư tìm đến."),
        ("Người vợ ký đơn ly hôn trong im lặng", "Ba năm sau, chồng cũ mới hiểu câu nói cuối cùng của bà nghĩa là gì."),
        ("Ông nội bị xem là gánh nặng", "Một đêm mất điện, đứa cháu nghe ông kể bí mật về mảnh đất cả nhà đang tranh chấp."),
        ("Con trai không về ăn Tết", "Mâm cơm nguội lạnh trở thành manh mối cho một lời hối hận không kịp nói."),
        ("Người phụ nữ bán hàng rong trước cổng trường", "Cậu học trò từng xấu hổ vì mẹ trở thành người duy nhất quay lại tìm bà."),
    ]
    hooks = [
        "Bà đã chờ cuộc gọi đó suốt ba năm, nhưng khi điện thoại reo, người ở đầu dây bên kia lại không phải con bà.",
        "Ngày các con trở về để chia nhà, ông cụ chỉ hỏi một câu khiến cả phòng khách im phăng phắc.",
        "Không ai tin người phụ nữ ấy trong suốt 20 năm, cho đến khi chiếc hộp gỗ dưới gầm giường được mở ra.",
        "Ông lão nghèo bị đuổi khỏi đám cưới con gái, nhưng món quà ông để lại khiến nhà trai không dám ngẩng mặt.",
        "Bà cụ không khóc trong ngày bị con đưa vào viện dưỡng lão. Bà chỉ lặng lẽ đưa cho cháu một chiếc chìa khóa.",
        "Cả làng gọi ông là kẻ vô tình, nhưng sau đám tang, một lá thư đã khiến mọi người cúi đầu xin lỗi.",
        "Người con dâu bị mắng là vô ơn lại là người duy nhất thức trắng bên giường bệnh của mẹ chồng.",
        "Căn nhà cũ tưởng chỉ đáng vài trăm triệu, nhưng bí mật trong bức tường đã chia lại lòng người trong gia đình.",
    ]
    archetypes = [
        "Người mẹ hy sinh âm thầm nhưng không biết nói lời ngọt ngào.",
        "Người cha nghiêm khắc, cả đời bị hiểu lầm là lạnh lùng.",
        "Con trưởng gánh gia đình nhưng bị xem là ích kỷ.",
        "Con út được cưng chiều nhưng là người thức tỉnh muộn.",
        "Nàng dâu chịu oan, không tranh cãi, chỉ chứng minh bằng hành động.",
        "Mẹ chồng cứng rắn vì từng chịu tổn thương tương tự.",
        "Người hàng xóm tử tế, giữ bí mật thay cả một gia đình.",
        "Luật sư/bác sĩ/y tá/người đưa thư làm nhân vật mở reveal.",
        "Người già cô đơn nhưng vẫn giữ lòng tự trọng.",
        "Người từng sai lầm, cuối đời muốn chuộc lỗi.",
    ]
    conflicts = [
        "Tranh chấp tài sản nhưng thật ra là tranh sự công nhận.",
        "Con cái bận rộn, cha mẹ không dám làm phiền.",
        "Nàng dâu bị đổ lỗi vì một bí mật người khác che giấu.",
        "Một người hy sinh quá lâu nên bị cả nhà xem là điều hiển nhiên.",
        "Lời hứa với người đã khuất khiến nhân vật phải chịu hiểu lầm.",
        "Tiền bạc làm lộ bản chất từng người trong gia đình.",
        "Một căn bệnh buộc mọi người đối diện điều chưa từng nói.",
        "Một cuộc trở về muộn khiến vết thương cũ bị mở lại.",
    ]
    reveals = [
        "Lá thư cũ trong áo khoác.",
        "Tin nhắn chưa gửi trong điện thoại.",
        "Bệnh án bị giấu.",
        "Camera bệnh viện/cửa hàng.",
        "Cuốn sổ tiết kiệm đứng tên người khác.",
        "Tấm ảnh phía sau khung ảnh.",
        "Người hàng xóm làm chứng.",
        "Di chúc chỉ có một câu dặn.",
        "Bản ghi âm từ nhiều năm trước.",
        "Chiếc chìa khóa mở căn phòng bị khóa.",
    ]
    series = [
        "Mỗi tập là một bí mật trong cùng một khu phố cũ.",
        "Mỗi tập xoay quanh một món đồ cha mẹ để lại.",
        "Một gia đình ba thế hệ, mỗi tập kể từ góc nhìn một người.",
        "Series về những cuộc gọi cuối cùng trước khi mọi thứ thay đổi.",
        "Series về người hàng xóm lặng lẽ giúp từng gia đình.",
        "Mỗi tập là một vụ tranh chấp tài sản nhưng kết bằng bài học tình thân.",
    ]
    global_formats = [
        "Micro-drama dọc 30-90 giây/tập: mỗi tập kết bằng cliffhanger cực rõ.",
        "Creator-series dài kiểu TV: nhân vật/kênh có format lặp lại, tập nào cũng có vấn đề mới.",
        "Webtoon short drama: mở bằng trope mạnh, đẩy cảm xúc nhanh, twist sau 1-2 phút.",
        "Reddit/AITA confession: người kể xưng tôi, kể một quyết định gây tranh cãi, cuối hỏi khán giả phán xét.",
        "True-story documentary: kể như hồ sơ vụ việc, có timeline, chứng cứ, bước ngoặt, bài học.",
        "Healing slice-of-life: ít drama, nhiều cảm xúc chữa lành, bối cảnh đời thường và kết ấm.",
        "Revenge transformation: nhân vật bị coi thường, lột xác, trả giá/công lý tới ở cuối.",
        "Romance contract/secret identity: quan hệ giả, thân phận thật, hiểu lầm và reveal.",
        "Workplace betrayal: đồng nghiệp/cấp trên cướp công, bằng chứng xuất hiện ở cao trào.",
        "Family inheritance battle: tài sản chỉ là bề mặt, lòng người mới là trọng tâm.",
        "POV social experiment: một hành động nhỏ lộ bản chất của người xung quanh.",
        "AI/tech accident story: một tin nhắn, camera, deepfake hoặc thuật toán làm lộ bí mật.",
        "Beauty/lifestyle transformation story: thay đổi ngoại hình/thói quen dẫn đến đổi đời hoặc trả giá.",
        "Food/travel memory story: món ăn/chuyến đi kéo về ký ức, tình thân, lời hứa cũ.",
        "Urban mystery/creepy but emotional: bí ẩn nhẹ, không quá kinh dị, kết bằng sự thật nhân văn.",
    ]
    japan_ideas = [
        ("Quán cơm đêm ở Tokyo", "Mỗi vị khách để lại một mẩu giấy, đến đêm thứ bảy chủ quán phát hiện họ đều liên quan đến một người đã mất."),
        ("Người đàn ông ngủ quên trên chuyến tàu cuối", "Một nữ nhân viên ga trả lại chiếc ví và mở ra bí mật về người mẹ ông đã bỏ quên."),
        ("Căn hộ 203 không bao giờ nhận bưu phẩm", "Người giao hàng trẻ phát hiện người nhận đã qua đời, nhưng hàng tháng vẫn có ai đó đặt hoa."),
        ("Bà cụ chăm vườn hoa ở khu chung cư", "Một học sinh cá biệt nhận ra loài hoa bà trồng là lời xin lỗi gửi cho con trai."),
        ("Nhật ký trong tiệm sách cũ", "Cô gái mua cuốn sách 100 yên và thấy câu chuyện trong đó giống hệt gia đình mình."),
        ("Người cha làm bentou mỗi sáng", "Con gái xấu hổ vì hộp cơm đơn giản, cho đến khi đọc những mẩu giấy cha giấu dưới nắp hộp."),
        ("Người phụ nữ dọn dẹp nhà sau mất mát", "Mỗi món đồ bỏ đi lại hé lộ một lời hứa chưa hoàn thành."),
        ("Y tá ca đêm và bệnh nhân không có người thăm", "Bà lão để lại danh sách 5 người cần được tha thứ trước khi qua đời."),
        ("Chú mèo ở ga tàu nhỏ", "Nó dẫn một cậu bé đến tấm ảnh cũ về người ông mà cậu chưa từng gặp."),
        ("Câu lạc bộ sửa đồ cũ", "Một chiếc đồng hồ hỏng khiến hai thế hệ trong gia đình chịu nói chuyện lại với nhau."),
        ("Công ty đen và lá đơn nghỉ việc", "Người nhân viên tưởng mình thất bại, nhưng một email cũ chứng minh anh đã cứu cả nhóm."),
        ("Lá thư trong máy bán hàng tự động", "Mỗi lon nước rơi ra kèm một câu nhắn, người nhận cuối cùng bật khóc."),
        ("Ngày cuối cùng ở làng biển", "Một cụ ông bán căn nhà cũ, nhưng người mua lại là đứa trẻ từng được ông cứu khỏi bão."),
        ("Cô gái cosplay chăm sóc bà ngoại", "Bà không hiểu anime, nhưng âm thầm may bộ trang phục giúp cháu đứng trên sân khấu."),
        ("Tiệm giặt là 24 giờ", "Một chiếc áo khoác bỏ quên chứa bằng chứng cho nỗi oan của một người cha."),
    ]
    korea_ideas = [
        ("Con dâu nghèo trong gia đình tài phiệt", "Cả nhà coi thường cô cho đến khi hợp đồng bí mật của chủ tịch lộ ra."),
        ("Cựu idol làm hướng dẫn viên du lịch", "Cô dẫn người khác đi chữa lành, nhưng chuyến đi cuối cùng lại chữa lành cho chính mình."),
        ("Webtoon trở thành đời thật", "Một biên tập viên phát hiện nhân vật phản diện trong webtoon giống hệt mẹ kế của mình."),
        ("Bắt nạt học đường sau 20 năm", "Cuộc họp phụ huynh biến thành phiên tòa khi con của kẻ bắt nạt gặp con của nạn nhân."),
        ("Bác sĩ thực tập và bệnh nhân không tên", "Bệnh án bị giấu hé lộ mối quan hệ giữa bệnh nhân và viện trưởng."),
        ("Nhân viên văn phòng bị cướp công", "Một file ghi âm trong máy pha cà phê giúp cô lấy lại danh dự."),
        ("Hợp đồng hôn nhân 100 ngày", "Hai người cưới giả để qua mặt gia đình, nhưng điều khoản cuối lại do người mẹ sắp mất viết."),
        ("K-beauty makeover trả thù", "Cô gái lột xác không phải để quay lại với người cũ, mà để làm chứng trước tòa."),
        ("Mẹ đơn thân bán đồ ăn đêm", "Một CEO trẻ thường xuyên ghé quán, không biết bà từng cứu mình khi còn nhỏ."),
        ("Gia đình che giấu thân phận con nuôi", "Ngày xét nghiệm ADN bị lộ, người bị xem là người ngoài lại là người giữ cả gia đình khỏi sụp đổ."),
        ("Luật sư ly hôn và vụ án của chính mẹ mình", "Cô càng thắng nhiều vụ ly hôn càng sợ đối diện cuộc hôn nhân của cha mẹ."),
        ("Streamer mukbang nhận hộp cơm lạ", "Món ăn trong hộp lần lượt kể lại tuổi thơ cô đã cố quên."),
        ("Người giúp việc trong căn penthouse", "Cô không đến để trả thù, mà để tìm đứa em mất tích trong vụ cháy năm xưa."),
        ("Thực tập sinh bị loại phút cuối", "Video hậu trường cho thấy người bị đuổi mới là người cứu cả buổi biểu diễn."),
        ("Cửa hàng tiện lợi lúc 2 giờ sáng", "Ba người lạ gặp nhau mỗi đêm, đến cuối mới biết họ cùng chờ một cuộc gọi từ bệnh viện."),
    ]
    us_ideas = [
        ("I found my mother's secret bank account", "A family money secret reveals who really paid for everyone's success."),
        ("My husband demanded a DNA test", "The test result exposes a different lie than the one he expected."),
        ("AITA for selling the family house", "The comments turn against the narrator until one missing detail changes everything."),
        ("The nanny camera caught my sister-in-law", "A domestic mystery becomes a story about manipulation and inheritance."),
        ("I quit my job on the worst day possible", "The resignation email accidentally reveals a fraud inside the company."),
        ("My dad left me a storage unit", "Inside is not money, but evidence of 30 years of sacrifice."),
        ("The bride's empty chair", "A wedding turns into a reckoning when the person everyone excluded leaves a recorded message."),
        ("Small town diner confession", "A waitress hears the same apology from three strangers in one week."),
        ("The neighbor who borrowed sugar every Sunday", "After her death, the family learns she was feeding someone they had forgotten."),
        ("My ex came back after I won the lottery", "The money is fake, but the reactions reveal who loved the narrator for real."),
        ("A true-crime style family mystery", "A missing heirloom, a will, and a quiet aunt reconstruct the truth without graphic content."),
        ("The viral apology video", "An influencer's public apology hides a private betrayal in the comments."),
        ("Grandma's recipe channel", "Her cooking videos become popular, but the final recipe is a message to her estranged son."),
        ("The substitute teacher recognized my name", "A classroom encounter uncovers the father the student was told had abandoned them."),
        ("The HOA letter", "A petty neighborhood dispute escalates into a story about loneliness, pride, and forgiveness."),
    ]
    china_ideas = [
        ("Tổng tài che giấu thân phận", "Người đàn ông giao hàng bị coi thường tại tiệc gia đình, cuối cùng là chủ nợ cứu cả công ty."),
        ("Thiếu phu nhân bị đuổi khỏi nhà", "Ba năm sau cô trở về không để trả thù tình cũ, mà để lấy lại danh dự cho mẹ."),
        ("Duanju 60 giây/tập: hợp đồng hôn nhân", "Mỗi tập kết bằng một cú lật: người chồng lạnh lùng đang âm thầm bảo vệ cô."),
        ("Cổ trang báo thù gia tộc", "Nhân vật sống sót sau biến cố, đổi thân phận và từng bước lật lại vụ án năm xưa."),
        ("Nữ chính giả nghèo thử lòng nhà chồng", "Một bữa cơm cho thấy ai xem cô là người và ai chỉ xem cô là tài sản."),
        ("Anh rể/cô em vợ và bí mật cổ phần", "Một cuộc họp cổ đông biến thành cao trào gia đình."),
        ("Thần y trở về quê", "Người bị làng khinh thường cứu đúng người từng đuổi mẹ mình khỏi nhà."),
        ("Đứa trẻ mang ngọc bội", "Vật chứng nhỏ hé lộ thân phận thật giữa hai gia đình đổi con."),
        ("Livestream bán hàng và cú bóc phốt", "Nữ chủ shop bị đối thủ hãm hại, nhưng đơn hàng cuối lại là bằng chứng sạch tên cô."),
        ("Người vợ bị thay thế", "Cô không tranh chồng, cô vạch trần hợp đồng lừa đảo sau cuộc hôn nhân."),
        ("Cha già ký giấy chuyển nhượng", "Các con tưởng đã thắng, nhưng điều khoản cuối do ông để lại khiến họ trả giá."),
        ("Bí mật trong nhà cổ", "Một chiếc chìa khóa mở ra căn phòng chứa hồ sơ về vụ oan ba đời."),
        ("Bạn thân cướp vị trí", "Nữ chính im lặng đến buổi lễ trao giải, rồi phát video chứng minh mọi thứ."),
        ("Chàng rể bị khinh thường", "Ngày ly hôn, cả nhà mới biết anh là người âm thầm trả nợ cho họ."),
        ("Người phụ nữ tái sinh sau biến cố", "Cô không quay lại để đổi số phận bằng phép màu, mà bằng trí nhớ và lựa chọn khác."),
    ]
    trend_notes = [
        "Micro-drama/vertical drama đang tăng mạnh toàn cầu: tập ngắn, cliffhanger dày, trope rõ, dễ batch thành series.",
        "Hàn Quốc nổi lên hướng webtoon/IP chuyển thành short drama, hợp các mô-típ romance, revenge, fantasy, workplace.",
        "Mỹ hợp format confession/AITA, creator-series, true-story documentary, family secret, workplace betrayal.",
        "Trung Quốc mạnh ở duanju: tổng tài, hợp đồng hôn nhân, trả thù, thân phận bí mật, cổ trang báo thù, cliffhanger mỗi tập.",
        "Nhật hợp healing/slice-of-life, tiệm nhỏ, ga tàu, căn hộ, đồ vật cũ, ký ức gia đình, nhịp kể lặng nhưng thấm.",
    ]
    trend_formats = [
        ("Vertical microdrama", "Tập 45-120 giây, một xung đột rõ, một cú lật cuối tập, hợp batch 30-80 tập."),
        ("Long-form kể chuyện voice", "Video 20-60 phút, nhịp chậm hơn, nhiều độc thoại nội tâm, twist rải đều mỗi 5-8 phút."),
        ("Confession/AITA", "Người kể thú nhận một quyết định gây tranh cãi, khán giả được mời phán xét ở cuối."),
        ("Webtoon/IP drama", "Trope mạnh ngay từ đầu, nhân vật có mục tiêu rõ, visual hóa cảnh như từng khung truyện."),
        ("True story dossier", "Kể như hồ sơ: timeline, bằng chứng, nhân chứng, hiểu lầm, kết luận nhân văn."),
        ("Healing documentary", "Ít đối đầu, nhiều quan sát đời sống, phù hợp Nhật/Hàn và người xem trưởng thành."),
        ("Social commerce story", "Sản phẩm/dịch vụ nằm trong câu chuyện, không bán thẳng; bài học đi trước CTA."),
        ("Creator universe", "Một người dẫn chuyện/kênh có vũ trụ nhân vật lặp lại, mỗi tập mở thêm một bí mật."),
        ("AI/tech moral tale", "Một công cụ AI, camera, dữ liệu hoặc tin nhắn làm lộ lựa chọn đạo đức của con người."),
        ("Community mystery", "Bí mật trong khu phố/công ty/trường học; tập trung vào lòng người hơn là phá án nặng."),
    ]
    global_topic_ideas = [
        ("Documentary đời thật", "Một người bình thường bỗng nổi tiếng vì đoạn video 12 giây, nhưng đằng sau là câu chuyện 20 năm bị hiểu lầm."),
        ("Phát triển bản thân", "Người đàn ông 52 tuổi mất việc, bắt đầu ghi nhật ký 100 ngày và phát hiện thứ ông cần sửa không phải kỹ năng mà là lòng tự trọng."),
        ("Tài chính gia đình", "Một khoản nợ bí mật làm tan vỡ bữa cơm, nhưng hóa ra đó là tiền chữa bệnh mà người cha giấu suốt nhiều năm."),
        ("Sức khỏe/tuổi trung niên", "Bác sĩ nói một câu khiến nhân vật quay lại xin lỗi người đã bị bỏ quên từ lâu."),
        ("Review sản phẩm có câu chuyện", "Một chiếc ghế massage, một camera gia đình hoặc máy lọc không khí trở thành vật chứng trong câu chuyện đoàn tụ."),
        ("Ẩm thực ký ức", "Một món ăn đường phố kéo nhân vật trở về lời hứa đã thất lạc với mẹ."),
        ("Du lịch/chữa lành", "Chuyến đi tưởng để nghỉ ngơi lại buộc nhân vật đối diện lá thư chưa từng dám mở."),
        ("Làm đẹp/lột xác", "Một lần thay đổi ngoại hình giúp nhân vật tự tin, nhưng giá trị thật nằm ở việc dám rời khỏi quan hệ độc hại."),
        ("Công sở", "Một nhân viên bị cướp công im lặng thu thập bằng chứng qua những email tưởng vô nghĩa."),
        ("Giáo dục/gia đình", "Một giáo viên về hưu nhận ra học trò nghịch nhất năm xưa là người duy nhất nhớ lời dặn của mình."),
        ("Lịch sử/nhân vật", "Một câu chuyện lịch sử được kể qua đồ vật nhỏ: chiếc nhẫn, bức ảnh, tờ giấy chuyển nhượng."),
        ("Đô thị bí ẩn nhẹ", "Căn hộ luôn sáng đèn lúc 3 giờ sáng, nhưng bí mật cuối cùng không đáng sợ mà rất đau lòng."),
        ("Pháp lý/tòa án", "Một phiên hòa giải tài sản trở thành nơi cả gia đình nghe lại sự thật từ người đã mất."),
        ("Quan hệ xã hội", "Một lời xin lỗi công khai trên mạng kéo theo chuỗi bình luận lộ ra người chịu thiệt thật sự."),
        ("AI tương lai", "AI tạo lại giọng nói người mẹ quá cố, khiến gia đình phải hỏi: họ muốn được an ủi hay muốn biết sự thật?"),
        ("Bán hàng bằng storytelling", "Khách hàng khó tính quay lại sau 10 năm, không phải để mua thêm mà để trả một món nợ ân tình."),
        ("Kênh tâm sự", "Một cuộc gọi radio ban đêm khiến ba người xa lạ nhận ra họ đang giữ cùng một bí mật."),
        ("Series hàng xóm", "Mỗi tập mở một căn hộ trong cùng chung cư, cuối mùa nối lại thành bí mật của cả khu nhà."),
        ("Series bệnh viện", "Mỗi bệnh nhân để lại một vật chứng, y tá ca đêm ghép chúng thành câu chuyện về lòng tha thứ."),
        ("Series luật sư", "Mỗi vụ kiện gia đình không thắng bằng tiền, mà bằng sự thật được nói ra đúng lúc."),
    ]
    trend_packs = [
        ("Short drama 30-80 tập", "Mỗi tập 60-120 giây, mở bằng cảnh đang căng, kết bằng một câu chưa nói hết; hợp tổng tài, gia đình, revenge, bí mật thân phận."),
        ("Long-form 40-60 phút", "Một bí mật lớn chia thành 5 lớp: hook, đời thường, mâu thuẫn, mid twist, phản bội, cao trào, hậu quả, bài học."),
        ("Confession/AITA", "Người kể xưng tôi, kể một lựa chọn bị người thân phản đối, cuối mở câu hỏi: nếu là bạn, bạn có tha thứ không?"),
        ("Documentary hồ sơ", "Dùng timeline, vật chứng, tin nhắn, camera, nhân chứng; kể như điều tra nhưng tránh giật gân rẻ tiền."),
        ("Review bán hàng mềm", "Sản phẩm xuất hiện như vật chứng hoặc giải pháp trong câu chuyện, cảm xúc đi trước, CTA đi sau."),
        ("AI/tech moral story", "AI, camera, deepfake, dữ liệu, tin nhắn cũ làm lộ bí mật; trọng tâm là đạo đức và lựa chọn con người."),
        ("Healing Nhật/Hàn", "Quán ăn, ga tàu, tiệm sách, bệnh viện, chung cư; nhịp chậm, chi tiết nhỏ, kết lặng nhưng sâu."),
        ("Workplace revenge", "Bị cướp công, bị đổ lỗi, email/camera/file ghi âm trở thành bằng chứng lấy lại danh dự."),
        ("Family inheritance battle", "Di chúc, nhà cũ, sổ tiết kiệm, giấy chuyển nhượng; tiền chỉ là bề mặt, lòng người là câu chuyện."),
        ("Beauty/lifestyle transformation", "Lột xác không chỉ để đẹp hơn, mà để rời khỏi quan hệ độc hại hoặc lấy lại tự trọng."),
        ("Food memory", "Một món ăn mở ra ký ức với mẹ/cha/người yêu cũ; hợp video kể chuyện nhẹ, chữa lành, 40+."),
        ("Legal family drama", "Phiên hòa giải, luật sư, bệnh án, giấy khai sinh, ADN; cao trào là sự thật được nói ra đúng lúc."),
        ("Community mystery", "Cả khu phố/chung cư/công ty giữ một bí mật, mỗi nhân vật nắm một mảnh ghép."),
        ("Second life / tái sinh nhẹ", "Không cần fantasy nặng; nhân vật có cơ hội sửa một quyết định cũ và trả giá cho lựa chọn mới."),
        ("Creator universe", "Một người kể chuyện, một khu phố, một bệnh viện hoặc một văn phòng trở thành vũ trụ nhiều tập."),
    ]
    viral_hook_formulas = [
        "Tôi đã nghĩ đó chỉ là một cuộc gọi nhầm, cho đến khi nghe thấy tên mẹ mình ở đầu dây bên kia.",
        "Ngày chúng tôi mở di chúc, người được nhắc tên đầu tiên lại là người cả nhà từng đuổi đi.",
        "Cô ấy không khóc trong lễ cưới của con trai, nhưng chiếc phong bì trong túi áo đã nói thay tất cả.",
        "Tôi lắp camera chỉ để trông nhà, không ngờ lại thấy bí mật khiến cả gia đình im lặng.",
        "Ông cụ bán căn nhà cũ với giá rẻ, nhưng điều kiện duy nhất khiến người mua bật khóc.",
        "Cô nhân viên bị đuổi việc trong một phút, rồi chính email cuối cùng của cô cứu cả công ty.",
        "Bữa cơm đoàn viên hôm đó thiếu một người, và cũng chính người đó để lại lời nhắn cuối cùng.",
        "Mọi người tưởng bà cụ lẫn, cho đến khi luật sư đọc đúng câu bà đã viết 20 năm trước.",
        "Tôi nhận một hộp cơm không ghi tên, và từng món ăn trong đó kéo tôi về một lỗi lầm cũ.",
        "Người đàn ông bị cả nhà gọi là vô dụng lại là người âm thầm trả hết món nợ lớn nhất.",
        "Tấm ảnh cũ sau khung tranh không chứng minh tình yêu, nó chứng minh một lời nói dối kéo dài 30 năm.",
        "Cô dâu bước vào lễ đường một mình, còn người cha bị chặn ngoài cửa để lại món quà không ai dám mở.",
    ]
    trend_mini_ideas = [
        ("Camera trong phòng khách", "Con dâu bị nghi lấy tiền, nhưng camera cho thấy người lấy là người được tin nhất nhà."),
        ("Hộp cơm gửi nhầm", "Một nhân viên văn phòng nhận hộp cơm mỗi thứ hai và lần theo ký ức của người mẹ đã mất."),
        ("Di chúc bằng video", "Ông cụ không để lại tài sản ngay, mà bắt mỗi người con xem một đoạn video riêng."),
        ("AI đọc nhật ký cũ", "Con trai dùng AI khôi phục chữ viết của mẹ và phát hiện lời xin lỗi bà chưa từng gửi."),
        ("Quán ăn đêm cuối phố", "Mỗi vị khách gọi cùng một món, vì họ đều từng mắc nợ người chủ quán."),
        ("Livestream bóc phốt sai người", "Một cô gái bị cả mạng công kích, nhưng đơn hàng cuối cùng lật lại sự thật."),
        ("Căn hộ không ai thuê", "Mọi người nghĩ căn hộ có chuyện lạ, thật ra chủ nhà đang giữ lời hứa với con gái."),
        ("Bản ghi âm trong máy pha cà phê", "Công ty đổ lỗi cho thực tập sinh, nhưng chiếc máy trong pantry ghi lại toàn bộ sự thật."),
        ("Đám cưới không có mẹ", "Nhà trai cấm người mẹ nghèo xuất hiện, nhưng người ký hợp đồng cứu công ty lại là bà."),
        ("Bệnh án bị đổi tên", "Một y tá già nhận ra bệnh nhân vô danh là người từng cứu mình trong chiến tranh."),
        ("Storage unit số 17", "Người cha để lại một kho đồ cũ, mỗi món là một bằng chứng ông đã yêu con thế nào."),
        ("Hàng xóm mượn đường mỗi sáng", "Hành động kỳ lạ của bà cụ che giấu việc bà đang bảo vệ một đứa trẻ bị bỏ quên."),
        ("Hợp đồng hôn nhân giả", "Hai người ký hợp đồng để qua mặt gia đình, nhưng người mẹ bệnh nặng đã nhìn ra tình yêu thật."),
        ("Người giúp việc trở về", "Bà bị đuổi khỏi biệt thự, 15 năm sau quay lại với thân phận người giữ bằng chứng vụ cháy."),
        ("Bức thư trong áo khoác", "Một chiếc áo được quyên góp vô tình đưa lá thư cuối cùng đến đúng người cần đọc nó."),
        ("Phiên hòa giải cuối cùng", "Luật sư tưởng đang xử tranh chấp tài sản, nhưng thân chủ chỉ muốn nghe một câu xin lỗi."),
        ("Tiệm sách 100 yên", "Cuốn sách cũ chứa ghi chú của cha, dẫn con gái đến bí mật về ngày mẹ rời nhà."),
        ("Mã QR trên mộ", "Một mã QR dẫn đến video lời nhắn của người đã mất, nhưng người xem đầu tiên lại là kẻ phản bội."),
        ("Người cha bị chặn số", "Ông gửi tiền qua một người lạ suốt nhiều năm, cho đến ngày con gái tìm ra hóa đơn bệnh viện."),
        ("Công ty gia đình phá sản", "Người bị đổ lỗi là kế toán già, nhưng chính ông giữ lại chứng cứ cứu toàn bộ nhân viên."),
    ]
    market_trope_matrix = [
        ("Nhật", "healing + đời thường", "ga tàu, tiệm sách, quán ăn đêm, chung cư cũ, đồ vật kỷ niệm", "kết lặng, day dứt, ít phán xét"),
        ("Nhật", "work-life + cô đơn đô thị", "công ty đen, đơn nghỉ việc, phòng trọ, chuyến tàu cuối", "nhân vật tự chữa lành sau một biến cố nhỏ"),
        ("Hàn", "webtoon drama", "tài phiệt, hợp đồng hôn nhân, bí mật thân phận, revenge", "cao trào rõ, cảm xúc mạnh, twist nhanh"),
        ("Hàn", "workplace/school revenge", "bắt nạt, cướp công, thực tập sinh, luật sư/bác sĩ", "trả lại danh dự bằng bằng chứng"),
        ("Mỹ", "AITA/confession", "gia đình, cưới hỏi, hàng xóm, công sở, camera, storage unit", "người kể xưng tôi, cuối mở tranh luận"),
        ("Mỹ", "true-story documentary", "timeline, hồ sơ, nhân chứng, đoạn ghi âm, bình luận mạng", "nhịp rõ như điều tra nhưng kết nhân văn"),
        ("Trung Quốc", "duanju/tổng tài", "hợp đồng hôn nhân, thân phận bí mật, chàng rể bị khinh, cổ phần", "cliffhanger dày, payoff mạnh"),
        ("Trung Quốc", "cổ trang/tái sinh/báo thù", "gia tộc, oan án, ngọc bội, đổi thân phận, ký ức đời trước", "mưu trí, từng bước lật lại thế cờ"),
        ("Việt Nam", "đời thường gia đình", "bữa cơm, nhà cũ, viện dưỡng lão, mẹ chồng nàng dâu, di chúc", "chân thật, có hiếu, nhân quả mềm"),
        ("Global", "AI/tech accident", "camera, deepfake, lịch sử chat, thuật toán gợi ý, dữ liệu gia đình", "đặt câu hỏi đạo đức, không quá kỹ thuật"),
    ]
    prompt_seeds = [
        "Tạo 10 ý tưởng kiểu Nhật: healing, ít drama, bối cảnh đời thường, twist bằng đồ vật cũ, kết lặng.",
        "Tạo 10 ý tưởng kiểu Hàn: webtoon drama, tài phiệt/công sở, nhân vật bị hạ nhục rồi lấy lại danh dự.",
        "Tạo 10 ý tưởng kiểu Mỹ: confession/AITA, người kể xưng tôi, tình huống gây tranh cãi, cuối hỏi khán giả.",
        "Tạo 10 ý tưởng kiểu Trung Quốc: duanju, mỗi tập có cliffhanger, tổng tài/hôn nhân hợp đồng/thân phận bí mật.",
        "Tạo 10 ý tưởng long-form 40-60 phút: nhiều lớp bí mật, twist mỗi 7 phút, kết có bài học nhân sinh.",
        "Tạo 10 ý tưởng review bán hàng bằng storytelling: sản phẩm là vật chứng trong câu chuyện, CTA mềm.",
        "Tạo 10 ý tưởng documentary: timeline, chứng cứ, nhân chứng, bài học, không giật gân rẻ tiền.",
        "Tạo 10 ý tưởng AI/tech moral story: công nghệ làm lộ bí mật, trọng tâm là lựa chọn của con người.",
    ]
    return "\n".join(
        [
            "# Kho ý tưởng kịch bản cho phần Huấn luyện",
            "",
            f"- Người xem đang nhắm tới: {audience}",
            f"- Tone đang dùng: {tone}",
            f"- Niche: {niche}",
            f"- CTA: {cta}",
            "",
            *(
                [
                    "## Ý tưởng riêng người dùng đã nhập",
                    custom_ideas,
                    "",
                    "## Cách AI nên nâng cấp ý tưởng riêng",
                    "- Giữ insight/cảm xúc lõi của ý tưởng riêng, nhưng tăng hook, xung đột, reveal, cao trào, payoff và CTA.",
                    "- Nếu ý tưởng còn mơ hồ, biến nó thành 3 hướng: long-form 40+, short drama nhiều tập, documentary/confession.",
                    "- Không chỉ chép lại ý tưởng; phải mở rộng thành engine có thể tạo nhiều kịch bản khác nhau.",
                    "",
                ]
                if custom_ideas
                else []
            ),
            "## Ghi chú xu hướng global",
            *[f"- {item}" for item in trend_notes],
            "",
            "## 15 format kịch bản đang dễ triển khai",
            *[f"{index}. {item}" for index, item in enumerate(global_formats, 1)],
            "",
            "## 10 format xu hướng theo cách sản xuất",
            *[f"{index}. {name}: {note}" for index, (name, note) in enumerate(trend_formats, 1)],
            "",
            "## 15 trend pack để tạo series",
            *[f"{index}. {name}: {note}" for index, (name, note) in enumerate(trend_packs, 1)],
            "",
            "## 25 ý tưởng kịch bản kể chuyện 40+",
            *[f"{index}. {title}: {twist}" for index, (title, twist) in enumerate(ideas, 1)],
            "",
            "## 20 ý tưởng global đa chủ đề",
            *[f"{index}. {topic}: {idea}" for index, (topic, idea) in enumerate(global_topic_ideas, 1)],
            "",
            "## 20 ý tưởng trend ngắn có thể triển khai ngay",
            *[f"{index}. {title}: {twist}" for index, (title, twist) in enumerate(trend_mini_ideas, 1)],
            "",
            "## 15 ý tưởng theo thị trường Nhật",
            *[f"{index}. {title}: {twist}" for index, (title, twist) in enumerate(japan_ideas, 1)],
            "",
            "## 15 ý tưởng theo thị trường Hàn",
            *[f"{index}. {title}: {twist}" for index, (title, twist) in enumerate(korea_ideas, 1)],
            "",
            "## 15 ý tưởng theo thị trường Mỹ",
            *[f"{index}. {title}: {twist}" for index, (title, twist) in enumerate(us_ideas, 1)],
            "",
            "## 15 ý tưởng theo thị trường Trung Quốc",
            *[f"{index}. {title}: {twist}" for index, (title, twist) in enumerate(china_ideas, 1)],
            "",
            "## Ma trận thị trường / trope để phối ý tưởng",
            *[
                f"- {market} | {trope} | Bối cảnh: {setting} | Cách kể: {style}"
                for market, trope, setting, style in market_trope_matrix
            ],
            "",
            "## 8 hook có thể dùng ngay",
            *[f"- {hook}" for hook in hooks],
            "",
            "## 12 hook trend có thể biến thành video ngay",
            *[f"- {hook}" for hook in viral_hook_formulas],
            "",
            "## 10 kiểu nhân vật dễ kéo cảm xúc",
            *[f"- {item}" for item in archetypes],
            "",
            "## 8 động cơ xung đột mạnh",
            *[f"- {item}" for item in conflicts],
            "",
            "## 10 cơ chế reveal/twist",
            *[f"- {item}" for item in reveals],
            "",
            "## 6 format series có thể phát triển dài hạn",
            *[f"- {item}" for item in series],
            "",
            "## Công thức tạo ý tưởng mới",
            "- Chọn 1 nhân vật bị hiểu lầm + 1 vết thương gia đình + 1 vật chứng reveal + 1 bài học cuối.",
            "- Đổi bối cảnh đời thường: bệnh viện, bữa cơm, nhà cũ, đám cưới, đám tang, viện dưỡng lão, phiên tòa, chuyến xe.",
            "- Đổi người kể: mẹ, cha, con dâu, hàng xóm, luật sư, bác sĩ, cháu nhỏ, người từng mắc lỗi.",
            "- Mỗi ý tưởng phải có: hook 3-7 giây, nỗi đau chính, bí mật, cao trào, bài học, CTA mềm.",
            "",
            "## Prompt có thể dán vào Chat AI",
            *[f"- {seed}" for seed in prompt_seeds],
            "",
            "## Prompt 40+ mặc định",
            "Hãy tạo 20 ý tưởng kịch bản kể chuyện cho người xem 40+ theo profile kênh hiện tại. "
            "Mỗi ý tưởng gồm: tiêu đề, hook 3 câu, nhân vật chính, mâu thuẫn, twist/reveal, bài học cuối, CTA mềm. "
            "Không dùng lại tuyến truyện từ kịch bản gốc, ưu tiên bối cảnh đời thường Việt Nam và cảm xúc gia đình.",
        ]
    )


def training_story_idea_locked_rules() -> str:
    return """## Luật ý tưởng kịch bản / Story Idea Engine + Market Trend Engine
- Trước khi viết, luôn chọn rõ: thị trường mục tiêu, format, nhân vật chính, nỗi đau, mâu thuẫn, bí mật/reveal, bài học cuối và CTA.
- Nếu chọn Nhật: ưu tiên healing, đời thường, đồ vật cũ, ga tàu, tiệm nhỏ, nhịp lặng và kết thấm.
- Nếu chọn Hàn: ưu tiên webtoon drama, công sở/tài phiệt, revenge, hợp đồng hôn nhân, nhân vật lấy lại danh dự.
- Nếu chọn Mỹ: ưu tiên confession/AITA, true-story documentary, family secret, workplace betrayal, góc kể xưng tôi.
- Nếu chọn Trung Quốc: ưu tiên duanju/vertical drama, tổng tài, thân phận bí mật, hợp đồng hôn nhân, cổ trang/tái sinh, cliffhanger dày.
- Ưu tiên ý tưởng hợp người xem 40+: cha mẹ, con cái, hôn nhân, tuổi già, tài sản, lòng hiếu thảo, nhân quả, tình người.
- Mỗi kịch bản cần có ít nhất một vật chứng hoặc tín hiệu reveal: lá thư, cuộc gọi, bệnh án, di chúc, tấm ảnh, chìa khóa, sổ tiết kiệm, người làm chứng.
- Không dùng lại cùng một mô-típ quá nhiều lần. Luân phiên giữa: gia đình, hôn nhân, hàng xóm, tuổi già, tài sản, nỗi oan, báo hiếu, tình yêu muộn.
- Có thể dùng mô-típ ngoài 40+ nếu hợp kênh: documentary, review bán hàng bằng storytelling, AI/tech moral story, confession, healing, workplace, pháp lý, ẩm thực ký ức.
- Nếu chọn mode 100%, chỉ giữ ý tưởng lõi của nguồn, còn nhân vật, bối cảnh, chuỗi sự kiện và twist phải mới hoàn toàn.
- Hook phải có biến cố rõ trong 3-7 giây đầu, không mở đầu chung chung.
- Kết phải để lại dư âm nhân sinh, không chỉ giải thích sự kiện."""


def default_negative_training_rules() -> str:
    return """- Không dùng giọng quá trẻ, meme, slang khó hiểu hoặc câu quá giật gân rẻ tiền.
- Không sao chép câu chữ, nhịp câu hoặc cụm diễn đạt đặc trưng từ kịch bản mẫu/gốc.
- Không biến câu chuyện thành bản tóm tắt khô.
- Không kết quá vội, không giảng đạo nặng nề.
- Không lạm dụng dấu chấm than, câu hỏi liên tục hoặc từ ngữ phóng đại vô căn cứ."""


def default_locked_training_rules() -> str:
    return """- Luôn viết tiếng Việt có dấu nếu ngôn ngữ đầu ra là Tiếng Việt.
- Luôn giữ giọng kể chân thật, dễ nghe khi voice.
- Luôn có hook đời thường trong 3-7 giây đầu.
- Luôn xây đồng cảm trước khi đẩy drama.
- Luôn kết bằng bài học hoặc dư âm cảm xúc phù hợp người xem 40+.
- Luôn đổi mạnh cách kể để bản mới khác nguồn khoảng 70-80%."""


def training_profile_40plus_template(config: dict) -> str:
    custom_ideas = (config.get("custom_story_ideas") or "").strip()
    custom_ideas_section = (
        f"""
## Ý tưởng riêng / trend seed người dùng
{custom_ideas}

## Custom Idea Engine
- Xem ý tưởng riêng là kho nguyên liệu ưu tiên khi tạo hook, bối cảnh, mâu thuẫn và reveal.
- Không chép nguyên văn ý tưởng; nâng cấp thành nhiều phiên bản có cùng insight nhưng khác tuyến truyện.
- Mỗi ý tưởng nên có thể phát triển thành long-form 40+, short drama nhiều tập và documentary/confession.
"""
        if custom_ideas
        else ""
    )
    return f"""# CHANNEL TRAINING PROFILE MẪU - KỂ CHUYỆN 40+

## Mục tiêu kênh
- Nền tảng: {config.get("platform", "YouTube")}
- Người xem chính: nam nữ 40-65 tuổi, thích câu chuyện đời thường, gia đình, hôn nhân, tuổi già, nhân quả và tình người.
- Niche: {config.get("niche", "Kể chuyện đời sống / gia đình / bài học nhân sinh")}
- Tone: {config.get("tone", "Ấm áp, chân thật, từng trải, giàu cảm xúc")}
- CTA: {config.get("cta", "Mời người xem bình luận trải nghiệm hoặc quan điểm sống")}
{custom_ideas_section}

## Công thức cố định
1. Mở đầu bằng một biến cố gần gũi: bữa cơm, cuộc gọi, lá thư, bệnh viện, di chúc, hàng xóm, con cái.
2. Giới thiệu nhân vật qua nỗi đau, sự im lặng, hiểu lầm hoặc lựa chọn khó.
3. Xây đồng cảm trước, sau đó mới đẩy mâu thuẫn.
4. Mỗi 45-60 giây có một câu kéo tiếp để mở vòng tò mò.
5. Reveal bằng sự thật bị giấu, lời thú nhận, sự trở về, lá thư, bệnh án hoặc hành động báo đáp.
6. Cao trào phải có cảm xúc nhưng không quá lố.
7. Kết bằng bài học mềm: tự trọng, biết ơn, tha thứ, nhân quả, tình thân, sống tử tế.

## Luật phong cách
- Câu văn rõ, dễ nghe khi đọc voice, nhịp chậm vừa.
- Ít tiếng lóng, không meme, không giọng trẻ hóa.
- Dùng nhiều chi tiết đời thường để người xem 40+ dễ thấy mình trong câu chuyện.
- Tôn trọng nhân vật, không bôi nhọ, không phán xét cực đoan.

## Story Idea Engine
- Tạo ý tưởng bằng công thức: nhân vật bị hiểu lầm + vết thương gia đình + vật chứng reveal + bài học cuối.
- Luân phiên mô-típ: con cái vô tâm, cha mẹ hy sinh, hôn nhân tan vỡ, mẹ chồng nàng dâu, hàng xóm tử tế, tuổi già cô đơn, tài sản/di chúc, nỗi oan được giải, tình yêu muộn, báo hiếu.
- Luân phiên vật chứng reveal: lá thư, cuộc gọi, bệnh án, di chúc, tấm ảnh, chìa khóa, cuốn sổ nợ, sổ tiết kiệm, camera, người làm chứng.
- Mỗi ý tưởng phải có hook 3-7 giây, nỗi đau rõ, bí mật, cao trào, bài học và CTA mềm.
- Nếu ý tưởng quá giống mẫu cũ, đổi nhân vật, bối cảnh, cơ chế reveal và kết.

## Market Trend Engine
- Nhật: healing, slice-of-life, ga tàu, tiệm nhỏ, đồ vật cũ, nhịp lặng, kết thấm.
- Hàn: webtoon drama, công sở/tài phiệt, revenge, hợp đồng hôn nhân, lấy lại danh dự.
- Mỹ: confession/AITA, true-story documentary, family secret, workplace betrayal, người kể xưng tôi.
- Trung Quốc: duanju/vertical drama, tổng tài, thân phận bí mật, hợp đồng hôn nhân, cổ trang/tái sinh, cliffhanger dày.
- Global: AI/tech moral story, documentary đời thật, review bằng storytelling, food/travel memory, pháp lý/tòa án, community mystery.
- Khi đổi thị trường, giữ giá trị lõi của kênh nhưng đổi bối cảnh, trope, nhịp reveal và CTA cho hợp văn hóa.

## Luật viết lại
- Chỉ giữ cảm xúc lõi, chủ đề, quan hệ nhân vật và bài học.
- Đổi hook, thứ tự reveal, cảnh phụ, câu thoại, chuyển đoạn và CTA.
- Không paraphrase từng câu, không giữ cụm 7 từ liên tiếp từ nguồn.
- Nếu cần kéo dài, mở rộng bằng hồi tưởng, nội tâm, đối thoại, cảnh đời thường và chiêm nghiệm."""


def merge_training_profile(profile: str, local_profile: str, negative_rules: str, locked_rules: str, config: dict) -> str:
    parts = [
        "# CHANNEL TRAINING PROFILE - BẢN NÂNG CẤP",
        "",
        "## Profile hiện có",
        profile.strip() or "Chưa có profile cũ.",
        "",
        "## Bổ sung tự động từ mẫu/cấu hình",
        local_profile.strip(),
    ]
    if locked_rules.strip():
        parts.extend(["", "## Luật bắt buộc", locked_rules.strip()])
    if negative_rules.strip():
        parts.extend(["", "## Luật cấm / Negative style", negative_rules.strip()])
    parts.extend(
        [
            "",
            "## Luật ưu tiên khi viết",
            f"- Ưu tiên người xem: {config.get('audience', '')}",
            f"- Ưu tiên tone: {config.get('tone', '')}",
            f"- Ưu tiên niche: {config.get('niche', '')}",
            f"- Ý tưởng riêng/trend seed: {config.get('custom_story_ideas', '') or 'chưa có'}",
            f"- Mức biến đổi mặc định: {config.get('target_change', 78)}%",
            "- Nếu profile cũ mâu thuẫn với luật bắt buộc, luôn theo luật bắt buộc.",
        ]
    )
    return "\n".join(parts).strip()


def duration_minutes_range(duration: str) -> tuple[float, float]:
    text = (duration or "").strip().lower()
    text = text.replace("’", "'").replace("′", "'").replace("`", "'")
    numbers = [float(item.replace(",", ".")) for item in re.findall(r"\d+(?:[.,]\d+)?", text)]
    if not numbers:
        return 0.0, 0.0
    if len(numbers) == 1:
        low = high = numbers[0]
    else:
        low, high = min(numbers[0], numbers[1]), max(numbers[0], numbers[1])
    if re.search(r"giây|giay|sec|second|s\b", text) and not re.search(r"phút|phut|min|minute|'", text):
        low /= 60
        high /= 60
    return low, high


def format_int_vn(value: int) -> str:
    return f"{value:,}".replace(",", ".")


def duration_unit_target(duration: str, language: str = "Tiếng Việt") -> tuple[int, int, dict]:
    low, high = duration_minutes_range(duration)
    profile = voice_profile(language)
    if low <= 0:
        return 0, 0, profile
    min_units = max(80, round(low * profile["min_rate"]))
    max_units = max(min_units, round(high * profile["max_rate"]))
    return min_units, max_units, profile


def minutes_range_label(low: float, high: float) -> str:
    if low <= 0:
        return "tự chọn"
    if abs(low - high) < 0.2:
        return f"{low:g} phút"
    return f"{low:g}-{high:g} phút"


def source_based_duration_range(source: str, config: dict) -> dict:
    source_language = "" if config.get("source_language") == "auto" else config.get("source_language", "")
    target_language = config.get("target_language", "Tiếng Việt")
    source_minutes = estimated_voice_minutes(source, source_language)
    user_low, user_high = duration_minutes_range(config.get("duration", ""))
    if source_minutes <= 0:
        return {
            "low": user_low,
            "high": user_high,
            "source_minutes": 0.0,
            "duration": minutes_range_label(user_low, user_high),
            "goal": duration_goal_text(minutes_range_label(user_low, user_high), target_language),
            "strategy": "Theo ô thời lượng",
        }

    if source_minutes < 3:
        low = max(source_minutes + 0.4, source_minutes * 1.15)
        high = max(low + 1.0, source_minutes * 1.8)
    elif source_minutes < 10:
        low = max(source_minutes + 1.0, source_minutes * 1.15)
        high = max(low + 2.0, source_minutes * 1.6)
    else:
        low = max(source_minutes + 2.0, source_minutes * 1.15)
        high = max(low + 3.0, source_minutes * 1.5)

    reasonable_cap = max(low + 1.0, source_minutes * 1.7)
    if user_high > 0 and source_minutes < user_high <= reasonable_cap:
        high = max(high, user_high)
    if user_low > 0 and source_minutes < user_low <= reasonable_cap:
        low = max(low, min(user_low, high - 0.5))

    low = math.ceil(low)
    high = math.ceil(max(high, low + 1))
    duration = minutes_range_label(low, high)
    goal = duration_goal_text(duration, target_language)
    return {
        "low": low,
        "high": high,
        "source_minutes": source_minutes,
        "duration": duration,
        "goal": f"{goal} | tự động theo nguồn ~{source_minutes:g} phút, bản mới luôn dài hơn bản gốc",
        "strategy": f"Tự động theo nguồn: nguồn ~{source_minutes:g} phút -> bản mới {duration}",
    }


def config_with_source_duration(config: dict, source: str) -> dict:
    target = source_based_duration_range(source, config)
    effective = dict(config)
    effective.setdefault("duration_user", config.get("duration", ""))
    effective["duration"] = target["duration"]
    effective["duration_goal"] = target["goal"]
    effective["duration_strategy"] = target["strategy"]
    effective["source_estimated_minutes"] = target["source_minutes"]
    return effective


def duration_goal_text(duration: str, language: str = "Tiếng Việt") -> str:
    low, high = duration_minutes_range(duration)
    if low <= 0:
        return f"{duration or 'tự chọn'}"
    min_units, max_units, profile = duration_unit_target(duration, language)
    if abs(low - high) < 0.01:
        label = f"{low:g} phút"
    else:
        label = f"{low:g}-{high:g} phút"
    return (
        f"{label} đọc voice, tương đương khoảng {format_int_vn(min_units)}-{format_int_vn(max_units)} "
        f"{profile['unit']} ở tốc độ {profile['min_rate']}-{profile['max_rate']} {profile['unit']}/phút"
    )


def duration_word_target(duration: str) -> tuple[int, int]:
    min_units, max_units, _ = duration_unit_target(duration, "Tiếng Việt")
    return min_units, max_units


def text_length_meta(text: str, language: str = "", duration: str = "", include_target: bool = False) -> str:
    if not text.strip():
        return "0"
    units = voice_unit_count(text, language)
    profile = voice_profile(language, text)
    minute_range = estimated_voice_range_text(units, language, text)
    meta = f"{format_int_vn(units)} {profile['unit']} ≈ {minute_range}"
    if include_target:
        min_units, max_units, target_profile = duration_unit_target(duration, language)
        if min_units and max_units:
            target_text = f"{format_int_vn(min_units)}-{format_int_vn(max_units)} {target_profile['unit']}"
            if units < round(min_units * 0.9):
                meta += f" | mục tiêu {target_text}: thiếu khoảng {format_int_vn(max(min_units - units, 0))}"
            elif units > round(max_units * 1.15):
                meta += f" | mục tiêu {target_text}: đang dài hơn"
            else:
                meta += f" | đạt gần mục tiêu {target_text}"
    return meta


def batch_length_status(units: int, min_units: int, max_units: int) -> str:
    if not min_units or not max_units:
        return "no_target"
    if units < round(min_units * 0.9):
        return "short"
    if units > round(max_units * 1.15):
        return "long"
    return "ok"


def batch_quality_metrics(source: str, output: str, config: dict) -> dict:
    effective_config = config_with_source_duration(config, source)
    source_language = "" if config.get("source_language") == "auto" else config.get("source_language", "")
    target_language = effective_config.get("target_language", "Tiếng Việt")
    duration = effective_config.get("duration", "")
    source_units = voice_unit_count(source, source_language)
    output_units = voice_unit_count(output, target_language)
    min_units, max_units, profile = duration_unit_target(duration, target_language)
    return {
        "source_words": len(normalize_words(source)),
        "output_words": len(normalize_words(output)),
        "source_units": source_units,
        "output_units": output_units,
        "source_voice": estimated_voice_range_text(source_units, source_language, source),
        "output_voice": estimated_voice_range_text(output_units, target_language, output),
        "target_min_units": min_units,
        "target_max_units": max_units,
        "target_unit": profile.get("unit", "từ"),
        "duration_strategy": effective_config.get("duration_strategy", ""),
        "duration_goal": effective_config.get("duration_goal", ""),
        "length_status": batch_length_status(output_units, min_units, max_units),
    }


def batch_item_suggestions(report: dict, story_score: dict, metrics: dict) -> list[str]:
    suggestions: list[str] = []
    similarity = int(report.get("similarity_percent") or report.get("risk_score") or 0)
    risk = str(report.get("risk", "")).lower()
    story = int(story_score.get("score") or 0)
    if metrics.get("length_status") == "short":
        missing = max(int(metrics.get("target_min_units", 0)) - int(metrics.get("output_units", 0)), 0)
        suggestions.append(f"Đang thiếu thời lượng, nên dùng Nâng cấp draft và yêu cầu mở rộng thêm khoảng {format_int_vn(missing)} {metrics.get('target_unit', 'từ')}.")
    elif metrics.get("length_status") == "long":
        suggestions.append("Bản mới dài hơn mục tiêu, nên rút bớt cảnh lặp và giữ các đoạn cao trào chính.")
    if similarity >= 65 or risk == "high":
        suggestions.append("Độ giống còn cao, nên đổi mở bài, đảo trình tự sự kiện, thêm cảnh mới và viết lại đối thoại theo góc nhìn khác.")
    elif similarity >= 45:
        suggestions.append("Độ giống trung bình, nên thay thêm cách chuyển cảnh và cách kết luận để bản mới khác nguồn hơn.")
    if story < 45:
        suggestions.append("Story 40+ còn yếu, nên thêm cảm xúc gia đình, xung đột rõ, đoạn lắng lại và bài học cuối câu chuyện.")
    elif story < 70:
        suggestions.append("Có thể tăng Story 40+ bằng một cú twist giữa truyện và đoạn chiêm nghiệm cuối sâu hơn.")
    if not suggestions:
        suggestions.append("Chất lượng ổn để kiểm tra bản dịch, nghe thử voice và xuất file.")
    return suggestions[:4]


def format_batch_result_block(
    index: int,
    total: int,
    name: str,
    source: str,
    output: str,
    report: dict,
    story_score: dict,
    config: dict,
    *,
    process_label: str = "Gemini",
    exported: dict | None = None,
    source_label: str = "File",
    story_title: str = "",
    title_source: str = "",
) -> tuple[str, dict]:
    metrics = batch_quality_metrics(source, output, config)
    suggestions = batch_item_suggestions(report, story_score, metrics)
    source_language = "" if config.get("source_language") == "auto" else config.get("source_language", "")
    effective_config = config_with_source_duration(config, source)
    target_language = effective_config.get("target_language", "Tiếng Việt")
    source_meta = text_length_meta(source, source_language)
    output_meta = text_length_meta(output, target_language, effective_config.get("duration", ""), include_target=True)
    lines = [
        "",
        "=" * 78,
        f"[OK] {index}/{total} | {source_label}: {name}",
        f"Title: {story_title or 'N/A'}" + (f" | Title source: {title_source}" if title_source else ""),
        f"Mục tiêu: {metrics.get('duration_strategy')}",
        f"Nguồn: {format_int_vn(metrics['source_words'])} từ | voice ước tính {metrics['source_voice']} | {source_meta}",
        f"Bản mới: {format_int_vn(metrics['output_words'])} từ | voice ước tính {metrics['output_voice']} | {output_meta}",
        f"Story 40+: {story_score.get('score', 'N/A')}/100 | Độ giống: {str(report.get('risk', 'N/A')).upper()} {report.get('similarity_percent', 'N/A')}/100 | Xử lý: {process_label}",
        "Gợi ý nâng cấp:",
    ]
    lines.extend(f"  {idx}. {suggestion}" for idx, suggestion in enumerate(suggestions, 1))
    if exported and exported.get("txt"):
        lines.append(f"TXT: {exported.get('txt')}")
    lines.append("=" * 78)
    metrics["suggestions"] = suggestions
    return "\n".join(lines) + "\n", metrics


def format_batch_error_block(index: int, total: int, name: str, error: Exception | str, *, source_label: str = "File") -> str:
    return "\n".join(
        [
            "",
            "!" * 78,
            f"[LỖI] {index}/{total} | {source_label}: {name}",
            str(error),
            "Gợi ý: kiểm tra file/URL đầu vào, quota API, model đang dùng, rồi chạy lại riêng mục này nếu cần.",
            "!" * 78,
            "",
        ]
    )


def format_video_batch_result_block(index: int, total: int, video_name: str, transcript: str, config: dict, size_mb: float, exported: dict | None = None) -> tuple[str, dict]:
    target_language = config.get("target_language", "Tiếng Việt")
    units = voice_unit_count(transcript, target_language)
    words = len(normalize_words(transcript))
    voice_time = estimated_voice_range_text(units, target_language, transcript)
    suggestions: list[str] = []
    if words < 250:
        suggestions.append("Transcript khá ngắn, nên thử chế độ Chi tiết hơn nếu video dài hoặc có nhiều thoại.")
    if config.get("video_extract_mode", "").startswith("Nhanh") and words < 800:
        suggestions.append("Nếu cần đủ ý hơn, chuyển Chế độ trích video sang Cân bằng hoặc Chi tiết.")
    if not suggestions:
        suggestions.append("Transcript ổn để đưa vào Gemini viết lại hoặc kiểm tra bản dịch.")
    lines = [
        "",
        "=" * 78,
        f"[OK] {index}/{total} | Video: {video_name}",
        f"Dung lượng: {size_mb:.1f} MB | Transcript: {format_int_vn(words)} từ | voice ước tính {voice_time}",
        f"Chế độ trích: {config.get('video_extract_mode')} | Ngôn ngữ đầu ra: {target_language}",
        "Gợi ý:",
    ]
    lines.extend(f"  {idx}. {suggestion}" for idx, suggestion in enumerate(suggestions, 1))
    if exported and exported.get("txt"):
        lines.append(f"TXT: {exported.get('txt')}")
    lines.append("=" * 78)
    metrics = {"words": words, "voice_time": voice_time, "voice_units": units, "suggestions": suggestions}
    return "\n".join(lines) + "\n", metrics


def video_batch_summary_overview(summary: list[dict], output_dir: Path) -> str:
    ok_items = [item for item in summary if item.get("status") == "ok"]
    error_items = [item for item in summary if item.get("status") == "error"]
    avg_words = round(sum(int(item.get("words") or 0) for item in ok_items) / max(len(ok_items), 1)) if ok_items else 0
    short_items = [item for item in ok_items if int(item.get("words") or 0) < 250]
    lines = [
        "",
        "#" * 78,
        "TỔNG KẾT BATCH VIDEO",
        f"Output: {output_dir}",
        f"Thành công: {len(ok_items)} | Lỗi: {len(error_items)} | Tổng: {len(summary)}",
        f"Transcript trung bình: {format_int_vn(avg_words)} từ",
        f"Cần xem lại: {len(short_items)} transcript quá ngắn",
    ]
    if short_items:
        names = ", ".join(Path(item.get("file", "")).name[:35] for item in short_items[:5])
        lines.append(f"Ưu tiên trích lại chế độ Chi tiết: {names}")
    if error_items:
        names = ", ".join(Path(item.get("file", "")).name[:35] for item in error_items[:5])
        lines.append(f"Video lỗi cần chạy lại: {names}")
    lines.append("#" * 78)
    return "\n".join(lines) + "\n"


def batch_summary_overview(summary: list[dict], config: dict, output_dir: Path, title: str = "Tổng kết batch") -> str:
    ok_items = [item for item in summary if item.get("status") == "ok"]
    error_items = [item for item in summary if item.get("status") == "error"]
    high_similarity = [item for item in ok_items if int(item.get("similarity_percent") or 0) >= 65 or str(item.get("similarity_risk", "")).lower() == "high"]
    short_items = [item for item in ok_items if item.get("length_status") == "short"]
    avg_story = round(sum(int(item.get("story_score") or 0) for item in ok_items) / max(len(ok_items), 1), 1) if ok_items else 0
    avg_similarity = round(sum(int(item.get("similarity_percent") or 0) for item in ok_items) / max(len(ok_items), 1), 1) if ok_items else 0
    avg_words = round(sum(int(item.get("output_words") or item.get("words_output") or 0) for item in ok_items) / max(len(ok_items), 1)) if ok_items else 0
    lines = [
        "",
        "#" * 78,
        title.upper(),
        f"Output: {output_dir}",
        f"Thành công: {len(ok_items)} | Lỗi: {len(error_items)} | Tổng: {len(summary)}",
        f"Trung bình bản mới: {format_int_vn(avg_words)} từ | Story 40+ TB: {avg_story}/100 | Độ giống TB: {avg_similarity}/100",
        f"Cần xem lại: {len(high_similarity)} bản độ giống cao | {len(short_items)} bản thiếu thời lượng",
    ]
    if short_items:
        names = ", ".join(Path(item.get("file") or item.get("url") or "").name[:35] for item in short_items[:5])
        lines.append(f"Ưu tiên kéo dài: {names}")
    if high_similarity:
        names = ", ".join(Path(item.get("file") or item.get("url") or "").name[:35] for item in high_similarity[:5])
        lines.append(f"Ưu tiên viết khác hơn: {names}")
    titled_items = [str(item.get("story_title", "")).strip() for item in ok_items if str(item.get("story_title", "")).strip()]
    if titled_items:
        lines.append("Title mẫu: " + " | ".join(titled_items[:5]))
    if error_items:
        names = ", ".join(Path(item.get("file") or item.get("url") or "").name[:35] for item in error_items[:5])
        lines.append(f"Mục lỗi cần chạy lại: {names}")
    lines.append("#" * 78)
    return "\n".join(lines) + "\n"


def final_script_only_instruction(config: dict) -> str:
    min_units, max_units, profile = duration_unit_target(config.get("duration", ""), config.get("target_language", "Tiếng Việt"))
    low_minutes, high_minutes = duration_minutes_range(config.get("duration", ""))
    if min_units and max_units:
        long_form_rule = ""
        if high_minutes >= 30:
            long_form_rule = (
                f" Đây là kịch bản long-form {low_minutes:g}-{high_minutes:g} phút: phải triển khai thành nhiều lớp cảnh, "
                "nhiều đoạn đối thoại, nội tâm, quan hệ nhân vật, chi tiết đời thường, bước ngoặt giữa truyện và đoạn chiêm nghiệm. "
                "Không được tóm tắt cốt truyện thành bản 10-20 phút."
            )
        length_rule = (
            f"- Viết đủ dài để khi đọc voice đạt {config.get('duration_goal', config.get('duration'))}. "
            f"Mục tiêu thực tế: khoảng {format_int_vn(min_units)}-{format_int_vn(max_units)} {profile['unit']}. "
            f"Đây là yêu cầu bắt buộc: không kết thúc khi mới đạt một bản ngắn vài phút. "
            f"Bản mới phải dài hơn kịch bản gốc theo chiến lược: {config.get('duration_strategy', 'dài hơn nguồn')}. "
            f"Nếu nguồn quá ngắn, hãy mở rộng bằng chi tiết đời thường, nội tâm nhân vật, đối thoại, mâu thuẫn, bước ngoặt và đoạn chiêm nghiệm, nhưng không lan man."
            f"{long_form_rule}"
        )
    else:
        length_rule = "- Viết đủ dài theo thời lượng mục tiêu của dự án; nếu thời lượng không rõ, ưu tiên kịch bản hoàn chỉnh, không cụt ý."
    return f"""## Định dạng đầu ra bắt buộc
Chỉ trả về KỊCH BẢN HOÀN CHỈNH để đưa thẳng vào voice.
Không trả tiêu đề, không outline, không bảng, không bullet, không checklist, không self-check, không giải thích, không ghi chú B-roll, không timestamp.
Không dùng Markdown heading như #, ##.
Viết thành các đoạn văn hoàn chỉnh, liền mạch, tự nhiên như một bài kể chuyện đã hoàn thiện.
{length_rule}
"""


def review_translation_language_rules(language: str) -> str:
    key = language_profile_key(language)
    if key == "default" and "việt" in (language or "").lower():
        return (
            "- BẮT BUỘC trả 100% bằng tiếng Việt có dấu.\n"
            "- Dịch TOÀN BỘ nội dung sang tiếng Việt chuẩn, không bỏ sót đoạn nào, không tóm tắt.\n"
            "- Không được trả tiếng Hàn, Nhật, Trung, Anh hoặc ngôn ngữ nguồn, trừ tên riêng thật sự cần giữ.\n"
            "- Nếu gặp chữ Hàn/Nhật/Trung trong nguồn, phải chuyển nghĩa sang tiếng Việt, không giữ nguyên cụm câu nguồn.\n"
            "- Dùng cách xưng hô Việt tự nhiên theo quan hệ nhân vật: tôi, bà, ông, anh, chị, mẹ, cha, con, cô, chú...\n"
            "- Không dùng văn dịch máy từng chữ; câu phải có dấu tiếng Việt đầy đủ và đọc trôi chảy."
        )
    if key == "korean":
        return "- BẮT BUỘC trả bằng tiếng Hàn tự nhiên, không giữ nguyên ngôn ngữ nguồn trừ tên riêng."
    if key == "japanese":
        return "- BẮT BUỘC trả bằng tiếng Nhật tự nhiên, không giữ nguyên ngôn ngữ nguồn trừ tên riêng."
    if key == "chinese":
        return "- BẮT BUỘC trả bằng tiếng Trung tự nhiên, không giữ nguyên ngôn ngữ nguồn trừ tên riêng."
    return f"- BẮT BUỘC trả bằng {language}, không giữ nguyên ngôn ngữ nguồn trừ tên riêng."


def build_single_review_translation_prompt(text: str, language: str, label: str, strict_retry: bool = False) -> str:
    retry_rule = ""
    if strict_retry:
        retry_rule = (
            "\nLƯU Ý SỬA LỖI: Lần trước kết quả chưa đúng ngôn ngữ yêu cầu. "
            f"Lần này phải dịch lại toàn bộ sang {language}, không được trả lại ngôn ngữ nguồn. "
            "Nếu còn ký tự Hàn/Nhật/Trung không phải tên riêng, kết quả bị xem là sai.\n"
        )
    vietnamese_contract = ""
    if "việt" in (language or "").lower():
        vietnamese_contract = """
HỢP ĐỒNG ĐẦU RA TIẾNG VIỆT:
- Chỉ dùng tiếng Việt có dấu trong toàn bộ bản dịch.
- Không trả lời bằng tiếng Hàn, Nhật, Trung, Anh.
- Không để nguyên câu nguồn vì nghĩ người dùng hiểu được; người dùng cần bản tiếng Việt để kiểm tra.
- Tên riêng viết bằng chữ Nhật/Hàn/Trung phải chuyển sang dạng Latin/Việt hóa dễ đọc, không giữ nguyên ký tự Nhật/Hàn/Trung.
- Nếu đoạn nguồn đã là tiếng Việt không dấu hoặc tiếng Việt lẫn ngoại ngữ, hãy chuẩn hóa thành tiếng Việt có dấu.
"""
    return f"""Bạn là biên dịch viên kiểm tra nội dung kịch bản đa ngôn ngữ.
Hãy dịch phần "{label}" dưới đây sang {language} để người dùng kiểm tra ý nghĩa.

Yêu cầu:
- Ngôn ngữ đầu ra bắt buộc: {language}.
{review_translation_language_rules(language)}
- Dịch đủ từng ý theo đúng thứ tự câu chuyện, không rút gọn kịch bản dài thành bản tóm tắt.
- Dịch trung thành về ý, nhân vật, cảm xúc, sự kiện và quan hệ trong câu chuyện.
- Không viết lại hay nâng cấp nội dung.
- Không thêm phân tích, không thêm nhận xét, không tóm tắt.
- Giữ đoạn văn dễ đọc.
- Nếu có tên riêng, chỉ giữ nguyên khi tên đã ở dạng Latin; nếu tên đang ở chữ Nhật/Hàn/Trung thì chuyển sang dạng Latin/Việt hóa.
- Nếu một phần đã là {language}, hãy chuẩn hóa câu chữ nhẹ cho dễ đọc nhưng không đổi ý.
- Chỉ trả bản dịch, không dùng heading, không dùng markdown.
{vietnamese_contract}
{retry_rule}

## Nội dung cần dịch
```text
{text}
```"""


def build_review_translation_prompt(source: str, rewritten: str, language: str) -> str:
    return f"""Bạn là biên dịch viên kiểm tra nội dung kịch bản đa ngôn ngữ.
Hãy dịch 2 phần dưới đây sang {language} để người dùng kiểm tra ý nghĩa.

Yêu cầu:
- Dịch trung thành về ý, nhân vật, cảm xúc, sự kiện và quan hệ trong câu chuyện.
- Không viết lại hay nâng cấp nội dung.
- Không thêm phân tích, không thêm nhận xét, không tóm tắt.
- Giữ đoạn văn dễ đọc.
- Nếu có tên riêng, giữ nguyên tên riêng.
- Nếu một phần đã là {language}, hãy chuẩn hóa câu chữ nhẹ cho dễ đọc nhưng không đổi ý.

Đầu ra bắt buộc dùng đúng 2 header sau:
=== BẢN DỊCH KỊCH BẢN GỐC ===
[dịch kịch bản gốc]

=== BẢN DỊCH KỊCH BẢN ĐÃ VIẾT LẠI ===
[dịch kịch bản đã viết lại]

## Kịch bản gốc
```text
{source}
```

## Kịch bản đã viết lại
```text
{rewritten}
```"""


def split_review_translation(text: str) -> tuple[str, str]:
    source_marker = "=== BẢN DỊCH KỊCH BẢN GỐC ==="
    rewritten_marker = "=== BẢN DỊCH KỊCH BẢN ĐÃ VIẾT LẠI ==="
    if source_marker in text and rewritten_marker in text:
        source_part = text.split(source_marker, 1)[1].split(rewritten_marker, 1)[0].strip()
        rewritten_part = text.split(rewritten_marker, 1)[1].strip()
        return source_part, rewritten_part
    return text.strip(), ""


def translation_generation_settings(*texts: str) -> dict:
    total_units = sum(max(len(normalize_words(text)), voice_unit_count(text)) for text in texts)
    max_tokens = max(3000, min(16000, round(total_units * 2.4)))
    return {
        "temperature": 0.1,
        "topP": 0.75,
        "maxOutputTokens": max_tokens,
    }


def same_review_language(declared_language: str, review_language: str) -> bool:
    if not declared_language or declared_language == "auto":
        return False
    return declared_language.strip().lower() == review_language.strip().lower()


def text_already_in_review_language(text: str, declared_language: str, review_language: str) -> bool:
    return same_review_language(declared_language, review_language) and text_looks_like_language(text, review_language)


def valid_review_translation_text(text: str, language: str) -> bool:
    return bool((text or "").strip()) and not language_mismatch_warning(text, language)


def translation_average_minutes(text: str, language: str = "") -> float:
    units = voice_unit_count(text, language)
    profile = voice_profile(language, text)
    if not units:
        return 0.0
    return units / ((profile["min_rate"] + profile["max_rate"]) / 2)


def translation_coverage_warning(source: str, translated: str, source_language: str = "", target_language: str = "") -> str:
    source = (source or "").strip()
    translated = (translated or "").strip()
    if not source:
        return ""
    if not translated:
        return "bản dịch trống"
    source_units = voice_unit_count(source, source_language)
    translated_units = voice_unit_count(translated, target_language)
    source_minutes = translation_average_minutes(source, source_language)
    translated_minutes = translation_average_minutes(translated, target_language)
    if source_minutes >= 12 and translated_minutes < max(4.0, source_minutes * 0.45):
        return (
            f"bản dịch quá ngắn so với nguồn "
            f"({estimated_voice_range_text(translated_units, target_language, translated)} / "
            f"{estimated_voice_range_text(source_units, source_language, source)})"
        )
    if source_minutes >= 6 and translated_minutes < source_minutes * 0.32:
        return "bản dịch có dấu hiệu chỉ dịch đoạn đầu"
    if source_units >= 6000 and translated_units < 900:
        return "bản dịch thiếu phần lớn nội dung nguồn"
    if len(translated) < 600 and source_units >= 1800:
        return "bản dịch quá ngắn"
    return ""


def translation_chunk_unit_limit(source_language: str = "", text: str = "") -> int:
    key = language_profile_key(source_language, text)
    if key in {"japanese", "chinese", "korean"}:
        return 3200
    return 1800


def translation_should_use_segments(text: str, source_language: str = "") -> bool:
    units = voice_unit_count(text, source_language)
    key = language_profile_key(source_language, text)
    if key in {"japanese", "chinese", "korean"}:
        return units >= 8500
    return units >= 4200 or len(text or "") >= 22000


def split_text_for_translation(text: str, source_language: str = "", max_units: int | None = None) -> list[str]:
    clean = (text or "").strip()
    if not clean:
        return []
    max_units = max_units or translation_chunk_unit_limit(source_language, clean)
    sentences = [sentence.strip() for sentence in split_sentences(clean) if sentence.strip()]
    if not sentences:
        return [clean]
    chunks: list[str] = []
    current: list[str] = []
    current_units = 0
    for sentence in sentences:
        sentence_units = max(1, voice_unit_count(sentence, source_language))
        if sentence_units > max_units:
            if current:
                chunks.append("\n".join(current).strip())
                current = []
                current_units = 0
            start = 0
            step = max(1200, max_units)
            while start < len(sentence):
                chunks.append(sentence[start : start + step].strip())
                start += step
            continue
        if current and current_units + sentence_units > max_units:
            chunks.append("\n".join(current).strip())
            current = []
            current_units = 0
        current.append(sentence)
        current_units += sentence_units
    if current:
        chunks.append("\n".join(current).strip())
    return [chunk for chunk in chunks if chunk]


def build_segment_review_translation_prompt(
    text: str,
    language: str,
    label: str,
    index: int,
    total: int,
    strict_retry: bool = False,
) -> str:
    retry_rule = ""
    if strict_retry:
        retry_rule = f"\nLƯU Ý: Đây là lượt dịch lại vì bản trước bị thiếu hoặc sai ngôn ngữ. Bắt buộc dịch đầy đủ phần {index}/{total} sang {language}.\n"
    return f"""Bạn là biên dịch viên kiểm tra nội dung kịch bản dài.
Hãy dịch PHẦN {index}/{total} của "{label}" sang {language}.

Yêu cầu bắt buộc:
- Ngôn ngữ đầu ra: {language}.
{review_translation_language_rules(language)}
- Dịch đầy đủ 100% nội dung trong phần này, không bỏ sót câu nào.
- Không tóm tắt, không rút gọn, không viết lại, không nâng cấp nội dung.
- Không thêm tiêu đề "phần {index}", không markdown, không nhận xét.
- Giữ đúng thứ tự câu chuyện, nhân vật, quan hệ, cảm xúc và sự kiện.
- Nếu dịch sang Tiếng Việt, tên riêng viết bằng chữ Nhật/Hàn/Trung phải chuyển sang dạng Latin/Việt hóa, không giữ nguyên ký tự nguồn.
- Nếu có tên riêng dạng Latin, có thể giữ nguyên; các câu còn lại phải dịch sang {language}.
{retry_rule}

## Phần cần dịch
```text
{text}
```"""


def stream_translate_segmented_text(
    api_key,
    model: str,
    system_instruction: str,
    text: str,
    language: str,
    label: str,
    *,
    source_language: str = "",
    strict_retry: bool = False,
    chunk_callback=None,
    retry_callback=None,
    progress_callback=None,
    api_switch_callback=None,
    cancel_event=None,
) -> str:
    chunks = split_text_for_translation(text, source_language)
    if not chunks:
        return ""
    translated_parts: list[str] = []
    for index, chunk in enumerate(chunks, start=1):
        if cancel_event and cancel_event.is_set():
            raise RuntimeError("Đã hủy dịch kiểm tra.")
        if progress_callback:
            progress_callback(index, len(chunks))
        if chunk_callback and translated_parts:
            chunk_callback("\n\n")
        prompt = build_segment_review_translation_prompt(chunk, language, label, index, len(chunks), strict_retry=strict_retry)
        output = call_gemini_stream(
            api_key,
            model,
            system_instruction,
            prompt,
            translation_generation_settings(chunk),
            chunk_callback=chunk_callback,
            cancel_event=cancel_event,
            retry_callback=retry_callback,
            api_switch_callback=api_switch_callback,
        ).strip()
        translated_parts.append(output)
    return "\n\n".join(part.strip() for part in translated_parts if part.strip()).strip()


def stream_translate_whole_text(
    api_key,
    model: str,
    system_instruction: str,
    text: str,
    language: str,
    label: str,
    *,
    strict_retry: bool = False,
    chunk_callback=None,
    retry_callback=None,
    api_switch_callback=None,
    cancel_event=None,
) -> str:
    prompt = build_single_review_translation_prompt(text, language, label, strict_retry=strict_retry)
    return call_gemini_stream(
        api_key,
        model,
        system_instruction,
        prompt,
        translation_generation_settings(text),
        chunk_callback=chunk_callback,
        cancel_event=cancel_event,
        retry_callback=retry_callback,
        api_switch_callback=api_switch_callback,
    ).strip()


def compact_source_for_speed(source: str, config: dict) -> str:
    speed_mode = config.get("gemini_speed_mode", "")
    if not speed_mode.startswith("Siêu nhanh") or len(source) <= 26000:
        return source
    head = source[:10000].strip()
    middle_start = max((len(source) // 2) - 4000, 0)
    middle = source[middle_start : middle_start + 8000].strip()
    tail = source[-10000:].strip()
    return "\n\n".join(
        [
            head,
            "[...Đã rút gọn phần giữa để tăng tốc. Hãy giữ logic câu chuyện dựa trên mở đầu, bước ngoặt giữa và kết thúc...]",
            middle,
            "[...Tiếp phần kết của nguồn...]",
            tail,
        ]
    )


def gemini_generation_settings(config: dict, mode: str) -> dict:
    speed_mode = config.get("gemini_speed_mode", "Siêu nhanh - kịch bản kể chuyện")
    model = (config.get("gemini_model") or "").lower()
    if mode == "variants":
        base_tokens = 9000 if speed_mode.startswith("Siêu nhanh") else 12000
    elif mode == "series":
        base_tokens = 12000 if speed_mode.startswith("Siêu nhanh") else 18000
    else:
        base_tokens = 6500 if mode == "script_rewrite" else 5000
    _, target_max_units, profile = duration_unit_target(config.get("duration", ""), config.get("target_language", "Tiếng Việt"))
    if mode in {"script_rewrite", "generate", "improve"} and target_max_units:
        base_tokens = max(base_tokens, min(32000, round(target_max_units * profile["token_factor"])))
    if speed_mode.startswith("Siêu nhanh"):
        settings = {
            "temperature": 0.9,
            "topP": 0.9,
            "maxOutputTokens": base_tokens,
        }
        if "2.5" in model:
            settings["thinkingConfig"] = {"thinkingBudget": 0}
        elif "gemini-3" in model or "3." in model:
            settings["thinkingConfig"] = {"thinkingLevel": "minimal"}
        return settings
    if speed_mode.startswith("Nhanh"):
        settings = {
            "temperature": 0.95,
            "topP": 0.92,
            "maxOutputTokens": max(base_tokens, 9000),
        }
        if "2.5" in model:
            settings["thinkingConfig"] = {"thinkingBudget": 512}
        elif "gemini-3" in model or "3." in model:
            settings["thinkingConfig"] = {"thinkingLevel": "low"}
        return settings
    settings = {
        "temperature": 1,
        "topP": 0.95,
        "maxOutputTokens": max(base_tokens, 12000),
    }
    if "2.5" in model:
        settings["thinkingConfig"] = {"thinkingBudget": 1024}
    elif "gemini-3" in model or "3." in model:
        settings["thinkingConfig"] = {"thinkingLevel": "low"}
    return settings


def build_gemini_system_instruction(config: dict) -> str:
    story_focus = """
For this project, prioritize storytelling for viewers around age 40 and above when the config indicates that audience:
- mature, respectful, emotionally credible, and easy to follow;
- family, marriage, children, aging, dignity, regret, reconciliation, gratitude, and life lessons;
- avoid youth slang, noisy hype, and overly fast TikTok-style pacing;
- build empathy before drama and end with a clear human lesson.
""" if is_story_40plus_config(config) else ""
    return f"""You are a senior multilingual video script strategist, localization editor, and retention analyst.
You work with source videos/scripts from Chinese, Japanese, Korean, English US, English UK, German, French, and mixed-language transcripts.
Your job is not to translate word-by-word and not to imitate the original creator's protected expression.
Your job is to extract the high-level idea, viewer psychology, factual claims, and content promise, then create a stronger, original script in {config["target_language"]}.

Core rules:
- Detect the source language when it is set to auto.
- Localize cultural references, examples, humor, emotional framing, and CTA for the target audience.
- Keep only the topic, factual backbone, and useful logic. Replace hook, story path, examples, metaphors, transitions, punchlines, and CTA.
- Do not copy distinctive phrasing. Avoid any 7-word sequence from the source.
- Mark uncertain facts, dates, names, statistics, medical/legal/financial claims as [CẦN KIỂM CHỨNG].
- Improve retention with open loops, contrast, stakes, pattern interrupts, scene changes, and visual cues.
- Treat the user's training profile as the channel style guide, not as model fine-tuning.
{story_focus}
"""


def build_gemini_user_prompt(mode: str, source: str, draft: str, analysis: Analysis | None, config: dict) -> str:
    source = compact_source_for_speed(source, config)
    source_language = "tự nhận diện" if config["source_language"] == "auto" else config["source_language"]
    training = config["training_profile"] or "Chưa có training profile riêng. Hãy tự suy ra một phong cách rõ ràng, giữ chân người xem tốt."
    speed_mode = config.get("gemini_speed_mode", "Siêu nhanh - kịch bản kể chuyện")
    story_guidance = story_40plus_guidance() if is_story_40plus_config(config) else ""
    custom_ideas = (config.get("custom_story_ideas") or "").strip()
    custom_idea_block = (
        f"""
## Ý tưởng riêng / trend seed người dùng nhập
{custom_ideas}

Luật dùng ý tưởng riêng:
- Xem đây là kho nguyên liệu ưu tiên để tạo hook, bối cảnh, trope, xung đột, reveal, cao trào và CTA.
- Không chép nguyên văn ý tưởng; nâng cấp thành kịch bản mới hoàn chỉnh, giàu cảm xúc và khác nguồn.
- Nếu ý tưởng riêng mâu thuẫn với kịch bản nguồn, ưu tiên giữ insight/cảm xúc của ý tưởng riêng nhưng vẫn không bịa claim thật.
"""
        if custom_ideas
        else ""
    )
    min_units, max_units, length_profile = duration_unit_target(config.get("duration", ""), config.get("target_language", "Tiếng Việt"))
    low_minutes, high_minutes = duration_minutes_range(config.get("duration", ""))
    length_guard = ""
    if min_units and max_units:
        length_guard = (
            f"- Kiểm soát độ dài đầu ra: bản cuối cần đạt khoảng {format_int_vn(min_units)}-{format_int_vn(max_units)} "
            f"{length_profile['unit']}. Không trả bản ngắn dưới {format_int_vn(round(min_units * 0.9))} {length_profile['unit']}."
        )
        if high_minutes >= 30:
            length_guard += (
                f"\n- Mục tiêu {low_minutes:g}-{high_minutes:g} phút là LONG-FORM. "
                "Không viết bản tóm tắt 10-20 phút. Hãy mở rộng đầy đủ bằng cảnh nối tiếp, đối thoại, hồi tưởng, nội tâm, mâu thuẫn phụ, cao trào và kết đoạn có dư âm."
            )
    common = f"""## Cấu hình dự án
- Ngôn ngữ nguồn: {source_language}
- Ngôn ngữ đầu ra: {config["target_language"]}
- Nền tảng: {config["platform"]}
- Thời lượng mục tiêu: {config.get("duration_goal", config["duration"])}
- Chiến lược độ dài: {config.get("duration_strategy", "Bản mới phải dài hơn bản gốc, không viết ngắn hơn nguồn.")}
- Người xem: {config["audience"]}
- Tone: {config["tone"]}
- Niche: {config["niche"] or "tự suy ra từ nguồn"}
- CTA: {config["cta"] or "đề xuất CTA phù hợp"}
- Mức biến đổi mong muốn: {config["target_change"]}% về hook, cấu trúc, ví dụ, nhịp câu và cách triển khai.
- Chế độ tốc độ Gemini: {speed_mode}. Ưu tiên trả kết quả hữu ích nhanh, không viết phân tích lan man.
{length_guard}

## Training profile của kênh
{training}

{custom_idea_block}

{story_guidance}

## Phân tích heuristic từ tool
{analysis_brief(analysis)}

## Transcript/kịch bản video gốc
```text
{source}
```"""
    if mode == "audit":
        return f"""{common}

## Nhiệm vụ
Phân tích video gốc và tạo báo cáo chiến lược ngắn gọn bằng {config["target_language"]}.
Nếu ngôn ngữ đầu ra là Tiếng Việt, hãy viết tiếng Việt có dấu đầy đủ.

Các phần đầu ra:
1. Nhận diện ngôn ngữ và thị trường.
2. Vì sao bản gốc hiệu quả.
3. Điểm yếu hoặc phần đã cũ.
4. Cơ hội tăng retention.
5. 5 góc viết lại nguyên bản hơn.
6. 10 hook tốt hơn.
7. Ghi chú localize theo văn hóa.
8. Rủi ro: claim cần fact-check hoặc phần không nên sao chép."""
    if mode == "improve":
        output_format = final_script_only_instruction(config)
        return f"""{common}

## Bản nháp hiện tại cần nâng cấp
```text
{draft or "Chưa có bản nháp."}
```

## Nhiệm vụ
Viết lại và nâng cấp bản nháp thành một kịch bản mạnh hơn, nguyên bản hơn bằng {config["target_language"]}.
Nếu ngôn ngữ đầu ra là Tiếng Việt, hãy viết tiếng Việt có dấu đầy đủ.
Giảm độ giống với nguồn, tăng sức mạnh hook, thêm pattern interrupt, ghi chú visual và localize tự nhiên.
Nếu cần kéo dài đến đúng thời lượng voice, hãy mở rộng bằng cảnh đời thường, hồi tưởng, đối thoại, độc thoại nội tâm, xung đột, chi tiết cảm xúc và đoạn chiêm nghiệm.

{output_format}"""
    if mode == "variants":
        return f"""{common}

## Nhiệm vụ
Tạo 3 hướng viết lại khác nhau cho cùng một kịch bản kể chuyện, tối ưu cho người xem 40+ nếu cấu hình đang hướng tới nhóm này.
Nếu ngôn ngữ đầu ra là Tiếng Việt, hãy viết tiếng Việt có dấu đầy đủ.

Luật bắt buộc:
1. Không dịch sát câu, không paraphrase từng dòng.
2. Mỗi phiên bản phải có hook, cảm xúc và cách reveal khác nhau.
3. Giữ chủ đề/cảm xúc lõi, nhưng đổi mạnh cấu trúc và câu chữ khoảng {config["target_change"]}%.
4. Chấm điểm theo 5 tiêu chí: hook, đồng cảm 40+, mâu thuẫn, reveal, bài học cuối.
5. Sau khi chọn bản thắng, chỉ viết FULL SCRIPT cho bản thắng để tiết kiệm thời gian/token.

Đầu ra bắt buộc:
1. Bảng 3 phiên bản:
   - A: Cảm động nhân văn
   - B: Drama gia đình mạnh
   - C: Nhẹ nhàng chiêm nghiệm
   Với mỗi bản: tiêu đề, hook 3-5 câu, outline 6-8 beat, điểm /100, lý do điểm.
2. Chọn bản thắng và giải thích ngắn.
3. Kịch bản hoàn chỉnh của bản thắng, chia đoạn/timestamp gần đúng, có ghi chú visual ngắn.
4. CTA mềm hợp người xem 40+.
5. Self-check similarity: những cụm/cách kể nào cần tránh sao chép từ nguồn."""
    if mode == "series":
        return f"""{common}

## Nhiệm vụ
Biến kịch bản/ý tưởng gốc thành một SERIES YouTube nhiều tập bằng {config["target_language"]}.
Nếu ngôn ngữ đầu ra là Tiếng Việt, hãy viết tiếng Việt có dấu đầy đủ.

Mục tiêu:
1. Tạo concept series dài hạn dựa trên cảm xúc lõi, chủ đề và insight của nguồn, nhưng không sao chép tuyến kể/câu chữ.
2. Tối ưu cho người xem YouTube: title hấp dẫn, hook mạnh, cliffhanger cuối tập, nhân vật có động cơ rõ.
3. Nếu cấu hình đang hướng tới người xem 40+, ưu tiên gia đình, hôn nhân, con cái, tuổi trung niên, nhân quả, biết ơn, tha thứ, bài học cuộc đời.

Đầu ra bắt buộc:
1. Tên series dưới 100 ký tự.
2. Logline 2-3 câu.
3. Bộ nhân vật chính: tên, tuổi, bí mật, mong muốn, nỗi sợ.
4. Bảng 8 tập:
   - Tập số
   - Title YouTube hấp dẫn
   - Hook 3-5 câu
   - Xung đột chính
   - Reveal/twist
   - Cliffhanger cuối tập
5. Viết FULL SCRIPT cho TẬP 1, thành đoạn hoàn chỉnh, không bullet, không phân tích.
6. Gợi ý cách phát triển tập 2-3 thật ngắn.

Luật:
- Không paraphrase nguồn. Chỉ giữ cảm xúc lõi và bài học.
- Title phải đúng ngôn ngữ đầu ra, hấp dẫn nhưng không giật tít lừa.
- Mỗi tập phải có lý do để người xem muốn xem tập tiếp theo.
- Nếu kịch bản gốc rất dài, chỉ lấy lõi drama/nhân vật/bài học để mở thành series mới."""
    if mode == "script_rewrite":
        rewrite_mode = config.get("script_rewrite_mode", "Viết lại mạnh - đổi 70-80%")
        rewrite_guidance = rewrite_mode_guidance_text(rewrite_mode)
        rewrite_contract = rewrite_mode_contract(rewrite_mode)
        rewrite_dominance = rewrite_mode_dominance_rules(rewrite_mode, int(config.get("target_change", 78)))
        change_goal = "95-100%" if is_full_rewrite_mode(rewrite_mode) else f'{config["target_change"]}%'
        preserve_rule = (
            "Chỉ giữ chủ đề/cảm xúc lõi/bài học, còn nhân vật, bối cảnh, tuyến sự kiện, reveal, ví dụ, câu thoại và CTA phải mới hoàn toàn."
            if is_full_rewrite_mode(rewrite_mode)
            else "Giữ cảm xúc lõi nhưng đổi mạnh hook, cấu trúc, thứ tự reveal, ví dụ, chuyển cảnh, câu thoại và CTA."
        )
        output_format = final_script_only_instruction(config)
        if speed_mode.startswith("Siêu nhanh"):
            return f"""{common}

## Loại nguồn
Đây là kịch bản kể chuyện có sẵn. Người xem mục tiêu ưu tiên là nhóm 40+ nếu cấu hình người xem có nhắc tới 40+ hoặc trung niên.

## Chế độ viết lại
{rewrite_mode}

## Luật riêng của chế độ này
{rewrite_guidance}

{rewrite_contract}

{rewrite_dominance}

## Nhiệm vụ
Viết lại nhanh thành một kịch bản mới bằng {config["target_language"]}. {preserve_rule}
Nếu ngôn ngữ đầu ra là Tiếng Việt, hãy viết tiếng Việt có dấu đầy đủ.

Luật bắt buộc:
1. Không dịch sát câu, không paraphrase từng dòng.
2. Đổi khoảng {change_goal} ở hook, thứ tự reveal, ví dụ, chuyển cảnh, câu thoại và CTA.
3. Viết cho người xem 40+ nếu phù hợp: chân thật, từng trải, dễ hiểu, có bài học nhân sinh, tránh slang trẻ.
4. Mỗi đoạn phải kéo người xem sang đoạn sau bằng một câu mở vòng tò mò.
5. Tránh mọi cụm 7 từ liên tiếp giống nguồn. Claim chưa chắc thì ghi [CẦN KIỂM CHỨNG].
6. Nếu cần kéo dài đến đúng thời lượng voice, hãy mở rộng bằng cảnh đời thường, hồi tưởng, đối thoại, độc thoại nội tâm, xung đột gia đình, chi tiết cảm xúc và đoạn chiêm nghiệm.

{output_format}"""
        return f"""{common}

## Loại nguồn
Đây là kịch bản có sẵn do người dùng nhập/dán/tải từ file, có thể là transcript thô, phụ đề, bài kể chuyện, review, video nước ngoài hoặc text chưa có cấu trúc.

## Chế độ viết lại
{rewrite_mode}

## Luật riêng của chế độ này
{rewrite_guidance}

{rewrite_contract}

{rewrite_dominance}

## Nhiệm vụ
Đọc toàn bộ kịch bản nguồn, hiểu ý chính, cảm xúc, nhân vật, bối cảnh, logic nội dung và lời hứa với người xem. Sau đó viết lại thành một kịch bản mới hay hơn bằng {config["target_language"]}.
Nếu ngôn ngữ đầu ra là Tiếng Việt, hãy viết tiếng Việt có dấu đầy đủ.

Luật nâng cấp bắt buộc:
1. Không dịch sát câu, không paraphrase từng dòng, không giữ nhịp văn của bản gốc.
2. Biến đổi khoảng {change_goal}: hook, cấu trúc, thứ tự reveal, ví dụ, chuyển cảnh, CTA và cách diễn đạt.
3. Giữ lại phần cốt lõi hữu ích: chủ đề, insight, thông tin thật sự cần thiết và cảm xúc chính.
4. Thêm hook mạnh trong 3-7 giây đầu, open loop, stakes, pattern interrupt và payoff rõ.
5. Nếu nguồn là tiếng nước ngoài, localize tự nhiên cho thị trường/người xem đầu ra.
6. Nếu có tên riêng, số liệu, ngày tháng, tuyên bố y tế/tài chính/pháp lý, đánh dấu [CẦN KIỂM CHỨNG] khi không chắc.
7. Tránh mọi cụm 7 từ liên tiếp giống nguồn. Với tiếng Nhật/Trung/Hàn, tránh giữ nguyên cụm diễn đạt đặc trưng.
8. Nếu cần kéo dài đến đúng thời lượng voice, hãy mở rộng bằng cảnh đời thường, hồi tưởng, đối thoại, độc thoại nội tâm, xung đột gia đình, chi tiết cảm xúc và đoạn chiêm nghiệm.

{output_format}"""
    output_format = final_script_only_instruction(config)
    return f"""{common}

## Nhiệm vụ
Tạo một kịch bản mới, hay hơn bằng {config["target_language"]}, dựa trên ý tưởng cấp cao của video nguồn.
Nếu ngôn ngữ đầu ra là Tiếng Việt, hãy viết tiếng Việt có dấu đầy đủ.

Không dịch sát từng chữ. Không paraphrase từng câu.
Hãy làm phiên bản mới mạnh hơn bản gốc ở hook, cấu trúc câu chuyện, curiosity gap, độ rõ, localize văn hóa, mật độ visual, CTA và ví dụ nguyên bản.
Nếu cần kéo dài đến đúng thời lượng voice, hãy mở rộng bằng cảnh đời thường, hồi tưởng, đối thoại, độc thoại nội tâm, xung đột, chi tiết cảm xúc và đoạn chiêm nghiệm.

{output_format}"""


def gemini_response_text(data: dict) -> str:
    parts = data.get("candidates", [{}])[0].get("content", {}).get("parts", [])
    return "\n".join(part.get("text", "") for part in parts if part.get("text")).strip()


def gemini_response_parts(data: dict) -> list[dict]:
    return data.get("candidates", [{}])[0].get("content", {}).get("parts", []) or []


def image_extension_from_mime(mime_type: str) -> str:
    mime_type = (mime_type or "").lower()
    if "jpeg" in mime_type or "jpg" in mime_type:
        return ".jpg"
    if "webp" in mime_type:
        return ".webp"
    if "gif" in mime_type:
        return ".gif"
    return ".png"


def guess_chat_mime(path: Path) -> str:
    guessed, _ = mimetypes.guess_type(str(path))
    if guessed:
        return guessed
    if path.suffix.lower() in CHAT_TEXT_SUFFIXES:
        return "text/plain"
    return "application/octet-stream"


def is_chat_image_generation_request(text: str) -> bool:
    lowered = (text or "").lower()
    return any(
        marker in lowered
        for marker in [
            "tạo ảnh",
            "tao anh",
            "vẽ ảnh",
            "ve anh",
            "vẽ hình",
            "ve hinh",
            "thiết kế ảnh",
            "thiet ke anh",
            "generate image",
            "create image",
            "make an image",
            "draw",
            "poster",
            "thumbnail",
            "logo",
            "minh họa",
            "minh hoa",
            "sửa ảnh",
            "sua anh",
            "edit image",
        ]
    )


def gemini_cache_key(model: str, system_instruction: str, user_prompt: str, generation_config: dict, mode: str) -> str:
    payload = {
        "model": model.strip().removeprefix("models/"),
        "mode": mode,
        "system": system_instruction,
        "prompt": user_prompt,
        "generation_config": generation_config,
    }
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def parse_gemini_retry_delay(body: str) -> int:
    def walk(value):
        if isinstance(value, dict):
            if "retryDelay" in value:
                return value["retryDelay"]
            for child in value.values():
                found = walk(child)
                if found:
                    return found
        elif isinstance(value, list):
            for child in value:
                found = walk(child)
                if found:
                    return found
        return None

    retry_value = None
    try:
        retry_value = walk(json.loads(body))
    except json.JSONDecodeError:
        retry_value = None

    if retry_value:
        match = re.search(r"([\d.]+)s", str(retry_value))
        if match:
            return max(1, math.ceil(float(match.group(1))))
    match = re.search(r"retry\s+in\s+([\d.]+)s", body, re.IGNORECASE)
    if match:
        return max(1, math.ceil(float(match.group(1))))
    return GEMINI_RATE_LIMIT_FALLBACK_DELAY


def sleep_with_cancel(seconds: int, cancel_event=None) -> None:
    deadline = time.time() + seconds
    while time.time() < deadline:
        if cancel_event and cancel_event.is_set():
            raise RuntimeError("Đã hủy tác vụ Gemini.")
        time.sleep(min(0.5, max(0.0, deadline - time.time())))


def gemini_quota_message(label: str, body: str) -> str:
    return (
        f"{label} 429: Gemini đang giới hạn quota/rate limit của API key.\n\n"
        f"App đã tự chờ và thử lại {GEMINI_RATE_LIMIT_RETRIES} lần nhưng vẫn bị giới hạn. "
        "Hãy chờ vài phút rồi chạy lại, bật cache, tắt tự dịch kiểm tra nếu không cần, giảm batch, "
        "hoặc nâng quota/billing trong Google AI Studio.\n\n"
        f"Chi tiết Gemini: {body[:700]}"
    )


def gemini_unavailable_message(label: str, body: str) -> str:
    return (
        f"{label} 503: Gemini/model đang quá tải hoặc tạm thời không khả dụng.\n\n"
        "Tool đang dùng 1 API key duy nhất. Hãy thử lại sau vài phút, bật cache, giảm batch, "
        "đổi sang model nhẹ hơn hoặc thay API key khác nếu key hiện tại bị giới hạn.\n\n"
        f"Chi tiết Gemini: {body[:700]}"
    )


def parse_gemini_api_keys(value) -> list[str]:
    if callable(value):
        try:
            value = value()
        except Exception:
            value = ""
    if isinstance(value, (list, tuple)):
        raw_parts = [str(item) for item in value]
    else:
        raw_parts = re.split(r"[\s,;]+", str(value or ""))
    keys: list[str] = []
    seen: set[str] = set()
    for part in raw_parts:
        key = part.strip()
        if not key or key.startswith("#"):
            continue
        if len(key) < 20:
            continue
        if key not in seen:
            keys.append(key)
            seen.add(key)
    return keys


def gemini_api_key_text_value(value) -> str:
    if callable(value):
        try:
            return str(value() or "")
        except Exception:
            return ""
    return str(value or "")


def sleep_until_api_key_change_or_timeout(seconds: int, api_key_pool, previous_value: str, cancel_event=None) -> bool:
    deadline = time.time() + seconds
    previous_value = previous_value.strip()
    while time.time() < deadline:
        if cancel_event and cancel_event.is_set():
            raise RuntimeError("Đã hủy tác vụ Gemini.")
        if callable(api_key_pool) and gemini_api_key_text_value(api_key_pool).strip() != previous_value:
            return True
        time.sleep(min(0.5, max(0.0, deadline - time.time())))
    return False


def masked_api_key(key: str) -> str:
    key = key.strip()
    if len(key) <= 12:
        return "***"
    return f"{key[:6]}...{key[-4:]}"


def is_gemini_retryable_key_error(message: str) -> bool:
    lowered = message.lower()
    return any(
        marker in lowered
        for marker in [
            "429",
            "503",
            "resource_exhausted",
            "unavailable",
            "quota",
            "rate limit",
            "high demand",
            "temporarily",
            "quá tải",
            "không khả dụng",
            "giới hạn",
        ]
    )


def is_batch_circuit_breaker_error(error) -> bool:
    message = str(error)
    lowered = message.lower()
    return is_gemini_retryable_key_error(message) or any(
        marker in lowered
        for marker in [
            "tất cả api key",
            "all api",
            "chưa có gemini api key",
            "api key hợp lệ",
        ]
    )


def call_with_gemini_api_pool(
    api_key_pool,
    label: str,
    callback,
    *,
    api_switch_callback=None,
    retry_callback=None,
    cancel_event=None,
):
    live_key = callable(api_key_pool)
    if not parse_gemini_api_keys(api_key_pool):
        raise RuntimeError("Chưa có Gemini API key hợp lệ.")
    last_error: Exception | None = None
    retry_round = 0
    while True:
        keys = parse_gemini_api_keys(api_key_pool)
        if not keys:
            raise RuntimeError("Chưa có Gemini API key hợp lệ.")
        key_snapshot = gemini_api_key_text_value(api_key_pool)
        for index, key in enumerate(keys):
            try:
                return callback(key)
            except RuntimeError as exc:
                last_error = exc
                retryable = is_gemini_retryable_key_error(str(exc))
                if index < len(keys) - 1 and retryable:
                    next_key = keys[index + 1]
                    if api_switch_callback:
                        api_switch_callback(index + 2, len(keys), masked_api_key(next_key), str(exc))
                    continue
                if live_key and retryable and retry_round < GEMINI_RATE_LIMIT_RETRIES:
                    delay = min(GEMINI_RATE_LIMIT_MAX_DELAY, GEMINI_RATE_LIMIT_FALLBACK_DELAY + retry_round * 5)
                    if retry_callback:
                        retry_callback(delay, retry_round + 1, GEMINI_RATE_LIMIT_RETRIES)
                    sleep_until_api_key_change_or_timeout(delay, api_key_pool, key_snapshot, cancel_event)
                    retry_round += 1
                    break
                raise
        else:
            break
    raise RuntimeError(f"{label}: API key hiện tại bị lỗi. Lỗi cuối: {last_error}")


def open_gemini_request_with_retry(
    request: urllib.request.Request,
    *,
    timeout: int,
    label: str,
    cancel_event=None,
    retry_callback=None,
    fast_fail_on_limit: bool = False,
):
    last_body = ""
    for attempt in range(GEMINI_RATE_LIMIT_RETRIES + 1):
        if cancel_event and cancel_event.is_set():
            raise RuntimeError("Đã hủy tác vụ Gemini.")
        try:
            return TrackedHTTPResponse(urllib.request.urlopen(request, timeout=timeout))
        except urllib.error.HTTPError as exc:
            body = exc.read().decode("utf-8", errors="replace")
            last_body = body
            if exc.code == 429:
                if fast_fail_on_limit:
                    raise RuntimeError(gemini_quota_message(label, last_body)) from exc
                if attempt < GEMINI_RATE_LIMIT_RETRIES:
                    delay = min(GEMINI_RATE_LIMIT_MAX_DELAY, parse_gemini_retry_delay(body) + attempt * 5)
                    if retry_callback:
                        retry_callback(delay, attempt + 1, GEMINI_RATE_LIMIT_RETRIES)
                    sleep_with_cancel(delay, cancel_event)
                    continue
                raise RuntimeError(gemini_quota_message(label, last_body)) from exc
            if exc.code == 503:
                if fast_fail_on_limit:
                    raise RuntimeError(gemini_unavailable_message(label, last_body)) from exc
                if attempt < 1:
                    delay = 8
                    if retry_callback:
                        retry_callback(delay, attempt + 1, 1)
                    sleep_with_cancel(delay, cancel_event)
                    continue
                raise RuntimeError(gemini_unavailable_message(label, last_body)) from exc
            raise RuntimeError(f"{label} {exc.code}: {body[:900]}") from exc
        except urllib.error.URLError as exc:
            raise RuntimeError(f"Lỗi mạng Gemini: {exc}") from exc
    raise RuntimeError(gemini_quota_message(label, last_body))


def call_gemini(
    api_key: str,
    model: str,
    system_instruction: str,
    user_prompt: str,
    generation_config: dict | None = None,
    *,
    cancel_event=None,
    retry_callback=None,
    api_switch_callback=None,
) -> str:
    clean_model = model.strip().removeprefix("models/") or "gemini-3.1-flash-lite"
    fast_key_switch = callable(api_key) or len(parse_gemini_api_keys(api_key)) > 1
    config = {
        "temperature": 1,
        "topP": 0.95,
        "maxOutputTokens": 12000,
    }
    if generation_config:
        config.update(generation_config)
    payload = {
        "system_instruction": {"parts": [{"text": system_instruction}]},
        "contents": [{"role": "user", "parts": [{"text": user_prompt}]}],
        "generationConfig": config,
    }
    def request_once(key: str) -> dict:
        request = urllib.request.Request(
            GEMINI_ENDPOINT.format(model=clean_model),
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json", "x-goog-api-key": key.strip()},
            method="POST",
        )
        with open_gemini_request_with_retry(
            request,
            timeout=120,
            label="Gemini API",
            cancel_event=cancel_event,
            retry_callback=retry_callback,
            fast_fail_on_limit=fast_key_switch,
        ) as response:
            return json.loads(response.read().decode("utf-8"))

    data = call_with_gemini_api_pool(
        api_key,
        "Gemini API",
        request_once,
        api_switch_callback=api_switch_callback,
        retry_callback=retry_callback,
        cancel_event=cancel_event,
    )

    text = gemini_response_text(data)
    if text:
        return text
    reason = data.get("candidates", [{}])[0].get("finishReason") or data.get("promptFeedback", {}).get("blockReason")
    return f"Gemini không trả về text. Lý do: {reason or 'không rõ'}"


def chat_attachment_part(
    api_key: str,
    path: Path,
    *,
    cancel_event=None,
    progress_callback=None,
    api_switch_callback=None,
) -> dict:
    mime_type = guess_chat_mime(path)
    suffix = path.suffix.lower()
    size_mb = path.stat().st_size / (1024 * 1024)
    if suffix in CHAT_TEXT_SUFFIXES and size_mb <= 3:
        try:
            content = read_script_file(path)
        except Exception:
            content = path.read_text(encoding="utf-8", errors="replace")
        if len(content) > 60000:
            content = content[:30000] + "\n\n[...đã rút gọn file quá dài...]\n\n" + content[-30000:]
        return {
            "text": f"\n\n## File đính kèm: {path.name}\nLoại: {mime_type}\nNội dung:\n```text\n{content}\n```"
        }
    if mime_type.startswith(CHAT_UPLOAD_MIME_PREFIXES):
        if progress_callback:
            progress_callback(f"Đang upload file đính kèm: {path.name}")
        file_info = upload_file_to_gemini(
            api_key,
            path,
            mime_type,
            cancel_event=cancel_event,
            api_switch_callback=api_switch_callback,
        )
        return {
            "file_data": {
                "mime_type": file_info.get("mimeType") or file_info.get("mime_type") or mime_type,
                "file_uri": file_info["uri"],
            }
        }
    if size_mb <= 3:
        content = path.read_text(encoding="utf-8", errors="replace")
        if len(content) > 60000:
            content = content[:30000] + "\n\n[...đã rút gọn file quá dài...]\n\n" + content[-30000:]
        return {
            "text": f"\n\n## File đính kèm: {path.name}\nLoại: {mime_type}\nNội dung đọc dạng text:\n```text\n{content}\n```"
        }
    raise RuntimeError(f"File {path.name} chưa được hỗ trợ trong Chat AI hoặc quá lớn để đọc trực tiếp.")


def call_gemini_chat_multimodal(
    api_key: str,
    model: str,
    system_instruction: str,
    user_prompt: str,
    generation_config: dict | None = None,
    *,
    attachment_paths: list[Path] | None = None,
    output_dir: Path | None = None,
    image_mode: bool = False,
    cancel_event=None,
    retry_callback=None,
    progress_callback=None,
    api_switch_callback=None,
) -> tuple[str, list[Path], dict]:
    clean_model = model.strip().removeprefix("models/") or "gemini-3.1-flash-lite"
    fast_key_switch = callable(api_key) or len(parse_gemini_api_keys(api_key)) > 1
    config = {
        "temperature": 0.65,
        "topP": 0.9,
        "maxOutputTokens": 8000,
    }
    if generation_config:
        config.update(generation_config)
    if image_mode:
        config.setdefault("responseModalities", ["TEXT", "IMAGE"])

    parts: list[dict] = [{"text": user_prompt}]
    for path in attachment_paths or []:
        if cancel_event and cancel_event.is_set():
            raise RuntimeError("Đã hủy tác vụ Chat AI.")
        parts.append(
            chat_attachment_part(
                api_key,
                path,
                cancel_event=cancel_event,
                progress_callback=progress_callback,
                api_switch_callback=api_switch_callback,
            )
        )

    payload = {
        "system_instruction": {"parts": [{"text": system_instruction}]},
        "contents": [{"role": "user", "parts": parts}],
        "generationConfig": config,
    }

    def request_once(key: str) -> dict:
        request = urllib.request.Request(
            GEMINI_ENDPOINT.format(model=clean_model),
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json", "x-goog-api-key": key.strip()},
            method="POST",
        )
        with open_gemini_request_with_retry(
            request,
            timeout=240,
            label="Gemini multimodal chat API",
            cancel_event=cancel_event,
            retry_callback=retry_callback,
            fast_fail_on_limit=fast_key_switch,
        ) as response:
            return json.loads(response.read().decode("utf-8"))

    data = call_with_gemini_api_pool(
        api_key,
        "Gemini multimodal chat API",
        request_once,
        api_switch_callback=api_switch_callback,
        retry_callback=retry_callback,
        cancel_event=cancel_event,
    )
    output_dir = output_dir or (APP_DIR / "chat_images")
    output_dir.mkdir(parents=True, exist_ok=True)
    text_parts: list[str] = []
    image_paths: list[Path] = []
    for index, part in enumerate(gemini_response_parts(data), start=1):
        if part.get("text"):
            text_parts.append(part["text"])
            continue
        inline_data = part.get("inlineData") or part.get("inline_data")
        if inline_data and inline_data.get("data"):
            mime_type = inline_data.get("mimeType") or inline_data.get("mime_type") or "image/png"
            extension = image_extension_from_mime(mime_type)
            image_path = output_dir / f"chat_image_{time.strftime('%Y%m%d_%H%M%S')}_{index}{extension}"
            image_path.write_bytes(base64.b64decode(inline_data["data"]))
            image_paths.append(image_path)
    text = "\n".join(item.strip() for item in text_parts if item.strip()).strip()
    if not text and not image_paths:
        reason = data.get("candidates", [{}])[0].get("finishReason") or data.get("promptFeedback", {}).get("blockReason")
        text = f"Gemini không trả về text/ảnh. Lý do: {reason or 'không rõ'}"
    return text, image_paths, data


def call_gemini_stream(
    api_key: str,
    model: str,
    system_instruction: str,
    user_prompt: str,
    generation_config: dict | None = None,
    chunk_callback=None,
    cancel_event=None,
    retry_callback=None,
    api_switch_callback=None,
) -> str:
    clean_model = model.strip().removeprefix("models/") or "gemini-3.1-flash-lite"
    fast_key_switch = callable(api_key) or len(parse_gemini_api_keys(api_key)) > 1
    config = {
        "temperature": 1,
        "topP": 0.95,
        "maxOutputTokens": 12000,
    }
    if generation_config:
        config.update(generation_config)
    payload = {
        "system_instruction": {"parts": [{"text": system_instruction}]},
        "contents": [{"role": "user", "parts": [{"text": user_prompt}]}],
        "generationConfig": config,
    }
    def request_once(key: str) -> str:
        request = urllib.request.Request(
            GEMINI_STREAM_ENDPOINT.format(model=clean_model),
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json", "x-goog-api-key": key.strip()},
            method="POST",
        )
        chunks: list[str] = []

        def on_retry(delay: int, attempt: int, total: int) -> None:
            if retry_callback:
                retry_callback(delay, attempt, total)
            elif chunk_callback:
                chunk_callback(f"\n\n[Gemini bị giới hạn/quá tải, đợi {delay}s rồi thử lại {attempt}/{total}...]\n\n")

        with open_gemini_request_with_retry(
            request,
            timeout=300,
            label="Gemini stream API",
            cancel_event=cancel_event,
            retry_callback=on_retry,
            fast_fail_on_limit=fast_key_switch,
        ) as response:
            for raw_line in response:
                if cancel_event and cancel_event.is_set():
                    raise RuntimeError("Đã hủy tác vụ Gemini.")
                line = raw_line.decode("utf-8", errors="replace").strip()
                if not line.startswith("data:"):
                    continue
                payload_text = line[5:].strip()
                if not payload_text or payload_text == "[DONE]":
                    continue
                try:
                    data = json.loads(payload_text)
                except json.JSONDecodeError:
                    continue
                text = gemini_response_text(data)
                if not text:
                    continue
                chunks.append(text)
                if chunk_callback:
                    chunk_callback(text)
        return "".join(chunks).strip()

    return call_with_gemini_api_pool(
        api_key,
        "Gemini stream API",
        request_once,
        api_switch_callback=api_switch_callback,
        retry_callback=retry_callback,
        cancel_event=cancel_event,
    )


def call_gemini_url_context(
    api_key: str,
    model: str,
    system_instruction: str,
    user_prompt: str,
    generation_config: dict | None = None,
    *,
    cancel_event=None,
    retry_callback=None,
    api_switch_callback=None,
) -> tuple[str, dict]:
    clean_model = model.strip().removeprefix("models/") or "gemini-3.1-flash-lite"
    fast_key_switch = callable(api_key) or len(parse_gemini_api_keys(api_key)) > 1
    config = {
        "temperature": 0.3,
        "topP": 0.85,
        "maxOutputTokens": 10000,
    }
    if generation_config:
        config.update(generation_config)
    payload = {
        "system_instruction": {"parts": [{"text": system_instruction}]},
        "contents": [{"role": "user", "parts": [{"text": user_prompt}]}],
        "generationConfig": config,
        "tools": [{"url_context": {}}],
    }
    def request_once(key: str) -> dict:
        request = urllib.request.Request(
            GEMINI_ENDPOINT.format(model=clean_model),
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json", "x-goog-api-key": key.strip()},
            method="POST",
        )
        with open_gemini_request_with_retry(
            request,
            timeout=180,
            label="Gemini URL Context API",
            cancel_event=cancel_event,
            retry_callback=retry_callback,
            fast_fail_on_limit=fast_key_switch,
        ) as response:
            return json.loads(response.read().decode("utf-8"))

    data = call_with_gemini_api_pool(
        api_key,
        "Gemini URL Context API",
        request_once,
        api_switch_callback=api_switch_callback,
        retry_callback=retry_callback,
        cancel_event=cancel_event,
    )
    text = gemini_response_text(data)
    candidate = data.get("candidates", [{}])[0]
    metadata = candidate.get("urlContextMetadata") or candidate.get("url_context_metadata") or {}
    if text:
        return text, metadata
    reason = candidate.get("finishReason") or data.get("promptFeedback", {}).get("blockReason")
    return f"Gemini không trả về text từ URL. Lý do: {reason or 'không rõ'}", metadata


def duration_gap_info(output: str, config: dict) -> dict:
    target_language = config.get("target_language", "Tiếng Việt")
    min_units, max_units, profile = duration_unit_target(config.get("duration", ""), target_language)
    units = voice_unit_count(output, target_language)
    low_minutes, high_minutes = duration_minutes_range(config.get("duration", ""))
    if not min_units:
        ratio = 1.0
    else:
        ratio = units / max(min_units, 1)
    threshold = 0.88 if high_minutes >= 30 else 0.82
    return {
        "units": units,
        "min_units": min_units,
        "max_units": max_units,
        "unit_label": profile.get("unit", "từ"),
        "ratio": ratio,
        "low_minutes": low_minutes,
        "high_minutes": high_minutes,
        "needs_expansion": bool(min_units and units < round(min_units * threshold)),
    }


def build_duration_expansion_prompt(source: str, current_output: str, config: dict, gap: dict, pass_index: int) -> str:
    source = compact_source_for_speed(source, config)
    target_language = config.get("target_language", "Tiếng Việt")
    return f"""Bản kịch bản hiện tại chưa đạt thời lượng mục tiêu.

Mục tiêu người dùng đặt: {config.get('duration_goal', config.get('duration', ''))}
Độ dài hiện tại: {format_int_vn(gap['units'])} {gap['unit_label']}
Mục tiêu tối thiểu: {format_int_vn(gap['min_units'])} {gap['unit_label']}
Mục tiêu tối đa tham khảo: {format_int_vn(gap['max_units'])} {gap['unit_label']}
Lượt bù thời lượng: {pass_index}

Yêu cầu bắt buộc:
- Chỉ trả về KỊCH BẢN HOÀN CHỈNH đã được mở rộng, không giải thích, không checklist, không heading markdown.
- Giữ ngôn ngữ đầu ra: {target_language}.
- Không tóm tắt. Không kết thúc sớm ở bản 10-20 phút nếu mục tiêu là long-form.
- Giữ mạch chính của bản hiện tại, nhưng mở rộng bằng cảnh đời thường, đối thoại, hồi tưởng, nội tâm, quan hệ nhân vật, mâu thuẫn phụ, bước ngoặt và đoạn chiêm nghiệm.
- Nếu cần thêm độ dài, hãy triển khai sâu từng cảnh thay vì lặp lại cùng một ý.
- Bản cuối phải tiến gần mục tiêu tối thiểu {format_int_vn(gap['min_units'])} {gap['unit_label']}.

## Kịch bản gốc / nguồn tham khảo
```text
{source}
```

## Bản hiện tại cần bù thời lượng
```text
{current_output}
```"""


def build_duration_continuation_prompt(source: str, current_output: str, config: dict, gap: dict, part_index: int) -> str:
    source = compact_source_for_speed(source, config)
    target_language = config.get("target_language", "Tiếng Việt")
    current_tail = current_output[-14000:].strip()
    missing_units = max(0, int(gap.get("min_units", 0)) - int(gap.get("units", 0)))
    return f"""Bản kịch bản đã viết vẫn còn thiếu thời lượng. Hãy viết PHẦN NỐI THÊM để ghép tiếp vào cuối bản hiện tại.

Mục tiêu người dùng đặt: {config.get('duration_goal', config.get('duration', ''))}
Độ dài hiện tại: {format_int_vn(gap['units'])} {gap['unit_label']}
Còn thiếu tối thiểu khoảng: {format_int_vn(missing_units)} {gap['unit_label']}
Lượt nối thêm: {part_index}

Yêu cầu bắt buộc:
- Chỉ trả về nội dung kịch bản nối tiếp, không tiêu đề, không markdown, không giải thích.
- Giữ ngôn ngữ đầu ra: {target_language}.
- Không lặp lại các đoạn đã có, không mở đầu lại câu chuyện từ đầu.
- Tiếp tục tự nhiên sau đoạn cuối, đào sâu thêm cảnh đời thường, đối thoại, hồi tưởng, tâm lý nhân vật, mâu thuẫn phụ, chi tiết gia đình và bài học nhân sinh.
- Phù hợp người xem 40 tuổi trở lên: chậm vừa, cảm xúc, dễ theo dõi, có chiều sâu và dư âm.
- Nếu câu chuyện đã có kết, hãy mở rộng bằng hồi tưởng, hậu quả sau sự kiện, lời thú nhận, sự hòa giải hoặc đoạn chiêm nghiệm trước khi kết lại.

## Kịch bản gốc / nguồn tham khảo
```text
{source}
```

## Phần cuối của bản hiện tại để viết tiếp
```text
{current_tail}
```"""


def expand_script_to_duration_if_needed(
    api_key: str,
    config: dict,
    source: str,
    output: str,
    *,
    cancel_event=None,
    retry_callback=None,
    api_switch_callback=None,
    progress_callback=None,
) -> tuple[str, int]:
    if not output.strip():
        return output, 0
    low_minutes, high_minutes = duration_minutes_range(config.get("duration", ""))
    if high_minutes <= 0:
        return output, 0
    rewrite_passes = 2 if high_minutes >= 45 else 1
    expanded = output
    passes = 0
    for pass_index in range(1, rewrite_passes + 1):
        gap = duration_gap_info(expanded, config)
        if not gap.get("needs_expansion"):
            break
        if progress_callback:
            progress_callback(pass_index, gap)
        prompt = build_duration_expansion_prompt(source, expanded, config, gap, pass_index)
        generation_config = gemini_generation_settings(config, "script_rewrite")
        candidate = call_gemini(
            api_key,
            config["gemini_model"],
            build_gemini_system_instruction(config),
            prompt,
            generation_config,
            cancel_event=cancel_event,
            retry_callback=retry_callback,
            api_switch_callback=api_switch_callback,
        ).strip()
        if cancel_event and cancel_event.is_set():
            raise RuntimeError("Đã hủy tác vụ.")
        candidate_units = voice_unit_count(candidate, config.get("target_language", "Tiếng Việt"))
        current_units = voice_unit_count(expanded, config.get("target_language", "Tiếng Việt"))
        if candidate_units <= current_units:
            break
        expanded = candidate
        passes += 1

    append_passes = 4 if high_minutes >= 45 else (3 if high_minutes >= 25 else 1)
    for append_index in range(1, append_passes + 1):
        gap = duration_gap_info(expanded, config)
        if not gap.get("needs_expansion"):
            break
        if progress_callback:
            progress_callback(passes + 1, gap)
        prompt = build_duration_continuation_prompt(source, expanded, config, gap, append_index)
        generation_config = gemini_generation_settings(config, "script_rewrite")
        continuation = call_gemini(
            api_key,
            config["gemini_model"],
            build_gemini_system_instruction(config),
            prompt,
            generation_config,
            cancel_event=cancel_event,
            retry_callback=retry_callback,
            api_switch_callback=api_switch_callback,
        ).strip()
        if cancel_event and cancel_event.is_set():
            raise RuntimeError("Đã hủy tác vụ.")
        continuation_units = voice_unit_count(continuation, config.get("target_language", "Tiếng Việt"))
        if continuation_units < max(180, round(gap["min_units"] * 0.025)):
            break
        expanded = expanded.rstrip() + "\n\n" + continuation
        passes += 1
    return expanded, passes


def generate_gemini_cached(
    api_key: str,
    config: dict,
    source: str,
    mode: str,
    *,
    draft: str = "",
    cache_store: dict | None = None,
    use_cache: bool = True,
    cancel_event=None,
    retry_callback=None,
    api_switch_callback=None,
) -> tuple[str, Analysis, bool]:
    if cancel_event and cancel_event.is_set():
        raise RuntimeError("Đã hủy tác vụ.")
    analysis = analyze_script(source)
    effective_config = config_with_source_duration(config, source) if mode in {"script_rewrite", "generate", "improve"} else config
    if effective_config.get("test_mode_no_api"):
        return mock_gemini_output(mode, source, draft, effective_config), analysis, False
    system = build_gemini_system_instruction(effective_config)
    prompt = build_gemini_user_prompt(mode, source, draft, analysis, effective_config)
    generation_config = gemini_generation_settings(effective_config, mode)
    cache_key = gemini_cache_key(effective_config["gemini_model"], system, prompt, generation_config, mode)
    if use_cache and cache_store is not None:
        cached = cache_store.get(cache_key, {}).get("output", "")
        if cached and not duration_gap_info(cached, effective_config).get("needs_expansion"):
            return cached, analysis, True
    if effective_config.get("cache_only_mode"):
        raise RuntimeError("Đang bật 'Chỉ dùng cache, không gọi API mới' nhưng tác vụ này chưa có cache. Tắt chế độ này hoặc chạy thật một lần để tạo cache.")
    output = call_gemini(
        api_key,
        effective_config["gemini_model"],
        system,
        prompt,
        generation_config,
        cancel_event=cancel_event,
        retry_callback=retry_callback,
        api_switch_callback=api_switch_callback,
    )
    expansion_passes = 0
    if mode in {"script_rewrite", "generate", "improve"}:
        output, expansion_passes = expand_script_to_duration_if_needed(
            api_key,
            effective_config,
            source,
            output,
            cancel_event=cancel_event,
            retry_callback=retry_callback,
            api_switch_callback=api_switch_callback,
        )
    if cancel_event and cancel_event.is_set():
        raise RuntimeError("Đã hủy tác vụ.")
    if use_cache and cache_store is not None and output:
        cache_store[cache_key] = {
            "mode": mode,
            "model": effective_config["gemini_model"],
            "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "duration_expansion_passes": expansion_passes,
            "output": output,
        }
        save_gemini_cache_file(cache_store)
    return output, analysis, False


def guess_video_mime(path: Path) -> str:
    guessed, _ = mimetypes.guess_type(str(path))
    if guessed and guessed.startswith("video/"):
        return guessed
    return VIDEO_MIME_BY_SUFFIX.get(path.suffix.lower(), "video/mp4")


def upload_file_to_gemini(api_key: str, path: Path, mime_type: str, progress_callback=None, cancel_event=None, api_switch_callback=None) -> dict:
    size = path.stat().st_size
    fast_key_switch = callable(api_key) or len(parse_gemini_api_keys(api_key)) > 1
    metadata = {"file": {"display_name": path.name}}
    if progress_callback:
        progress_callback("start", 0, size, "Đang xin upload URL từ Gemini...")

    def upload_retry(delay: int, attempt: int, total: int) -> None:
        if progress_callback:
            progress_callback("retry", 0, size, f"Gemini giới hạn quota, đợi {delay}s rồi thử lại upload {attempt}/{total}...")

    def start_upload_once(key: str) -> str:
        start_request = urllib.request.Request(
            GEMINI_UPLOAD_ENDPOINT,
            data=json.dumps(metadata).encode("utf-8"),
            headers={
                "x-goog-api-key": key.strip(),
                "X-Goog-Upload-Protocol": "resumable",
                "X-Goog-Upload-Command": "start",
                "X-Goog-Upload-Header-Content-Length": str(size),
                "X-Goog-Upload-Header-Content-Type": mime_type,
                "Content-Type": "application/json",
            },
            method="POST",
        )
        with open_gemini_request_with_retry(
            start_request,
            timeout=120,
            label="Gemini upload API",
            cancel_event=cancel_event,
            retry_callback=upload_retry,
            fast_fail_on_limit=fast_key_switch,
        ) as response:
            return response.headers.get("x-goog-upload-url", "")

    upload_url = call_with_gemini_api_pool(
        api_key,
        "Gemini upload API",
        start_upload_once,
        api_switch_callback=api_switch_callback,
        retry_callback=upload_retry,
        cancel_event=cancel_event,
    )

    if not upload_url:
        raise RuntimeError("Gemini không trả về upload URL.")

    parsed = urllib.parse.urlparse(upload_url)
    target = parsed.path + (f"?{parsed.query}" if parsed.query else "")
    connection = http.client.HTTPSConnection(parsed.netloc, timeout=1800)
    headers = {
        "Content-Length": str(size),
        "X-Goog-Upload-Offset": "0",
        "X-Goog-Upload-Command": "upload, finalize",
    }
    sent = 0
    chunk_size = 1024 * 1024
    try:
        connection.putrequest("POST", target)
        for key, value in headers.items():
            connection.putheader(key, value)
        connection.endheaders()
        with path.open("rb") as file_handle:
            while True:
                if cancel_event and cancel_event.is_set():
                    raise RuntimeError("Đã hủy tác vụ upload video.")
                chunk = file_handle.read(chunk_size)
                if not chunk:
                    break
                connection.send(chunk)
                sent += len(chunk)
                if progress_callback:
                    progress_callback("upload", sent, size, f"Đang upload video: {sent / max(size, 1):.1%}")
        if progress_callback:
            progress_callback("finalize", size, size, "Upload xong, đang nhận file URI từ Gemini...")
        response = connection.getresponse()
        body = response.read().decode("utf-8", errors="replace")
    finally:
        try:
            connection.close()
        except Exception:
            pass

    if response.status >= 400:
        raise RuntimeError(f"Lỗi upload Gemini {response.status}: {body[:900]}")

    try:
        data = json.loads(body)
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"Gemini trả về upload response không hợp lệ: {body[:900]}") from exc

    file_info = data.get("file") or data
    if not file_info.get("uri"):
        raise RuntimeError(f"Upload xong nhưng không có file URI: {body[:900]}")
    return file_info


def call_gemini_with_file(
    api_key: str,
    model: str,
    file_uri: str,
    mime_type: str,
    prompt: str,
    *,
    max_output_tokens: int = 8000,
    media_resolution: str = "MEDIA_RESOLUTION_LOW",
    cancel_event=None,
    retry_callback=None,
    api_switch_callback=None,
) -> str:
    clean_model = model.strip().removeprefix("models/") or "gemini-3.1-flash-lite"
    fast_key_switch = callable(api_key) or len(parse_gemini_api_keys(api_key)) > 1
    is_youtube_input = not mime_type and is_youtube_url(file_uri)
    file_data = {"file_uri": file_uri}
    if mime_type:
        file_data["mime_type"] = mime_type
    parts = [{"file_data": file_data}, {"text": prompt}]
    if is_youtube_input:
        parts = [{"text": prompt}, {"file_data": file_data}]
    generation_config = {
        "temperature": 1,
        "topP": 0.95,
        "maxOutputTokens": max_output_tokens,
    }
    if media_resolution and not is_youtube_input:
        generation_config["mediaResolution"] = media_resolution
    payload = {
        "contents": [
            {
                "role": "user",
                "parts": parts,
            }
        ],
        "generationConfig": generation_config,
    }
    def request_once(key: str) -> dict:
        request = urllib.request.Request(
            GEMINI_ENDPOINT.format(model=clean_model),
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json", "x-goog-api-key": key.strip()},
            method="POST",
        )
        with open_gemini_request_with_retry(
            request,
            timeout=600,
            label="Gemini video API",
            cancel_event=cancel_event,
            retry_callback=retry_callback,
            fast_fail_on_limit=fast_key_switch,
        ) as response:
            return json.loads(response.read().decode("utf-8"))

    data = call_with_gemini_api_pool(
        api_key,
        "Gemini video API",
        request_once,
        api_switch_callback=api_switch_callback,
        retry_callback=retry_callback,
        cancel_event=cancel_event,
    )

    parts = data.get("candidates", [{}])[0].get("content", {}).get("parts", [])
    text = "\n".join(part.get("text", "") for part in parts if part.get("text")).strip()
    if text:
        return text
    reason = data.get("candidates", [{}])[0].get("finishReason") or data.get("promptFeedback", {}).get("blockReason")
    return f"Gemini không trả về text. Lý do: {reason or 'không rõ'}"


def video_extraction_settings(mode: str) -> dict:
    if mode.startswith("Nhanh"):
        return {
            "max_output_tokens": 6000,
            "media_resolution": "MEDIA_RESOLUTION_LOW",
            "prompt_level": "fast",
        }
    if mode.startswith("Chi tiết"):
        return {
            "max_output_tokens": 16000,
            "media_resolution": "MEDIA_RESOLUTION_MEDIUM",
            "prompt_level": "detailed",
        }
    return {
        "max_output_tokens": 10000,
        "media_resolution": "MEDIA_RESOLUTION_LOW",
        "prompt_level": "balanced",
    }


def build_video_script_prompt(config: dict) -> str:
    source_language = "tự nhận diện" if config["source_language"] == "auto" else config["source_language"]
    extraction_mode = config.get("video_extract_mode", "Nhanh - ưu tiên lời thoại")
    level = video_extraction_settings(extraction_mode)["prompt_level"]
    if level == "fast":
        return f"""Hãy trích kịch bản từ video này theo chế độ NHANH.

Yêu cầu:
- Ngôn ngữ nguồn: {source_language}.
- Ngôn ngữ đầu ra: {config["target_language"]}.
- Nếu đầu ra là Tiếng Việt, viết tiếng Việt có dấu đầy đủ.
- Ưu tiên lời thoại/audio. Không mô tả visual dài trừ khi có chữ quan trọng trên màn hình.
- Không cần timestamp quá dày; chỉ chia theo đoạn chính.
- Không tự bịa thông tin không có trong video.
- Nếu nghe không rõ, ghi [KHÔNG NGHE RÕ].

Đầu ra ngắn gọn:
1. Ngôn ngữ được nhận diện.
2. Transcript/kịch bản chính theo từng đoạn.
3. Hook, các luận điểm chính, CTA nếu có.
"""

    if level == "balanced":
        return f"""Hãy xem video này và trích xuất kịch bản ở chế độ CÂN BẰNG.

Yêu cầu:
- Ngôn ngữ nguồn: {source_language}.
- Ngôn ngữ đầu ra: {config["target_language"]}.
- Nếu đầu ra là Tiếng Việt, viết tiếng Việt có dấu đầy đủ.
- Ưu tiên lời thoại/audio, thêm visual/text on screen quan trọng.
- Chia timestamp theo các đoạn lớn, không cần từng câu.
- Không tự bịa thông tin không có trong video.
- Nếu có số liệu, tên riêng, ngày tháng, tuyên bố y tế/tài chính/pháp lý, đánh dấu [CẦN KIỂM CHỨNG] khi không chắc.

Đầu ra:
1. Ngôn ngữ/giọng thị trường được nhận diện.
2. Kịch bản/transcript theo đoạn:
   - Timestamp gần đúng
   - Lời thoại/nội dung nghe được
   - Visual/text on screen quan trọng nếu có
3. Tóm tắt cấu trúc video: Hook, setup, luận điểm chính, payoff/CTA.
4. Ghi chú ngắn để viết lại hay hơn.
"""

    return f"""Hãy xem video này và trích xuất kịch bản đầy đủ nhất có thể.

Yêu cầu:
- Ngôn ngữ nguồn: {source_language}.
- Ngôn ngữ đầu ra: {config["target_language"]}.
- Nếu đầu ra là Tiếng Việt, viết tiếng Việt có dấu đầy đủ.
- Ưu tiên lời thoại/audio. Nếu đoạn nào không nghe rõ, ghi [KHÔNG NGHE RÕ].
- Kết hợp cả thông tin visual quan trọng: chữ trên màn hình, hành động, bối cảnh, biểu cảm, chuyển cảnh.
- Không tự bịa thông tin không có trong video.
- Nếu có số liệu, tên riêng, ngày tháng, tuyên bố y tế/tài chính/pháp lý, đánh dấu [CẦN KIỂM CHỨNG] khi không chắc.
- Dùng timestamp theo dạng [MM:SS-MM:SS] nếu có thể.

Đầu ra bắt buộc:
1. Ngôn ngữ/giọng thị trường được nhận diện.
2. Kịch bản/tr transcript theo timestamp:
   - Timestamp
   - Lời thoại hoặc nội dung nghe được
   - Visual/text on screen quan trọng
3. Tóm tắt cấu trúc video:
   - Hook
   - Setup
   - Các luận điểm chính
   - Payoff/CTA
4. Ghi chú để viết lại hay hơn:
   - Phần mạnh
   - Phần yếu
   - Cơ hội nâng cấp retention
"""


def build_url_source_prompt(url: str, config: dict) -> str:
    source_language = "tự nhận diện" if config["source_language"] == "auto" else config["source_language"]
    return f"""Hãy dùng URL Context để đọc nguồn công khai sau và trích thành kịch bản/tư liệu nguồn sạch:
{url}

Yêu cầu:
- Ngôn ngữ nguồn: {source_language}.
- Ngôn ngữ đầu ra: {config["target_language"]}.
- Nếu đầu ra là Tiếng Việt, viết tiếng Việt có dấu đầy đủ.
- Ưu tiên nội dung chính, transcript, lời thoại, câu chuyện, nhân vật, sự kiện, mâu thuẫn, bài học và CTA nếu có.
- Loại bỏ menu, quảng cáo, điều hướng, footer, cookie banner, bình luận rác và nội dung thừa.
- Nếu URL là bài viết kể chuyện, chuyển thành kịch bản nguồn mạch lạc theo trình tự câu chuyện.
- Nếu URL là PDF/tài liệu, trích các phần liên quan để làm nguồn viết lại.
- Không tự bịa thông tin không có trong URL.
- Nếu có tên riêng, số liệu, ngày tháng, tuyên bố y tế/tài chính/pháp lý, đánh dấu [CẦN KIỂM CHỨNG] khi không chắc.

Đầu ra:
1. URL nguồn.
2. Ngôn ngữ/thị trường nhận diện.
3. Kịch bản/tư liệu nguồn đã trích theo đoạn rõ ràng.
4. Hook, nhân vật/sự kiện chính, payoff/CTA nếu có.
"""


def decode_text_bytes(data: bytes) -> str:
    if data.startswith((b"\xff\xfe", b"\xfe\xff")):
        return data.decode("utf-16")
    for encoding in TEXT_ENCODINGS:
        try:
            return data.decode(encoding)
        except UnicodeDecodeError:
            continue
    return data.decode("utf-8", errors="replace")


def collect_json_strings(value) -> list[str]:
    if isinstance(value, str):
        text = value.strip()
        return [text] if len(text) >= 12 else []
    if isinstance(value, list):
        items: list[str] = []
        for item in value:
            items.extend(collect_json_strings(item))
        return items
    if isinstance(value, dict):
        items: list[str] = []
        priority_keys = ["script", "transcript", "content", "text", "source", "draft", "gemini_output"]
        for key in priority_keys:
            if key in value:
                items.extend(collect_json_strings(value[key]))
        if items:
            return items
        for item in value.values():
            items.extend(collect_json_strings(item))
        return items
    return []


def read_docx_text(path: Path) -> str:
    try:
        with zipfile.ZipFile(path) as archive:
            document_xml = archive.read("word/document.xml")
    except Exception as exc:
        raise RuntimeError(f"Không đọc được file DOCX: {exc}") from exc

    root = ET.fromstring(document_xml)
    namespace = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
    paragraphs: list[str] = []
    for paragraph in root.iter(f"{namespace}p"):
        parts: list[str] = []
        for node in paragraph.iter():
            if node.tag == f"{namespace}t" and node.text:
                parts.append(node.text)
            elif node.tag == f"{namespace}tab":
                parts.append("\t")
            elif node.tag in {f"{namespace}br", f"{namespace}cr"}:
                parts.append("\n")
        line = "".join(parts).strip()
        if line:
            paragraphs.append(line)
    return "\n".join(paragraphs)


def read_script_file(path: Path) -> str:
    suffix = path.suffix.lower()
    if suffix == ".docx":
        return read_docx_text(path)
    raw_text = decode_text_bytes(path.read_bytes())
    if suffix == ".json":
        try:
            data = json.loads(raw_text)
            strings = collect_json_strings(data)
            if strings:
                return "\n\n".join(strings)
        except Exception:
            pass
    return raw_text


def clean_imported_script(text: str) -> str:
    text = text.replace("\ufeff", "").replace("\r\n", "\n").replace("\r", "\n")
    text = re.sub(r"<\d{1,2}:\d{2}(?::\d{2})?(?:[.,]\d{1,3})?>", "", text)
    cleaned_lines: list[str] = []
    previous = ""
    skip_note_block = False
    for raw_line in text.split("\n"):
        line = raw_line.strip()
        if not line:
            skip_note_block = False
            continue
        upper = line.upper()
        if upper == "WEBVTT":
            continue
        if upper.startswith(("NOTE", "STYLE", "REGION")):
            skip_note_block = True
            continue
        if skip_note_block:
            continue
        if re.fullmatch(r"\d+", line):
            continue
        if "-->" in line and re.search(r"\d{1,2}:\d{2}", line):
            continue
        line = re.sub(r"\{\\[^}]+\}", "", line)
        line = re.sub(r"<[^>]+>", "", line)
        line = re.sub(r"^\[?\d{1,2}:\d{2}(?::\d{2})?(?:[.,]\d{1,3})?\]?\s*[-–—:]?\s*", "", line)
        line = re.sub(r"\s+", " ", line).strip()
        if not line or line == previous:
            continue
        cleaned_lines.append(line)
        previous = line

    result = "\n".join(cleaned_lines)
    result = re.sub(r"\n{3,}", "\n\n", result).strip()
    return result


def load_json(path: Path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def save_json(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def prune_gemini_cache(cache: dict | None) -> tuple[dict, bool]:
    if not isinstance(cache, dict):
        return {}, False
    slim: dict[str, dict] = {}
    changed = False
    heavy_modes = {
        "script_rewrite",
        "generate",
        "improve",
        "url_context_rewrite",
        "url_youtube_rewrite",
        "review_translation_source_vi_only_v3",
        "review_translation_rewritten_vi_only_v3",
    }
    for key, item in cache.items():
        if not isinstance(item, dict):
            changed = True
            continue
        output = item.get("output", "")
        mode = str(item.get("mode", ""))
        if isinstance(output, str) and len(output) > GEMINI_CACHE_MAX_OUTPUT_CHARS and mode in heavy_modes:
            changed = True
            continue
        slim[key] = item
    if len(slim) > GEMINI_CACHE_MAX_ENTRIES:
        ordered = sorted(
            slim.items(),
            key=lambda pair: str(pair[1].get("created_at", "")),
            reverse=True,
        )
        slim = dict(ordered[:GEMINI_CACHE_MAX_ENTRIES])
        changed = True
    return slim, changed


def save_gemini_cache_file(cache: dict | None) -> None:
    slim, _changed = prune_gemini_cache(cache)
    if isinstance(cache, dict):
        cache.clear()
        cache.update(slim)
    save_json(GEMINI_CACHE_FILE, slim)


def safe_filename(name: str, fallback: str = "output") -> str:
    cleaned = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", name).strip(" .")
    return cleaned[:120] or fallback


def iter_script_files(folder: Path) -> list[Path]:
    suffixes = {".txt", ".md", ".srt", ".vtt", ".docx", ".json", ".csv"}
    files = [path for path in folder.rglob("*") if path.is_file() and path.suffix.lower() in suffixes]
    return sorted(files, key=lambda item: str(item).lower())


def iter_video_files(folder: Path) -> list[Path]:
    suffixes = set(VIDEO_MIME_BY_SUFFIX)
    files = [path for path in folder.rglob("*") if path.is_file() and path.suffix.lower() in suffixes]
    return sorted(files, key=lambda item: str(item).lower())


def extract_urls(text: str) -> list[str]:
    seen: set[str] = set()
    urls: list[str] = []
    for match in URL_RE.findall(text):
        url = match.rstrip(".,;:!?")
        if url not in seen:
            seen.add(url)
            urls.append(url)
    return urls


def is_youtube_url(url: str) -> bool:
    host = urllib.parse.urlparse(url).netloc.lower()
    return host in {"youtu.be", "www.youtu.be"} or host.endswith("youtube.com") or host.endswith("youtube-nocookie.com")


def youtube_video_id(url: str) -> str:
    parsed = urllib.parse.urlparse(url)
    host = parsed.netloc.lower()
    if host in {"youtu.be", "www.youtu.be"}:
        return parsed.path.strip("/").split("/")[0]
    query_id = urllib.parse.parse_qs(parsed.query).get("v", [""])[0]
    if query_id:
        return query_id
    parts = [part for part in parsed.path.split("/") if part]
    for marker in ("shorts", "embed", "live", "v"):
        if marker in parts:
            index = parts.index(marker)
            if index + 1 < len(parts):
                return parts[index + 1]
    return ""


def is_valid_youtube_video_id(video_id: str) -> bool:
    return bool(re.fullmatch(r"[A-Za-z0-9_-]{11}", (video_id or "").strip()))


def canonical_youtube_url(url: str) -> str:
    video_id = youtube_video_id(url)
    if not is_valid_youtube_video_id(video_id):
        return url
    return f"https://www.youtube.com/watch?v={video_id}"


def is_direct_media_url(url: str) -> bool:
    suffix = Path(urllib.parse.urlparse(url).path).suffix.lower()
    audio_suffixes = {".mp3", ".wav", ".m4a", ".aac", ".ogg", ".flac", ".wma"}
    return suffix in set(VIDEO_MIME_BY_SUFFIX) or suffix in audio_suffixes


def url_base_name(url: str, fallback: str = "url") -> str:
    parsed = urllib.parse.urlparse(url)
    host = parsed.netloc.lower().removeprefix("www.")
    if is_youtube_url(url):
        video_id = youtube_video_id(url)
        return safe_filename(f"{host}_{video_id or fallback}", fallback)
    path = parsed.path.strip("/").replace("/", "_")
    if not path:
        path = fallback
    return safe_filename(f"{host}_{path}", fallback)


def write_docx_text(path: Path, title: str, body: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    paragraphs = [title, *body.splitlines()]

    def paragraph_xml(text: str) -> str:
        if not text.strip():
            return "<w:p/>"
        return f"<w:p><w:r><w:t xml:space=\"preserve\">{xml_escape(text)}</w:t></w:r></w:p>"

    document = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
        f"<w:body>{''.join(paragraph_xml(item) for item in paragraphs)}"
        '<w:sectPr><w:pgSz w:w="12240" w:h="15840"/><w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440"/></w:sectPr>'
        "</w:body></w:document>"
    )
    content_types = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
</Types>"""
    rels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>"""
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("[Content_Types].xml", content_types)
        archive.writestr("_rels/.rels", rels)
        archive.writestr("word/document.xml", document)


def export_script_bundle(output_dir: Path, base_name: str, source: str, output: str, report: dict | None = None, story_score: dict | None = None) -> dict:
    output_dir.mkdir(parents=True, exist_ok=True)
    safe_base = safe_filename(base_name)
    txt_path = output_dir / f"{safe_base}.txt"
    md_path = output_dir / f"{safe_base}.md"
    docx_path = output_dir / f"{safe_base}.docx"
    meta_path = output_dir / f"{safe_base}.json"
    txt_path.write_text(output, encoding="utf-8")
    md = "\n\n".join(
        [
            f"# {base_name}",
            "## Kịch bản đã viết lại",
            output,
            "## Story Score 40+",
            json.dumps(story_score or {}, ensure_ascii=False, indent=2),
            "## Similarity",
            json.dumps(report or {}, ensure_ascii=False, indent=2),
        ]
    )
    md_path.write_text(md, encoding="utf-8")
    write_docx_text(docx_path, base_name, output)
    meta_path.write_text(
        json.dumps(
            {
                "name": base_name,
                "source_chars": len(source),
                "output_chars": len(output),
                "story_score": story_score or {},
                "similarity": report or {},
                "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )
    return {"txt": str(txt_path), "md": str(md_path), "docx": str(docx_path), "json": str(meta_path)}


def export_batch_script_bundle(
    output_dir: Path,
    index: int,
    original_path: Path,
    story_title: str,
    source: str,
    output: str,
    report: dict | None = None,
    story_score: dict | None = None,
) -> dict:
    title = clean_youtube_title(story_title) or clean_youtube_title(original_path.stem) or f"batch_{index:02d}"
    base_name = f"{index:02d}_{title}"
    exported = export_script_bundle(output_dir, base_name, source, output, report, story_score)
    meta_path_text = exported.get("json", "")
    if meta_path_text:
        meta_path = Path(meta_path_text)
        if meta_path.exists():
            try:
                data = json.loads(meta_path.read_text(encoding="utf-8"))
            except Exception:
                data = {}
            data.update(
                {
                    "name": title,
                    "story_title": title,
                    "original_file": str(original_path),
                    "batch_index": index,
                    "export_base": base_name,
                }
            )
            meta_path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    return exported


def export_video_transcript_bundle(output_dir: Path, index: int, video_path: Path, transcript: str, config: dict, file_info: dict | None = None) -> dict:
    output_dir.mkdir(parents=True, exist_ok=True)
    safe_base = safe_filename(f"{index:02d}_{video_path.stem}_transcript")
    txt_path = output_dir / f"{safe_base}.txt"
    md_path = output_dir / f"{safe_base}.md"
    docx_path = output_dir / f"{safe_base}.docx"
    meta_path = output_dir / f"{safe_base}.json"
    txt_path.write_text(transcript, encoding="utf-8")
    md = "\n\n".join(
        [
            f"# Transcript - {video_path.name}",
            "## Nguồn video",
            str(video_path),
            "## Kịch bản/transcript trích từ video",
            transcript,
        ]
    )
    md_path.write_text(md, encoding="utf-8")
    write_docx_text(docx_path, f"Transcript - {video_path.name}", transcript)
    meta_path.write_text(
        json.dumps(
            {
                "video": str(video_path),
                "video_name": video_path.name,
                "video_size_bytes": video_path.stat().st_size if video_path.exists() else None,
                "transcript_chars": len(transcript),
                "transcript_words": len(normalize_words(transcript)),
                "model": config.get("gemini_model"),
                "video_extract_mode": config.get("video_extract_mode"),
                "target_language": config.get("target_language"),
                "file_uri": (file_info or {}).get("uri"),
                "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )
    return {"txt": str(txt_path), "md": str(md_path), "docx": str(docx_path), "json": str(meta_path)}


def export_url_rewrite_bundle(
    output_dir: Path,
    index: int,
    url: str,
    source: str,
    output: str,
    report: dict | None,
    story_score: dict | None,
    metadata: dict | None = None,
) -> dict:
    output_dir.mkdir(parents=True, exist_ok=True)
    base = safe_filename(f"{index:02d}_{url_base_name(url)}")
    source_txt = output_dir / f"{base}_source.txt"
    source_md = output_dir / f"{base}_source.md"
    source_txt.write_text(source, encoding="utf-8")
    source_md.write_text("\n\n".join([f"# URL Source - {url}", "## Nội dung đã trích", source]), encoding="utf-8")
    rewritten = export_script_bundle(output_dir, f"{base}_rewritten", source, output, report, story_score)
    meta_path = output_dir / f"{base}_url_meta.json"
    meta_path.write_text(
        json.dumps(
            {
                "url": url,
                "source_chars": len(source),
                "source_words": len(normalize_words(source)),
                "output_chars": len(output),
                "output_words": len(normalize_words(output)),
                "similarity": report or {},
                "story_score": story_score or {},
                "metadata": metadata or {},
                "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )
    return {"source_txt": str(source_txt), "source_md": str(source_md), **rewritten, "url_meta": str(meta_path)}


def story_score_40plus(text: str) -> dict:
    checks = [
        ("hook đời thường có nút thắt", bool(re.search(r"nhưng|không ngờ|cho đến khi|ngày hôm đó|một lá thư|cuộc gọi|di chúc|bí mật", text, re.I))),
        ("nhân vật dễ đồng cảm", bool(re.search(r"mẹ|cha|ba|bố|bà|ông|vợ|chồng|con|người phụ nữ|người đàn ông|người mẹ", text, re.I))),
        ("mâu thuẫn gia đình/đời sống", bool(re.search(r"gia đình|hôn nhân|con cái|hàng xóm|tài sản|bệnh|tuổi già|cô đơn|tha thứ|ân nghĩa", text, re.I))),
        ("bước ngoặt/reveal rõ", bool(re.search(r"sự thật|bí mật|lá thư|cuộc gọi|di chúc|bệnh án|trở về|lời xin lỗi|cuối cùng", text, re.I))),
        ("bài học nhân sinh", bool(re.search(r"bài học|nhân quả|tình người|biết ơn|tha thứ|tử tế|trân trọng|đừng đợi", text, re.I))),
        ("CTA mềm", bool(re.search(r"bình luận|chia sẻ|trải nghiệm|bạn nghĩ|nhớ đến ai|quan điểm", text, re.I))),
        ("câu dễ nghe", bool(text and (len(normalize_words(text)) / max(len(split_sentences(text)), 1)) <= 30)),
    ]
    passed = sum(1 for _, ok in checks if ok)
    return {
        "score": round(passed / len(checks) * 100),
        "passed": passed,
        "total": len(checks),
        "checks": [{"label": label, "ok": ok} for label, ok in checks],
    }


def story_score_markdown(score: dict) -> str:
    lines = [
        f"# Story Engine 40+ - {score.get('score', 0)}/100",
        "",
        f"Đạt {score.get('passed', 0)}/{score.get('total', 0)} tiêu chí.",
        "",
        "## Checklist",
    ]
    for item in score.get("checks", []):
        lines.append(f"- [{'x' if item.get('ok') else ' '}] {item.get('label')}")
    lines.extend(
        [
            "",
            "## Cách nâng điểm nhanh",
            "- Thêm một chi tiết đời thường người 40+ dễ nhận ra: bữa cơm, căn nhà cũ, lá thư, cuộc gọi, bệnh án, di chúc.",
            "- Tăng đồng cảm trước khi đẩy drama.",
            "- Reveal nên đến từ một sự thật bị giấu hoặc một lựa chọn muộn màng.",
            "- Kết bằng bài học nhân sinh rõ, không giảng đạo dài.",
            "- CTA mềm: hỏi trải nghiệm hoặc quan điểm sống của người xem.",
        ]
    )
    return "\n".join(lines)


def serialize_analysis(analysis: Analysis | None):
    return asdict(analysis) if analysis else None


def deserialize_analysis(data) -> Analysis | None:
    if not data:
        return None
    beats = [Beat(**beat) for beat in data.get("beats", [])]
    return Analysis(
        word_count=data.get("word_count", 0),
        estimated_minutes=data.get("estimated_minutes", 0.0),
        sentence_count=data.get("sentence_count", 0),
        top_keywords=data.get("top_keywords", []),
        opening=data.get("opening", []),
        closing=data.get("closing", []),
        beats=beats,
    )


class NeonScriptStudio(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title(APP_NAME)
        self._set_window_icon()
        self.geometry("1440x900")
        self.minsize(1120, 760)
        self.configure(bg="#07040d")

        self.analysis: Analysis | None = None
        self.report: dict | None = None
        self.current_project_id: str | None = None
        self.cancel_event: threading.Event | None = None
        self.active_task_started_at: float | None = None
        self.progress_timer_id: str | None = None
        self.settings_save_after_id: str | None = None
        self.runtime_api_key_lock = threading.Lock()
        self.runtime_api_key_value = ""
        self.task_lock = threading.Lock()
        self.task_serial = 0
        self.title_task_serial = 0
        self.cancelled_task_serials: set[int] = set()
        self.translation_signature: str | None = None
        self.pending_summary_select_tab = False
        self.pending_auto_translate_after_summary = False
        self.url_batch_results: list[dict] = []
        self.batch_results: list[dict] = []
        self.batch_output_dir: Path | None = None
        self.chat_messages: list[dict] = []
        self.chat_attachments: list[Path] = []
        self.chat_image_refs: list[tk.PhotoImage] = []
        self.upload_cache: dict[str, dict] = {}
        self.gemini_cache, cache_pruned = prune_gemini_cache(load_json(GEMINI_CACHE_FILE, {}))
        if cache_pruned:
            try:
                save_gemini_cache_file(self.gemini_cache)
            except Exception:
                pass
        self.projects: list[dict] = load_json(PROJECTS_FILE, [])
        self.training_profiles: list[dict] = load_json(TRAINING_PROFILES_FILE, [])
        self.settings: dict = load_json(SETTINGS_FILE, {})

        self.vars: dict[str, tk.StringVar | tk.IntVar | tk.BooleanVar] = {}
        self.action_buttons: list[ttk.Button] = []
        self._build_vars()
        self._build_style()
        self._build_ui()
        self._load_settings()
        self._bind_meta_traces()
        self._sync_runtime_api_key()
        self._render_projects()
        self._render_training_profiles()
        self._render_all()
        self.after(800, self.enable_windows_file_drop)
        self.protocol("WM_DELETE_WINDOW", self.on_close)

    def _set_window_icon(self) -> None:
        ico_path = resource_path("assets", "neon_script_studio.ico")
        png_path = resource_path("assets", "neon_script_studio.png")
        try:
            if png_path.exists():
                self.app_icon_photo = tk.PhotoImage(file=str(png_path))
                self.iconphoto(True, self.app_icon_photo)
        except tk.TclError:
            pass
        try:
            if ico_path.exists():
                self.iconbitmap(str(ico_path))
                self.iconbitmap(default=str(ico_path))
        except tk.TclError:
            pass

    def _build_vars(self) -> None:
        self.vars["project_name"] = tk.StringVar(value="Dự án kể chuyện 40+")
        self.vars["story_title"] = tk.StringVar(value="")
        self.vars["auto_title_with_gemini"] = tk.BooleanVar(value=False)
        self.vars["selected_preset"] = tk.StringVar(value="Storytelling 40+")
        self.vars["platform"] = tk.StringVar(value="YouTube")
        self.vars["duration"] = tk.StringVar(value="8-12 phút")
        self.vars["audience"] = tk.StringVar(value="Nam nữ 40-65 tuổi, thích câu chuyện đời thường, gia đình, hôn nhân, con cái, nhân quả và bài học nhân sinh")
        self.vars["tone"] = tk.StringVar(value="Ấm áp, chậm vừa, chân thật, giàu cảm xúc, có cao trào và kết để lại dư âm")
        self.vars["niche"] = tk.StringVar(value="Kể chuyện đời sống / gia đình / tuổi trung niên / tình người / bài học nhân sinh")
        self.vars["cta"] = tk.StringVar(value="Nếu câu chuyện này làm bạn nhớ đến ai, hãy để lại một lời bình luận hoặc chia sẻ trải nghiệm của bạn.")
        self.vars["target_change"] = tk.IntVar(value=78)
        self.vars["gemini_api_key"] = tk.StringVar()
        self.vars["remember_key"] = tk.BooleanVar(value=False)
        self.vars["use_streaming"] = tk.BooleanVar(value=True)
        self.vars["use_cache"] = tk.BooleanVar(value=True)
        self.vars["cache_only_mode"] = tk.BooleanVar(value=False)
        self.vars["test_mode_no_api"] = tk.BooleanVar(value=False)
        self.vars["auto_translate_after_rewrite"] = tk.BooleanVar(value=False)
        self.vars["use_training_profile"] = tk.BooleanVar(value=True)
        self.vars["gemini_model"] = tk.StringVar(value="gemini-3.1-flash-lite")
        self.vars["source_language"] = tk.StringVar(value="auto")
        self.vars["target_language"] = tk.StringVar(value="Tiếng Việt")
        self.vars["review_translation_language"] = tk.StringVar(value="Tiếng Việt")
        self.vars["script_rewrite_mode"] = tk.StringVar(value="Kể chuyện 40+ - nhanh và cảm xúc")
        self.vars["gemini_speed_mode"] = tk.StringVar(value="Siêu nhanh - kịch bản kể chuyện")
        self.vars["video_extract_mode"] = tk.StringVar(value="Nhanh - ưu tiên lời thoại")
        self.vars["video_path"] = tk.StringVar(value="Chưa chọn video")
        self.vars["status"] = tk.StringVar(value="Sẵn sàng")
        self.vars["progress_text"] = tk.StringVar(value="Chưa có tác vụ")
        self.vars["progress_value"] = tk.DoubleVar(value=0)
        self.vars["source_meta"] = tk.StringVar(value="0 từ")
        self.vars["draft_meta"] = tk.StringVar(value="0 từ")
        self.vars["risk"] = tk.StringVar(value="N/A")
        self.vars["similarity_percent"] = tk.StringVar(value="0%")
        self.vars["originality_percent"] = tk.StringVar(value="0%")
        self.vars["similarity_mode"] = tk.StringVar(value="Chưa so sánh")
        self.vars["url_result_meta"] = tk.StringVar(value="Chưa có kết quả URL")
        self.vars["batch_result_meta"] = tk.StringVar(value="Chưa có batch")
        self.vars["training_sample_meta"] = tk.StringVar(value="Chưa có mẫu huấn luyện")
        self.vars["training_profile_name"] = tk.StringVar(value="Profile kể chuyện 40+")
        self.vars["training_quality"] = tk.StringVar(value="Profile: chưa chấm")
        self.vars["chat_context_mode"] = tk.StringVar(value="Chat tự do như Gemini")
        self.vars["chat_attachment_meta"] = tk.StringVar(value="Chưa đính kèm file")

    def _bind_meta_traces(self) -> None:
        for key in ("duration", "source_language", "target_language"):
            self.vars[key].trace_add("write", lambda *_args: self._render_all_if_ready())
        self.vars["gemini_api_key"].trace_add("write", lambda *_args: self._sync_runtime_api_key())

    def _render_all_if_ready(self) -> None:
        if hasattr(self, "source_text") and hasattr(self, "draft_text"):
            self._render_all()

    def _build_style(self) -> None:
        style = ttk.Style(self)
        style.theme_use("clam")
        base = "#07040d"
        panel = "#12081f"
        field = "#090613"
        line = "#4b255d"
        cyan = "#38e8ff"
        pink = "#ff4fd8"
        purple = "#7c3cff"
        lime = "#baff4a"
        style.configure(".", background=base, foreground="#fff4ff", fieldbackground=field)
        style.configure("TFrame", background=base)
        style.configure("Panel.TFrame", background=panel, relief="flat")
        style.configure("Workflow.TLabelframe", background=base, foreground="#fff4ff", bordercolor="#7c3cff", relief="solid")
        style.configure("Workflow.TLabelframe.Label", background=base, foreground=pink, font=("Segoe UI", 10, "bold"))
        style.configure("TLabel", background=base, foreground="#fff4ff")
        style.configure("Muted.TLabel", background=base, foreground="#c9a7d8")
        style.configure("Panel.TLabel", background=panel, foreground="#fff4ff")
        style.configure("Title.TLabel", font=("Segoe UI", 18, "bold"), foreground=pink)
        style.configure("Metric.TLabel", font=("Segoe UI", 24, "bold"), foreground="#fff4ff")
        style.configure("TButton", background="#171029", foreground="#fff4ff", bordercolor=cyan, focusthickness=0, padding=(12, 8))
        style.map("TButton", background=[("active", "#23153e")], foreground=[("active", "#ffffff")])
        style.configure("Primary.TButton", background="#102a3a", foreground="#ffffff", bordercolor=cyan)
        style.configure("Magenta.TButton", background="#4a1244", foreground="#ffffff", bordercolor=pink)
        style.configure("Lime.TButton", background="#243517", foreground="#ffffff", bordercolor=lime)
        style.configure("Danger.TButton", background="#421223", foreground="#ffdce2", bordercolor="#ff5f73")
        style.configure("Hot.TButton", background="#5a1552", foreground="#ffffff", bordercolor=pink, padding=(14, 10))
        style.configure("Ghost.TButton", background="#160d28", foreground="#ffd6f7", bordercolor=purple, padding=(10, 7))
        style.configure("Compact.TButton", padding=(8, 5))
        style.configure("TEntry", fieldbackground=field, foreground="#fff4ff", insertcolor=pink, bordercolor=line)
        style.configure("TCombobox", fieldbackground=field, foreground="#fff4ff", arrowcolor=pink)
        style.map(
            "TCombobox",
            fieldbackground=[("readonly", field)],
            selectbackground=[("readonly", field)],
            selectforeground=[("readonly", "#fff4ff")],
            foreground=[("readonly", "#fff4ff")],
        )
        style.configure("TCheckbutton", background=panel, foreground="#fff4ff")
        style.map("TCheckbutton", background=[("active", panel)], foreground=[("active", "#ffffff")])
        style.configure("Horizontal.TScale", background=panel, troughcolor=field)
        style.configure("TNotebook", background=base, borderwidth=0)
        style.configure("TNotebook.Tab", background="#140c24", foreground="#c9a7d8", padding=(14, 8))
        style.map("TNotebook.Tab", background=[("selected", "#35113f")], foreground=[("selected", "#ffffff")])
        style.configure("Treeview", background=field, fieldbackground=field, foreground="#fff4ff", rowheight=28, bordercolor=line)
        style.configure("Treeview.Heading", background=panel, foreground=pink, font=("Segoe UI", 10, "bold"))
        style.map("Treeview", background=[("selected", "#35113f")], foreground=[("selected", "#ffffff")])

    def _build_ui(self) -> None:
        root = ttk.Frame(self, padding=14)
        root.pack(fill="both", expand=True)

        header = ttk.Frame(root)
        header.pack(fill="x", pady=(0, 12))
        ttk.Label(header, text=APP_NAME, style="Title.TLabel").pack(side="left")
        ttk.Label(header, textvariable=self.vars["status"], style="Muted.TLabel").pack(side="right")

        body = ttk.Frame(root)
        body.pack(fill="both", expand=True)
        sidebar = ttk.Frame(body, style="Panel.TFrame", width=420)
        sidebar.pack(side="left", fill="y", padx=(0, 12))
        sidebar.pack_propagate(False)
        self.left_canvas = tk.Canvas(sidebar, bg="#12081f", highlightthickness=0, width=400)
        self.left_scrollbar = ttk.Scrollbar(sidebar, orient="vertical", command=self.left_canvas.yview)
        self.left = ttk.Frame(self.left_canvas, style="Panel.TFrame", padding=14)
        self.left_window = self.left_canvas.create_window((0, 0), window=self.left, anchor="nw")
        self.left_canvas.configure(yscrollcommand=self.left_scrollbar.set)
        self.left_canvas.pack(side="left", fill="both", expand=True)
        self.left_scrollbar.pack(side="right", fill="y")
        self.left.bind("<Configure>", self._sync_sidebar_scroll)
        self.left_canvas.bind("<Configure>", self._sync_sidebar_width)
        self.left_canvas.bind_all("<MouseWheel>", self._on_mousewheel)
        self.main = ttk.Frame(body)
        self.main.pack(side="left", fill="both", expand=True)

        self._build_left_panel()
        self._build_notebook()

    def _sync_sidebar_scroll(self, _event=None) -> None:
        self.left_canvas.configure(scrollregion=self.left_canvas.bbox("all"))

    def _sync_sidebar_width(self, event) -> None:
        self.left_canvas.itemconfigure(self.left_window, width=max(event.width - 6, 360))

    def _on_mousewheel(self, event) -> None:
        widget = self.winfo_containing(event.x_root, event.y_root)
        if widget and str(widget).startswith(str(self.left_canvas)):
            self.left_canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

    def _panel_label(self, parent, text: str) -> None:
        ttk.Label(parent, text=text, style="Panel.TLabel", font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(10, 4))

    def _entry(self, parent, key: str, show: str | None = None) -> ttk.Entry:
        entry = ttk.Entry(parent, textvariable=self.vars[key], show=show)
        entry.pack(fill="x")
        return entry

    def _combo(self, parent, key: str, values: list[str]) -> ttk.Combobox:
        combo = ttk.Combobox(parent, textvariable=self.vars[key], values=values, state="readonly")
        combo.pack(fill="x")
        return combo

    def _sidebar_text(self, parent, height: int = 6) -> scrolledtext.ScrolledText:
        text = scrolledtext.ScrolledText(
            parent,
            height=height,
            wrap="word",
            bg="#090613",
            fg="#fff4ff",
            insertbackground="#ff4fd8",
            selectbackground="#35113f",
            selectforeground="#ffffff",
            relief="solid",
            borderwidth=1,
            padx=8,
            pady=7,
            font=("Segoe UI", 9),
        )
        text.pack(fill="x")
        return text

    def _build_left_panel(self) -> None:
        ttk.Label(self.left, text="Dự án", style="Panel.TLabel", font=("Segoe UI", 13, "bold")).pack(anchor="w")
        self._panel_label(self.left, "Tên dự án")
        self._entry(self.left, "project_name")
        self._panel_label(self.left, "Tên câu chuyện / Title YouTube")
        self._entry(self.left, "story_title")
        ttk.Label(
            self.left,
            text="Tối đa 100 ký tự để phù hợp giới hạn tiêu đề YouTube.",
            style="Panel.TLabel",
            wraplength=360,
        ).pack(anchor="w", pady=(3, 0))
        ttk.Button(self.left, text="Tạo title YouTube", style="Lime.TButton", command=self.generate_youtube_title_current).pack(fill="x", pady=(6, 0))
        ttk.Checkbutton(
            self.left,
            text="Gemini chọn title hay nhất",
            variable=self.vars["auto_title_with_gemini"],
            command=self.save_settings,
        ).pack(anchor="w", pady=(4, 0))

        ttk.Label(self.left, text="Mẫu cấu hình", style="Panel.TLabel", font=("Segoe UI", 13, "bold")).pack(anchor="w", pady=(18, 4))
        ttk.Combobox(
            self.left,
            textvariable=self.vars["selected_preset"],
            values=list(PRESETS),
            state="readonly",
        ).pack(fill="x", pady=(0, 6))
        preset_actions = ttk.Frame(self.left, style="Panel.TFrame")
        preset_actions.pack(fill="x")
        ttk.Button(
            preset_actions,
            text="Áp dụng mẫu",
            style="Hot.TButton",
            command=lambda: self.apply_preset(self.vars["selected_preset"].get()),
        ).pack(side="left", fill="x", expand=True, padx=(0, 4))
        ttk.Button(
            preset_actions,
            text="Gợi ý mode",
            style="Ghost.TButton",
            command=self.show_story_40plus_suggestions,
        ).pack(side="left", fill="x", expand=True, padx=(4, 0))
        ttk.Label(
            self.left,
            text="Một mẫu sẽ tự set người xem, tone, niche, CTA, thời lượng và chế độ viết lại.",
            style="Panel.TLabel",
            wraplength=360,
        ).pack(anchor="w", pady=(5, 0))

        ttk.Label(self.left, text="Cấu hình", style="Panel.TLabel", font=("Segoe UI", 13, "bold")).pack(anchor="w", pady=(18, 4))
        self._panel_label(self.left, "Nền tảng")
        self._combo(self.left, "platform", ["YouTube", "YouTube Shorts", "TikTok/Reels", "Podcast video", "Course lesson"])
        self._panel_label(self.left, "Thời lượng")
        self._entry(self.left, "duration")
        ttk.Label(self.left, text="Ví dụ: 50 = 50 phút; 40-50' = voice 40-50 phút.", style="Panel.TLabel", wraplength=360).pack(anchor="w", pady=(3, 0))
        self._panel_label(self.left, "Người xem")
        self._entry(self.left, "audience")
        self._panel_label(self.left, "Tone")
        self._entry(self.left, "tone")
        self._panel_label(self.left, "Niche")
        self._entry(self.left, "niche")
        self._panel_label(self.left, "CTA")
        self._entry(self.left, "cta")
        self._panel_label(self.left, "Ý tưởng riêng / kho trend")
        self.custom_ideas_text = self._sidebar_text(self.left, height=7)
        self.custom_ideas_text.bind("<FocusOut>", lambda _event: self.save_settings())
        ttk.Label(
            self.left,
            text="Dán ý tưởng ở đây. AI huấn luyện và Gemini Writer sẽ đọc để nâng cấp thành hook, trope, reveal, series.",
            style="Panel.TLabel",
            wraplength=360,
        ).pack(anchor="w", pady=(3, 0))
        idea_buttons = ttk.Frame(self.left, style="Panel.TFrame")
        idea_buttons.pack(fill="x", pady=(6, 0))
        ttk.Button(idea_buttons, text="Nạp trend", style="Primary.TButton", command=self.load_trend_ideas_into_custom_box).pack(side="left", fill="x", expand=True, padx=(0, 4))
        ttk.Button(idea_buttons, text="Đưa vào huấn luyện", style="Lime.TButton", command=self.append_custom_ideas_to_training).pack(side="left", fill="x", expand=True, padx=(4, 0))
        self._panel_label(self.left, "Mức biến đổi")
        ttk.Scale(self.left, from_=50, to=90, variable=self.vars["target_change"], orient="horizontal").pack(fill="x")

        ttk.Label(self.left, text="Gemini AI", style="Panel.TLabel", font=("Segoe UI", 13, "bold")).pack(anchor="w", pady=(18, 4))
        self._panel_label(self.left, "API key")
        self._entry(self.left, "gemini_api_key", show="*")
        ttk.Label(self.left, text="Tool chỉ dùng 1 API key. Khi đổi key/email khác, dữ liệu huấn luyện vẫn được giữ trên máy.", style="Panel.TLabel", wraplength=360).pack(anchor="w", pady=(3, 0))
        self.apply_api_button = ttk.Button(self.left, text="Áp dụng API key mới", style="Primary.TButton", command=self.apply_runtime_api_settings)
        self.apply_api_button.pack(fill="x", pady=(6, 0))
        ttk.Checkbutton(self.left, text="Lưu key trên máy này", variable=self.vars["remember_key"], command=self.save_settings).pack(anchor="w", pady=(6, 0))
        ttk.Checkbutton(self.left, text="Stream output khi Gemini đang viết", variable=self.vars["use_streaming"], command=self.save_settings).pack(anchor="w", pady=(4, 0))
        ttk.Checkbutton(self.left, text="Dùng cache để tiết kiệm API", variable=self.vars["use_cache"], command=self.save_settings).pack(anchor="w", pady=(4, 0))
        ttk.Checkbutton(self.left, text="Chỉ dùng cache, không gọi API mới", variable=self.vars["cache_only_mode"], command=self.save_settings).pack(anchor="w", pady=(4, 0))
        ttk.Checkbutton(self.left, text="Test không gọi API", variable=self.vars["test_mode_no_api"], command=self.save_settings).pack(anchor="w", pady=(4, 0))
        ttk.Checkbutton(self.left, text="Tự dịch kiểm tra sau khi viết", variable=self.vars["auto_translate_after_rewrite"], command=self.save_settings).pack(anchor="w", pady=(4, 0))
        self._panel_label(self.left, "Model")
        self._combo(self.left, "gemini_model", GEMINI_MODEL_OPTIONS)
        self._panel_label(self.left, "Tốc độ Gemini")
        self._combo(self.left, "gemini_speed_mode", GEMINI_SPEED_MODES)
        self._panel_label(self.left, "Ngôn ngữ nguồn")
        self._combo(self.left, "source_language", ["auto", "Tiếng Trung", "Tiếng Nhật", "Tiếng Hàn", "Tiếng Anh - Mỹ", "Tiếng Anh - Anh", "Tiếng Đức", "Tiếng Pháp"])
        self._panel_label(self.left, "Ngôn ngữ đầu ra")
        self._combo(self.left, "target_language", ["Tiếng Việt", "Tiếng Anh - Mỹ", "Tiếng Anh - Anh", "Tiếng Trung", "Tiếng Nhật", "Tiếng Hàn", "Tiếng Đức", "Tiếng Pháp"])
        self._panel_label(self.left, "Ngôn ngữ dịch kiểm tra")
        ttk.Label(
            self.left,
            text="Bắt buộc: Tiếng Việt có dấu. App không cho đổi mục này để tránh dịch sai ngôn ngữ.",
            style="Panel.TLabel",
            wraplength=360,
        ).pack(anchor="w", pady=(0, 6))
        self._panel_label(self.left, "Chế độ viết lại kịch bản")
        self._combo(
            self.left,
            "script_rewrite_mode",
            SCRIPT_REWRITE_MODES,
        )
        self._panel_label(self.left, "Chế độ trích video")
        self._combo(
            self.left,
            "video_extract_mode",
            [
                "Nhanh - ưu tiên lời thoại",
                "Cân bằng - lời thoại + visual chính",
                "Chi tiết - transcript + visual đầy đủ",
            ],
        )

    def _build_notebook(self) -> None:
        self.notebook = ttk.Notebook(self.main)
        self.notebook.pack(fill="both", expand=True)
        self.editor_tab = ttk.Frame(self.notebook, padding=8)
        self.analysis_tab = ttk.Frame(self.notebook, padding=8)
        self.training_tab = ttk.Frame(self.notebook, padding=8)
        self.gemini_tab = ttk.Frame(self.notebook, padding=8)
        self.chat_tab = ttk.Frame(self.notebook, padding=8)
        self.batch_tab = ttk.Frame(self.notebook, padding=8)
        self.url_results_tab = ttk.Frame(self.notebook, padding=8)
        self.translation_tab = ttk.Frame(self.notebook, padding=8)
        self.summary_tab = ttk.Frame(self.notebook, padding=8)
        self.similarity_tab = ttk.Frame(self.notebook, padding=8)
        self.planner_tab = ttk.Frame(self.notebook, padding=8)
        self.projects_tab = ttk.Frame(self.notebook, padding=8)
        self.notebook.add(self.editor_tab, text="Biên tập")
        self.notebook.add(self.analysis_tab, text="Phân tích")
        self.notebook.add(self.training_tab, text="Huấn luyện")
        self.notebook.add(self.gemini_tab, text="Gemini Writer")
        self.notebook.add(self.chat_tab, text="Chat AI")
        self.notebook.add(self.batch_tab, text="Batch")
        self.notebook.add(self.url_results_tab, text="URL Results")
        self.notebook.add(self.translation_tab, text="Bản dịch")
        self.notebook.add(self.summary_tab, text="Tóm tắt")
        self.notebook.add(self.similarity_tab, text="Độ giống")
        self.notebook.add(self.planner_tab, text="Kế hoạch")
        self.notebook.add(self.projects_tab, text="Dự án")
        self._build_editor_tab()
        self._build_analysis_tab()
        self._build_training_tab()
        self._build_gemini_tab()
        self._build_chat_tab()
        self._build_batch_tab()
        self._build_url_results_tab()
        self._build_translation_tab()
        self._build_summary_tab()
        self._build_similarity_tab()
        self._build_planner_tab()
        self._build_projects_tab()

    def _workflow_section(self, parent, title: str, buttons: list[tuple], columns: int = 2) -> ttk.LabelFrame:
        section = ttk.LabelFrame(parent, text=title, style="Workflow.TLabelframe", padding=(10, 8))
        for column in range(columns):
            section.columnconfigure(column, weight=1, uniform="workflow_buttons")
        for index, spec in enumerate(buttons):
            text, command = spec[0], spec[1]
            style = spec[2] if len(spec) > 2 else "TButton"
            row = index // columns
            column = index % columns
            ttk.Button(section, text=text, command=command, style=style).grid(
                row=row,
                column=column,
                sticky="ew",
                padx=4,
                pady=4,
            )
        return section

    def _build_editor_tab(self) -> None:
        workflow = ttk.Frame(self.editor_tab)
        workflow.pack(fill="x", pady=(0, 10))
        for column in range(3):
            workflow.columnconfigure(column, weight=1, uniform="editor_workflow")

        sections = [
            (
                "1. Nhập nguồn",
                [
                    ("File text", self.import_script_file, "Primary.TButton"),
                    ("Folder text hàng loạt", self.batch_rewrite_folder, "Primary.TButton"),
                    ("Dán clipboard", self.paste_script_from_clipboard),
                    ("Chọn video", self.extract_script_from_video, "Primary.TButton"),
                    ("Folder video", self.batch_extract_videos_folder),
                    ("URL list", self.import_url_list_file),
                    ("Xem kết quả URL", lambda: self.notebook.select(self.url_results_tab)),
                ],
            ),
            (
                "2. AI viết lại",
                [
                    ("Đọc & viết ngay", self.rewrite_existing_script_now, "Hot.TButton"),
                    ("Xử lý 1 chạm", self.one_click_rewrite, "Lime.TButton"),
                    ("Chạy folder text", self.batch_rewrite_folder, "Primary.TButton"),
                    ("Resume batch", self.resume_batch_rewrite_folder, "Primary.TButton"),
                    ("Batch URL", self.batch_rewrite_urls, "Primary.TButton"),
                    ("Nâng cấp draft", lambda: self.run_gemini("improve"), "Lime.TButton"),
                    ("Tạo series", lambda: self.run_gemini("series"), "Magenta.TButton"),
                ],
            ),
            (
                "3. Kiểm tra & xuất",
                [
                    ("Tóm tắt + so sánh", self.summarize_scripts, "Lime.TButton"),
                    ("Độ giống", self.score),
                    ("Dịch kiểm tra", self.translate_for_review),
                    ("Tạo title YouTube", self.generate_youtube_title_current, "Lime.TButton"),
                    ("Xuất TXT/DOCX", self.export_current_bundle),
                    ("Lưu dự án", self.save_project),
                ],
            ),
        ]
        for index, (title, button_specs) in enumerate(sections):
            section = self._workflow_section(workflow, title, button_specs)
            section.grid(row=0, column=index, sticky="nsew", padx=5, pady=5)

        panes = ttk.PanedWindow(self.editor_tab, orient="horizontal")
        panes.pack(fill="both", expand=True)
        source_frame = ttk.Frame(panes)
        draft_frame = ttk.Frame(panes)
        panes.add(source_frame, weight=1)
        panes.add(draft_frame, weight=1)
        ttk.Label(source_frame, text="Kịch bản gốc / transcript", font=("Segoe UI", 11, "bold")).pack(anchor="w")
        ttk.Label(source_frame, textvariable=self.vars["source_meta"], style="Muted.TLabel").pack(anchor="w")
        self.source_text = self._text(source_frame, max_chars=TEXT_WIDGET_FULL_SCRIPT_MAX_CHARS)
        ttk.Label(draft_frame, text="Bản nháp mới / Gemini output", font=("Segoe UI", 11, "bold")).pack(anchor="w")
        ttk.Label(draft_frame, textvariable=self.vars["draft_meta"], style="Muted.TLabel").pack(anchor="w")
        self.draft_text = self._text(draft_frame, max_chars=TEXT_WIDGET_FULL_SCRIPT_MAX_CHARS)
        self.source_text.bind("<<Modified>>", lambda event: self._on_text_modified(event, "source"))
        self.draft_text.bind("<<Modified>>", lambda event: self._on_text_modified(event, "draft"))

    def _build_analysis_tab(self) -> None:
        top = ttk.Frame(self.analysis_tab)
        top.pack(fill="x")
        self.metric_source = ttk.Label(top, text="0 từ", style="Metric.TLabel")
        self.metric_source.pack(side="left", padx=(0, 24))
        self.metric_duration = ttk.Label(top, text="0.0 phút", style="Metric.TLabel")
        self.metric_duration.pack(side="left", padx=24)
        self.metric_beats = ttk.Label(top, text="0 beat", style="Metric.TLabel")
        self.metric_beats.pack(side="left", padx=24)
        self.analysis_output = self._text(self.analysis_tab, height=28)

    def _build_training_tab(self) -> None:
        controls = ttk.LabelFrame(self.training_tab, text="1. Nạp mẫu và tạo profile", style="Workflow.TLabelframe", padding=(10, 8))
        controls.pack(fill="x", pady=(0, 8))
        quick_row = ttk.Frame(controls)
        quick_row.pack(fill="x", pady=(0, 4))
        ttk.Button(quick_row, text="Huấn luyện 1 chạm", style="Magenta.TButton", command=self.train_ai_one_click).pack(side="left", padx=(0, 6), pady=3)
        ttk.Button(quick_row, text="Tối ưu setup", style="Lime.TButton", command=self.prepare_training_best_practices).pack(side="left", padx=6, pady=3)
        ttk.Button(quick_row, text="Hướng dẫn nhanh", style="Primary.TButton", command=self.show_training_quick_guide).pack(side="left", padx=6, pady=3)
        ttk.Label(
            quick_row,
            text="Gợi ý: bấm Huấn luyện 1 chạm nếu muốn tool tự xử lý các bước chính.",
            style="Muted.TLabel",
        ).pack(side="left", padx=(10, 0))
        row1 = ttk.Frame(controls)
        row1.pack(fill="x")
        ttk.Button(row1, text="Nạp nguồn hiện tại", style="Primary.TButton", command=self.add_current_source_to_training).pack(side="left", padx=(0, 6), pady=3)
        ttk.Button(row1, text="Nhập file mẫu", style="Primary.TButton", command=self.import_training_sample_files).pack(side="left", padx=6, pady=3)
        ttk.Button(row1, text="Nhập folder mẫu", style="Primary.TButton", command=self.import_training_sample_folder).pack(side="left", padx=6, pady=3)
        ttk.Button(row1, text="Dán mẫu clipboard", command=self.paste_training_sample_from_clipboard).pack(side="left", padx=6, pady=3)
        ttk.Button(row1, text="Profile mẫu 40+", command=self.load_training_template_40plus).pack(side="left", padx=6, pady=3)
        ttk.Label(row1, textvariable=self.vars["training_sample_meta"], style="Muted.TLabel").pack(side="right", padx=(10, 0))

        row2 = ttk.Frame(controls)
        row2.pack(fill="x", pady=(4, 0))
        ttk.Label(row2, text="Tên profile").pack(side="left")
        ttk.Entry(row2, textvariable=self.vars["training_profile_name"], width=28).pack(side="left", padx=(6, 12))
        ttk.Button(row2, text="Tạo profile nhanh", style="Lime.TButton", command=self.generate_training_profile_local).pack(side="left", padx=6, pady=3)
        ttk.Button(row2, text="Gemini học profile", style="Magenta.TButton", command=self.generate_training_profile_with_gemini).pack(side="left", padx=6, pady=3)
        ttk.Button(row2, text="AI nâng cấp profile", style="Magenta.TButton", command=self.upgrade_training_profile_with_gemini).pack(side="left", padx=6, pady=3)
        ttk.Button(row2, text="Nâng cấp local", style="Lime.TButton", command=self.improve_training_profile_local).pack(side="left", padx=6, pady=3)
        ttk.Button(row2, text="Chấm profile", command=self.score_training_profile).pack(side="left", padx=6, pady=3)

        row3 = ttk.Frame(controls)
        row3.pack(fill="x", pady=(4, 0))
        ttk.Button(row3, text="Import profile", command=self.import_training_profile_file).pack(side="left", padx=(0, 6), pady=3)
        ttk.Button(row3, text="Export profile", command=self.export_training_profile_file).pack(side="left", padx=6, pady=3)
        ttk.Button(row3, text="Gợi ý nâng cấp", command=self.show_training_upgrade_suggestions).pack(side="left", padx=6, pady=3)
        ttk.Button(row3, text="Kho ý tưởng global", style="Primary.TButton", command=self.show_training_story_idea_bank).pack(side="left", padx=6, pady=3)
        ttk.Button(row3, text="Thêm luật ý tưởng", command=self.append_training_story_idea_rules).pack(side="left", padx=6, pady=3)
        ttk.Button(row3, text="Chat với profile", style="Primary.TButton", command=self.open_training_chat).pack(side="left", padx=6, pady=3)
        self.training_cancel_button = ttk.Button(row3, text="Hủy", style="Danger.TButton", command=self.cancel_current_task, state="disabled")
        self.training_cancel_button.pack(side="left", padx=6, pady=3)
        ttk.Checkbutton(
            row3,
            text="Dùng profile khi viết",
            variable=self.vars["use_training_profile"],
            command=self.save_settings,
        ).pack(side="left", padx=12)

        library = ttk.LabelFrame(self.training_tab, text="2. Thư viện profile", style="Workflow.TLabelframe", padding=(10, 8))
        library.pack(fill="x", pady=(0, 8))
        library_controls = ttk.Frame(library)
        library_controls.pack(side="right", fill="y", padx=(8, 0))
        ttk.Button(library_controls, text="Lưu vào thư viện", style="Lime.TButton", command=self.save_training_profile_to_library).pack(fill="x", pady=2)
        ttk.Button(library_controls, text="Mở profile", command=self.open_selected_training_profile).pack(fill="x", pady=2)
        ttk.Button(library_controls, text="Xóa profile", style="Danger.TButton", command=self.delete_selected_training_profile).pack(fill="x", pady=2)
        self.training_profiles_list = tk.Listbox(
            library,
            height=4,
            bg="#090613",
            fg="#fff4ff",
            selectbackground="#35113f",
            selectforeground="#ffffff",
            highlightthickness=1,
            highlightcolor="#ff4fd8",
            relief="flat",
            font=("Segoe UI", 10),
        )
        self.training_profiles_list.pack(side="left", fill="both", expand=True)
        self.training_profiles_list.bind("<<ListboxSelect>>", self._on_training_profile_selected)

        panes = ttk.PanedWindow(self.training_tab, orient="horizontal")
        panes.pack(fill="both", expand=True)
        sample_frame = ttk.Frame(panes)
        profile_frame = ttk.Frame(panes)
        panes.add(sample_frame, weight=1)
        panes.add(profile_frame, weight=1)

        sample_header = ttk.Frame(sample_frame)
        sample_header.pack(fill="x")
        ttk.Label(sample_header, text="Kịch bản mẫu để huấn luyện", font=("Segoe UI", 11, "bold")).pack(side="left")
        ttk.Button(sample_header, text="Xóa mẫu", style="Danger.TButton", command=self.clear_training_samples).pack(side="right")
        self.training_samples_text = self._text(sample_frame, height=30)

        profile_header = ttk.Frame(profile_frame)
        profile_header.pack(fill="x")
        ttk.Label(profile_header, text="Channel Training Profile", font=("Segoe UI", 11, "bold")).pack(side="left")
        ttk.Label(profile_header, textvariable=self.vars["training_quality"], style="Muted.TLabel").pack(side="left", padx=(12, 0))
        ttk.Button(profile_header, text="Copy profile", command=self.copy_training_profile).pack(side="right", padx=(6, 0))
        ttk.Button(profile_header, text="Lưu profile", style="Lime.TButton", command=self.save_training_profile).pack(side="right", padx=6)
        ttk.Button(profile_header, text="Xóa profile", style="Danger.TButton", command=self.clear_training_profile).pack(side="right", padx=6)
        self.training_text = self._text(profile_frame, height=16)
        rule_panes = ttk.PanedWindow(profile_frame, orient="horizontal")
        rule_panes.pack(fill="both", expand=True, pady=(8, 0))
        negative_frame = ttk.Frame(rule_panes)
        locked_frame = ttk.Frame(rule_panes)
        rule_panes.add(negative_frame, weight=1)
        rule_panes.add(locked_frame, weight=1)
        ttk.Label(negative_frame, text="Luật cấm / Negative style", font=("Segoe UI", 10, "bold")).pack(anchor="w")
        self.training_negative_text = self._text(negative_frame, height=8)
        ttk.Label(locked_frame, text="Luật bắt buộc / Locked rules", font=("Segoe UI", 10, "bold")).pack(anchor="w")
        self.training_locked_text = self._text(locked_frame, height=8)

    def _build_gemini_tab(self) -> None:
        workflow = ttk.Frame(self.gemini_tab)
        workflow.pack(fill="x", pady=(0, 10))
        for column in range(3):
            workflow.columnconfigure(column, weight=1, uniform="gemini_workflow")

        source_section = self._workflow_section(
            workflow,
            "1. Chọn nguồn",
            [
                ("File kịch bản", self.import_script_file, "Primary.TButton"),
                ("Folder text hàng loạt", self.batch_rewrite_folder, "Primary.TButton"),
                ("Dán clipboard", self.paste_script_from_clipboard),
                ("Video đơn", self.extract_script_from_video, "Primary.TButton"),
                ("Folder video", self.batch_extract_videos_folder),
                ("URL list", self.import_url_list_file, "Primary.TButton"),
            ],
        )
        source_section.grid(row=0, column=0, sticky="nsew", padx=5, pady=5)

        ai_section = self._workflow_section(
            workflow,
            "2. Gemini xử lý",
            [
                ("Viết lại ngay", self.rewrite_existing_script_now, "Hot.TButton"),
                ("Chạy folder text", self.batch_rewrite_folder, "Primary.TButton"),
                ("Resume batch", self.resume_batch_rewrite_folder, "Primary.TButton"),
                ("Batch URL", self.batch_rewrite_urls, "Primary.TButton"),
                ("Nâng cấp draft", lambda: self.run_gemini("improve"), "Lime.TButton"),
                ("Tạo series", lambda: self.run_gemini("series"), "Magenta.TButton"),
            ],
        )
        ai_section.grid(row=0, column=1, sticky="nsew", padx=5, pady=5)

        after_section = ttk.LabelFrame(workflow, text="3. Sau khi có output", style="Workflow.TLabelframe", padding=(10, 8))
        after_section.grid(row=0, column=2, sticky="nsew", padx=5, pady=5)
        for column in range(2):
            after_section.columnconfigure(column, weight=1, uniform="gemini_after_buttons")
        after_buttons = [
            ("Output -> draft", self.use_gemini_as_draft, "Lime.TButton"),
            ("Tóm tắt", self.summarize_scripts, "Lime.TButton"),
            ("Dịch kiểm tra", self.translate_for_review),
            ("Độ giống", self.score),
            ("Copy output", self.copy_gemini_output),
            ("Huấn luyện", lambda: self.notebook.select(self.training_tab), "Primary.TButton"),
            ("Chat AI", lambda: self.notebook.select(self.chat_tab), "Primary.TButton"),
        ]
        for index, spec in enumerate(after_buttons):
            text, command = spec[0], spec[1]
            style = spec[2] if len(spec) > 2 else "TButton"
            ttk.Button(after_section, text=text, command=command, style=style).grid(
                row=index // 2,
                column=index % 2,
                sticky="ew",
                padx=4,
                pady=4,
            )
        self.cancel_button = ttk.Button(after_section, text="Hủy tác vụ", style="Danger.TButton", command=self.cancel_current_task, state="disabled")
        self.cancel_button.grid(row=3, column=1, sticky="ew", padx=4, pady=4)
        training_hint = ttk.Frame(self.gemini_tab)
        training_hint.pack(fill="x", pady=(0, 8))
        ttk.Label(training_hint, text="Training profile lấy từ tab Huấn luyện", font=("Segoe UI", 11, "bold")).pack(side="left")
        ttk.Button(training_hint, text="Mở Huấn luyện", style="Primary.TButton", command=lambda: self.notebook.select(self.training_tab)).pack(side="right")
        ttk.Button(training_hint, text="Chat AI", style="Primary.TButton", command=lambda: self.notebook.select(self.chat_tab)).pack(side="right", padx=(0, 6))
        progress_frame = ttk.Frame(self.gemini_tab)
        progress_frame.pack(fill="x", pady=(10, 2))
        self.progress_bar = ttk.Progressbar(progress_frame, variable=self.vars["progress_value"], maximum=100, mode="determinate")
        self.progress_bar.pack(side="left", fill="x", expand=True)
        ttk.Label(progress_frame, textvariable=self.vars["progress_text"], style="Muted.TLabel").pack(side="left", padx=(10, 0))
        ttk.Label(self.gemini_tab, text="Kết quả Gemini", font=("Segoe UI", 11, "bold")).pack(anchor="w", pady=(10, 0))
        self.gemini_output = self._text(self.gemini_tab, height=24, max_chars=TEXT_WIDGET_LOG_MAX_CHARS)

    def _build_chat_tab(self) -> None:
        controls = ttk.LabelFrame(self.chat_tab, text="Chat trực tiếp với Gemini", style="Workflow.TLabelframe", padding=(10, 8))
        controls.pack(fill="x", pady=(0, 8))
        ttk.Label(controls, text="Ngữ cảnh").pack(side="left")
        ttk.Combobox(
            controls,
            textvariable=self.vars["chat_context_mode"],
            values=[
                "Chat tự do như Gemini",
                "Dùng profile + kịch bản hiện tại",
                "Chỉ dùng training profile",
                "Chỉ dùng kịch bản hiện tại",
                "Không dùng ngữ cảnh",
            ],
            state="readonly",
            width=34,
        ).pack(side="left", padx=(6, 12))
        ttk.Button(controls, text="Gửi", style="Lime.TButton", command=self.send_chat_message).pack(side="left", padx=4)
        ttk.Button(controls, text="Đính kèm file", style="Primary.TButton", command=self.add_chat_attachments_dialog).pack(side="left", padx=4)
        ttk.Button(controls, text="Xóa file", command=self.clear_chat_attachments).pack(side="left", padx=4)
        ttk.Button(controls, text="Gợi ý nâng cấp kịch bản", style="Primary.TButton", command=self.chat_suggest_script_upgrade).pack(side="left", padx=4)
        ttk.Button(controls, text="Hỏi về profile", style="Primary.TButton", command=self.chat_review_training_profile).pack(side="left", padx=4)
        ttk.Button(controls, text="Xóa chat", style="Danger.TButton", command=self.clear_chat).pack(side="right", padx=4)
        ttk.Label(self.chat_tab, textvariable=self.vars["chat_attachment_meta"], style="Muted.TLabel").pack(anchor="w", pady=(0, 6))

        self.chat_output = self._text(self.chat_tab, height=28)
        input_frame = ttk.Frame(self.chat_tab)
        input_frame.pack(fill="x", pady=(8, 0))
        ttk.Label(input_frame, text="Câu hỏi / yêu cầu", font=("Segoe UI", 11, "bold")).pack(anchor="w")
        self.chat_input = scrolledtext.ScrolledText(
            input_frame,
            height=5,
            wrap="word",
            bg="#090613",
            fg="#fff4ff",
            insertbackground="#ff4fd8",
            selectbackground="#35113f",
            selectforeground="#ffffff",
            relief="flat",
            padx=10,
            pady=10,
            font=("Consolas", 10),
        )
        self.chat_input.pack(fill="x", expand=False, pady=(4, 0))
        self.chat_input.bind("<Control-Return>", lambda _event: (self.send_chat_message(), "break"))
        self.set_text(
            self.chat_output,
            "Chat AI sẵn sàng.\n\n"
            "Bạn có thể hỏi ví dụ:\n"
            "- Hôm nay tôi nên lên kế hoạch làm việc như thế nào?\n"
            "- Giải thích giúp tôi lỗi Windows/API này.\n"
            "- Viết giúp tôi một email chuyên nghiệp.\n"
            "- Kéo/thêm ảnh vào đây rồi hỏi: mô tả ảnh này, sửa ảnh này, hoặc tạo ảnh mới.\n"
            "- Profile này còn thiếu gì để viết kịch bản hay hơn?\n"
            "- Hãy tạo 5 hook theo phong cách kênh này.\n"
            "- Sửa đoạn mở đầu để hợp người xem 40+ hơn.\n"
            "- Kịch bản hiện tại thiếu cao trào ở đâu?\n",
        )

    def _build_batch_tab(self) -> None:
        controls = ttk.Frame(self.batch_tab)
        controls.pack(fill="x", pady=(0, 8))
        ttk.Button(controls, text="Chạy folder text mới", style="Primary.TButton", command=self.batch_rewrite_folder).pack(side="left", padx=(0, 6))
        ttk.Button(controls, text="Resume batch lỗi/quota", style="Lime.TButton", command=self.resume_batch_rewrite_folder).pack(side="left", padx=6)
        ttk.Button(controls, text="Dùng item đã chọn", style="Hot.TButton", command=self.use_selected_batch_result).pack(side="left", padx=6)
        ttk.Button(controls, text="Mở output", command=self.open_batch_output_folder).pack(side="left", padx=6)
        ttk.Button(controls, text="Copy title", command=self.copy_selected_batch_title).pack(side="left", padx=6)
        ttk.Button(controls, text="Copy path", command=self.copy_selected_batch_path).pack(side="left", padx=6)
        ttk.Button(controls, text="Copy tóm tắt", command=self.copy_selected_batch_summaries).pack(side="left", padx=6)
        ttk.Button(controls, text="Copy so sánh", command=self.copy_selected_batch_comparison).pack(side="left", padx=6)
        ttk.Label(controls, textvariable=self.vars["batch_result_meta"], style="Muted.TLabel").pack(side="right")

        self.batch_results_tree = ttk.Treeview(
            self.batch_tab,
            columns=("index", "status", "file", "title", "words", "voice", "story", "similarity", "length", "note"),
            show="headings",
            height=10,
            selectmode="browse",
        )
        columns = [
            ("index", "#", 48),
            ("status", "Trạng thái", 86),
            ("file", "File", 230),
            ("title", "Title", 300),
            ("words", "Từ", 90),
            ("voice", "Voice", 120),
            ("story", "Story", 70),
            ("similarity", "Độ giống", 90),
            ("length", "Độ dài", 110),
            ("note", "Ghi chú / lỗi", 360),
        ]
        for key, title, width in columns:
            self.batch_results_tree.heading(key, text=title)
            self.batch_results_tree.column(key, width=width, minwidth=45, stretch=(key in {"title", "note"}))
        self.batch_results_tree.pack(fill="x", pady=(0, 8))
        self.batch_results_tree.bind("<<TreeviewSelect>>", self._on_batch_result_selected)

        panes = ttk.PanedWindow(self.batch_tab, orient="horizontal")
        panes.pack(fill="both", expand=True)
        source_frame = ttk.Frame(panes)
        output_frame = ttk.Frame(panes)
        summary_frame = ttk.Frame(panes)
        panes.add(source_frame, weight=1)
        panes.add(output_frame, weight=1)
        panes.add(summary_frame, weight=1)
        ttk.Label(source_frame, text="Kịch bản gốc của item đã chọn", font=("Segoe UI", 11, "bold")).pack(anchor="w")
        self.batch_source_preview = self._text(source_frame, height=12, max_chars=TEXT_WIDGET_PREVIEW_MAX_CHARS)
        ttk.Label(output_frame, text="Kịch bản AI đã viết lại của item đã chọn", font=("Segoe UI", 11, "bold")).pack(anchor="w")
        self.batch_output_preview = self._text(output_frame, height=12, max_chars=TEXT_WIDGET_PREVIEW_MAX_CHARS)
        summary_top = ttk.PanedWindow(summary_frame, orient="horizontal")
        summary_top.pack(fill="both", expand=True)
        batch_source_summary_frame = ttk.Frame(summary_top)
        batch_output_summary_frame = ttk.Frame(summary_top)
        summary_top.add(batch_source_summary_frame, weight=1)
        summary_top.add(batch_output_summary_frame, weight=1)
        ttk.Label(batch_source_summary_frame, text="Tóm tắt bản gốc", font=("Segoe UI", 10, "bold")).pack(anchor="w")
        self.batch_source_summary_text = self._text(batch_source_summary_frame, height=8, max_chars=TEXT_WIDGET_SUMMARY_MAX_CHARS)
        ttk.Label(batch_output_summary_frame, text="Tóm tắt bản AI", font=("Segoe UI", 10, "bold")).pack(anchor="w")
        self.batch_output_summary_text = self._text(batch_output_summary_frame, height=8, max_chars=TEXT_WIDGET_SUMMARY_MAX_CHARS)
        ttk.Label(summary_frame, text="So sánh 2 nội dung", font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(8, 0))
        self.batch_summary_compare_text = self._text(summary_frame, height=8, max_chars=TEXT_WIDGET_SUMMARY_MAX_CHARS)
        self._render_batch_results()

    def _build_url_results_tab(self) -> None:
        controls = ttk.Frame(self.url_results_tab)
        controls.pack(fill="x", pady=(0, 8))
        ttk.Button(controls, text="Dùng URL đã chọn làm draft", style="Lime.TButton", command=self.use_selected_url_result).pack(side="left", padx=(0, 6))
        ttk.Button(controls, text="Copy kịch bản đã chọn", style="Primary.TButton", command=self.copy_selected_url_output).pack(side="left", padx=6)
        ttk.Button(controls, text="Copy nguồn đã chọn", command=self.copy_selected_url_source).pack(side="left", padx=6)
        ttk.Button(controls, text="Xóa danh sách", style="Danger.TButton", command=self.clear_url_results).pack(side="left", padx=6)
        ttk.Label(controls, textvariable=self.vars["url_result_meta"], style="Muted.TLabel").pack(side="right")

        self.url_results_tree = ttk.Treeview(
            self.url_results_tab,
            columns=("index", "status", "type", "story", "similarity", "url"),
            show="headings",
            height=8,
            selectmode="browse",
        )
        columns = [
            ("index", "#", 54),
            ("status", "Trạng thái", 90),
            ("type", "Loại", 110),
            ("story", "Story", 70),
            ("similarity", "Độ giống", 90),
            ("url", "URL", 760),
        ]
        for key, title, width in columns:
            self.url_results_tree.heading(key, text=title)
            self.url_results_tree.column(key, width=width, minwidth=40, stretch=(key == "url"))
        self.url_results_tree.pack(fill="x", pady=(0, 8))
        self.url_results_tree.bind("<<TreeviewSelect>>", self._on_url_result_selected)

        panes = ttk.PanedWindow(self.url_results_tab, orient="horizontal")
        panes.pack(fill="both", expand=True)
        source_frame = ttk.Frame(panes)
        output_frame = ttk.Frame(panes)
        panes.add(source_frame, weight=1)
        panes.add(output_frame, weight=1)
        ttk.Label(source_frame, text="Nguồn URL đã trích", font=("Segoe UI", 11, "bold")).pack(anchor="w")
        self.url_source_preview = self._text(source_frame, height=22)
        ttk.Label(output_frame, text="Kịch bản đã viết lại của URL đã chọn", font=("Segoe UI", 11, "bold")).pack(anchor="w")
        self.url_output_preview = self._text(output_frame, height=22)
        self._render_url_results()

    def _build_translation_tab(self) -> None:
        controls = ttk.Frame(self.translation_tab)
        controls.pack(fill="x", pady=(0, 8))
        ttk.Button(controls, text="Dịch kịch bản gốc + bản mới", style="Primary.TButton", command=self.translate_for_review).pack(side="left", padx=(0, 6))
        ttk.Button(controls, text="Copy dịch gốc", command=lambda: self.copy_text_widget(self.source_translation_text)).pack(side="left", padx=6)
        ttk.Button(controls, text="Copy dịch bản mới", command=lambda: self.copy_text_widget(self.rewritten_translation_text)).pack(side="left", padx=6)
        ttk.Label(controls, text="Bắt buộc: Tiếng Việt có dấu", style="Muted.TLabel").pack(side="right")

        panes = ttk.PanedWindow(self.translation_tab, orient="horizontal")
        panes.pack(fill="both", expand=True)
        source_frame = ttk.Frame(panes)
        rewritten_frame = ttk.Frame(panes)
        panes.add(source_frame, weight=1)
        panes.add(rewritten_frame, weight=1)
        ttk.Label(source_frame, text="Bản dịch kịch bản gốc", font=("Segoe UI", 11, "bold")).pack(anchor="w")
        self.source_translation_text = self._text(source_frame)
        ttk.Label(rewritten_frame, text="Bản dịch kịch bản đã viết lại", font=("Segoe UI", 11, "bold")).pack(anchor="w")
        self.rewritten_translation_text = self._text(rewritten_frame)

    def _build_summary_tab(self) -> None:
        controls = ttk.Frame(self.summary_tab)
        controls.pack(fill="x", pady=(0, 8))
        ttk.Button(controls, text="Tóm tắt tiếng Việt + so sánh", style="Lime.TButton", command=self.summarize_scripts).pack(side="left", padx=(0, 6))
        ttk.Button(controls, text="Tóm tắt raw / không dịch", style="Primary.TButton", command=lambda: self.summarize_scripts(use_translations=False)).pack(side="left", padx=6)
        ttk.Button(controls, text="Copy tóm tắt gốc", command=lambda: self.copy_text_widget(self.source_summary_text)).pack(side="left", padx=6)
        ttk.Button(controls, text="Copy tóm tắt bản AI", command=lambda: self.copy_text_widget(self.rewritten_summary_text)).pack(side="left", padx=6)
        ttk.Button(controls, text="Copy so sánh", command=lambda: self.copy_text_widget(self.summary_compare_text)).pack(side="right")

        top = ttk.PanedWindow(self.summary_tab, orient="horizontal")
        top.pack(fill="both", expand=True)
        source_frame = ttk.Frame(top)
        rewritten_frame = ttk.Frame(top)
        top.add(source_frame, weight=1)
        top.add(rewritten_frame, weight=1)
        ttk.Label(source_frame, text="Tóm tắt kịch bản gốc", font=("Segoe UI", 11, "bold")).pack(anchor="w")
        self.source_summary_text = self._text(source_frame, height=18)
        ttk.Label(rewritten_frame, text="Tóm tắt kịch bản AI đã viết lại", font=("Segoe UI", 11, "bold")).pack(anchor="w")
        self.rewritten_summary_text = self._text(rewritten_frame, height=18)

        compare_frame = ttk.Frame(self.summary_tab)
        compare_frame.pack(fill="both", expand=True, pady=(8, 0))
        ttk.Label(compare_frame, text="So sánh trực quan", font=("Segoe UI", 11, "bold")).pack(anchor="w")
        self.summary_compare_text = self._text(compare_frame, height=14)
        self.set_text(self.source_summary_text, "Bấm Tóm tắt tiếng Việt + so sánh để tạo tóm tắt kịch bản gốc.")
        self.set_text(self.rewritten_summary_text, "Bấm Tóm tắt tiếng Việt + so sánh để tạo tóm tắt bản AI đã viết lại.")
        self.set_text(self.summary_compare_text, "Khu vực này sẽ hiển thị độ dài, ý chính, chủ đề chung, chủ đề thêm mới/bị giảm và gợi ý chỉnh sửa.")

    def _build_similarity_tab(self) -> None:
        controls = ttk.Frame(self.similarity_tab)
        controls.pack(fill="x", pady=(0, 8))
        ttk.Button(controls, text="So sánh ngay", style="Lime.TButton", command=self.score).pack(side="left", padx=(0, 6))
        ttk.Button(controls, text="Dùng Gemini output làm draft", style="Primary.TButton", command=self.use_gemini_as_draft).pack(side="left", padx=6)
        ttk.Button(controls, text="Dịch kiểm tra trước", command=self.translate_for_review).pack(side="left", padx=6)
        ttk.Button(controls, text="Copy báo cáo", command=lambda: self.copy_text_widget(self.similarity_output)).pack(side="right")

        top = ttk.Frame(self.similarity_tab)
        top.pack(fill="x", pady=(0, 8))
        metrics = ttk.Frame(top)
        metrics.pack(side="left", fill="x", expand=True)
        ttk.Label(metrics, text="Độ giống").grid(row=0, column=0, sticky="w", padx=(0, 26))
        ttk.Label(metrics, text="Độ khác biệt").grid(row=0, column=1, sticky="w", padx=(0, 26))
        ttk.Label(metrics, text="Rủi ro").grid(row=0, column=2, sticky="w", padx=(0, 26))
        ttk.Label(metrics, textvariable=self.vars["similarity_percent"], style="Metric.TLabel").grid(row=1, column=0, sticky="w", padx=(0, 26))
        ttk.Label(metrics, textvariable=self.vars["originality_percent"], style="Metric.TLabel").grid(row=1, column=1, sticky="w", padx=(0, 26))
        ttk.Label(metrics, textvariable=self.vars["risk"], style="Metric.TLabel").grid(row=1, column=2, sticky="w", padx=(0, 26))
        ttk.Label(metrics, textvariable=self.vars["similarity_mode"], style="Muted.TLabel", wraplength=640).grid(row=2, column=0, columnspan=3, sticky="w", pady=(4, 0))

        self.risk_canvas = tk.Canvas(top, width=340, height=170, bg="#07040d", highlightthickness=0)
        self.risk_canvas.pack(side="right")
        self.similarity_output = self._text(self.similarity_tab, height=28)

    def _build_planner_tab(self) -> None:
        self.retention_canvas = tk.Canvas(self.planner_tab, width=820, height=260, bg="#07040d", highlightthickness=0)
        self.retention_canvas.pack(fill="x", pady=(0, 8))
        self.planner_output = self._text(self.planner_tab, height=26)

    def _build_projects_tab(self) -> None:
        controls = ttk.Frame(self.projects_tab)
        controls.pack(fill="x", pady=(0, 8))
        ttk.Button(controls, text="Lưu dự án hiện tại", style="Lime.TButton", command=self.save_project).pack(side="left", padx=(0, 6))
        ttk.Button(controls, text="Mở dự án đã chọn", command=self.open_selected_project).pack(side="left", padx=6)
        ttk.Button(controls, text="Import JSON", style="Primary.TButton", command=self.import_project).pack(side="left", padx=6)
        ttk.Button(controls, text="Export JSON", style="Primary.TButton", command=self.export_project).pack(side="left", padx=6)
        ttk.Button(controls, text="Xóa dự án", style="Danger.TButton", command=self.delete_selected_project).pack(side="left", padx=6)
        self.projects_list = tk.Listbox(
            self.projects_tab,
            bg="#090613",
            fg="#fff4ff",
            selectbackground="#35113f",
            selectforeground="#ffffff",
            highlightthickness=1,
            highlightcolor="#ff4fd8",
            relief="flat",
            font=("Segoe UI", 11),
        )
        self.projects_list.pack(fill="both", expand=True)

    def _text(self, parent, height: int = 20, max_chars: int = TEXT_WIDGET_DEFAULT_MAX_CHARS) -> scrolledtext.ScrolledText:
        text = scrolledtext.ScrolledText(
            parent,
            height=height,
            wrap="word",
            bg="#090613",
            fg="#fff4ff",
            insertbackground="#ff4fd8",
            selectbackground="#35113f",
            selectforeground="#ffffff",
            relief="flat",
            padx=10,
            pady=10,
            font=("Consolas", 10),
        )
        text._max_chars = max_chars
        text.pack(fill="both", expand=True, pady=(4, 0))
        return text

    def _on_text_modified(self, event, which: str) -> None:
        widget = event.widget
        if widget.edit_modified():
            widget.edit_modified(False)
            if which == "source":
                self.analysis = None
                self.report = None
                self.translation_signature = None
            if which == "draft":
                self.report = None
                self.translation_signature = None
            self._render_all()

    def get_text(self, widget: scrolledtext.ScrolledText) -> str:
        return widget.get("1.0", "end-1c")

    def compact_text_for_widget(self, value: str, max_chars: int) -> str:
        value = value or ""
        if max_chars <= 0 or len(value) <= max_chars:
            return value
        keep_head = max_chars // 2
        keep_tail = max_chars - keep_head
        marker = (
            "\n\n[...Nội dung rất dài nên app đã rút gọn phần giữa để tránh hết bộ nhớ giao diện. "
            "File xuất vẫn giữ đầy đủ nội dung...]\n\n"
        )
        return value[:keep_head].rstrip() + marker + value[-keep_tail:].lstrip()

    def set_text(self, widget: scrolledtext.ScrolledText, value: str) -> None:
        max_chars = int(getattr(widget, "_max_chars", TEXT_WIDGET_DEFAULT_MAX_CHARS) or 0)
        value = self.compact_text_for_widget(value or "", max_chars)
        try:
            widget.edit_modified(False)
        except tk.TclError:
            pass
        try:
            widget.delete("1.0", "end")
            widget.insert("1.0", value)
        except tk.TclError as exc:
            fallback = self.compact_text_for_widget(str(value), min(max_chars or 80_000, 80_000))
            try:
                widget.delete("1.0", "end")
                widget.insert("1.0", fallback)
            except tk.TclError:
                messagebox.showerror(APP_NAME, f"Không đủ bộ nhớ để hiển thị nội dung này trong giao diện.\n\n{exc}")
        try:
            widget.edit_modified(False)
        except tk.TclError:
            pass

    def append_text(self, widget: scrolledtext.ScrolledText, value: str) -> None:
        try:
            widget.insert("end", value)
            max_chars = int(getattr(widget, "_max_chars", TEXT_WIDGET_DEFAULT_MAX_CHARS) or 0)
            if max_chars > 0:
                current_len = int(widget.count("1.0", "end-1c", "chars")[0])
                if current_len > max_chars:
                    delete_to = max(current_len - max_chars + 20_000, 1)
                    widget.delete("1.0", f"1.0+{delete_to}c")
                    widget.insert("1.0", "[...Log cũ đã được tự rút gọn để tránh hết bộ nhớ giao diện...]\n")
            widget.see("end")
        except tk.TclError:
            try:
                self.set_text(widget, "[Không đủ bộ nhớ để tiếp tục hiển thị log dài. App đã rút gọn log trong giao diện.]\n")
            except Exception:
                pass

    def single_gemini_api_key_text(self) -> str:
        raw = self.vars["gemini_api_key"].get().strip()
        keys = parse_gemini_api_keys(raw)
        return keys[0] if keys else raw

    def _sync_runtime_api_key(self) -> None:
        with self.runtime_api_key_lock:
            self.runtime_api_key_value = self.single_gemini_api_key_text()

    def live_gemini_api_key_text(self) -> str:
        with self.runtime_api_key_lock:
            return self.runtime_api_key_value

    def apply_runtime_api_settings(self) -> None:
        self._sync_runtime_api_key()
        self.save_settings()
        if self.has_gemini_api_key():
            self.vars["status"].set("Đã áp dụng API key mới. Tác vụ đang chờ quota sẽ tự thử lại bằng key này.")
        else:
            self.vars["status"].set("Chưa có API key hợp lệ để áp dụng.")

    def gemini_api_key_pool_text(self):
        return self.live_gemini_api_key_text

    def gemini_api_key_count(self) -> int:
        return 1 if parse_gemini_api_keys(self.gemini_api_key_pool_text()) else 0

    def has_gemini_api_key(self) -> bool:
        return self.gemini_api_key_count() > 0

    def gemini_api_key_status_text(self) -> str:
        return "đã nhập" if self.has_gemini_api_key() else "chưa nhập"

    def api_switch_callback(self, context: str):
        def callback(next_index: int, total: int, masked_key: str, error: str) -> None:
            message = f"API key {next_index}/{total}: {masked_key}"
            self.after(
                0,
                lambda: (
                    self.vars["status"].set(f"{context}: API key hiện tại bị limit/quá tải"),
                    self.append_text(self.gemini_output, f"\n[API] {context}: API key hiện tại bị limit/quá tải. Hãy thử lại sau hoặc thay key khác nếu cần.\n"),
                ),
            )
        return callback

    def start_task_feedback(self, message: str, indeterminate: bool = False) -> None:
        old_cancel_event = self.cancel_event
        if old_cancel_event:
            old_cancel_event.set()
        close_active_gemini_responses()
        with self.task_lock:
            if self.task_serial:
                self.cancelled_task_serials.add(self.task_serial)
            self.task_serial += 1
            task_id = self.task_serial
            self.cancelled_task_serials = {item for item in self.cancelled_task_serials if item >= task_id - 3}
        self.cancel_event = threading.Event()
        self.active_task_started_at = time.time()
        self.vars["progress_value"].set(0)
        self.vars["progress_text"].set(message)
        self.vars["status"].set(message)
        if hasattr(self, "progress_bar"):
            self.progress_bar.configure(mode="indeterminate" if indeterminate else "determinate")
            if indeterminate:
                self.progress_bar.start(10)
            else:
                self.progress_bar.stop()
        if hasattr(self, "cancel_button"):
            self.cancel_button.configure(state="normal")
        if hasattr(self, "training_cancel_button"):
            self.training_cancel_button.configure(state="normal")
        self._tick_task_timer()
        return task_id

    def finish_task_feedback(self, message: str, success: bool = True, task_id: int | None = None) -> None:
        if task_id is not None and not self.is_task_current(task_id):
            return
        if hasattr(self, "progress_bar"):
            self.progress_bar.stop()
            self.progress_bar.configure(mode="determinate")
        if hasattr(self, "cancel_button"):
            self.cancel_button.configure(state="disabled")
        if hasattr(self, "training_cancel_button"):
            self.training_cancel_button.configure(state="disabled")
        if self.progress_timer_id:
            try:
                self.after_cancel(self.progress_timer_id)
            except Exception:
                pass
            self.progress_timer_id = None
        self.vars["progress_value"].set(100 if success else 0)
        self.vars["progress_text"].set(message)
        self.vars["status"].set(message)
        self.active_task_started_at = None
        self.cancel_event = None
        gc.collect()

    def is_task_current(self, task_id: int | None) -> bool:
        if task_id is None:
            return True
        with self.task_lock:
            return task_id == self.task_serial and task_id not in self.cancelled_task_serials

    def task_cancelled(self, task_id: int | None, cancel_event=None) -> bool:
        if cancel_event and cancel_event.is_set():
            return True
        return not self.is_task_current(task_id)

    def after_task(self, task_id: int | None, callback, *args) -> None:
        self.after(0, lambda: callback(*args) if self.is_task_current(task_id) else None)

    def _tick_task_timer(self) -> None:
        if not self.active_task_started_at:
            return
        elapsed = int(time.time() - self.active_task_started_at)
        base = self.vars["progress_text"].get().split(" | ")[0]
        self.vars["progress_text"].set(f"{base} | {elapsed}s")
        self.progress_timer_id = self.after(1000, self._tick_task_timer)

    def update_progress(self, current: int, total: int, message: str) -> None:
        percent = min(100, max(0, current / max(total, 1) * 100))
        self.vars["progress_value"].set(percent)
        self.vars["progress_text"].set(f"{message} ({percent:.1f}%)")
        self.vars["status"].set(message)

    def set_indeterminate_progress(self, message: str) -> None:
        self.vars["progress_text"].set(message)
        self.vars["status"].set(message)
        if hasattr(self, "progress_bar"):
            self.progress_bar.configure(mode="indeterminate")
            self.progress_bar.start(10)
        if hasattr(self, "cancel_button"):
            self.cancel_button.configure(state="normal")
        if hasattr(self, "training_cancel_button"):
            self.training_cancel_button.configure(state="normal")

    def cancel_current_task(self) -> None:
        if self.cancel_event:
            self.cancel_event.set()
        with self.task_lock:
            if self.task_serial:
                self.cancelled_task_serials.add(self.task_serial)
                self.task_serial += 1
        close_active_gemini_responses()
        if hasattr(self, "progress_bar"):
            self.progress_bar.stop()
            self.progress_bar.configure(mode="determinate")
        if self.progress_timer_id:
            try:
                self.after_cancel(self.progress_timer_id)
            except Exception:
                pass
            self.progress_timer_id = None
        self._set_buttons_state("normal")
        if hasattr(self, "cancel_button"):
            self.cancel_button.configure(state="disabled")
        if hasattr(self, "training_cancel_button"):
            self.training_cancel_button.configure(state="disabled")
        self.active_task_started_at = None
        self.cancel_event = None
        self.vars["progress_value"].set(0)
        self.vars["progress_text"].set("Đã hủy trong app. Có thể chạy tác vụ mới ngay.")
        self.vars["status"].set("Đã hủy tác vụ. Bạn có thể chạy tác vụ mới ngay.")
        gc.collect()

    def video_cache_key(self, path: Path) -> str:
        stat = path.stat()
        return f"{path.resolve()}::{stat.st_size}::{int(stat.st_mtime)}"

    def _training_samples(self) -> str:
        samples = self.get_text(self.training_samples_text).strip() if hasattr(self, "training_samples_text") else ""
        if samples:
            return samples
        return self.get_text(self.source_text).strip() if hasattr(self, "source_text") else ""

    def _refresh_training_sample_meta(self) -> None:
        samples = self.get_text(self.training_samples_text).strip() if hasattr(self, "training_samples_text") else ""
        if not samples:
            self.vars["training_sample_meta"].set("Chưa có mẫu huấn luyện")
            return
        units = len(normalize_words(samples))
        blocks = samples.count("===== MẪU") or 1
        self.vars["training_sample_meta"].set(f"{blocks} mẫu | {format_int_vn(units)} từ")

    def _append_training_sample(self, title: str, text: str) -> None:
        cleaned = clean_imported_script(text)
        if not cleaned:
            return
        current = self.get_text(self.training_samples_text).strip()
        block = f"===== MẪU: {title} =====\n{cleaned}"
        self.set_text(self.training_samples_text, f"{current}\n\n{block}".strip() if current else block)
        self._refresh_training_sample_meta()
        self.save_settings()

    def add_current_source_to_training(self) -> None:
        source = self.get_text(self.source_text).strip()
        if not source:
            messagebox.showwarning(APP_NAME, "Chưa có kịch bản gốc/transcript để nạp làm mẫu huấn luyện.")
            return
        self._append_training_sample("Nguồn hiện tại", source)
        self.notebook.select(self.training_tab)
        self.vars["status"].set("Đã nạp nguồn hiện tại vào mẫu huấn luyện")

    def import_training_sample_files(self) -> None:
        paths = filedialog.askopenfilenames(filetypes=SCRIPT_FILE_TYPES, title="Chọn file kịch bản mẫu để huấn luyện")
        if not paths:
            return
        imported = 0
        errors: list[str] = []
        for path_text in paths:
            path = Path(path_text)
            try:
                raw_text = read_script_file(path)
                self._append_training_sample(path.name, raw_text)
                imported += 1
            except Exception as exc:
                errors.append(f"{path.name}: {exc}")
        self.notebook.select(self.training_tab)
        if errors:
            messagebox.showwarning(APP_NAME, "Một số file mẫu không đọc được:\n" + "\n".join(errors[:8]))
        self.vars["status"].set(f"Đã nhập {imported} file mẫu huấn luyện")

    def import_training_sample_folder(self) -> None:
        folder = filedialog.askdirectory(title="Chọn thư mục chứa kịch bản mẫu huấn luyện")
        if not folder:
            return
        root = Path(folder)
        files = [path for path in root.rglob("*") if path.is_file() and path.suffix.lower() in SCRIPT_SUFFIXES]
        files.sort(key=lambda path: path.name.lower())
        if not files:
            messagebox.showwarning(APP_NAME, "Không tìm thấy file kịch bản mẫu trong thư mục này.")
            return
        if len(files) > 100:
            messagebox.showinfo(APP_NAME, f"Tìm thấy {len(files)} file. App sẽ nạp 100 file đầu tiên để tránh quá nặng.")
            files = files[:100]
        imported = 0
        errors: list[str] = []
        for path in files:
            try:
                self._append_training_sample(path.name, read_script_file(path))
                imported += 1
            except Exception as exc:
                errors.append(f"{path.name}: {exc}")
        self.notebook.select(self.training_tab)
        if errors:
            messagebox.showwarning(APP_NAME, "Một số file mẫu không đọc được:\n" + "\n".join(errors[:8]))
        self.vars["status"].set(f"Đã nạp {imported} file mẫu từ folder")

    def paste_training_sample_from_clipboard(self) -> None:
        try:
            text = self.clipboard_get()
        except tk.TclError:
            text = ""
        if not text.strip():
            messagebox.showwarning(APP_NAME, "Clipboard không có text mẫu để huấn luyện.")
            return
        self._append_training_sample("Clipboard", text)
        self.notebook.select(self.training_tab)
        self.vars["status"].set("Đã dán mẫu huấn luyện từ clipboard")

    def clear_training_samples(self) -> None:
        self.set_text(self.training_samples_text, "")
        self._refresh_training_sample_meta()
        self.save_settings()
        self.vars["status"].set("Đã xóa mẫu huấn luyện")

    def clear_training_profile(self) -> None:
        self.set_text(self.training_text, "")
        self.vars["training_quality"].set("Profile: chưa chấm")
        self.vars["status"].set("Đã xóa training profile")

    def copy_training_profile(self) -> None:
        profile = self.get_text(self.training_text).strip()
        self.clipboard_clear()
        self.clipboard_append(profile)
        self.vars["status"].set("Đã copy training profile")

    def save_training_profile(self) -> None:
        self.vars["use_training_profile"].set(True)
        self.score_training_profile(show_tab=False)
        self.save_settings()
        self.vars["status"].set("Đã lưu training profile vào settings")

    def load_training_template_40plus(self) -> None:
        self.set_text(self.training_text, training_profile_40plus_template(self.config_dict()))
        self.set_text(self.training_negative_text, default_negative_training_rules())
        self.set_text(self.training_locked_text, default_locked_training_rules())
        self.vars["use_training_profile"].set(True)
        self.score_training_profile(show_tab=False)
        self.save_settings()
        self.notebook.select(self.training_tab)
        self.vars["status"].set("Đã nạp profile mẫu 40+")

    def improve_training_profile_local(self) -> None:
        samples = self._training_samples()
        profile = self.get_text(self.training_text).strip()
        if not samples and not profile:
            messagebox.showwarning(APP_NAME, "Cần có profile hoặc mẫu huấn luyện để nâng cấp.")
            return
        local_profile = build_local_training_profile(samples or profile, self.config_dict())
        merged = merge_training_profile(
            profile,
            local_profile,
            self.get_text(self.training_negative_text),
            self.get_text(self.training_locked_text),
            self.config_dict(),
        )
        self.set_text(self.training_text, merged)
        self.vars["use_training_profile"].set(True)
        self.score_training_profile(show_tab=False)
        self.save_settings()
        self.notebook.select(self.training_tab)
        self.vars["status"].set("Đã nâng cấp training profile local")

    def score_training_profile(self, show_tab: bool = True) -> None:
        profile = self.get_text(self.training_text).strip()
        samples = self._training_samples()
        negative = self.get_text(self.training_negative_text) if hasattr(self, "training_negative_text") else ""
        locked = self.get_text(self.training_locked_text) if hasattr(self, "training_locked_text") else ""
        quality = training_profile_quality(profile, samples, negative, locked)
        self.vars["training_quality"].set(f"Profile: {quality['score']}/100 - {quality['level']}")
        report = training_quality_report(profile, samples, negative, locked)
        self.set_text(self.gemini_output, report)
        if show_tab:
            self.notebook.select(self.training_tab)
        self.vars["status"].set(f"Đã chấm training profile: {quality['score']}/100")

    def _training_profile_payload(self) -> dict:
        profile = self.get_text(self.training_text).strip()
        samples = self.get_text(self.training_samples_text).strip() if hasattr(self, "training_samples_text") else ""
        negative = self.get_text(self.training_negative_text).strip() if hasattr(self, "training_negative_text") else ""
        locked = self.get_text(self.training_locked_text).strip() if hasattr(self, "training_locked_text") else ""
        quality = training_profile_quality(profile, samples, negative, locked)
        return {
            "version": 2,
            "id": f"profile-{int(time.time())}",
            "name": self.vars["training_profile_name"].get().strip() or "Training profile",
            "updated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "profile": profile,
            "samples": samples,
            "negative_rules": negative,
            "locked_rules": locked,
            "quality": quality,
            "config": self.config_dict(),
        }

    def save_training_profile_to_library(self) -> None:
        payload = self._training_profile_payload()
        if not payload["profile"]:
            messagebox.showwarning(APP_NAME, "Chưa có training profile để lưu vào thư viện.")
            return
        existing = next((i for i, item in enumerate(self.training_profiles) if item.get("name") == payload["name"]), None)
        if existing is None:
            self.training_profiles.insert(0, payload)
        else:
            payload["id"] = self.training_profiles[existing].get("id", payload["id"])
            self.training_profiles[existing] = payload
        self.training_profiles = self.training_profiles[:80]
        save_json(TRAINING_PROFILES_FILE, self.training_profiles)
        self._render_training_profiles()
        self.vars["status"].set(f"Đã lưu profile vào thư viện: {payload['name']}")

    def _render_training_profiles(self) -> None:
        if not hasattr(self, "training_profiles_list"):
            return
        self.training_profiles_list.delete(0, "end")
        if not self.training_profiles:
            self.training_profiles_list.insert("end", "Chưa có profile nào. Hãy tạo profile rồi bấm Lưu vào thư viện.")
            return
        for item in self.training_profiles:
            quality = item.get("quality", {})
            score = quality.get("score", "N/A")
            level = quality.get("level", "")
            name = item.get("name", "Training profile")
            updated = item.get("updated_at", "")
            self.training_profiles_list.insert("end", f"{name} | {score}/100 {level} | {updated}")

    def _selected_training_profile(self) -> dict | None:
        if not hasattr(self, "training_profiles_list") or not self.training_profiles:
            return None
        selection = self.training_profiles_list.curselection()
        if not selection:
            return None
        index = selection[0]
        if 0 <= index < len(self.training_profiles):
            return self.training_profiles[index]
        return None

    def _on_training_profile_selected(self, _event=None) -> None:
        item = self._selected_training_profile()
        if not item:
            return
        quality = item.get("quality", {})
        self.vars["training_quality"].set(f"Profile chọn: {quality.get('score', 'N/A')}/100 - {quality.get('level', '')}")

    def open_selected_training_profile(self) -> None:
        item = self._selected_training_profile()
        if not item:
            return
        self.vars["training_profile_name"].set(item.get("name", "Training profile"))
        self.set_text(self.training_text, item.get("profile", ""))
        self.set_text(self.training_samples_text, item.get("samples", ""))
        self.set_text(self.training_negative_text, item.get("negative_rules", ""))
        self.set_text(self.training_locked_text, item.get("locked_rules", ""))
        self._refresh_training_sample_meta()
        quality = item.get("quality") or training_profile_quality(item.get("profile", ""), item.get("samples", ""), item.get("negative_rules", ""), item.get("locked_rules", ""))
        self.vars["training_quality"].set(f"Profile: {quality.get('score', 'N/A')}/100 - {quality.get('level', '')}")
        self.vars["use_training_profile"].set(True)
        self.save_settings()
        self.vars["status"].set(f"Đã mở training profile: {item.get('name', '')}")

    def delete_selected_training_profile(self) -> None:
        if not hasattr(self, "training_profiles_list") or not self.training_profiles:
            return
        selection = self.training_profiles_list.curselection()
        if not selection:
            return
        del self.training_profiles[selection[0]]
        save_json(TRAINING_PROFILES_FILE, self.training_profiles)
        self._render_training_profiles()
        self.vars["status"].set("Đã xóa profile khỏi thư viện")

    def export_training_profile_file(self) -> None:
        payload = self._training_profile_payload()
        if not payload["profile"]:
            messagebox.showwarning(APP_NAME, "Chưa có training profile để export.")
            return
        path = filedialog.asksaveasfilename(
            defaultextension=".json",
            filetypes=[("Training profile JSON", "*.json"), ("Text", "*.txt"), ("All files", "*.*")],
            initialfile=f"{safe_filename(payload['name'])}_training_profile.json",
        )
        if not path:
            return
        out_path = Path(path)
        if out_path.suffix.lower() == ".txt":
            out_path.write_text(payload["profile"], encoding="utf-8-sig")
        else:
            out_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        self.vars["status"].set(f"Đã export training profile: {out_path.name}")

    def import_training_profile_file(self) -> None:
        path_text = filedialog.askopenfilename(filetypes=[("Training profile", "*.json *.txt *.md"), ("All files", "*.*")])
        if not path_text:
            return
        path = Path(path_text)
        try:
            raw = read_script_file(path)
            payload = json.loads(raw) if path.suffix.lower() == ".json" else None
        except Exception:
            payload = None
            raw = read_script_file(path)
        if isinstance(payload, dict):
            self.vars["training_profile_name"].set(payload.get("name", path.stem))
            self.set_text(self.training_text, payload.get("profile", raw))
            self.set_text(self.training_samples_text, payload.get("samples", ""))
            self.set_text(self.training_negative_text, payload.get("negative_rules", ""))
            self.set_text(self.training_locked_text, payload.get("locked_rules", ""))
        else:
            self.vars["training_profile_name"].set(path.stem)
            self.set_text(self.training_text, raw)
        self._refresh_training_sample_meta()
        self.score_training_profile(show_tab=False)
        self.vars["use_training_profile"].set(True)
        self.save_settings()
        self.notebook.select(self.training_tab)
        self.vars["status"].set(f"Đã import training profile: {path.name}")

    def generate_training_profile_local(self) -> None:
        samples = self._training_samples()
        if not samples:
            messagebox.showwarning(APP_NAME, "Hãy nạp ít nhất một kịch bản mẫu hoặc có kịch bản gốc trước khi tạo profile.")
            return
        profile = build_local_training_profile(samples, self.config_dict())
        self.set_text(self.training_text, profile)
        self.vars["use_training_profile"].set(True)
        self.score_training_profile(show_tab=False)
        self.save_settings()
        self.notebook.select(self.training_tab)
        self.vars["status"].set("Đã tạo training profile nhanh")

    def generate_training_profile_with_gemini(self) -> None:
        samples = self._training_samples()
        if not samples:
            messagebox.showwarning(APP_NAME, "Hãy nạp kịch bản mẫu hoặc có kịch bản gốc trước khi Gemini học profile.")
            return
        config = self.config_dict()
        if config.get("test_mode_no_api"):
            self.generate_training_profile_local()
            self.vars["status"].set("Test không gọi API: đã tạo training profile local")
            return
        api_key = self.gemini_api_key_pool_text()
        if not parse_gemini_api_keys(api_key) and not config.get("cache_only_mode"):
            messagebox.showwarning(APP_NAME, "Cần nhập Gemini API key để Gemini học profile.")
            return
        system = "Bạn là chuyên gia phân tích phong cách kênh và tạo channel training profile. Bắt buộc chỉ trả profile bằng tiếng Việt có dấu."
        prompt = build_training_profile_prompt(samples, config)
        generation_config = {"temperature": 0.35, "topP": 0.85, "maxOutputTokens": 4500}
        cache_key = gemini_cache_key(config["gemini_model"], system, prompt, generation_config, "training_profile")
        use_cache = bool(self.vars["use_cache"].get())
        if use_cache and cache_key in self.gemini_cache:
            cached = self.gemini_cache[cache_key].get("output", "")
            if cached and valid_vietnamese_training_profile(cached):
                self._training_profile_done(cached, from_cache=True)
                return
        if config.get("cache_only_mode"):
            self.notebook.select(self.training_tab)
            self.set_text(self.training_text, "Đang bật 'Chỉ dùng cache, không gọi API mới'.\n\nTraining profile này chưa có cache nên app đã dừng sớm để không tốn quota Gemini.\n\nCó thể dùng nút 'Tạo profile nhanh' để tạo profile local không tốn API.")
            self.vars["status"].set("Cache-only: chưa có cache training profile")
            return
        self.notebook.select(self.training_tab)
        self.set_text(self.training_text, "Đang để Gemini học phong cách từ mẫu...\n")
        task_id = self.start_task_feedback("Gemini đang tạo training profile...", indeterminate=True)
        self._set_buttons_state("disabled")
        cancel_event = self.cancel_event

        def worker() -> None:
            try:
                def on_rate_limit(delay: int, attempt: int, total: int) -> None:
                    self.after(
                        0,
                        lambda d=delay, a=attempt, t=total: self.set_indeterminate_progress(
                            f"Gemini bị giới hạn quota khi học profile, đợi {d}s rồi thử lại ({a}/{t})..."
                        ) if self.is_task_current(task_id) else None,
                    )

                def retry_profile_vietnamese(reason: str) -> str:
                    strict_prompt = (
                        prompt
                        + "\n\nLỖI CẦN SỬA: Kết quả trước chưa phải tiếng Việt có dấu. "
                        "Hãy tạo lại profile hoàn chỉnh 100% bằng tiếng Việt có dấu, không dùng tiếng Hàn/Nhật/Trung/Anh trừ tên riêng."
                    )
                    self.after(
                        0,
                        lambda r=reason: (
                            self.set_text(self.training_text, f"Profile chưa đúng tiếng Việt ({r}). Đang tạo lại bằng chế độ ép tiếng Việt...\n\n"),
                            self.set_indeterminate_progress("Đang tạo lại training profile bằng tiếng Việt..."),
                        ) if self.is_task_current(task_id) else None,
                    )
                    return call_gemini_stream(
                        api_key,
                        config["gemini_model"],
                        system,
                        strict_prompt,
                        generation_config,
                        chunk_callback=lambda chunk: self.after(0, lambda value=chunk: self.append_text(self.training_text, value) if self.is_task_current(task_id) else None),
                        cancel_event=cancel_event,
                        retry_callback=on_rate_limit,
                        api_switch_callback=self.api_switch_callback("Training profile retry"),
                    )

                if self.vars["use_streaming"].get():
                    self.after(0, lambda: self.set_text(self.training_text, "") if self.is_task_current(task_id) else None)

                    def on_chunk(chunk: str) -> None:
                        self.after(0, lambda value=chunk: self.append_text(self.training_text, value) if self.is_task_current(task_id) else None)

                    output = call_gemini_stream(
                        api_key,
                        config["gemini_model"],
                        system,
                        prompt,
                        generation_config,
                        chunk_callback=on_chunk,
                        cancel_event=cancel_event,
                        retry_callback=on_rate_limit,
                        api_switch_callback=self.api_switch_callback("Training profile"),
                    )
                else:
                    output = call_gemini(
                        api_key,
                        config["gemini_model"],
                        system,
                        prompt,
                        generation_config,
                        cancel_event=cancel_event,
                        retry_callback=on_rate_limit,
                        api_switch_callback=self.api_switch_callback("Training profile"),
                    )
                mismatch = language_mismatch_warning(output, "Tiếng Việt")
                if mismatch:
                    output = retry_profile_vietnamese(mismatch)
                    mismatch = language_mismatch_warning(output, "Tiếng Việt")
                    if mismatch:
                        raise RuntimeError(f"Training profile chưa đúng tiếng Việt: {mismatch}. Hãy thử model khác hoặc chạy lại.")
                if self.task_cancelled(task_id, cancel_event):
                    return
                if use_cache and output:
                    self.gemini_cache[cache_key] = {
                        "mode": "training_profile",
                        "model": config["gemini_model"],
                        "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                        "output": output,
                    }
                    save_gemini_cache_file(self.gemini_cache)
                self.after_task(task_id, self._training_profile_done, output)
            except Exception as exc:
                if self.task_cancelled(task_id, cancel_event):
                    return
                self.after_task(task_id, self._training_profile_error, str(exc))

        threading.Thread(target=worker, daemon=True).start()

    def _training_profile_done(self, output: str, from_cache: bool = False) -> None:
        self._set_buttons_state("normal")
        self.finish_task_feedback("Đã dùng cache training profile" if from_cache else "Gemini đã tạo training profile")
        self.set_text(self.training_text, output.strip())
        self.vars["use_training_profile"].set(True)
        self.score_training_profile(show_tab=False)
        self.save_settings()
        self.notebook.select(self.training_tab)
        self.vars["status"].set("Đã bật training profile cho các lần viết tiếp theo")

    def _training_profile_error(self, error: str) -> None:
        self._set_buttons_state("normal")
        self.finish_task_feedback("Lỗi tạo training profile", success=False)
        self.set_text(self.training_text, f"Lỗi tạo training profile:\n{error}")
        messagebox.showerror(APP_NAME, error[:1200])

    def chat_output_dir(self) -> Path:
        folder = APP_DIR / "chat_images"
        folder.mkdir(parents=True, exist_ok=True)
        return folder

    def add_chat_attachments_dialog(self) -> None:
        paths = filedialog.askopenfilenames(
            title="Chọn file đính kèm cho Chat AI",
            filetypes=[
                ("Supported", "*.png *.jpg *.jpeg *.webp *.heic *.heif *.pdf *.txt *.md *.docx *.csv *.json *.srt *.vtt *.mp3 *.wav *.m4a *.mp4 *.mov *.webm"),
                ("Images", "*.png *.jpg *.jpeg *.webp *.heic *.heif"),
                ("Documents", "*.pdf *.txt *.md *.docx *.csv *.json *.srt *.vtt"),
                ("Audio/video", "*.mp3 *.wav *.m4a *.mp4 *.mov *.webm"),
                ("All files", "*.*"),
            ],
        )
        self.add_chat_attachment_paths(paths)

    def add_chat_attachment_paths(self, paths) -> None:
        added = 0
        skipped: list[str] = []
        existing = {str(path.resolve()).lower() for path in self.chat_attachments if path.exists()}
        for value in paths or []:
            path = Path(str(value).strip("{}")).expanduser()
            if not path.exists():
                skipped.append(str(path))
                continue
            if path.is_dir():
                skipped.append(f"{path} (folder chưa hỗ trợ kéo trực tiếp)")
                continue
            key = str(path.resolve()).lower()
            if key in existing:
                continue
            self.chat_attachments.append(path)
            existing.add(key)
            added += 1
        self.refresh_chat_attachment_meta()
        if added:
            self.notebook.select(self.chat_tab)
            self.vars["status"].set(f"Đã đính kèm {added} file vào Chat AI")
        if skipped:
            self.append_text(self.chat_output, "\n[FILE BỎ QUA]\n" + "\n".join(f"- {item}" for item in skipped[:8]) + "\n")

    def refresh_chat_attachment_meta(self) -> None:
        if not self.chat_attachments:
            self.vars["chat_attachment_meta"].set("Chưa đính kèm file. Có thể bấm Đính kèm file hoặc kéo file vào cửa sổ app.")
            return
        labels = []
        for path in self.chat_attachments[:6]:
            try:
                labels.append(f"{path.name} ({path.stat().st_size / (1024 * 1024):.1f} MB)")
            except OSError:
                labels.append(path.name)
        extra = "" if len(self.chat_attachments) <= 6 else f" +{len(self.chat_attachments) - 6} file"
        self.vars["chat_attachment_meta"].set(f"Đang đính kèm {len(self.chat_attachments)} file: {', '.join(labels)}{extra}")

    def clear_chat_attachments(self) -> None:
        self.chat_attachments = []
        self.chat_image_refs = []
        self.refresh_chat_attachment_meta()
        gc.collect()
        self.vars["status"].set("Đã xóa file đính kèm Chat AI")

    def append_chat_image_preview(self, path: Path) -> None:
        self.append_text(self.chat_output, f"\n\n[Ảnh đã lưu] {path}\n")
        if path.suffix.lower() not in {".png", ".gif"}:
            return
        try:
            photo = tk.PhotoImage(file=str(path))
            max_width = 620
            if photo.width() > max_width:
                factor = max(1, math.ceil(photo.width() / max_width))
                photo = photo.subsample(factor, factor)
            self.chat_image_refs.append(photo)
            if len(self.chat_image_refs) > CHAT_IMAGE_PREVIEW_MAX_REFS:
                self.chat_image_refs = self.chat_image_refs[-CHAT_IMAGE_PREVIEW_MAX_REFS:]
            self.chat_output.image_create("end", image=photo)
            self.append_text(self.chat_output, "\n")
        except Exception:
            pass

    def enable_windows_file_drop(self) -> None:
        if sys.platform != "win32" or getattr(self, "_windows_drop_enabled", False):
            return
        try:
            self.update_idletasks()
            hwnd = self.winfo_id()
            user32 = ctypes.windll.user32
            shell32 = ctypes.windll.shell32
            WM_DROPFILES = 0x0233
            GWLP_WNDPROC = -4
            WNDPROC = ctypes.WINFUNCTYPE(ctypes.c_longlong, ctypes.c_void_p, ctypes.c_uint, ctypes.c_void_p, ctypes.c_void_p)

            user32.SetWindowLongPtrW.restype = ctypes.c_void_p
            user32.SetWindowLongPtrW.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_void_p]
            user32.CallWindowProcW.restype = ctypes.c_longlong
            user32.CallWindowProcW.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_uint, ctypes.c_void_p, ctypes.c_void_p]
            shell32.DragAcceptFiles.argtypes = [ctypes.c_void_p, ctypes.c_bool]
            shell32.DragQueryFileW.argtypes = [ctypes.c_void_p, ctypes.c_uint, ctypes.c_void_p, ctypes.c_uint]
            shell32.DragQueryFileW.restype = ctypes.c_uint
            shell32.DragFinish.argtypes = [ctypes.c_void_p]

            def wndproc(window_handle, message, wparam, lparam):
                if message == WM_DROPFILES:
                    try:
                        count = shell32.DragQueryFileW(wparam, 0xFFFFFFFF, None, 0)
                        paths: list[str] = []
                        for index in range(count):
                            length = shell32.DragQueryFileW(wparam, index, None, 0)
                            buffer = ctypes.create_unicode_buffer(length + 1)
                            shell32.DragQueryFileW(wparam, index, ctypes.cast(buffer, ctypes.c_void_p), length + 1)
                            paths.append(buffer.value)
                        shell32.DragFinish(wparam)
                        if paths:
                            self.after(0, lambda values=paths: self.add_chat_attachment_paths(values))
                        return 0
                    except Exception:
                        try:
                            shell32.DragFinish(wparam)
                        except Exception:
                            pass
                        return 0
                return user32.CallWindowProcW(self._old_drop_wndproc, window_handle, message, wparam, lparam)

            self._drop_wndproc = WNDPROC(wndproc)
            self._old_drop_wndproc = user32.SetWindowLongPtrW(hwnd, GWLP_WNDPROC, self._drop_wndproc)
            shell32.DragAcceptFiles(hwnd, True)
            self._windows_drop_enabled = True
            self.refresh_chat_attachment_meta()
        except Exception:
            self._windows_drop_enabled = False

    def show_training_upgrade_suggestions(self) -> None:
        profile = self.get_text(self.training_text).strip()
        samples = self._training_samples()
        negative = self.get_text(self.training_negative_text).strip() if hasattr(self, "training_negative_text") else ""
        locked = self.get_text(self.training_locked_text).strip() if hasattr(self, "training_locked_text") else ""
        report = training_upgrade_suggestions_text(profile, samples, negative, locked, self.config_dict())
        self.score_training_profile(show_tab=False)
        self.set_text(self.gemini_output, report)
        self.notebook.select(self.gemini_tab)
        self.vars["status"].set("Đã tạo gợi ý nâng cấp phần huấn luyện")

    def show_training_story_idea_bank(self) -> None:
        report = training_story_idea_bank_text(self.config_dict())
        self.set_text(self.gemini_output, report)
        if hasattr(self, "custom_ideas_text") and not self.custom_ideas_value():
            self.set_custom_ideas_value(trend_idea_seed_text(self.config_dict()).strip())
            self.save_settings()
        self.notebook.select(self.gemini_tab)
        self.vars["status"].set("Đã mở kho ý tưởng global và nạp trend seed vào ô Ý tưởng riêng nếu đang trống")

    def append_training_story_idea_rules(self) -> None:
        current = self.get_text(self.training_locked_text).strip() if hasattr(self, "training_locked_text") else ""
        addition = training_story_idea_locked_rules()
        if addition in current:
            self.vars["status"].set("Luật ý tưởng đã có trong Locked rules")
            return
        merged = f"{current}\n\n{addition}".strip() if current else addition
        self.set_text(self.training_locked_text, merged)
        self.vars["use_training_profile"].set(True)
        self.score_training_profile(show_tab=False)
        self.save_settings()
        self.notebook.select(self.training_tab)
        self.vars["status"].set("Đã thêm Story Idea Engine + Market Trend Engine vào huấn luyện")

    def upgrade_training_profile_with_gemini(self) -> None:
        profile = self.get_text(self.training_text).strip()
        samples = self._training_samples()
        if not profile and not samples:
            messagebox.showwarning(APP_NAME, "Cần có training profile hoặc mẫu huấn luyện trước khi nâng cấp.")
            return
        negative = self.get_text(self.training_negative_text).strip() if hasattr(self, "training_negative_text") else ""
        locked = self.get_text(self.training_locked_text).strip() if hasattr(self, "training_locked_text") else ""
        config = self.config_dict()
        if config.get("test_mode_no_api"):
            local_profile = build_local_training_profile(samples or profile, config)
            output = merge_training_profile(profile, local_profile, negative, locked, config)
            self._training_profile_done(output, from_cache=False)
            self.vars["status"].set("Test không gọi API: đã nâng cấp training profile local")
            return
        api_key = self.gemini_api_key_pool_text()
        if not parse_gemini_api_keys(api_key) and not config.get("cache_only_mode"):
            messagebox.showwarning(APP_NAME, "Cần nhập Gemini API key để AI nâng cấp profile.")
            return
        system = "Bạn là chuyên gia tối ưu prompt-training/profile cho kênh kể chuyện video. Chỉ trả về profile hoàn chỉnh bằng tiếng Việt có dấu."
        prompt = build_training_profile_upgrade_prompt(profile, samples, config, negative, locked)
        generation_config = {"temperature": 0.35, "topP": 0.85, "maxOutputTokens": 6500}
        cache_key = gemini_cache_key(config["gemini_model"], system, prompt, generation_config, "training_profile_upgrade")
        use_cache = bool(self.vars["use_cache"].get())
        if use_cache and cache_key in self.gemini_cache:
            cached = self.gemini_cache[cache_key].get("output", "")
            if cached and valid_vietnamese_training_profile(cached):
                self._training_profile_done(cached, from_cache=True)
                return
        if config.get("cache_only_mode"):
            self.notebook.select(self.training_tab)
            self.set_text(self.training_text, "Đang bật 'Chỉ dùng cache, không gọi API mới'.\n\nBản nâng cấp training này chưa có cache nên app đã dừng sớm để không tốn quota Gemini.\n\nCó thể bật 'Test không gọi API' để nâng cấp local.")
            self.vars["status"].set("Cache-only: chưa có cache nâng cấp training")
            return
        self.notebook.select(self.training_tab)
        self.set_text(self.training_text, "Đang để Gemini nâng cấp training profile...\n")
        task_id = self.start_task_feedback("Gemini đang nâng cấp training profile...", indeterminate=True)
        self._set_buttons_state("disabled")
        cancel_event = self.cancel_event

        def worker() -> None:
            try:
                def on_rate_limit(delay: int, attempt: int, total: int) -> None:
                    self.after(
                        0,
                        lambda d=delay, a=attempt, t=total: self.set_indeterminate_progress(
                            f"Gemini bị giới hạn quota khi nâng cấp profile, đợi {d}s rồi thử lại ({a}/{t})..."
                        ) if self.is_task_current(task_id) else None,
                    )

                def retry_profile_vietnamese(reason: str) -> str:
                    strict_prompt = (
                        prompt
                        + "\n\nLỖI CẦN SỬA: Kết quả trước chưa phải tiếng Việt có dấu. "
                        "Hãy nâng cấp lại profile hoàn chỉnh 100% bằng tiếng Việt có dấu, không dùng tiếng Hàn/Nhật/Trung/Anh trừ tên riêng."
                    )
                    self.after(
                        0,
                        lambda r=reason: (
                            self.set_text(self.training_text, f"Profile nâng cấp chưa đúng tiếng Việt ({r}). Đang nâng cấp lại bằng chế độ ép tiếng Việt...\n\n"),
                            self.set_indeterminate_progress("Đang nâng cấp lại training profile bằng tiếng Việt..."),
                        ) if self.is_task_current(task_id) else None,
                    )
                    return call_gemini_stream(
                        api_key,
                        config["gemini_model"],
                        system,
                        strict_prompt,
                        generation_config,
                        chunk_callback=lambda chunk: self.after(0, lambda value=chunk: self.append_text(self.training_text, value) if self.is_task_current(task_id) else None),
                        cancel_event=cancel_event,
                        retry_callback=on_rate_limit,
                        api_switch_callback=self.api_switch_callback("Nâng cấp training profile retry"),
                    )

                if self.vars["use_streaming"].get():
                    self.after(0, lambda: self.set_text(self.training_text, "") if self.is_task_current(task_id) else None)

                    def on_chunk(chunk: str) -> None:
                        self.after(0, lambda value=chunk: self.append_text(self.training_text, value) if self.is_task_current(task_id) else None)

                    output = call_gemini_stream(
                        api_key,
                        config["gemini_model"],
                        system,
                        prompt,
                        generation_config,
                        chunk_callback=on_chunk,
                        cancel_event=cancel_event,
                        retry_callback=on_rate_limit,
                        api_switch_callback=self.api_switch_callback("Nâng cấp training profile"),
                    )
                else:
                    output = call_gemini(
                        api_key,
                        config["gemini_model"],
                        system,
                        prompt,
                        generation_config,
                        cancel_event=cancel_event,
                        retry_callback=on_rate_limit,
                        api_switch_callback=self.api_switch_callback("Nâng cấp training profile"),
                    )
                mismatch = language_mismatch_warning(output, "Tiếng Việt")
                if mismatch:
                    output = retry_profile_vietnamese(mismatch)
                    mismatch = language_mismatch_warning(output, "Tiếng Việt")
                    if mismatch:
                        raise RuntimeError(f"Training profile nâng cấp chưa đúng tiếng Việt: {mismatch}. Hãy thử model khác hoặc chạy lại.")
                if self.task_cancelled(task_id, cancel_event):
                    return
                if use_cache and output:
                    self.gemini_cache[cache_key] = {
                        "mode": "training_profile_upgrade",
                        "model": config["gemini_model"],
                        "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                        "output": output,
                    }
                    save_gemini_cache_file(self.gemini_cache)
                self.after_task(task_id, self._training_profile_done, output)
            except Exception as exc:
                if self.task_cancelled(task_id, cancel_event):
                    return
                self.after_task(task_id, self._training_profile_error, str(exc))

        threading.Thread(target=worker, daemon=True).start()

    def open_training_chat(self) -> None:
        self.notebook.select(self.chat_tab)
        self.set_text(
            self.chat_input,
            "Hãy đánh giá training profile hiện tại và cho tôi 5 nâng cấp quan trọng nhất để viết kịch bản kể chuyện hay hơn cho người xem 40+.",
        )
        self.vars["status"].set("Đã mở Chat AI với ngữ cảnh training profile")

    def _chat_context_text(self) -> str:
        mode = self.vars["chat_context_mode"].get()
        parts: list[str] = []
        if mode in {"Chat tự do như Gemini", "Không dùng ngữ cảnh"}:
            return ""
        if mode in {"Dùng profile + kịch bản hiện tại", "Chỉ dùng training profile"}:
            profile = self.get_text(self.training_text).strip() if hasattr(self, "training_text") else ""
            negative = self.get_text(self.training_negative_text).strip() if hasattr(self, "training_negative_text") else ""
            locked = self.get_text(self.training_locked_text).strip() if hasattr(self, "training_locked_text") else ""
            if profile:
                parts.append("## Training profile đang bật\n" + profile[-14000:])
            if locked:
                parts.append("## Luật bắt buộc\n" + locked[-5000:])
            if negative:
                parts.append("## Luật cấm\n" + negative[-5000:])
        if mode in {"Dùng profile + kịch bản hiện tại", "Chỉ dùng kịch bản hiện tại"}:
            source = self.get_text(self.source_text).strip() if hasattr(self, "source_text") else ""
            draft = self.get_text(self.draft_text).strip() if hasattr(self, "draft_text") else ""
            if source:
                parts.append("## Kịch bản gốc / transcript hiện tại\n" + source[-18000:])
            if draft:
                parts.append("## Bản nháp mới hiện tại\n" + draft[-18000:])
        return "\n\n".join(parts).strip()

    def _chat_prompt(self, user_message: str) -> str:
        history_lines: list[str] = []
        for item in self.chat_messages[-8:]:
            role = "Người dùng" if item.get("role") == "user" else "AI"
            history_lines.append(f"{role}: {item.get('content', '')}")
        context = self._chat_context_text()
        mode = self.vars["chat_context_mode"].get()
        return f"""Bạn là trợ lý AI đa năng trong app Kịch bản AI, hoạt động giống một cuộc trò chuyện Gemini thông thường.

Nhiệm vụ:
- Trả lời trực tiếp, hữu ích, bằng tiếng Việt có dấu trừ khi người dùng yêu cầu ngôn ngữ khác.
- Có thể trả lời mọi chủ đề hợp lệ: kiến thức chung, học tập, công việc, viết email, dịch, tóm tắt, lập kế hoạch, giải thích lỗi, code, ý tưởng kinh doanh, cũng như kịch bản/video.
- Nếu câu hỏi KHÔNG liên quan đến kịch bản, hãy trả lời như một trợ lý Gemini bình thường, không cố kéo về nội dung video.
- Nếu câu hỏi liên quan đến kịch bản, training profile hoặc nội dung đang có trong tool, hãy tận dụng ngữ cảnh hiện tại để trả lời cụ thể hơn.
- Nếu người dùng hỏi về training, hãy chỉ ra profile nên sửa gì và đưa mẫu câu/prompt cụ thể.
- Nếu người dùng hỏi viết/sửa kịch bản, hãy trả về đoạn có thể dùng ngay.
- Nếu không chắc hoặc thiếu dữ liệu, nói rõ giả định và hỏi lại ngắn gọn khi cần.
- Không bịa là đã fine-tune model. Phần huấn luyện trong tool là prompt-training/profile.

## Cấu hình nhanh
- Chế độ chat: {mode}
- Người xem: {self.vars['audience'].get()}
- Tone: {self.vars['tone'].get()}
- Niche: {self.vars['niche'].get()}
- Ngôn ngữ đầu ra: {self.vars['target_language'].get()}

## Ngữ cảnh hiện tại
```text
{context or "Không dùng ngữ cảnh."}
```

## Lịch sử chat gần nhất
```text
{chr(10).join(history_lines) or "Chưa có."}
```

## Câu hỏi mới
{user_message}"""

    def send_chat_message(self) -> None:
        api_key = self.gemini_api_key_pool_text()
        message = self.get_text(self.chat_input).strip()
        if not message:
            messagebox.showwarning(APP_NAME, "Hãy nhập câu hỏi hoặc yêu cầu cho Chat AI.")
            return
        config = self.config_dict()
        if config.get("test_mode_no_api"):
            self.chat_messages.append({"role": "user", "content": message, "created_at": time.strftime("%Y-%m-%d %H:%M:%S")})
            answer = (
                "\n\nAI:\n"
                "[CHẾ ĐỘ TEST KHÔNG GỌI API]\n"
                "Tôi đã nhận câu hỏi của bạn nhưng không gọi Gemini để tránh tốn quota.\n\n"
                "Bạn có thể dùng chế độ này để test giao diện chat, kéo file, lịch sử hội thoại và nút gửi. "
                "Khi cần câu trả lời thật, hãy tắt `Test không gọi API` rồi gửi lại."
            )
            self.append_text(self.chat_output, f"\n\n{'=' * 70}\nBạn:\n{message}\n{answer}\n")
            self.set_text(self.chat_input, "")
            self.vars["status"].set("Test không gọi API: Chat AI trả lời giả lập local")
            return
        if config.get("cache_only_mode"):
            self.append_text(self.chat_output, "\n\n[Cache-only] Chat AI là hội thoại mới nên không có cache để dùng. App không gọi API mới để tránh quota.\n")
            self.vars["status"].set("Cache-only: Chat AI không gọi API")
            return
        if not parse_gemini_api_keys(api_key):
            messagebox.showwarning(APP_NAME, "Cần nhập Gemini API key để dùng Chat AI.")
            return
        attachment_paths = [path for path in self.chat_attachments if path.exists()]
        image_mode = is_chat_image_generation_request(message)
        chat_model = config["gemini_model"]
        if image_mode and chat_model not in GEMINI_IMAGE_MODEL_OPTIONS:
            chat_model = GEMINI_IMAGE_MODEL_OPTIONS[0]
        system = (
            "Bạn là trợ lý AI đa năng giống Gemini. Trả lời mọi câu hỏi hợp lệ một cách hữu ích, "
            "rõ ràng, bằng tiếng Việt có dấu trừ khi người dùng yêu cầu ngôn ngữ khác. "
            "Chỉ ưu tiên kịch bản/training profile khi người dùng hỏi về chủ đề đó hoặc có ngữ cảnh liên quan."
        )
        prompt = self._chat_prompt(message)
        generation_config = {"temperature": 0.55, "topP": 0.9, "maxOutputTokens": 6000}
        if image_mode:
            generation_config = {"temperature": 0.8, "topP": 0.95, "maxOutputTokens": 4096}
        self.chat_messages.append(
            {
                "role": "user",
                "content": message,
                "attachments": [str(path) for path in attachment_paths],
                "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            }
        )
        attach_note = ""
        if attachment_paths:
            attach_note = "\nFile đính kèm:\n" + "\n".join(f"- {path.name}" for path in attachment_paths)
        model_note = f"\nModel: {chat_model}" if image_mode else ""
        self.append_text(self.chat_output, f"\n\n{'=' * 72}\nBạn:\n{message}{attach_note}{model_note}\n\nAI:\n")
        self.set_text(self.chat_input, "")
        self.notebook.select(self.chat_tab)
        task_id = self.start_task_feedback("Chat AI đang trả lời...", indeterminate=True)
        self._set_buttons_state("disabled")
        self._chat_clear_attachments_after_done = bool(attachment_paths)
        cancel_event = self.cancel_event

        def worker() -> None:
            try:
                chunks: list[str] = []

                def on_chunk(chunk: str) -> None:
                    chunks.append(chunk)
                    self.after(0, lambda value=chunk: self.append_text(self.chat_output, value) if self.is_task_current(task_id) else None)

                def on_rate_limit(delay: int, attempt: int, total: int) -> None:
                    self.after(
                        0,
                        lambda d=delay, a=attempt, t=total: self.set_indeterminate_progress(
                            f"Gemini giới hạn quota khi chat, đợi {d}s rồi thử lại ({a}/{t})..."
                        ) if self.is_task_current(task_id) else None,
                    )

                def on_multimodal_progress(message_text: str) -> None:
                    self.after(0, lambda value=message_text: self.set_indeterminate_progress(value) if self.is_task_current(task_id) else None)

                if attachment_paths or image_mode:
                    output, image_paths, _raw = call_gemini_chat_multimodal(
                        api_key,
                        chat_model,
                        system,
                        prompt,
                        generation_config,
                        attachment_paths=attachment_paths,
                        output_dir=self.chat_output_dir(),
                        image_mode=image_mode,
                        cancel_event=cancel_event,
                        retry_callback=on_rate_limit,
                        progress_callback=on_multimodal_progress,
                        api_switch_callback=self.api_switch_callback("Chat AI multimodal"),
                    )
                    if output:
                        self.after(0, lambda value=output: self.append_text(self.chat_output, value) if self.is_task_current(task_id) else None)
                    for image_path in image_paths:
                        self.after(0, lambda value=image_path: self.append_chat_image_preview(value) if self.is_task_current(task_id) else None)
                elif self.vars["use_streaming"].get():
                    output = call_gemini_stream(
                        api_key,
                        chat_model,
                        system,
                        prompt,
                        generation_config,
                        chunk_callback=on_chunk,
                        cancel_event=cancel_event,
                        retry_callback=on_rate_limit,
                        api_switch_callback=self.api_switch_callback("Chat AI"),
                    )
                else:
                    output = call_gemini(
                        api_key,
                        chat_model,
                        system,
                        prompt,
                        generation_config,
                        cancel_event=cancel_event,
                        retry_callback=on_rate_limit,
                        api_switch_callback=self.api_switch_callback("Chat AI"),
                    )
                    self.after(0, lambda value=output: self.append_text(self.chat_output, value) if self.is_task_current(task_id) else None)
                if self.task_cancelled(task_id, cancel_event):
                    return
                final_output = output.strip() or "".join(chunks).strip()
                if attachment_paths or image_mode:
                    final_images = [str(path) for path in locals().get("image_paths", [])]
                    if final_images:
                        final_output = (final_output + "\n\nẢnh đã lưu:\n" + "\n".join(final_images)).strip()
                self.chat_messages.append({"role": "assistant", "content": final_output, "model": chat_model, "created_at": time.strftime("%Y-%m-%d %H:%M:%S")})
                self.after_task(task_id, self._chat_done)
            except Exception as exc:
                if self.task_cancelled(task_id, cancel_event):
                    return
                self.after_task(task_id, self._chat_error, str(exc))

        threading.Thread(target=worker, daemon=True).start()

    def _chat_done(self) -> None:
        self._set_buttons_state("normal")
        self.finish_task_feedback("Chat AI đã trả lời")
        if getattr(self, "_chat_clear_attachments_after_done", False):
            self.chat_attachments = []
            self.chat_image_refs = []
            self.refresh_chat_attachment_meta()
            self._chat_clear_attachments_after_done = False
            gc.collect()
        self.append_text(self.chat_output, "\n")
        self.vars["status"].set("Chat AI đã trả lời xong")

    def _chat_error(self, error: str) -> None:
        self._set_buttons_state("normal")
        self.finish_task_feedback("Lỗi Chat AI", success=False)
        self.append_text(self.chat_output, f"\n\n[LỖI CHAT]\n{error}\n")
        messagebox.showerror(APP_NAME, error[:1200])

    def clear_chat(self) -> None:
        self.chat_messages = []
        self.chat_image_refs = []
        gc.collect()
        self.set_text(self.chat_output, "Đã xóa chat. Hãy nhập câu hỏi mới.\n")
        self.vars["status"].set("Đã xóa Chat AI")

    def chat_suggest_script_upgrade(self) -> None:
        self.notebook.select(self.chat_tab)
        self.set_text(
            self.chat_input,
            "Dựa trên training profile và kịch bản hiện tại, hãy chỉ ra 7 điểm cần nâng cấp để kịch bản hay hơn cho người xem 40+, rồi viết mẫu một đoạn mở đầu mới.",
        )
        self.send_chat_message()

    def chat_review_training_profile(self) -> None:
        self.notebook.select(self.chat_tab)
        self.set_text(
            self.chat_input,
            "Hãy audit training profile hiện tại: điểm mạnh, điểm yếu, luật còn thiếu, và viết lại 10 locked rules mạnh nhất để dùng khi Gemini viết kịch bản.",
        )
        self.send_chat_message()

    def extract_source_from_url(
        self,
        api_key: str,
        url: str,
        config: dict,
        *,
        use_cache: bool = True,
        cancel_event=None,
        retry_callback=None,
        api_switch_callback=None,
    ) -> tuple[str, dict, bool]:
        if config.get("test_mode_no_api"):
            source = (
                "[CHẾ ĐỘ TEST KHÔNG GỌI API]\n"
                f"URL: {url}\n\n"
                "Đây là nguồn giả lập để test Batch URL/URL đơn mà không gọi Gemini. "
                "Tắt `Test không gọi API` để Gemini đọc nội dung URL thật."
            )
            return source, {"source_type": "mock_url", "url": url}, False
        if is_direct_media_url(url) and not is_youtube_url(url):
            raise RuntimeError(
                "URL này là file video/audio trực tiếp. Gemini URL Context không hỗ trợ video/audio URL trực tiếp; "
                "hãy tải file về và dùng Batch folder video, hoặc dùng URL YouTube công khai."
            )

        if is_youtube_url(url):
            video_id = youtube_video_id(url)
            if not is_valid_youtube_video_id(video_id):
                found_id = video_id or "rỗng"
                raise RuntimeError(
                    "URL YouTube không hợp lệ hoặc bị thiếu ký tự video ID. "
                    f"Video ID phải có 11 ký tự, app đọc được: {found_id}. "
                    "Hãy mở video trên YouTube, bấm Chia sẻ, copy lại link đầy đủ rồi thử lại."
                )
            clean_url = f"https://www.youtube.com/watch?v={video_id}"
            settings = video_extraction_settings(config["video_extract_mode"])
            prompt = build_video_script_prompt(config)
            source_mode = "youtube_url_source_minimal_payload_v2"
            cache_config = {
                "maxOutputTokens": settings["max_output_tokens"],
            }
            cache_key = gemini_cache_key(config["gemini_model"], f"YouTube URL source: {clean_url}", prompt, cache_config, source_mode)
            if use_cache:
                cached = self.gemini_cache.get(cache_key, {}).get("output", "")
                if cached:
                    return cached, {"source_type": "youtube_url", "url": url, "canonical_url": clean_url}, True
            if config.get("cache_only_mode"):
                raise RuntimeError("Đang bật 'Chỉ dùng cache, không gọi API mới' nhưng URL YouTube này chưa có cache.")
            try:
                output = call_gemini_with_file(
                    api_key=api_key,
                    model=config["gemini_model"],
                    file_uri=clean_url,
                    mime_type="",
                    prompt=prompt,
                    max_output_tokens=settings["max_output_tokens"],
                    media_resolution=settings["media_resolution"],
                    cancel_event=cancel_event,
                    retry_callback=retry_callback,
                    api_switch_callback=api_switch_callback,
                )
            except RuntimeError as exc:
                message = str(exc)
                if "Unsupported MIME type: text/html" in message or "INVALID_ARGUMENT" in message:
                    raise RuntimeError(
                        "Gemini không nhận URL này như YouTube video input. App đã thử URL sạch "
                        f"{clean_url} với payload tối giản, không gửi MIME/mediaResolution. "
                        "Hãy kiểm tra video có public không, không phải private/unlisted, không bị giới hạn khu vực/tuổi, "
                        "và thử model gemini-3.5-flash hoặc gemini-2.5-flash. Nếu vẫn lỗi, hãy tải video về rồi dùng Batch folder video. Chi tiết: "
                        f"{message[:500]}"
                    ) from exc
                raise
            if use_cache and output:
                self.gemini_cache[cache_key] = {
                    "mode": source_mode,
                    "model": config["gemini_model"],
                    "url": url,
                    "canonical_url": clean_url,
                    "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                    "output": output,
                }
                save_gemini_cache_file(self.gemini_cache)
            return output, {"source_type": "youtube_url", "url": url, "canonical_url": clean_url}, False

        system = "Bạn đọc URL công khai và trích nội dung nguồn thành kịch bản/tư liệu sạch để viết lại."
        prompt = build_url_source_prompt(url, config)
        settings = video_extraction_settings(config["video_extract_mode"])
        generation_config = {
            "temperature": 0.2,
            "topP": 0.85,
            "maxOutputTokens": max(10000, settings["max_output_tokens"]),
        }
        source_mode = "url_context_source"
        cache_key = gemini_cache_key(config["gemini_model"], system, prompt, generation_config, source_mode)
        if use_cache:
            cached = self.gemini_cache.get(cache_key, {}).get("output", "")
            metadata = self.gemini_cache.get(cache_key, {}).get("metadata", {})
            if cached:
                return cached, metadata or {"source_type": "url_context", "url": url}, True
        if config.get("cache_only_mode"):
            raise RuntimeError("Đang bật 'Chỉ dùng cache, không gọi API mới' nhưng URL này chưa có cache.")
        output, metadata = call_gemini_url_context(
            api_key,
            config["gemini_model"],
            system,
            prompt,
            generation_config,
            cancel_event=cancel_event,
            retry_callback=retry_callback,
            api_switch_callback=api_switch_callback,
        )
        metadata = metadata or {"source_type": "url_context", "url": url}
        if use_cache and output:
            self.gemini_cache[cache_key] = {
                "mode": source_mode,
                "model": config["gemini_model"],
                "url": url,
                "metadata": metadata,
                "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                "output": output,
            }
            save_gemini_cache_file(self.gemini_cache)
        return output, metadata, False

    def config_dict(self) -> dict:
        raw_duration = self.vars["duration"].get().strip()
        target_language = self.vars["target_language"].get()
        rewrite_mode = self.vars["script_rewrite_mode"].get()
        target_change = 100 if is_full_rewrite_mode(rewrite_mode) else int(self.vars["target_change"].get())
        training_profile = self.get_text(self.training_text).strip()
        training_negative_rules = self.get_text(self.training_negative_text).strip() if hasattr(self, "training_negative_text") else ""
        training_locked_rules = self.get_text(self.training_locked_text).strip() if hasattr(self, "training_locked_text") else ""
        use_training_profile = bool(self.vars["use_training_profile"].get())
        active_training_profile = training_profile
        if active_training_profile and training_locked_rules:
            active_training_profile += f"\n\n## Luật bắt buộc / Locked rules\n{training_locked_rules}"
        if active_training_profile and training_negative_rules:
            active_training_profile += f"\n\n## Luật cấm / Negative style\n{training_negative_rules}"
        if not use_training_profile:
            active_training_profile = ""
        return {
            "project_name": self.vars["project_name"].get().strip() or "Dự án kể chuyện 40+",
            "story_title": self.vars["story_title"].get().strip(),
            "auto_title_with_gemini": bool(self.vars["auto_title_with_gemini"].get()),
            "training_profile_name": self.vars["training_profile_name"].get().strip() or "Training profile",
            "platform": self.vars["platform"].get().strip(),
            "duration": raw_duration,
            "duration_goal": duration_goal_text(raw_duration, target_language),
            "audience": self.vars["audience"].get().strip(),
            "tone": self.vars["tone"].get().strip(),
            "niche": self.vars["niche"].get().strip(),
            "cta": self.vars["cta"].get().strip(),
            "custom_story_ideas": self.custom_ideas_value(),
            "target_change": target_change,
            "gemini_model": self.vars["gemini_model"].get().strip() or "gemini-3.1-flash-lite",
            "source_language": self.vars["source_language"].get(),
            "target_language": target_language,
            "review_translation_language": DEFAULT_REVIEW_LANGUAGE,
            "script_rewrite_mode": rewrite_mode,
            "gemini_speed_mode": self.vars["gemini_speed_mode"].get(),
            "video_extract_mode": self.vars["video_extract_mode"].get(),
            "cache_only_mode": bool(self.vars["cache_only_mode"].get()),
            "test_mode_no_api": bool(self.vars["test_mode_no_api"].get()),
            "use_training_profile": use_training_profile,
            "training_profile": active_training_profile,
            "training_profile_raw": training_profile,
            "training_negative_rules": training_negative_rules,
            "training_locked_rules": training_locked_rules,
        }

    def apply_preset(self, name: str) -> None:
        if name not in PRESETS:
            return
        self.vars["selected_preset"].set(name)
        preset = PRESETS[name]
        for key, value in preset.items():
            if key in self.vars:
                self.vars[key].set(value)
        self.save_settings()
        self.vars["status"].set(f"Đã áp dụng mẫu: {name}")

    def show_story_40plus_suggestions(self) -> None:
        self.set_text(self.gemini_output, story_40plus_suggestions_text())
        self.notebook.select(self.gemini_tab)
        self.vars["status"].set("Đã mở gợi ý storytelling 40+")

    def custom_ideas_value(self) -> str:
        if hasattr(self, "custom_ideas_text"):
            return self.get_text(self.custom_ideas_text).strip()
        return ""

    def set_custom_ideas_value(self, value: str) -> None:
        if hasattr(self, "custom_ideas_text"):
            self.set_text(self.custom_ideas_text, value or "")

    def load_trend_ideas_into_custom_box(self) -> None:
        seed = trend_idea_seed_text(self.config_dict()).strip()
        current = self.custom_ideas_value()
        if current:
            merged = f"{current}\n\n--- GỢI Ý TREND MỚI ---\n{seed}"
        else:
            merged = seed
        self.set_custom_ideas_value(merged)
        self.save_settings()
        self.vars["status"].set("Đã nạp trend seed vào ô Ý tưởng riêng")

    def _append_custom_ideas_to_training_samples(self, *, notify: bool = True) -> bool:
        ideas = self.custom_ideas_value()
        if not ideas:
            if notify:
                messagebox.showwarning(APP_NAME, "Chưa có ý tưởng riêng để đưa vào huấn luyện.")
            return False
        current = self.get_text(self.training_samples_text).strip() if hasattr(self, "training_samples_text") else ""
        if ideas in current:
            if notify:
                self.vars["status"].set("Ý tưởng riêng đã có trong mẫu huấn luyện")
            return False
        block = (
            "===== MẪU: Ý TƯỞNG RIÊNG / TREND SEED =====\n"
            "Đây không phải kịch bản hoàn chỉnh. Đây là kho ý tưởng người dùng muốn AI ưu tiên nâng cấp khi tạo profile và viết kịch bản.\n\n"
            f"{ideas}"
        )
        self.set_text(self.training_samples_text, f"{current}\n\n{block}".strip() if current else block)
        self._refresh_training_sample_meta()
        self.vars["use_training_profile"].set(True)
        self.save_settings()
        if notify:
            self.notebook.select(self.training_tab)
            self.vars["status"].set("Đã đưa ý tưởng riêng vào mẫu huấn luyện")
        return True

    def append_custom_ideas_to_training(self) -> None:
        self._append_custom_ideas_to_training_samples(notify=True)

    def prepare_training_best_practices(self) -> None:
        if not self.custom_ideas_value():
            self.set_custom_ideas_value(trend_idea_seed_text(self.config_dict()).strip())
        if hasattr(self, "training_negative_text") and not self.get_text(self.training_negative_text).strip():
            self.set_text(self.training_negative_text, default_negative_training_rules())
        if hasattr(self, "training_locked_text"):
            locked = self.get_text(self.training_locked_text).strip()
            base_rules = default_locked_training_rules()
            idea_rules = training_story_idea_locked_rules()
            merged_parts = []
            if locked:
                merged_parts.append(locked)
            elif base_rules:
                merged_parts.append(base_rules)
            if idea_rules not in "\n\n".join(merged_parts):
                merged_parts.append(idea_rules)
            self.set_text(self.training_locked_text, "\n\n".join(part for part in merged_parts if part.strip()))
        self._append_custom_ideas_to_training_samples(notify=False)
        self.vars["use_training_profile"].set(True)
        self.score_training_profile(show_tab=False)
        self.save_settings()
        self.notebook.select(self.training_tab)
        self.vars["status"].set("Đã tối ưu setup huấn luyện: trend, luật cấm, locked rules và ý tưởng riêng")

    def show_training_quick_guide(self) -> None:
        self.set_text(self.gemini_output, training_quick_guide_text(self.config_dict()))
        self.notebook.select(self.gemini_tab)
        self.vars["status"].set("Đã mở hướng dẫn nhanh Huấn luyện AI")

    def train_ai_one_click(self) -> None:
        self.prepare_training_best_practices()
        samples = self._training_samples()
        source = self.get_text(self.source_text).strip() if hasattr(self, "source_text") else ""
        if not samples and source:
            self._append_training_sample("Nguồn hiện tại", source)
            samples = self._training_samples()
        if not samples and self.custom_ideas_value():
            self._append_custom_ideas_to_training_samples(notify=False)
            samples = self._training_samples()
        profile = self.get_text(self.training_text).strip() if hasattr(self, "training_text") else ""
        if self.config_dict().get("test_mode_no_api"):
            if profile:
                self.improve_training_profile_local()
            elif samples:
                self.generate_training_profile_local()
            else:
                self.set_text(self.training_text, training_profile_40plus_template(self.config_dict()))
                self.vars["use_training_profile"].set(True)
                self.score_training_profile(show_tab=False)
                self.save_settings()
                self.vars["status"].set("Test không gọi API: đã tạo profile mẫu local")
            return
        has_api = bool(parse_gemini_api_keys(self.gemini_api_key_pool_text()))
        if has_api:
            if profile:
                self.upgrade_training_profile_with_gemini()
            else:
                self.generate_training_profile_with_gemini()
            return
        if profile:
            self.improve_training_profile_local()
        else:
            if not samples:
                self.set_text(self.training_text, training_profile_40plus_template(self.config_dict()))
                self.vars["use_training_profile"].set(True)
                self.score_training_profile(show_tab=False)
                self.save_settings()
                self.vars["status"].set("Chưa có API/mẫu; đã tạo profile mẫu 40+ để dùng tạm")
            else:
                self.generate_training_profile_local()

    def load_sample(self) -> None:
        self.set_text(self.source_text, SAMPLE_SCRIPT)
        self.analysis = analyze_script(SAMPLE_SCRIPT)
        self.report = None
        self._render_all()
        self.vars["status"].set("Đã tải mẫu thử")

    def import_script_file(self) -> None:
        path_text = filedialog.askopenfilename(filetypes=SCRIPT_FILE_TYPES, title="Chọn file kịch bản hoặc phụ đề")
        if not path_text:
            return
        path = Path(path_text)
        if not path.exists():
            messagebox.showerror(APP_NAME, "File kịch bản không tồn tại.")
            return
        try:
            raw_text = read_script_file(path)
            cleaned = clean_imported_script(raw_text)
        except Exception as exc:
            messagebox.showerror(APP_NAME, f"Không đọc được file kịch bản:\n{exc}")
            return
        if not cleaned:
            messagebox.showwarning(APP_NAME, "File này không có nội dung kịch bản đọc được.")
            return
        self.set_text(self.source_text, cleaned)
        self.analysis = analyze_script(cleaned)
        self.report = None
        self.vars["video_path"].set(f"Kịch bản: {path.name}")
        self.set_text(
            self.gemini_output,
            f"Đã nhập kịch bản:\n{path}\n\nSố ký tự sau khi làm sạch: {len(cleaned):,}\nSố token/từ ước tính: {len(normalize_words(cleaned)):,}\n\n"
            "Bạn có thể bấm 'Đọc và viết lại ngay' để Gemini tạo bản mới.",
        )
        self._render_all()
        self.notebook.select(self.editor_tab)
        self.vars["status"].set(f"Đã nhập kịch bản: {path.name}")

    def import_url_list_file(self) -> None:
        path_text = filedialog.askopenfilename(
            filetypes=[
                ("URL list", "*.txt *.md *.csv *.json"),
                ("Text", "*.txt *.md"),
                ("CSV/JSON", "*.csv *.json"),
                ("All files", "*.*"),
            ],
            title="Chọn file chứa danh sách URL",
        )
        if not path_text:
            return
        path = Path(path_text)
        if not path.exists():
            messagebox.showerror(APP_NAME, "File danh sách URL không tồn tại.")
            return
        try:
            raw_text = read_script_file(path)
        except Exception as exc:
            messagebox.showerror(APP_NAME, f"Không đọc được file URL:\n{exc}")
            return
        urls = extract_urls(raw_text)
        if not urls:
            messagebox.showwarning(APP_NAME, "File này không có URL hợp lệ. Mỗi link cần bắt đầu bằng http:// hoặc https://.")
            return
        self.set_text(self.source_text, "\n".join(urls))
        self.analysis = None
        self.report = None
        self.vars["video_path"].set(f"URL list: {path.name}")
        self.set_text(
            self.gemini_output,
            f"Đã nhập danh sách URL:\n{path}\n\nSố URL tìm thấy: {len(urls)}\n\nBấm 'Batch URL' để Gemini đọc từng URL và viết lại kịch bản.",
        )
        self._render_all()
        self.notebook.select(self.editor_tab)
        self.vars["status"].set(f"Đã nhập {len(urls)} URL")

    def paste_script_from_clipboard(self) -> None:
        try:
            raw_text = self.clipboard_get()
        except tk.TclError:
            messagebox.showwarning(APP_NAME, "Clipboard không có text để dán.")
            return
        cleaned = clean_imported_script(raw_text)
        if not cleaned:
            messagebox.showwarning(APP_NAME, "Clipboard không có nội dung kịch bản đọc được.")
            return
        self.set_text(self.source_text, cleaned)
        self.analysis = analyze_script(cleaned)
        self.report = None
        self.vars["video_path"].set("Kịch bản: clipboard")
        self.set_text(
            self.gemini_output,
            f"Đã dán và làm sạch kịch bản từ clipboard.\n\nSố ký tự: {len(cleaned):,}\nSố token/từ ước tính: {len(normalize_words(cleaned)):,}",
        )
        self._render_all()
        self.notebook.select(self.editor_tab)
        self.vars["status"].set("Đã dán kịch bản từ clipboard")

    def clean_source_script(self) -> None:
        source = self.get_text(self.source_text)
        if not source.strip():
            messagebox.showwarning(APP_NAME, "Chưa có kịch bản để làm sạch.")
            return
        cleaned = clean_imported_script(source)
        self.set_text(self.source_text, cleaned)
        self.analysis = analyze_script(cleaned) if cleaned else None
        self.report = None
        self._render_all()
        self.vars["status"].set("Đã làm sạch text/phụ đề")

    def rewrite_existing_script_now(self) -> None:
        source = self.get_text(self.source_text).strip()
        if not source:
            messagebox.showwarning(APP_NAME, "Hãy nhập file kịch bản hoặc dán text vào ô kịch bản gốc trước.")
            return
        self.run_gemini("script_rewrite")

    def one_click_rewrite(self) -> None:
        source = self.get_text(self.source_text).strip()
        if not source:
            messagebox.showwarning(APP_NAME, "Hãy nhập file kịch bản, dán text hoặc trích video trước.")
            return
        cleaned = clean_imported_script(source)
        self.set_text(self.source_text, cleaned)
        self.analysis = analyze_script(cleaned)
        self.report = None
        self._render_all()
        self.run_gemini("script_rewrite")

    def score_story_40plus_current(self) -> None:
        text = self.get_text(self.draft_text).strip() or self.get_text(self.gemini_output).strip() or self.get_text(self.source_text).strip()
        if not text:
            messagebox.showwarning(APP_NAME, "Chưa có kịch bản để chấm Story Score 40+.")
            return
        score = story_score_40plus(text)
        self.set_text(self.gemini_output, story_score_markdown(score))
        self.notebook.select(self.gemini_tab)
        self.vars["status"].set(f"Story Score 40+: {score['score']}/100")

    def export_current_bundle(self) -> None:
        output = self.get_text(self.draft_text).strip() or self.get_text(self.gemini_output).strip()
        source = self.get_text(self.source_text).strip()
        if not output:
            messagebox.showwarning(APP_NAME, "Chưa có output/draft để xuất.")
            return
        folder_text = filedialog.askdirectory(title="Chọn thư mục lưu TXT/DOCX/Markdown")
        if not folder_text:
            return
        story_score = story_score_40plus(output)
        report = self.report or (score_similarity(source, output) if source else None)
        base_name = self.vars["story_title"].get().strip() or self.vars["project_name"].get().strip() or "kịch bản"
        paths = export_script_bundle(Path(folder_text), base_name, source, output, report, story_score)
        self.set_text(self.gemini_output, "Đã xuất bộ file:\n" + "\n".join(f"- {key}: {value}" for key, value in paths.items()))
        self.vars["status"].set("Đã xuất TXT/DOCX/Markdown")

    def batch_rewrite_folder(self) -> None:
        api_key = self.gemini_api_key_pool_text()
        config = self.config_dict()
        if not parse_gemini_api_keys(api_key) and not config.get("test_mode_no_api") and not config.get("cache_only_mode"):
            messagebox.showwarning(APP_NAME, "Cần nhập Gemini API key để chạy batch.")
            return
        folder_text = filedialog.askdirectory(title="Chọn folder chứa file .txt để viết lại hàng loạt không giới hạn")
        if not folder_text:
            return
        input_dir = Path(folder_text)
        files = iter_script_files(input_dir)
        if not files:
            messagebox.showwarning(APP_NAME, "Không tìm thấy file kịch bản trong thư mục này.")
            return
        output_dir = input_dir / f"neon_batch_output_{time.strftime('%Y%m%d_%H%M%S')}"
        self._start_batch_rewrite(input_dir, output_dir, previous_summary=None)

    def resume_batch_rewrite_folder(self) -> None:
        output_text = filedialog.askdirectory(title="Chọn folder output neon_batch_output cũ để resume")
        if not output_text:
            return
        output_dir = Path(output_text)
        summary_path = output_dir / "_batch_summary.json"
        if not summary_path.exists():
            messagebox.showwarning(APP_NAME, "Folder này không có _batch_summary.json để resume.")
            return
        try:
            previous_summary = json.loads(summary_path.read_text(encoding="utf-8"))
        except Exception as exc:
            messagebox.showerror(APP_NAME, f"Không đọc được _batch_summary.json:\n{exc}")
            return
        input_dir = self._infer_batch_input_dir(output_dir, previous_summary)
        if not input_dir or not input_dir.exists():
            source_text = filedialog.askdirectory(title="Không suy ra được nguồn. Chọn lại folder text gốc")
            if not source_text:
                return
            input_dir = Path(source_text)
        self._start_batch_rewrite(input_dir, output_dir, previous_summary=previous_summary)

    def _infer_batch_input_dir(self, output_dir: Path, summary: list[dict]) -> Path | None:
        md_path = output_dir / "_batch_summary.md"
        if md_path.exists():
            try:
                for line in md_path.read_text(encoding="utf-8").splitlines():
                    if line.startswith("- Nguồn:"):
                        candidate = Path(line.split(":", 1)[1].strip())
                        if candidate.exists():
                            return candidate
            except Exception:
                pass
        paths = [Path(item.get("file", "")) for item in summary if item.get("file")]
        parents = [path.parent for path in paths if path.exists()]
        if not parents:
            return None
        try:
            common = Path(os.path.commonpath([str(parent) for parent in parents]))
            return common if common.exists() else parents[0]
        except Exception:
            return parents[0]

    def _start_batch_rewrite(self, input_dir: Path, output_dir: Path, previous_summary: list[dict] | None = None) -> None:
        api_key = self.gemini_api_key_pool_text()
        config = self.config_dict()
        if not parse_gemini_api_keys(api_key) and not config.get("test_mode_no_api") and not config.get("cache_only_mode"):
            messagebox.showwarning(APP_NAME, "Cần nhập Gemini API key để chạy hoặc resume batch.")
            return
        files = iter_script_files(input_dir)
        if not files:
            messagebox.showwarning(APP_NAME, "Không tìm thấy file kịch bản trong thư mục này.")
            return
        previous_summary = self._slim_batch_summary(previous_summary or [])
        summary_by_file = {str(Path(item.get("file", ""))): item for item in previous_summary if item.get("file")}
        ok_files = {
            str(Path(item.get("file", "")))
            for item in previous_summary
            if item.get("file") and item.get("status") == "ok"
        }
        pending_files = [path for path in files if str(path) not in ok_files]
        skipped_count = len(files) - len(pending_files)
        if not pending_files:
            self.batch_results = list(summary_by_file.values())
            self.batch_output_dir = output_dir
            self._render_batch_results()
            self.notebook.select(self.batch_tab)
            messagebox.showinfo(APP_NAME, "Batch này đã xử lý xong toàn bộ file. Không còn file lỗi/chưa chạy để resume.")
            return
        use_cache = bool(self.vars["use_cache"].get())
        self.batch_results = list(summary_by_file.values())
        self.batch_output_dir = output_dir
        self._render_batch_results()
        self.notebook.select(self.gemini_tab)
        self.set_text(
            self.gemini_output,
            f"BATCH VIẾT LẠI KỊCH BẢN\n\n"
            f"Nguồn: {input_dir}\n"
            f"Output: {output_dir}\n"
            f"Số file xử lý lần này: {len(pending_files)} / {len(files)} (bỏ qua {skipped_count} file đã OK, không giới hạn số file)\n"
            f"Model: {config['gemini_model']}\n"
            f"Ngôn ngữ đầu ra: {config['target_language']}\n"
            f"Chiến lược thời lượng: tự đo từng kịch bản gốc, bản mới luôn dài hơn bản gốc.\n"
            f"Ô thời lượng hiện tại chỉ là tham khảo: {config.get('duration_goal', config.get('duration', ''))}\n"
            f"API key: {self.gemini_api_key_status_text()}\n\n"
            "Mỗi kết quả sẽ hiển thị: title, số từ, thời gian đọc voice, Story 40+, độ giống và gợi ý nâng cấp.\n"
            "App xử lý tuần tự từng file để giảm treo/quota; có thể bấm Hủy để dừng batch dài.\n",
        )
        task_id = self.start_task_feedback(f"Batch rewrite: 0/{len(pending_files)}", indeterminate=False)
        self._set_buttons_state("disabled")
        cancel_event = self.cancel_event

        def worker() -> None:
            consecutive_api_errors = 0
            last_source = ""
            last_output = ""
            last_title = ""
            try:
                for run_index, path in enumerate(pending_files, start=1):
                    if self.task_cancelled(task_id, cancel_event):
                        raise RuntimeError("Đã hủy batch.")
                    display_index = files.index(path) + 1
                    self.after(0, lambda i=run_index, p=path: self.update_progress(i - 1, len(pending_files), f"Đang đọc {i}/{len(pending_files)}: {p.name}") if self.is_task_current(task_id) else None)
                    try:
                        raw_text = read_script_file(path)
                        source = clean_imported_script(raw_text)
                        if not source:
                            raise RuntimeError("File không có nội dung đọc được.")
                        output, analysis, from_cache = generate_gemini_cached(
                            api_key,
                            config,
                            source,
                            "script_rewrite",
                            cache_store=None,
                            use_cache=False,
                            cancel_event=cancel_event,
                            api_switch_callback=self.api_switch_callback(f"Batch text {run_index}/{len(pending_files)}"),
                        )
                        report = score_similarity(source, output)
                        story_score = story_score_40plus(output)
                        output_analysis = analyze_script(output)
                        story_title, title_source = self.generate_batch_story_title(
                            api_key,
                            config,
                            source,
                            output,
                            use_cache=use_cache,
                            cancel_event=cancel_event,
                            index=run_index,
                            total=len(pending_files),
                        )
                        exported = export_batch_script_bundle(
                            output_dir,
                            display_index,
                            path,
                            story_title,
                            source,
                            output,
                            report,
                            story_score,
                        )
                        process_label = "cache" if from_cache else "Gemini"
                        log_block, quality = format_batch_result_block(
                            run_index,
                            len(pending_files),
                            path.name,
                            source,
                            output,
                            report,
                            story_score,
                            config,
                            process_label=process_label,
                            exported=exported,
                            story_title=story_title,
                            title_source=title_source,
                        )
                        item = {
                            "file": str(path),
                            "status": "ok",
                            "index": display_index,
                            "story_title": story_title,
                            "title_source": title_source,
                            "from_cache": from_cache,
                            "words_source": analysis.word_count,
                            "words_output": output_analysis.word_count,
                            "source_voice": quality.get("source_voice"),
                            "output_voice": quality.get("output_voice"),
                            "output_units": quality.get("output_units"),
                            "target_min_units": quality.get("target_min_units"),
                            "target_max_units": quality.get("target_max_units"),
                            "length_status": quality.get("length_status"),
                            "suggestions": quality.get("suggestions"),
                            "story_score": story_score.get("score"),
                            "similarity_risk": report.get("risk"),
                            "similarity_percent": report.get("similarity_percent"),
                            "exported": exported,
                        }
                        summary_by_file[str(path)] = item
                        last_source = source
                        last_output = output
                        last_title = story_title
                        consecutive_api_errors = 0
                        self.after(
                            0,
                            lambda text=log_block: self.append_text(self.gemini_output, text) if self.is_task_current(task_id) else None,
                        )
                        self.after(0, lambda: self._update_batch_results_from_map(summary_by_file, output_dir) if self.is_task_current(task_id) else None)
                    except Exception as file_exc:
                        item = {"file": str(path), "status": "error", "index": display_index, "error": str(file_exc)}
                        summary_by_file[str(path)] = item
                        self.after(
                            0,
                            lambda text=format_batch_error_block(run_index, len(pending_files), path.name, file_exc): self.append_text(self.gemini_output, text) if self.is_task_current(task_id) else None,
                        )
                        self.after(0, lambda: self._update_batch_results_from_map(summary_by_file, output_dir) if self.is_task_current(task_id) else None)
                        if is_batch_circuit_breaker_error(file_exc):
                            consecutive_api_errors += 1
                        else:
                            consecutive_api_errors = 0
                        if consecutive_api_errors >= 3:
                            self.after(
                                0,
                                lambda: self.append_text(
                                    self.gemini_output,
                                    "\n[DỪNG BATCH] Gặp 3 lỗi API/quota liên tiếp. App đã dừng để tránh mất thời gian và quota. "
                                    "Hãy thay API key, giảm batch hoặc thử lại sau vài phút.\n",
                                ) if self.is_task_current(task_id) else None,
                            )
                            break
                    finally:
                        try:
                            raw_text = ""
                            source = ""
                            output = ""
                        except Exception:
                            pass
                        if run_index % 3 == 0:
                            gc.collect()
                    self.after(0, lambda i=run_index: self.update_progress(i, len(pending_files), f"Batch rewrite: {i}/{len(pending_files)}") if self.is_task_current(task_id) else None)
                output_dir.mkdir(parents=True, exist_ok=True)
                summary = self._ordered_batch_summary(summary_by_file, files)
                (output_dir / "_batch_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
                summary_lines = [
                    "# Batch Summary",
                    "",
                    f"- Nguồn: {input_dir}",
                    f"- Output: {output_dir}",
                    f"- Tổng file: {len(files)}",
                    f"- Đã bỏ qua vì OK từ trước: {skipped_count}",
                    f"- Thành công: {sum(1 for item in summary if item.get('status') == 'ok')}",
                    f"- Lỗi: {sum(1 for item in summary if item.get('status') == 'error')}",
                    "",
                    "## Chi tiết",
                ]
                for item in summary:
                    summary_lines.append(
                        f"- {item.get('status').upper()} | {Path(item.get('file', '')).name} | "
                        f"Title: {item.get('story_title', 'N/A')} ({item.get('title_source', 'N/A')}) | "
                        f"Nguồn: {item.get('words_source', 'N/A')} từ | Bản mới: {item.get('words_output', 'N/A')} từ | "
                        f"Voice: {item.get('output_voice', 'N/A')} | Story: {item.get('story_score', 'N/A')} | "
                        f"Similarity: {item.get('similarity_risk', 'N/A')} {item.get('similarity_percent', 'N/A')}/100 | "
                        f"Length: {item.get('length_status', 'N/A')}"
                    )
                (output_dir / "_batch_summary.md").write_text("\n".join(summary_lines), encoding="utf-8")
                self.after_task(task_id, self._batch_done, output_dir, summary, last_source, last_output, last_title)
            except Exception as exc:
                if self.task_cancelled(task_id, cancel_event):
                    return
                self.after_task(task_id, self._batch_error, str(exc))

        threading.Thread(target=worker, daemon=True).start()

    def _slim_batch_summary(self, summary: list[dict]) -> list[dict]:
        slimmed: list[dict] = []
        for item in summary:
            if not isinstance(item, dict):
                continue
            clean_item = dict(item)
            clean_item.pop("source_text", None)
            clean_item.pop("output_text", None)
            slimmed.append(clean_item)
        return slimmed

    def _ordered_batch_summary(self, summary_by_file: dict[str, dict], files: list[Path]) -> list[dict]:
        ordered: list[dict] = []
        seen: set[str] = set()
        for index, path in enumerate(files, start=1):
            key = str(path)
            item = summary_by_file.get(key)
            if item:
                item.setdefault("index", index)
                ordered.append(item)
                seen.add(key)
        for key, item in summary_by_file.items():
            if key not in seen:
                ordered.append(item)
        return ordered

    def _update_batch_results_from_map(self, summary_by_file: dict[str, dict], output_dir: Path) -> None:
        files = [Path(item.get("file", "")) for item in summary_by_file.values() if item.get("file")]
        files = sorted(files, key=lambda item: str(item).lower())
        self.batch_results = self._ordered_batch_summary(summary_by_file, files)
        self.batch_output_dir = output_dir
        self._render_batch_results()

    def _render_batch_results(self) -> None:
        if not hasattr(self, "batch_results_tree"):
            return
        self.batch_results_tree.delete(*self.batch_results_tree.get_children())
        ok_count = sum(1 for item in self.batch_results if item.get("status") == "ok")
        error_count = sum(1 for item in self.batch_results if item.get("status") == "error")
        self.vars["batch_result_meta"].set(f"{len(self.batch_results)} dòng | OK {ok_count} | Lỗi {error_count}")
        for row_index, item in enumerate(self.batch_results, start=1):
            file_name = Path(item.get("file", "")).name
            words = ""
            if item.get("words_source") is not None or item.get("words_output") is not None:
                words = f"{item.get('words_source', '-')}/{item.get('words_output', '-')}"
            similarity = ""
            if item.get("similarity_percent") is not None:
                similarity = f"{item.get('similarity_risk', '')} {item.get('similarity_percent')}/100".strip()
            note = item.get("error") or "; ".join(item.get("suggestions") or [])[:260]
            self.batch_results_tree.insert(
                "",
                "end",
                iid=str(row_index - 1),
                values=(
                    item.get("index", row_index),
                    item.get("status", ""),
                    file_name,
                    item.get("story_title", ""),
                    words,
                    item.get("output_voice", ""),
                    item.get("story_score", ""),
                    similarity,
                    item.get("length_status", ""),
                    note,
                ),
            )

    def _selected_batch_item(self) -> dict | None:
        if not hasattr(self, "batch_results_tree"):
            return None
        selected = self.batch_results_tree.selection()
        if not selected:
            return None
        try:
            index = int(selected[0])
            return self.batch_results[index]
        except Exception:
            return None

    def _batch_item_output_text(self, item: dict) -> str:
        if item.get("output_text"):
            return item.get("output_text", "")
        exported = item.get("exported") or {}
        txt_path = exported.get("txt")
        if txt_path and Path(txt_path).exists():
            try:
                return Path(txt_path).read_text(encoding="utf-8")
            except Exception:
                return ""
        return ""

    def _batch_item_source_text(self, item: dict) -> str:
        if item.get("source_text"):
            return item.get("source_text", "")
        file_path = item.get("file")
        if file_path and Path(file_path).exists():
            try:
                return clean_imported_script(read_script_file(Path(file_path)))
            except Exception:
                return ""
        return ""

    def _batch_item_summary_bundle(self, item: dict, source: str, output: str) -> tuple[str, str, str]:
        source_summary = item.get("source_summary", "")
        output_summary = item.get("output_summary", "")
        comparison = item.get("summary_compare", "")
        if self._batch_summary_is_vietnamese(source_summary, output_summary, comparison):
            return source_summary, output_summary, comparison
        source_summary = "Đang chờ tạo tóm tắt tiếng Việt bắt buộc bằng Gemini."
        output_summary = "Đang chờ tạo tóm tắt tiếng Việt bắt buộc bằng Gemini."
        comparison = "Chưa có so sánh tiếng Việt. Hãy chọn item và chờ Gemini tạo tóm tắt."
        item["source_summary"] = source_summary
        item["output_summary"] = output_summary
        item["summary_compare"] = comparison
        self._save_batch_summary_if_possible()
        return source_summary, output_summary, comparison

    def _batch_summary_is_vietnamese(self, source_summary: str, output_summary: str, comparison: str) -> bool:
        combined = "\n".join([source_summary or "", output_summary or "", comparison or ""]).strip()
        if not source_summary or not output_summary or not comparison:
            return False
        if "Đang chờ tạo tóm tắt" in combined or "Chưa có so sánh tiếng Việt" in combined:
            return False
        return not language_mismatch_warning(combined, DEFAULT_REVIEW_LANGUAGE)

    def _set_batch_summary_widgets(self, source_summary: str, output_summary: str, comparison: str) -> None:
        if hasattr(self, "batch_source_summary_text"):
            self.set_text(self.batch_source_summary_text, source_summary)
        if hasattr(self, "batch_output_summary_text"):
            self.set_text(self.batch_output_summary_text, output_summary)
        if hasattr(self, "batch_summary_compare_text"):
            self.set_text(self.batch_summary_compare_text, comparison)

    def _generate_batch_summary_vietnamese_async(self, item: dict, source: str, output: str) -> None:
        config = self.config_dict()
        if self._batch_summary_is_vietnamese(item.get("source_summary", ""), item.get("output_summary", ""), item.get("summary_compare", "")):
            return
        if config.get("test_mode_no_api"):
            raw = mock_direct_summary_output(source, output, config)
            self._batch_direct_summary_done(item, raw, from_cache=False)
            return
        api_key = self.gemini_api_key_pool_text()
        system = (
            "Bạn là biên tập viên tóm tắt kịch bản đa ngôn ngữ cho người Việt. "
            "Chỉ trả về tiếng Việt có dấu. Không dịch nguyên văn toàn bộ, chỉ tóm tắt chi tiết và so sánh."
        )
        prompt = build_direct_vietnamese_summary_prompt(source, output, config)
        generation_config = direct_summary_generation_settings(config, source, output)
        cache_key = gemini_cache_key(config["gemini_model"], system, prompt, generation_config, "batch_direct_summary_vi_v1")
        use_cache = bool(self.vars["use_cache"].get())
        if use_cache:
            cached = self.gemini_cache.get(cache_key, {}).get("output", "")
            if cached and direct_vietnamese_summary_valid(cached):
                self._batch_direct_summary_done(item, cached, from_cache=True)
                return
            if cached:
                self.gemini_cache.pop(cache_key, None)
                save_gemini_cache_file(self.gemini_cache)
        if config.get("cache_only_mode") or not parse_gemini_api_keys(api_key):
            self._set_batch_summary_widgets(
                "Cần Gemini API key hoặc cache tóm tắt tiếng Việt để hiển thị phần này. App không hiển thị tóm tắt tiếng nước ngoài ở đây.",
                "Cần Gemini API key hoặc cache tóm tắt tiếng Việt để hiển thị phần này. App không hiển thị tóm tắt tiếng nước ngoài ở đây.",
                "Không có tóm tắt tiếng Việt trong cache. Hãy tắt cache-only hoặc nhập API key rồi chọn lại item.",
            )
            return
        self._set_batch_summary_widgets(
            "Gemini đang tạo tóm tắt tiếng Việt cho kịch bản gốc...",
            "Gemini đang tạo tóm tắt tiếng Việt cho bản AI...",
            "Gemini đang so sánh 2 nội dung bằng tiếng Việt...",
        )
        self.vars["status"].set("Đang tạo tóm tắt Batch bằng tiếng Việt...")

        def worker() -> None:
            try:
                raw = call_gemini(
                    api_key,
                    config["gemini_model"],
                    system,
                    prompt,
                    generation_config,
                    api_switch_callback=self.api_switch_callback("Batch summary tiếng Việt"),
                )
                if not direct_vietnamese_summary_valid(raw):
                    retry_prompt = build_direct_vietnamese_summary_prompt(source, output, config, strict_retry=True)
                    raw = call_gemini(
                        api_key,
                        config["gemini_model"],
                        system,
                        retry_prompt,
                        generation_config,
                        api_switch_callback=self.api_switch_callback("Batch summary retry"),
                    )
                if not direct_vietnamese_summary_valid(raw):
                    raise RuntimeError("Gemini trả tóm tắt chưa đạt yêu cầu tiếng Việt 100%. Hãy thử lại hoặc đổi model/API key.")
                if use_cache:
                    self.gemini_cache[cache_key] = {
                        "mode": "batch_direct_summary_vi_v1",
                        "model": config["gemini_model"],
                        "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                        "output": raw,
                    }
                    save_gemini_cache_file(self.gemini_cache)
                self.after(0, lambda: self._batch_direct_summary_done(item, raw, from_cache=False))
            except Exception as exc:
                self.after(0, lambda error=str(exc): self._batch_direct_summary_error(error))

        threading.Thread(target=worker, daemon=True).start()

    def _batch_direct_summary_done(self, item: dict, raw: str, from_cache: bool = False) -> None:
        source_summary, output_summary, comparison = split_direct_vietnamese_summary(raw)
        item["source_summary"] = source_summary
        item["output_summary"] = output_summary
        item["summary_compare"] = comparison
        self._set_batch_summary_widgets(source_summary, output_summary, comparison)
        self._save_batch_summary_if_possible()
        self.vars["status"].set("Đã dùng cache tóm tắt Batch tiếng Việt" if from_cache else "Đã tạo tóm tắt Batch tiếng Việt")

    def _batch_direct_summary_error(self, error: str) -> None:
        self._set_batch_summary_widgets(
            "Lỗi tạo tóm tắt tiếng Việt cho kịch bản gốc.",
            "Lỗi tạo tóm tắt tiếng Việt cho bản AI.",
            f"Lỗi tóm tắt tiếng Việt Batch:\n{error}",
        )
        self.vars["status"].set("Lỗi tóm tắt Batch tiếng Việt")

    def _save_batch_summary_if_possible(self) -> None:
        if not self.batch_output_dir:
            return
        try:
            self.batch_output_dir.mkdir(parents=True, exist_ok=True)
            (self.batch_output_dir / "_batch_summary.json").write_text(
                json.dumps(self._slim_batch_summary(self.batch_results), ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
        except Exception:
            pass

    def _on_batch_result_selected(self, _event=None) -> None:
        item = self._selected_batch_item()
        if not item:
            return
        source = self._batch_item_source_text(item)
        output = self._batch_item_output_text(item)
        if hasattr(self, "batch_source_preview"):
            self.set_text(self.batch_source_preview, source)
        if hasattr(self, "batch_output_preview"):
            self.set_text(self.batch_output_preview, output)
        if output:
            source_summary, output_summary, comparison = self._batch_item_summary_bundle(item, source, output)
            self._set_batch_summary_widgets(source_summary, output_summary, comparison)
            self._generate_batch_summary_vietnamese_async(item, source, output)
        else:
            self._set_batch_summary_widgets(
                "Item này chưa có output để tóm tắt.",
                "Item này chưa có output để tóm tắt.",
                "Cần batch item thành công để so sánh 2 nội dung.",
            )

    def use_selected_batch_result(self) -> None:
        item = self._selected_batch_item()
        if not item:
            messagebox.showwarning(APP_NAME, "Hãy chọn một dòng batch trước.")
            return
        source = self._batch_item_source_text(item)
        output = self._batch_item_output_text(item)
        if not output:
            messagebox.showwarning(APP_NAME, "Item này chưa có kịch bản output để dùng.")
            return
        self.set_text(self.source_text, source)
        self.set_text(self.draft_text, output)
        if item.get("story_title"):
            self.apply_story_title(item.get("story_title", ""), silent=True)
        if source:
            self.report = self._similarity_report(source, output, "So sánh batch item đã chọn với bản gốc")
        self._render_all()
        self.notebook.select(self.editor_tab)
        self.vars["status"].set(f"Đã đưa item batch vào Biên tập: {Path(item.get('file', '')).name}")

    def open_batch_output_folder(self) -> None:
        folder = self.batch_output_dir
        if not folder and self.batch_results:
            exported = self.batch_results[0].get("exported") or {}
            txt_path = exported.get("txt")
            if txt_path:
                folder = Path(txt_path).parent
        if not folder or not Path(folder).exists():
            messagebox.showwarning(APP_NAME, "Chưa có folder output batch để mở.")
            return
        os.startfile(str(folder))

    def copy_selected_batch_title(self) -> None:
        item = self._selected_batch_item()
        if not item:
            messagebox.showwarning(APP_NAME, "Hãy chọn một dòng batch trước.")
            return
        self.clipboard_clear()
        self.clipboard_append(item.get("story_title", ""))
        self.vars["status"].set("Đã copy title batch")

    def copy_selected_batch_path(self) -> None:
        item = self._selected_batch_item()
        if not item:
            messagebox.showwarning(APP_NAME, "Hãy chọn một dòng batch trước.")
            return
        exported = item.get("exported") or {}
        path_text = exported.get("txt") or item.get("file", "")
        self.clipboard_clear()
        self.clipboard_append(path_text)
        self.vars["status"].set("Đã copy đường dẫn item batch")

    def copy_selected_batch_summaries(self) -> None:
        item = self._selected_batch_item()
        if not item:
            messagebox.showwarning(APP_NAME, "Hãy chọn một dòng batch trước.")
            return
        source = self._batch_item_source_text(item)
        output = self._batch_item_output_text(item)
        if not output:
            messagebox.showwarning(APP_NAME, "Item này chưa có kịch bản output để tóm tắt.")
            return
        source_summary, output_summary, _comparison = self._batch_item_summary_bundle(item, source, output)
        self.clipboard_clear()
        self.clipboard_append(source_summary + "\n\n" + output_summary)
        self.vars["status"].set("Đã copy tóm tắt batch")

    def copy_selected_batch_comparison(self) -> None:
        item = self._selected_batch_item()
        if not item:
            messagebox.showwarning(APP_NAME, "Hãy chọn một dòng batch trước.")
            return
        source = self._batch_item_source_text(item)
        output = self._batch_item_output_text(item)
        if not output:
            messagebox.showwarning(APP_NAME, "Item này chưa có kịch bản output để so sánh.")
            return
        _source_summary, _output_summary, comparison = self._batch_item_summary_bundle(item, source, output)
        self.clipboard_clear()
        self.clipboard_append(comparison)
        self.vars["status"].set("Đã copy so sánh tóm tắt batch")

    def rewrite_single_url_now(self, url: str) -> None:
        api_key = self.gemini_api_key_pool_text()
        config = self.config_dict()
        if not parse_gemini_api_keys(api_key) and not config.get("test_mode_no_api") and not config.get("cache_only_mode"):
            messagebox.showwarning(APP_NAME, "Cần nhập Gemini API key để đọc URL và viết lại.")
            return
        use_cache = bool(self.vars["use_cache"].get())
        self.notebook.select(self.gemini_tab)
        self.set_text(
            self.gemini_output,
            "Đang đọc URL và viết lại kịch bản...\n\n"
            f"URL: {url}\n"
            f"Model: {config['gemini_model']}\n"
            f"Ngôn ngữ đầu ra: {config['target_language']}\n"
            f"API key: {self.gemini_api_key_status_text()}\n\n"
            "Bước 1/2: đọc nguồn từ URL...\n",
        )
        task_id = self.start_task_feedback("Đang đọc URL...", indeterminate=True)
        self._set_buttons_state("disabled")
        cancel_event = self.cancel_event

        def worker() -> None:
            try:
                def source_retry(delay: int, attempt: int, total: int) -> None:
                    self.after(
                        0,
                        lambda d=delay, a=attempt, t=total: self.set_indeterminate_progress(
                            f"Gemini giới hạn quota khi đọc URL, đợi {d}s rồi thử lại ({a}/{t})..."
                        ) if self.is_task_current(task_id) else None,
                    )

                source, metadata, source_cache = self.extract_source_from_url(
                    api_key,
                    url,
                    config,
                    use_cache=use_cache,
                    cancel_event=cancel_event,
                    retry_callback=source_retry,
                    api_switch_callback=self.api_switch_callback("URL đơn đọc nguồn"),
                )
                source = source.strip()
                if len(normalize_words(source)) < 30:
                    raise RuntimeError("Gemini không trích được đủ nội dung từ URL này. Hãy kiểm tra URL có công khai, đọc được và không cần đăng nhập.")

                self.after(0, lambda: self.set_indeterminate_progress("Đã đọc URL. Gemini đang viết lại kịch bản...") if self.is_task_current(task_id) else None)

                def rewrite_retry(delay: int, attempt: int, total: int) -> None:
                    self.after(
                        0,
                        lambda d=delay, a=attempt, t=total: self.set_indeterminate_progress(
                            f"Gemini giới hạn quota khi viết lại URL, đợi {d}s rồi thử lại ({a}/{t})..."
                        ) if self.is_task_current(task_id) else None,
                    )

                output, _analysis, rewrite_cache = generate_gemini_cached(
                    api_key,
                    config,
                    source,
                    "script_rewrite",
                    cache_store=self.gemini_cache,
                    use_cache=use_cache,
                    cancel_event=cancel_event,
                    retry_callback=rewrite_retry,
                    api_switch_callback=self.api_switch_callback("URL đơn viết lại"),
                )
                if self.task_cancelled(task_id, cancel_event):
                    return
                metadata = metadata if isinstance(metadata, dict) else {}
                report = score_similarity(source, output)
                story_score = story_score_40plus(output)
                process_label = f"source {'cache' if source_cache else 'Gemini'} | rewrite {'cache' if rewrite_cache else 'Gemini'}"
                _log_block, quality = format_batch_result_block(
                    1,
                    1,
                    url,
                    source,
                    output,
                    report,
                    story_score,
                    config,
                    process_label=process_label,
                    source_label="URL",
                )
                row = {
                    "index": 1,
                    "url": url,
                    "canonical_url": metadata.get("canonical_url", url),
                    "status": "ok",
                    "source_type": "youtube_url" if is_youtube_url(url) else "url_context",
                    "source_cache": source_cache,
                    "rewrite_cache": rewrite_cache,
                    "source_words": len(normalize_words(source)),
                    "output_words": len(normalize_words(output)),
                    "source_voice": quality.get("source_voice"),
                    "output_voice": quality.get("output_voice"),
                    "output_units": quality.get("output_units"),
                    "target_min_units": quality.get("target_min_units"),
                    "target_max_units": quality.get("target_max_units"),
                    "length_status": quality.get("length_status"),
                    "suggestions": quality.get("suggestions"),
                    "story_score": story_score.get("score"),
                    "similarity_risk": report.get("risk"),
                    "similarity_percent": report.get("similarity_percent"),
                    "metadata": metadata,
                    "source_text": source,
                    "output_text": output,
                }
                self.after_task(task_id, self._single_url_rewrite_done, url, source, output, row)
            except Exception as exc:
                if self.task_cancelled(task_id, cancel_event):
                    return
                self.after_task(task_id, self._single_url_rewrite_error, url, str(exc))

        threading.Thread(target=worker, daemon=True).start()

    def batch_rewrite_urls(self) -> None:
        api_key = self.gemini_api_key_pool_text()
        config = self.config_dict()
        if not parse_gemini_api_keys(api_key) and not config.get("test_mode_no_api") and not config.get("cache_only_mode"):
            messagebox.showwarning(APP_NAME, "Cần nhập Gemini API key để đọc URL và viết lại.")
            return
        raw_text = self.get_text(self.source_text).strip()
        urls = extract_urls(raw_text)
        if not urls:
            try:
                clipboard_text = self.clipboard_get()
                urls = extract_urls(clipboard_text)
                if urls:
                    self.set_text(self.source_text, "\n".join(urls))
            except tk.TclError:
                urls = []
        if not urls:
            messagebox.showwarning(APP_NAME, "Hãy dán danh sách URL vào ô kịch bản gốc, hoặc bấm 'Nhập URL list' trước.")
            return
        total_found = len(urls)
        if len(urls) > 50:
            urls = urls[:50]
            messagebox.showinfo(APP_NAME, f"Tìm thấy {total_found} URL. App sẽ xử lý 50 URL đầu tiên để tránh chạy quá lâu và vượt quota.")
        output_root = filedialog.askdirectory(title="Chọn thư mục lưu output cho batch URL")
        if not output_root:
            return
        output_dir = Path(output_root) / f"neon_url_rewrites_{time.strftime('%Y%m%d_%H%M%S')}"
        use_cache = bool(self.vars["use_cache"].get())
        self.notebook.select(self.gemini_tab)
        self.set_text(
            self.gemini_output,
            f"BATCH URL -> VIẾT LẠI\n\n"
            f"Output: {output_dir}\n"
            f"Số URL xử lý: {len(urls)} / {total_found}\n"
            f"Model: {config['gemini_model']}\n"
            f"Ngôn ngữ đầu ra: {config['target_language']}\n\n"
            f"Chiến lược thời lượng: tự đo từng nguồn URL, bản mới luôn dài hơn nguồn.\n"
            f"Ô thời lượng hiện tại chỉ là tham khảo: {config.get('duration_goal', config.get('duration', ''))}\n"
            f"API key: {self.gemini_api_key_status_text()}\n\n"
            "YouTube URL sẽ dùng Gemini Video Understanding. Trang web/PDF sẽ dùng URL Context.\n"
            "Mỗi URL sẽ có block riêng: số từ, thời gian đọc voice, Story 40+, độ giống và gợi ý nâng cấp.\n",
        )
        self.url_batch_results = []
        self._render_url_results()
        task_id = self.start_task_feedback(f"Batch URL: 0/{len(urls)}", indeterminate=False)
        self._set_buttons_state("disabled")
        cancel_event = self.cancel_event

        def worker() -> None:
            summary: list[dict] = []
            result_rows: list[dict] = []
            last_source = ""
            last_output = ""
            last_url = ""
            consecutive_api_errors = 0
            try:
                for index, url in enumerate(urls, start=1):
                    if self.task_cancelled(task_id, cancel_event):
                        return
                    self.after_task(
                        task_id,
                        lambda i=index, u=url: (
                            self.update_progress(i - 1, len(urls), f"Đang đọc URL {i}/{len(urls)}"),
                            self.append_text(self.gemini_output, f"\n[URL] {i}/{len(urls)} {u}\n"),
                        ),
                    )
                    try:
                        def source_retry(delay: int, attempt: int, total: int, u=url) -> None:
                            if self.is_task_current(task_id):
                                self.after_task(
                                    task_id,
                                    self.set_indeterminate_progress,
                                    f"Gemini giới hạn quota khi đọc URL, đợi {delay}s rồi thử lại ({attempt}/{total})...",
                                )

                        source, metadata, source_cache = self.extract_source_from_url(
                            api_key,
                            url,
                            config,
                            use_cache=use_cache,
                            cancel_event=cancel_event,
                            retry_callback=source_retry,
                            api_switch_callback=self.api_switch_callback(f"Batch URL source {index}/{len(urls)}"),
                        )
                        source = source.strip()
                        if len(normalize_words(source)) < 30:
                            raise RuntimeError("Gemini không trích được đủ nội dung từ URL này. URL có thể bị chặn, cần đăng nhập, hoặc không có text/transcript công khai.")

                        if self.task_cancelled(task_id, cancel_event):
                            return
                        self.after_task(task_id, self.set_indeterminate_progress, f"Đang viết lại kịch bản từ URL {index}/{len(urls)}...")

                        def rewrite_retry(delay: int, attempt: int, total: int) -> None:
                            if self.is_task_current(task_id):
                                self.after_task(
                                    task_id,
                                    self.set_indeterminate_progress,
                                    f"Gemini giới hạn quota khi viết lại URL, đợi {delay}s rồi thử lại ({attempt}/{total})...",
                                )

                        output, analysis, rewrite_cache = generate_gemini_cached(
                            api_key,
                            config,
                            source,
                            "script_rewrite",
                            cache_store=self.gemini_cache,
                            use_cache=use_cache,
                            cancel_event=cancel_event,
                            retry_callback=rewrite_retry,
                            api_switch_callback=self.api_switch_callback(f"Batch URL rewrite {index}/{len(urls)}"),
                        )
                        report = score_similarity(source, output)
                        story_score = story_score_40plus(output)
                        exported = export_url_rewrite_bundle(output_dir, index, url, source, output, report, story_score, metadata)
                        process_label = f"source {'cache' if source_cache else 'Gemini'} | rewrite {'cache' if rewrite_cache else 'Gemini'}"
                        log_block, quality = format_batch_result_block(
                            index,
                            len(urls),
                            url,
                            source,
                            output,
                            report,
                            story_score,
                            config,
                            process_label=process_label,
                            exported=exported,
                            source_label="URL",
                        )
                        item = {
                            "index": index,
                            "url": url,
                            "canonical_url": metadata.get("canonical_url", url),
                            "status": "ok",
                            "source_type": "youtube_url" if is_youtube_url(url) else "url_context",
                            "source_cache": source_cache,
                            "rewrite_cache": rewrite_cache,
                            "source_words": len(normalize_words(source)),
                            "output_words": len(normalize_words(output)),
                            "source_voice": quality.get("source_voice"),
                            "output_voice": quality.get("output_voice"),
                            "output_units": quality.get("output_units"),
                            "target_min_units": quality.get("target_min_units"),
                            "target_max_units": quality.get("target_max_units"),
                            "length_status": quality.get("length_status"),
                            "suggestions": quality.get("suggestions"),
                            "story_score": story_score.get("score"),
                            "similarity_risk": report.get("risk"),
                            "similarity_percent": report.get("similarity_percent"),
                            "exported": exported,
                            "metadata": metadata,
                        }
                        summary.append(item)
                        result_rows.append({**item, "source_text": source, "output_text": output})
                        last_source = source
                        last_output = output
                        last_url = url
                        consecutive_api_errors = 0
                        if self.task_cancelled(task_id, cancel_event):
                            return
                        self.after_task(task_id, self.append_text, self.gemini_output, log_block)
                    except Exception as url_exc:
                        if self.task_cancelled(task_id, cancel_event):
                            return
                        item = {"index": index, "url": url, "status": "error", "source_type": "error", "error": str(url_exc)}
                        summary.append(item)
                        result_rows.append({**item, "source_text": "", "output_text": ""})
                        self.after_task(task_id, self.append_text, self.gemini_output, format_batch_error_block(index, len(urls), url, url_exc, source_label="URL"))
                        if is_batch_circuit_breaker_error(url_exc):
                            consecutive_api_errors += 1
                        else:
                            consecutive_api_errors = 0
                        if consecutive_api_errors >= 3:
                            self.after_task(
                                task_id,
                                self.append_text,
                                self.gemini_output,
                                "\n[DỪNG BATCH URL] Gặp 3 lỗi API/quota liên tiếp. App đã dừng để tránh mất thời gian và quota. "
                                "Hãy thay API key, giảm batch hoặc thử lại sau vài phút.\n",
                            )
                            break
                    self.after_task(task_id, self.update_progress, index, len(urls), f"Batch URL: {index}/{len(urls)}")

                output_dir.mkdir(parents=True, exist_ok=True)
                (output_dir / "_url_batch_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
                summary_lines = [
                    "# URL Batch Summary",
                    "",
                    f"- Output: {output_dir}",
                    f"- Tổng URL xử lý: {len(urls)}",
                    f"- Thành công: {sum(1 for item in summary if item.get('status') == 'ok')}",
                    f"- Lỗi: {sum(1 for item in summary if item.get('status') == 'error')}",
                    f"- Model: {config['gemini_model']}",
                    "",
                    "## Chi tiết",
                ]
                for item in summary:
                    if item.get("status") == "ok":
                        summary_lines.append(
                            f"- OK | {item.get('source_type')} | {item.get('url')} | "
                            f"Nguồn: {item.get('source_words')} từ | Bản mới: {item.get('output_words')} từ | "
                            f"Voice: {item.get('output_voice', 'N/A')} | Story: {item.get('story_score')} | "
                            f"Similarity: {item.get('similarity_risk')} {item.get('similarity_percent')}/100 | Length: {item.get('length_status', 'N/A')}"
                        )
                    else:
                        summary_lines.append(f"- LỖI | {item.get('url')} | {item.get('error', '')}")
                (output_dir / "_url_batch_summary.md").write_text("\n".join(summary_lines), encoding="utf-8")
                if self.task_cancelled(task_id, cancel_event):
                    return
                self.after_task(task_id, self._url_batch_done, output_dir, summary, result_rows, last_url, last_source, last_output)
            except Exception as exc:
                if self.task_cancelled(task_id, cancel_event):
                    return
                self.after_task(task_id, self._url_batch_error, str(exc), result_rows)

        threading.Thread(target=worker, daemon=True).start()

    def batch_extract_videos_folder(self) -> None:
        api_key = self.gemini_api_key_pool_text()
        config = self.config_dict()
        if config.get("test_mode_no_api"):
            messagebox.showinfo(APP_NAME, "Đang bật Test không gọi API. Batch video cần upload/gọi Gemini nên app sẽ không xử lý video trong chế độ test.")
            return
        if config.get("cache_only_mode"):
            messagebox.showinfo(APP_NAME, "Đang bật Chỉ dùng cache. Batch video cần upload/gọi Gemini nếu chưa có cache nên app dừng sớm để tránh quota.")
            return
        if not parse_gemini_api_keys(api_key):
            messagebox.showwarning(APP_NAME, "Cần nhập Gemini API key để batch trích kịch bản video.")
            return
        folder_text = filedialog.askdirectory(title="Chọn thư mục chứa video cần trích kịch bản hàng loạt")
        if not folder_text:
            return
        input_dir = Path(folder_text)
        files = iter_video_files(input_dir)
        if not files:
            messagebox.showwarning(APP_NAME, "Không tìm thấy video được hỗ trợ trong thư mục này.")
            return
        total_found = len(files)
        if len(files) > 50:
            files = files[:50]
            messagebox.showinfo(APP_NAME, f"Tìm thấy {total_found} video. App sẽ xử lý 50 video đầu tiên để tránh chạy quá lâu và vượt quota.")

        output_dir = input_dir / f"neon_video_transcripts_{time.strftime('%Y%m%d_%H%M%S')}"
        settings = video_extraction_settings(config["video_extract_mode"])
        self.notebook.select(self.gemini_tab)
        self.set_text(
            self.gemini_output,
            f"BATCH VIDEO -> TRÍCH KỊCH BẢN\n\n"
            f"Nguồn: {input_dir}\n"
            f"Output: {output_dir}\n"
            f"Số video xử lý: {len(files)} / {total_found}\n"
            f"Chế độ: {config['video_extract_mode']}\n"
            f"Model: {config['gemini_model']}\n\n"
            f"Ngôn ngữ đầu ra: {config['target_language']}\n"
            f"API key: {self.gemini_api_key_status_text()}\n\n"
            "App sẽ xử lý tuần tự từng video để giảm lỗi quota 429.\n"
            "Mỗi video sẽ hiển thị: dung lượng, số từ transcript, thời gian đọc voice và gợi ý xử lý tiếp.\n",
        )
        task_id = self.start_task_feedback(f"Batch video: 0/{len(files)}", indeterminate=False)
        self._set_buttons_state("disabled")
        cancel_event = self.cancel_event

        def worker() -> None:
            summary: list[dict] = []
            last_transcript = ""
            last_video: Path | None = None
            consecutive_api_errors = 0
            try:
                prompt = build_video_script_prompt(config)
                for index, path in enumerate(files, start=1):
                    if self.task_cancelled(task_id, cancel_event):
                        return
                    mime_type = guess_video_mime(path)
                    size_mb = path.stat().st_size / (1024 * 1024)
                    self.after_task(
                        task_id,
                        lambda i=index, p=path, s=size_mb: (
                            self.update_progress(i - 1, len(files), f"Video {i}/{len(files)}: chuẩn bị {p.name}"),
                            self.append_text(self.gemini_output, f"\n[VIDEO] {i}/{len(files)} {p.name} | {s:.1f} MB\n"),
                        ),
                    )
                    try:
                        cache_key = self.video_cache_key(path)

                        def progress_callback(_phase, current, total, message, i=index, p=path):
                            if self.is_task_current(task_id):
                                self.after_task(task_id, self.update_progress, current, total, f"{p.name}: {message}")

                        if cache_key in self.upload_cache:
                            file_info = self.upload_cache[cache_key]
                            self.after_task(task_id, self.append_text, self.gemini_output, f"  Dùng lại file URI đã upload: {path.name}\n")
                        else:
                            file_info = upload_file_to_gemini(
                                api_key,
                                path,
                                mime_type,
                                progress_callback=progress_callback,
                                cancel_event=cancel_event,
                                api_switch_callback=self.api_switch_callback(f"Batch video upload {index}/{len(files)}"),
                            )
                            self.upload_cache[cache_key] = file_info

                        if self.task_cancelled(task_id, cancel_event):
                            return

                        def video_retry_callback(delay: int, attempt: int, total: int, p=path) -> None:
                            if self.is_task_current(task_id):
                                self.after_task(
                                    task_id,
                                    self.set_indeterminate_progress,
                                    f"{p.name}: Gemini giới hạn quota, đợi {delay}s rồi thử lại ({attempt}/{total})...",
                                )

                        self.after_task(task_id, self.set_indeterminate_progress, f"Gemini đang đọc video {index}/{len(files)}: {path.name}")
                        transcript = call_gemini_with_file(
                            api_key=api_key,
                            model=config["gemini_model"],
                            file_uri=file_info["uri"],
                            mime_type=file_info.get("mimeType") or file_info.get("mime_type") or mime_type,
                            prompt=prompt,
                            max_output_tokens=settings["max_output_tokens"],
                            media_resolution=settings["media_resolution"],
                            cancel_event=cancel_event,
                            retry_callback=video_retry_callback,
                            api_switch_callback=self.api_switch_callback(f"Batch video read {index}/{len(files)}"),
                        )
                        exported = export_video_transcript_bundle(output_dir, index, path, transcript, config, file_info)
                        analysis = analyze_script(transcript)
                        log_block, video_metrics = format_video_batch_result_block(index, len(files), path.name, transcript, config, size_mb, exported)
                        item = {
                            "file": str(path),
                            "status": "ok",
                            "mime_type": mime_type,
                            "size_mb": round(size_mb, 2),
                            "words": analysis.word_count,
                            "estimated_minutes": analysis.estimated_minutes,
                            "voice_time": video_metrics.get("voice_time"),
                            "voice_units": video_metrics.get("voice_units"),
                            "suggestions": video_metrics.get("suggestions"),
                            "exported": exported,
                        }
                        summary.append(item)
                        last_transcript = transcript
                        last_video = path
                        consecutive_api_errors = 0
                        if self.task_cancelled(task_id, cancel_event):
                            return
                        self.after_task(task_id, self.append_text, self.gemini_output, log_block)
                    except Exception as file_exc:
                        if self.task_cancelled(task_id, cancel_event):
                            return
                        item = {"file": str(path), "status": "error", "error": str(file_exc)}
                        summary.append(item)
                        self.after_task(task_id, self.append_text, self.gemini_output, format_batch_error_block(index, len(files), path.name, file_exc, source_label="Video"))
                        if is_batch_circuit_breaker_error(file_exc):
                            consecutive_api_errors += 1
                        else:
                            consecutive_api_errors = 0
                        if consecutive_api_errors >= 3:
                            self.after_task(
                                task_id,
                                self.append_text,
                                self.gemini_output,
                                "\n[DỪNG BATCH VIDEO] Gặp 3 lỗi API/quota liên tiếp. App đã dừng để tránh mất thời gian và quota. "
                                "Hãy thay API key, giảm batch hoặc thử lại sau vài phút.\n",
                            )
                            break
                    self.after_task(task_id, self.update_progress, index, len(files), f"Batch video: {index}/{len(files)}")

                output_dir.mkdir(parents=True, exist_ok=True)
                (output_dir / "_video_batch_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
                summary_lines = [
                    "# Video Batch Summary",
                    "",
                    f"- Nguồn: {input_dir}",
                    f"- Output: {output_dir}",
                    f"- Tổng video xử lý: {len(files)}",
                    f"- Thành công: {sum(1 for item in summary if item.get('status') == 'ok')}",
                    f"- Lỗi: {sum(1 for item in summary if item.get('status') == 'error')}",
                    f"- Chế độ trích: {config['video_extract_mode']}",
                    f"- Model: {config['gemini_model']}",
                    "",
                    "## Chi tiết",
                ]
                for item in summary:
                    if item.get("status") == "ok":
                        summary_lines.append(f"- OK | {Path(item.get('file', '')).name} | {item.get('words', 0)} từ | voice {item.get('voice_time', item.get('estimated_minutes', 0))}")
                    else:
                        summary_lines.append(f"- LỖI | {Path(item.get('file', '')).name} | {item.get('error', '')}")
                (output_dir / "_video_batch_summary.md").write_text("\n".join(summary_lines), encoding="utf-8")
                if self.task_cancelled(task_id, cancel_event):
                    return
                self.after_task(task_id, self._video_batch_done, output_dir, summary, last_video, last_transcript)
            except Exception as exc:
                if self.task_cancelled(task_id, cancel_event):
                    return
                self.after_task(task_id, self._video_batch_error, str(exc))

        threading.Thread(target=worker, daemon=True).start()

    def _batch_done(self, output_dir: Path, summary: list[dict], last_source: str = "", last_output: str = "", last_title: str = "") -> None:
        self._set_buttons_state("normal")
        ok_count = sum(1 for item in summary if item.get("status") == "ok")
        error_count = sum(1 for item in summary if item.get("status") == "error")
        self.finish_task_feedback(f"Batch xong: {ok_count} ok, {error_count} lỗi")
        self.append_text(self.gemini_output, batch_summary_overview(summary, self.config_dict(), output_dir, "Tổng kết batch kịch bản"))
        self.batch_results = summary
        self.batch_output_dir = output_dir
        self._render_batch_results()
        if last_output:
            self.set_text(self.source_text, last_source)
            self.set_text(self.draft_text, last_output)
            self.apply_story_title(last_title or best_youtube_story_title(last_output, last_source, self.config_dict()), silent=True)
            if last_source:
                self.report = self._similarity_report(last_source, last_output, "So sánh batch item cuối với bản gốc")
            self._render_all()
        self.notebook.select(self.batch_tab)
        self.vars["status"].set("Batch mode đã xử lý xong")

    def _batch_cancelled(self, output_dir: Path, summary: list[dict]) -> None:
        self._set_buttons_state("normal")
        self.finish_task_feedback("Đã hủy batch", success=False)
        self.batch_results = summary
        self.batch_output_dir = output_dir
        self._render_batch_results()
        self.append_text(self.gemini_output, f"\nBatch đã hủy. Output tạm thời: {output_dir}\nFile đã ghi: {sum(1 for item in summary if item.get('status') == 'ok')}\n")

    def _batch_error(self, error: str) -> None:
        self._set_buttons_state("normal")
        self.finish_task_feedback("Lỗi batch", success=False)
        self.append_text(self.gemini_output, f"\nLỗi batch:\n{error}\n")
        messagebox.showerror(APP_NAME, error[:1200])

    def _url_batch_done(self, output_dir: Path, summary: list[dict], result_rows: list[dict], last_url: str, last_source: str, last_output: str) -> None:
        self._set_buttons_state("normal")
        ok_count = sum(1 for item in summary if item.get("status") == "ok")
        error_count = sum(1 for item in summary if item.get("status") == "error")
        self.finish_task_feedback(f"Batch URL xong: {ok_count} ok, {error_count} lỗi")
        self.append_text(self.gemini_output, batch_summary_overview(summary, self.config_dict(), output_dir, "Tổng kết batch URL"))
        self.url_batch_results = result_rows
        self._render_url_results()
        if last_source and last_output:
            self.set_text(self.source_text, last_source)
            self.set_text(self.draft_text, last_output)
            self.analysis = analyze_script(last_source)
            self.report = self._similarity_report(last_source, last_output, "So sánh nguồn URL đã trích với bản viết lại")
            self.vars["video_path"].set(f"URL batch cuối: {last_url}")
            self._render_all()
        self.notebook.select(self.url_results_tab)
        self.vars["status"].set("Batch URL đã đọc và viết lại xong")

    def _url_batch_cancelled(self, output_dir: Path, summary: list[dict], result_rows: list[dict] | None = None) -> None:
        self._set_buttons_state("normal")
        self.finish_task_feedback("Đã hủy batch URL", success=False)
        if result_rows is not None:
            self.url_batch_results = result_rows
            self._render_url_results()
        self.append_text(self.gemini_output, f"\nBatch URL đã hủy. Output tạm thời: {output_dir}\nURL đã ghi: {sum(1 for item in summary if item.get('status') == 'ok')}\n")

    def _url_batch_error(self, error: str, result_rows: list[dict] | None = None) -> None:
        self._set_buttons_state("normal")
        self.finish_task_feedback("Lỗi batch URL", success=False)
        if result_rows is not None:
            self.url_batch_results = result_rows
            self._render_url_results()
        self.append_text(self.gemini_output, f"\nLỗi batch URL:\n{error}\n")
        messagebox.showerror(APP_NAME, error[:1200])

    def _single_url_rewrite_done(self, url: str, source: str, output: str, row: dict) -> None:
        self._set_buttons_state("normal")
        self.finish_task_feedback("Đã đọc URL và viết lại")
        self.set_text(self.source_text, source)
        self.set_text(self.draft_text, output)
        self.set_text(self.gemini_output, output)
        self.url_batch_results = [row]
        self._render_url_results()
        self.analysis = analyze_script(source)
        self.report = self._similarity_report(source, output, "So sánh nguồn URL với bản viết lại")
        self.vars["video_path"].set(f"URL: {url}")
        self.save_settings()
        self._render_all()
        effective_config = config_with_source_duration(self.config_dict(), source)
        self.vars["status"].set(
            f"Đã đọc URL và viết lại | {text_length_meta(output, effective_config['target_language'], effective_config['duration'], include_target=True)}"[:260]
        )
        self.notebook.select(self.editor_tab)

    def _single_url_rewrite_error(self, url: str, error: str) -> None:
        self._set_buttons_state("normal")
        self.finish_task_feedback("Lỗi đọc URL", success=False)
        self.set_text(self.gemini_output, f"Lỗi đọc URL và viết lại:\n{url}\n\n{error}")
        self.url_batch_results = [
            {
                "index": 1,
                "url": url,
                "status": "error",
                "source_type": "error",
                "error": error,
                "source_text": "",
                "output_text": "",
            }
        ]
        self._render_url_results()
        messagebox.showerror(APP_NAME, error[:1200])

    def _video_batch_done(self, output_dir: Path, summary: list[dict], last_video: Path | None, last_transcript: str) -> None:
        self._set_buttons_state("normal")
        ok_count = sum(1 for item in summary if item.get("status") == "ok")
        error_count = sum(1 for item in summary if item.get("status") == "error")
        self.finish_task_feedback(f"Batch video xong: {ok_count} ok, {error_count} lỗi")
        self.append_text(self.gemini_output, video_batch_summary_overview(summary, output_dir))
        if last_video and last_transcript:
            self.set_text(self.source_text, last_transcript)
            self.analysis = analyze_script(last_transcript)
            self.vars["video_path"].set(f"Video batch cuối: {last_video.name}")
            self._render_all()
        self.vars["status"].set("Batch video đã trích kịch bản xong")

    def _video_batch_cancelled(self, output_dir: Path, summary: list[dict]) -> None:
        self._set_buttons_state("normal")
        self.finish_task_feedback("Đã hủy batch video", success=False)
        self.append_text(self.gemini_output, f"\nBatch video đã hủy. Output tạm thời: {output_dir}\nVideo đã ghi: {sum(1 for item in summary if item.get('status') == 'ok')}\n")

    def _video_batch_error(self, error: str) -> None:
        self._set_buttons_state("normal")
        self.finish_task_feedback("Lỗi batch video", success=False)
        self.append_text(self.gemini_output, f"\nLỗi batch video:\n{error}\n")
        messagebox.showerror(APP_NAME, error[:1200])

    def analyze(self) -> None:
        source = self.get_text(self.source_text).strip()
        if not source:
            messagebox.showwarning(APP_NAME, "Cần có kịch bản gốc để phân tích.")
            return
        self.analysis = analyze_script(source)
        self._render_all()
        self.notebook.select(self.analysis_tab)
        self.vars["status"].set("Đã phân tích")

    def generate_prompt(self) -> None:
        source = self.get_text(self.source_text).strip()
        if not source:
            messagebox.showwarning(APP_NAME, "Cần có kịch bản gốc để tạo prompt.")
            return
        if not self.analysis:
            self.analysis = analyze_script(source)
        prompt = build_rewrite_prompt(source, self.analysis, self.config_dict())
        self.set_text(self.gemini_output, prompt)
        self.notebook.select(self.gemini_tab)
        self.vars["status"].set("Đã tạo prompt")

    def _usable_generated_text(self, text: str) -> bool:
        value = text.strip()
        if not value:
            return False
        blocked_prefixes = (
            "Đang gọi Gemini",
            "Đã chọn video:",
            "Lỗi Gemini",
            "Lỗi trích kịch bản",
            "Tác vụ Gemini",
            "Tác vụ đã được hủy",
        )
        return not any(value.startswith(prefix) for prefix in blocked_prefixes)

    def _usable_translation_text(self, text: str) -> bool:
        value = text.strip()
        if len(normalize_words(value)) < 20:
            return False
        blocked_prefixes = ("Đang dịch", "Lỗi dịch", "Đã hủy")
        return not any(value.startswith(prefix) for prefix in blocked_prefixes)

    def _make_translation_signature(self, source: str, rewritten: str) -> str:
        raw = json.dumps({"source": source.strip(), "rewritten": rewritten.strip()}, ensure_ascii=False, sort_keys=True)
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()

    def _similarity_report(self, source: str, rewritten: str, mode: str) -> dict:
        report = score_similarity(source, rewritten)
        similarity = report.get("similarity_percent", report.get("risk_score", 0))
        report["similarity_percent"] = similarity
        report["originality_percent"] = max(0, 100 - similarity)
        report["comparison_mode"] = mode
        return report

    def _similarity_inputs(self) -> tuple[str, str, str, str]:
        source = self.get_text(self.source_text).strip()
        draft = self.get_text(self.draft_text).strip()
        gemini_output = self.get_text(self.gemini_output).strip() if hasattr(self, "gemini_output") else ""
        rewritten = draft if self._usable_generated_text(draft) else ""
        if not rewritten and self._usable_generated_text(gemini_output):
            rewritten = gemini_output

        source_translation = self.get_text(self.source_translation_text).strip() if hasattr(self, "source_translation_text") else ""
        rewritten_translation = self.get_text(self.rewritten_translation_text).strip() if hasattr(self, "rewritten_translation_text") else ""
        translations_match_current_script = self.translation_signature == self._make_translation_signature(source, rewritten)
        if translations_match_current_script and self._usable_translation_text(source_translation) and self._usable_translation_text(rewritten_translation):
            return source_translation, rewritten_translation, rewritten, "So sánh bằng bản dịch kiểm tra - phù hợp nhất cho nguồn đa ngôn ngữ"
        return source, rewritten, rewritten, "So sánh trực tiếp kịch bản gốc với bản mới"

    def score(self) -> None:
        source, draft, raw_rewritten, mode = self._similarity_inputs()
        if not source or not draft:
            messagebox.showwarning(APP_NAME, "Cần có kịch bản gốc và bản mới/Gemini output để chấm độ giống.")
            return
        self.report = self._similarity_report(source, draft, mode)
        if not self.get_text(self.draft_text).strip() and raw_rewritten:
            self.set_text(self.draft_text, raw_rewritten)
        self._render_all()
        self.notebook.select(self.similarity_tab)
        self.vars["status"].set(f"Độ giống: {self.report['similarity_percent']}% | Rủi ro: {self.report['risk'].upper()}")

    def extract_script_from_video(self) -> None:
        api_key = self.gemini_api_key_pool_text()
        config = self.config_dict()
        if config.get("test_mode_no_api"):
            messagebox.showinfo(APP_NAME, "Đang bật Test không gọi API. Video cần Gemini Files API nên app sẽ không upload video trong chế độ test.")
            return
        if config.get("cache_only_mode"):
            messagebox.showinfo(APP_NAME, "Đang bật Chỉ dùng cache. Trích video mới cần upload/gọi Gemini nên app dừng sớm để tránh quota.")
            return
        if not parse_gemini_api_keys(api_key):
            messagebox.showwarning(APP_NAME, "Cần nhập Gemini API key trước khi phân tích video.")
            return
        path_text = filedialog.askopenfilename(filetypes=VIDEO_FILE_TYPES, title="Chọn video để trích kịch bản")
        if not path_text:
            return
        path = Path(path_text)
        if not path.exists():
            messagebox.showerror(APP_NAME, "File video không tồn tại.")
            return
        mime_type = guess_video_mime(path)
        self.vars["video_path"].set(f"Video: {path.name}")
        self.notebook.select(self.gemini_tab)
        size_mb = path.stat().st_size / (1024 * 1024)
        settings = video_extraction_settings(config["video_extract_mode"])
        self.set_text(
            self.gemini_output,
            f"Đã chọn video:\n{path}\n\nMIME: {mime_type}\nDung lượng: {size_mb:.1f} MB\n\n"
            f"Chế độ: {config['video_extract_mode']}\n"
            f"Media resolution: {settings['media_resolution']}\n"
            f"Max output tokens: {settings['max_output_tokens']}\n\n"
            "Bước 1/3: chuẩn bị upload lên Gemini...\n",
        )
        task_id = self.start_task_feedback("Đang chuẩn bị upload video...", indeterminate=False)
        self._set_buttons_state("disabled")
        cancel_event = self.cancel_event

        def worker() -> None:
            try:
                config = self.config_dict()
                settings = video_extraction_settings(config["video_extract_mode"])
                cache_key = self.video_cache_key(path)

                def progress_callback(_phase, current, total, message):
                    if self.is_task_current(task_id):
                        self.after_task(task_id, self.update_progress, current, total, message)

                if cache_key in self.upload_cache:
                    file_info = self.upload_cache[cache_key]
                    self.after_task(task_id, self.append_text, self.gemini_output, "\nĐã dùng lại file URI Gemini từ lần upload trước trong phiên app này.\n")
                else:
                    file_info = upload_file_to_gemini(
                        api_key,
                        path,
                        mime_type,
                        progress_callback=progress_callback,
                        cancel_event=cancel_event,
                        api_switch_callback=self.api_switch_callback("Video upload"),
                    )
                    self.upload_cache[cache_key] = file_info
                if self.task_cancelled(task_id, cancel_event):
                    return
                prompt = build_video_script_prompt(config)
                self.after_task(
                    task_id,
                    lambda: (
                        self.append_text(
                            self.gemini_output,
                            f"\nBước 2/3: upload xong. Gemini đang đọc video theo chế độ {config['video_extract_mode']}...\n",
                        ),
                        self.set_indeterminate_progress("Gemini đang xử lý video, bước này có thể mất vài phút..."),
                    ),
                )
                def video_retry_callback(delay: int, attempt: int, total: int) -> None:
                    if self.is_task_current(task_id):
                        self.after_task(
                            task_id,
                            self.set_indeterminate_progress,
                            f"Gemini giới hạn quota khi đọc video, đợi {delay}s rồi thử lại ({attempt}/{total})...",
                        )

                output = call_gemini_with_file(
                    api_key=api_key,
                    model=config["gemini_model"],
                    file_uri=file_info["uri"],
                    mime_type=file_info.get("mimeType") or file_info.get("mime_type") or mime_type,
                    prompt=prompt,
                    max_output_tokens=settings["max_output_tokens"],
                    media_resolution=settings["media_resolution"],
                    cancel_event=cancel_event,
                    retry_callback=video_retry_callback,
                    api_switch_callback=self.api_switch_callback("Video extract"),
                )
                if self.task_cancelled(task_id, cancel_event):
                    return
                self.after_task(task_id, self._video_script_done, path, output)
            except Exception as exc:
                if self.task_cancelled(task_id, cancel_event):
                    return
                self.after_task(task_id, self._video_script_error, str(exc))

        threading.Thread(target=worker, daemon=True).start()

    def _video_script_done(self, path: Path, output: str) -> None:
        self._set_buttons_state("normal")
        self.finish_task_feedback("Đã trích kịch bản từ video")
        self.set_text(self.gemini_output, output)
        self.set_text(self.source_text, output)
        self.analysis = analyze_script(output)
        self.report = None
        self.vars["video_path"].set(f"Video: {path.name}")
        self._render_all()
        self.notebook.select(self.editor_tab)

    def _video_script_cancelled(self) -> None:
        self._set_buttons_state("normal")
        self.finish_task_feedback("Đã hủy tác vụ", success=False)
        self.append_text(self.gemini_output, "\nTác vụ đã được hủy. Nếu upload/generate đã gửi lên server, Gemini có thể vẫn xử lý phía server nhưng app sẽ bỏ qua kết quả.\n")

    def _video_script_error(self, error: str) -> None:
        self._set_buttons_state("normal")
        self.finish_task_feedback("Lỗi trích kịch bản từ video", success=False)
        self.set_text(self.gemini_output, f"Lỗi trích kịch bản từ video:\n{error}")
        messagebox.showerror(APP_NAME, error[:1200])

    def run_gemini(self, mode: str) -> None:
        source = self.get_text(self.source_text).strip()
        draft = self.get_text(self.draft_text).strip()
        api_key = self.gemini_api_key_pool_text()
        if not source:
            messagebox.showwarning(APP_NAME, "Cần transcript/kịch bản gốc để dùng Gemini.")
            return
        config = self.config_dict()
        if mode == "improve" and not draft:
            messagebox.showwarning(APP_NAME, "Cần bản nháp mới để nâng cấp draft.")
            return
        if config.get("test_mode_no_api"):
            if not self.analysis:
                self.analysis = analyze_script(source)
            effective_config = config_with_source_duration(config, source) if mode in {"script_rewrite", "generate", "improve"} else config
            output = mock_gemini_output(mode, source, draft, effective_config)
            self.notebook.select(self.gemini_tab)
            self.set_text(self.gemini_output, output)
            self._gemini_done(mode, output)
            self.vars["status"].set("Test không gọi API: đã tạo output giả lập local")
            return
        urls = extract_urls(source)
        non_url_words = normalize_words(URL_RE.sub(" ", source))
        if mode in {"generate", "script_rewrite"} and len(urls) > 1 and len(non_url_words) <= 80:
            messagebox.showinfo(APP_NAME, f"App phát hiện {len(urls)} URL. Sẽ chuyển sang Batch URL để viết đủ từng URL, không chỉ viết 1 bản.")
            self.batch_rewrite_urls()
            return
        if mode in {"generate", "script_rewrite"} and len(urls) == 1 and len(non_url_words) <= 80:
            if not parse_gemini_api_keys(api_key) and not bool(self.vars["cache_only_mode"].get()):
                messagebox.showwarning(APP_NAME, "Cần nhập Gemini API key.")
                return
            self.rewrite_single_url_now(urls[0])
            return
        if not parse_gemini_api_keys(api_key) and not bool(self.vars["cache_only_mode"].get()):
            messagebox.showwarning(APP_NAME, "Cần nhập Gemini API key.")
            return
        if not self.analysis:
            self.analysis = analyze_script(source)
        if mode in {"script_rewrite", "generate", "improve"}:
            config = config_with_source_duration(config, source)
        system = build_gemini_system_instruction(config)
        prompt = build_gemini_user_prompt(mode, source, draft, self.analysis, config)
        generation_config = gemini_generation_settings(config, mode)
        cache_key = gemini_cache_key(config["gemini_model"], system, prompt, generation_config, mode)
        use_streaming = bool(self.vars["use_streaming"].get())
        use_cache = bool(self.vars["use_cache"].get())
        if use_cache and cache_key in self.gemini_cache:
            cached = self.gemini_cache[cache_key].get("output", "")
            if cached and not duration_gap_info(cached, config).get("needs_expansion"):
                self.notebook.select(self.gemini_tab)
                self.set_text(self.gemini_output, cached)
                self._gemini_done(mode, cached, from_cache=True)
                return
        if bool(self.vars["cache_only_mode"].get()):
            self.notebook.select(self.gemini_tab)
            self.set_text(
                self.gemini_output,
                "Đang bật 'Chỉ dùng cache, không gọi API mới'.\n\nTác vụ này chưa có cache nên app đã dừng sớm để không tốn quota Gemini.\n\nCách dùng:\n1. Tắt chế độ này và chạy thật một lần để tạo cache.\n2. Hoặc bật 'Test không gọi API' để kiểm tra giao diện/luồng mà không cần Gemini.",
            )
            self.vars["status"].set("Cache-only: chưa có cache, không gọi API")
            return
        if not parse_gemini_api_keys(api_key):
            messagebox.showwarning(APP_NAME, "Cần nhập Gemini API key.")
            return
        self.notebook.select(self.gemini_tab)
        start_message = (
            f"Đang gọi Gemini...\n\n"
            f"Model: {config['gemini_model']}\n"
            f"Tốc độ: {config['gemini_speed_mode']}\n"
            f"Mục tiêu thời lượng: {config.get('duration_goal', config['duration'])}\n"
            f"Max output tokens: {generation_config.get('maxOutputTokens')}\n"
            f"Thinking config: {generation_config.get('thinkingConfig', 'mặc định')}\n\n"
            "Vui lòng chờ..."
        )
        self.set_text(self.gemini_output, start_message)
        task_id = self.start_task_feedback(f"Đang gọi Gemini: {config['gemini_speed_mode']}", indeterminate=True)
        self._set_buttons_state("disabled")
        cancel_event = self.cancel_event

        def worker() -> None:
            try:
                def on_rate_limit(delay: int, attempt: int, total: int) -> None:
                    self.after(
                        0,
                        lambda d=delay, a=attempt, t=total: self.set_indeterminate_progress(
                            f"Gemini bị giới hạn quota, đợi {d}s rồi thử lại ({a}/{t})..."
                        ) if self.is_task_current(task_id) else None,
                    )

                if use_streaming:
                    self.after(0, lambda: self.set_text(self.gemini_output, "") if self.is_task_current(task_id) else None)

                    def on_chunk(chunk: str) -> None:
                        self.after(0, lambda value=chunk: self.append_text(self.gemini_output, value) if self.is_task_current(task_id) else None)

                    output = call_gemini_stream(
                        api_key,
                        config["gemini_model"],
                        system,
                        prompt,
                        generation_config,
                        chunk_callback=on_chunk,
                        cancel_event=cancel_event,
                        retry_callback=on_rate_limit,
                        api_switch_callback=self.api_switch_callback("Gemini Writer"),
                    )
                else:
                    output = call_gemini(
                        api_key,
                        config["gemini_model"],
                        system,
                        prompt,
                        generation_config,
                        cancel_event=cancel_event,
                        retry_callback=on_rate_limit,
                        api_switch_callback=self.api_switch_callback("Gemini Writer"),
                    )
                expansion_passes = 0
                if mode in {"script_rewrite", "generate", "improve"}:
                    def on_expand_duration(pass_index: int, gap: dict) -> None:
                        self.after(
                            0,
                            lambda p=pass_index, g=gap: self.set_indeterminate_progress(
                                f"Bản viết đang thiếu thời lượng, Gemini đang bù thêm lần {p}: {format_int_vn(g['units'])}/{format_int_vn(g['min_units'])} {g['unit_label']}..."
                            ) if self.is_task_current(task_id) else None,
                        )

                    output, expansion_passes = expand_script_to_duration_if_needed(
                        api_key,
                        config,
                        source,
                        output,
                        cancel_event=cancel_event,
                        retry_callback=on_rate_limit,
                        api_switch_callback=self.api_switch_callback("Bù thời lượng"),
                        progress_callback=on_expand_duration,
                    )
                if self.task_cancelled(task_id, cancel_event):
                    return
                if use_cache and output:
                    self.gemini_cache[cache_key] = {
                        "mode": mode,
                        "model": config["gemini_model"],
                        "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                        "duration_expansion_passes": expansion_passes,
                        "output": output,
                    }
                    save_gemini_cache_file(self.gemini_cache)
                self.after_task(task_id, self._gemini_done, mode, output)
            except Exception as exc:
                if self.task_cancelled(task_id, cancel_event):
                    return
                self.after_task(task_id, self._gemini_error, str(exc))

        threading.Thread(target=worker, daemon=True).start()

    def _gemini_done(self, mode: str, output: str, from_cache: bool = False) -> None:
        self._set_buttons_state("normal")
        self.finish_task_feedback("Đã dùng cache Gemini" if from_cache else "Gemini đã xử lý xong")
        self.set_text(self.gemini_output, output)
        if mode != "audit":
            self.set_text(self.draft_text, output)
            source = self.get_text(self.source_text).strip()
            local_title = self.update_story_title_from_script(output, source, silent=True)
            if local_title and self.should_use_gemini_title():
                self.generate_youtube_title_with_gemini_async(output, source, auto=True, local_title=local_title)
            self.report = self._similarity_report(source, output, "So sánh trực tiếp kịch bản gốc với bản mới")
        self.save_settings()
        self._render_all()
        status = "Đã dùng cache Gemini" if from_cache else "Gemini đã xử lý xong"
        direct_summary_will_run = False
        auto_translate_later = False
        if mode != "audit":
            config = self.config_dict()
            source = self.get_text(self.source_text).strip()
            effective_config = config_with_source_duration(config, source)
            status = f"{status} | {text_length_meta(output, effective_config['target_language'], effective_config['duration'], include_target=True)}"
            direct_summary_will_run = bool(
                source
                and hasattr(self, "summary_compare_text")
                and self._summary_needs_direct_vietnamese(source, output, use_translations=True)
                and parse_gemini_api_keys(self.gemini_api_key_pool_text())
            )
            if self.vars["auto_translate_after_rewrite"].get() and mode in {"script_rewrite", "generate", "improve"}:
                output_units = voice_unit_count(output, config.get("target_language", "Tiếng Việt"))
                if output_units <= 8000 and direct_summary_will_run:
                    auto_translate_later = True
                    self.pending_auto_translate_after_summary = True
            if source and hasattr(self, "summary_compare_text"):
                self.summarize_scripts(use_translations=True, select_tab=False, auto_translate_missing=False)
        if not direct_summary_will_run:
            self.vars["status"].set(status[:260])
        if self.vars["auto_translate_after_rewrite"].get() and mode in {"script_rewrite", "generate", "improve"}:
            config = self.config_dict()
            output_units = voice_unit_count(output, config.get("target_language", "Tiếng Việt"))
            if output_units > 8000:
                self.vars["status"].set((self.vars["status"].get() + " | Bản dài, đã bỏ tự dịch tự động")[:260])
            elif not auto_translate_later:
                self.after(200, lambda: self.translate_for_review(auto=True))

    def _gemini_cancelled(self) -> None:
        self._set_buttons_state("normal")
        self.finish_task_feedback("Đã hủy tác vụ", success=False)
        self.set_text(self.gemini_output, "Tác vụ Gemini đã được hủy trong app. Nếu request đã gửi lên server, Gemini có thể vẫn xử lý phía server nhưng app sẽ bỏ qua kết quả.")

    def _gemini_error(self, error: str) -> None:
        self._set_buttons_state("normal")
        self.finish_task_feedback("Lỗi Gemini", success=False)
        self.set_text(self.gemini_output, f"Lỗi Gemini:\n{error}")
        messagebox.showerror(APP_NAME, error[:1200])

    def _set_buttons_state(self, state: str) -> None:
        for child in self.winfo_children():
            self._set_state_recursive(child, state)

    def _set_state_recursive(self, widget, state: str) -> None:
        if isinstance(widget, ttk.Button):
            if hasattr(self, "cancel_button") and widget is self.cancel_button and state == "disabled":
                return
            if hasattr(self, "training_cancel_button") and widget is self.training_cancel_button and state == "disabled":
                return
            if hasattr(self, "apply_api_button") and widget is self.apply_api_button:
                return
            try:
                widget.configure(state=state)
            except tk.TclError:
                pass
        for child in widget.winfo_children():
            self._set_state_recursive(child, state)

    def use_gemini_as_draft(self) -> None:
        output = self.get_text(self.gemini_output).strip()
        if not output or output == "Đang gọi Gemini...":
            messagebox.showwarning(APP_NAME, "Chưa có Gemini output để dùng.")
            return
        self.set_text(self.draft_text, output)
        source = self.get_text(self.source_text).strip()
        local_title = self.update_story_title_from_script(output, source, silent=True)
        if local_title and self.should_use_gemini_title():
            self.generate_youtube_title_with_gemini_async(output, source, auto=True, local_title=local_title)
        if source:
            self.report = self._similarity_report(source, output, "So sánh trực tiếp kịch bản gốc với Gemini output")
        self._render_all()
        self.notebook.select(self.similarity_tab)

    def update_story_title_from_script(self, script: str, source: str = "", silent: bool = False) -> str:
        title = best_youtube_story_title(script, source, self.config_dict())
        title = self.apply_story_title(title, copy_to_clipboard=False, silent=True)
        if not silent:
            self.vars["status"].set(f"Đã tạo title YouTube: {title}")
        return title

    def apply_story_title(
        self,
        title: str,
        *,
        copy_to_clipboard: bool = False,
        silent: bool = False,
        source_label: str = "Local",
    ) -> str:
        title = clean_youtube_title(title)
        if not title:
            return ""
        self.vars["story_title"].set(title)
        self.vars["project_name"].set(title)
        if copy_to_clipboard:
            try:
                self.clipboard_clear()
                self.clipboard_append(title)
            except tk.TclError:
                pass
        if not silent:
            copied = " và đã copy" if copy_to_clipboard else ""
            self.vars["status"].set(
                f"{source_label}: đã tạo{copied} title YouTube ({len(title)}/{YOUTUBE_TITLE_MAX_CHARS} ký tự)"
            )
        return title

    def generate_youtube_title_current(self) -> None:
        script = self.get_text(self.draft_text).strip() or self.get_text(self.gemini_output).strip()
        source = self.get_text(self.source_text).strip()
        if not script:
            messagebox.showwarning(APP_NAME, "Chưa có bản AI/draft để tạo title YouTube.")
            return
        title = self.update_story_title_from_script(script, source, silent=False)
        if title:
            local_options = youtube_title_candidates(script, source, self.config_dict())[:10]
            self.apply_story_title(title, copy_to_clipboard=True, silent=True)
            self.set_text(self.gemini_output, title_options_markdown(title, local_options, "Local"))
            self.notebook.select(self.gemini_tab)
            self.save_settings()
            self.vars["status"].set(f"Đã tạo và copy title YouTube ({len(title)}/{YOUTUBE_TITLE_MAX_CHARS} ký tự)")
            if self.should_use_gemini_title():
                self.vars["status"].set("Đã tạo title local. Gemini đang chọn title hay hơn...")
                self.generate_youtube_title_with_gemini_async(script, source, auto=False, local_title=title)

    def should_use_gemini_title(self) -> bool:
        config = self.config_dict()
        if not self.vars["auto_title_with_gemini"].get():
            return False
        if config.get("test_mode_no_api") or config.get("cache_only_mode"):
            return False
        return bool(parse_gemini_api_keys(self.gemini_api_key_pool_text()))

    def generate_batch_story_title(
        self,
        api_key,
        config: dict,
        source: str,
        output: str,
        *,
        use_cache: bool,
        cancel_event=None,
        index: int = 0,
        total: int = 0,
    ) -> tuple[str, str]:
        local_title = best_youtube_story_title(output, source, config)
        if config.get("test_mode_no_api"):
            return local_title, "local-test"
        title_language = title_language_from_config(config, output, source)
        system = (
            "Bạn là chuyên gia đặt tiêu đề YouTube cho video kể chuyện. "
            f"Chỉ trả về title bằng {title_language}, đúng format, không giải thích."
        )
        prompt = build_youtube_title_prompt(output, source, config)
        generation_config = youtube_title_generation_settings(config)
        cache_key = gemini_cache_key(config["gemini_model"], system, prompt, generation_config, "batch_youtube_title_v3")
        if use_cache:
            cached = self.gemini_cache.get(cache_key, {}).get("output", "")
            best, _options = parse_youtube_title_output(cached)
            if best:
                return best, "title-cache"
            if cached:
                self.gemini_cache.pop(cache_key, None)
                save_gemini_cache_file(self.gemini_cache)
        if config.get("cache_only_mode") or not parse_gemini_api_keys(api_key):
            return local_title, "local"
        try:
            gemini_output = call_gemini(
                api_key,
                config["gemini_model"],
                system,
                prompt,
                generation_config,
                cancel_event=cancel_event,
                api_switch_callback=self.api_switch_callback(f"Batch title {index}/{total}") if index and total else None,
            )
            best, _options = parse_youtube_title_output(gemini_output)
            best = best or local_title
            if use_cache and best:
                self.gemini_cache[cache_key] = {
                    "mode": "batch_youtube_title_v3",
                    "model": config["gemini_model"],
                    "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                    "output": gemini_output,
                }
                save_gemini_cache_file(self.gemini_cache)
            return best, "title-gemini"
        except Exception:
            if cancel_event and cancel_event.is_set():
                raise
            return local_title, "local-fallback"

    def generate_youtube_title_with_gemini_async(
        self,
        script: str,
        source: str = "",
        *,
        auto: bool = True,
        local_title: str = "",
    ) -> None:
        config = self.config_dict()
        if config.get("test_mode_no_api"):
            if not auto:
                self.vars["status"].set("Test không gọi API: đã dùng title local")
            return
        if config.get("cache_only_mode"):
            if not auto:
                self.vars["status"].set("Cache-only: đã dùng title local, chưa gọi Gemini title")
            return
        if not parse_gemini_api_keys(self.gemini_api_key_pool_text()):
            if not auto:
                messagebox.showwarning(APP_NAME, "Cần Gemini API key để Gemini chọn title hay nhất.")
            return

        self.title_task_serial += 1
        title_task_id = self.title_task_serial
        title_language = title_language_from_config(config, script, source)
        system = (
            "Bạn là chuyên gia đặt tiêu đề YouTube cho video kể chuyện. "
            f"Chỉ trả về title bằng {title_language}, theo đúng format người dùng yêu cầu."
        )
        prompt = build_youtube_title_prompt(script, source, config)
        generation_config = youtube_title_generation_settings(config)
        cache_key = gemini_cache_key(config["gemini_model"], system, prompt, generation_config, "youtube_title_v2")
        use_cache = bool(self.vars["use_cache"].get())

        if use_cache:
            cached = self.gemini_cache.get(cache_key, {}).get("output", "")
            best, options = parse_youtube_title_output(cached)
            if best:
                self._gemini_title_done(title_task_id, best, options, auto=auto, from_cache=True)
                return
            if cached:
                self.gemini_cache.pop(cache_key, None)
                save_gemini_cache_file(self.gemini_cache)

        if not auto:
            self.set_text(self.gemini_output, "Gemini đang chọn title YouTube hay nhất...\n\n")
            self.notebook.select(self.gemini_tab)

        def worker() -> None:
            try:
                output = call_gemini(
                    self.gemini_api_key_pool_text(),
                    config["gemini_model"],
                    system,
                    prompt,
                    generation_config,
                    api_switch_callback=self.api_switch_callback("Title YouTube"),
                )
                best, options = parse_youtube_title_output(output)
                if not best:
                    best = local_title or best_youtube_story_title(script, source, config)
                    options = youtube_title_candidates(script, source, config)[:10]
                if use_cache:
                    self.gemini_cache[cache_key] = {
                        "mode": "youtube_title_v2",
                        "model": config["gemini_model"],
                        "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                        "output": output,
                    }
                    save_gemini_cache_file(self.gemini_cache)
                self.after(0, lambda: self._gemini_title_done(title_task_id, best, options, auto=auto, from_cache=False))
            except Exception as exc:
                self.after(0, lambda: self._gemini_title_error(title_task_id, str(exc), auto=auto, local_title=local_title))

        threading.Thread(target=worker, daemon=True).start()

    def _gemini_title_done(self, title_task_id: int, best: str, options: list[str], *, auto: bool, from_cache: bool) -> None:
        if title_task_id != self.title_task_serial:
            return
        best = self.apply_story_title(best, copy_to_clipboard=not auto, silent=True)
        if not best:
            return
        options = options or [best]
        self.save_settings()
        source_label = "Gemini cache" if from_cache else "Gemini"
        if not auto:
            self.set_text(self.gemini_output, title_options_markdown(best, options, source_label))
            self.notebook.select(self.gemini_tab)
        self.vars["status"].set(
            f"{source_label}: đã chọn title YouTube ({len(best)}/{YOUTUBE_TITLE_MAX_CHARS} ký tự)"
            + ("" if auto else " và copy")
        )

    def _gemini_title_error(self, title_task_id: int, error: str, *, auto: bool, local_title: str = "") -> None:
        if title_task_id != self.title_task_serial:
            return
        message = f"Gemini title bị lỗi, giữ title local. Chi tiết: {error[:260]}"
        if not auto:
            text = title_options_markdown(local_title, [local_title] if local_title else [], "Local")
            self.set_text(self.gemini_output, text + "\n\n## Lỗi Gemini title\n" + error[:1200])
            self.notebook.select(self.gemini_tab)
        self.vars["status"].set(message[:260])

    def _review_translations_ready(self) -> bool:
        if not hasattr(self, "source_translation_text") or not hasattr(self, "rewritten_translation_text"):
            return False
        source_translation = self.get_text(self.source_translation_text).strip()
        rewritten_translation = self.get_text(self.rewritten_translation_text).strip()
        if not self._usable_translation_text(source_translation) or not self._usable_translation_text(rewritten_translation):
            return False
        language = DEFAULT_REVIEW_LANGUAGE
        if not (text_looks_like_vietnamese_with_diacritics(source_translation) and text_looks_like_vietnamese_with_diacritics(rewritten_translation)):
            return False
        raw_source = self.get_text(self.source_text).strip()
        raw_rewritten = self.get_text(self.draft_text).strip() or self.get_text(self.gemini_output).strip()
        source_language = "" if self.vars["source_language"].get() == "auto" else self.vars["source_language"].get()
        target_language = self.vars["target_language"].get()
        if translation_coverage_warning(raw_source, source_translation, source_language, language):
            return False
        if translation_coverage_warning(raw_rewritten, rewritten_translation, target_language, language):
            return False
        return True

    def summary_inputs(self, use_translations: bool = True) -> tuple[str, str, str, str, str]:
        source = self.get_text(self.source_text).strip()
        rewritten = self.get_text(self.draft_text).strip()
        gemini_output = self.get_text(self.gemini_output).strip() if hasattr(self, "gemini_output") else ""
        if not rewritten and self._usable_generated_text(gemini_output):
            rewritten = gemini_output
        source_language = "" if self.vars["source_language"].get() == "auto" else self.vars["source_language"].get()
        target_language = self.vars["target_language"].get()
        source_label = "kịch bản gốc"
        rewritten_label = "bản AI"
        if use_translations and self._review_translations_ready():
            source_translation = self.get_text(self.source_translation_text).strip()
            rewritten_translation = self.get_text(self.rewritten_translation_text).strip()
            source = source_translation
            rewritten = rewritten_translation
            review_language = DEFAULT_REVIEW_LANGUAGE
            source_language = review_language
            target_language = review_language
            source_label = "bản dịch kịch bản gốc"
            rewritten_label = "bản dịch bản AI"
        return source, rewritten, source_language, target_language, f"{source_label} vs {rewritten_label}"

    def _summary_needs_direct_vietnamese(self, source: str, rewritten: str, use_translations: bool = True) -> bool:
        if not use_translations:
            return False
        if self._review_translations_ready():
            return False
        return not (
            text_looks_like_vietnamese_with_diacritics(source)
            and text_looks_like_vietnamese_with_diacritics(rewritten)
        )

    def _maybe_run_pending_auto_translation(self) -> None:
        if not self.pending_auto_translate_after_summary:
            return
        self.pending_auto_translate_after_summary = False
        self.after(250, lambda: self.translate_for_review(auto=True))

    def summarize_scripts_direct_vietnamese(self, source: str, rewritten: str, select_tab: bool = True) -> bool:
        config = self.config_dict()
        if config.get("test_mode_no_api"):
            if select_tab:
                self.notebook.select(self.summary_tab)
            self._direct_summary_done(mock_direct_summary_output(source, rewritten, config))
            self.vars["status"].set("Test không gọi API: đã tạo tóm tắt giả lập local")
            return True
        api_key = self.gemini_api_key_pool_text()
        if not parse_gemini_api_keys(api_key) and not config.get("cache_only_mode"):
            messagebox.showwarning(
                APP_NAME,
                "Cần Gemini API key để tóm tắt tiếng Việt trực tiếp từ kịch bản nước ngoài. Bạn vẫn có thể dùng 'Tóm tắt raw / không dịch' để xem nhanh.",
            )
            return False

        system = (
            "Bạn là biên tập viên tóm tắt kịch bản đa ngôn ngữ cho người Việt. "
            "Chỉ trả về tiếng Việt có dấu. Không dịch nguyên văn toàn bộ, chỉ tóm tắt chi tiết và so sánh."
        )
        prompt = build_direct_vietnamese_summary_prompt(source, rewritten, config)
        generation_config = direct_summary_generation_settings(config, source, rewritten)
        cache_key = gemini_cache_key(config["gemini_model"], system, prompt, generation_config, "direct_summary_vi_v1")
        use_cache = bool(self.vars["use_cache"].get())
        if use_cache:
            cached = self.gemini_cache.get(cache_key, {}).get("output", "")
            if cached and direct_vietnamese_summary_valid(cached):
                self._direct_summary_done(cached, from_cache=True)
                if select_tab:
                    self.notebook.select(self.summary_tab)
                return True
            if cached:
                self.gemini_cache.pop(cache_key, None)
                save_gemini_cache_file(self.gemini_cache)
        if config.get("cache_only_mode"):
            if select_tab:
                self.notebook.select(self.summary_tab)
            self.set_text(self.source_summary_text, "Chưa có cache tóm tắt tiếng Việt cho kịch bản gốc.")
            self.set_text(self.rewritten_summary_text, "Chưa có cache tóm tắt tiếng Việt cho bản AI.")
            self.set_text(
                self.summary_compare_text,
                "Đang bật 'Chỉ dùng cache, không gọi API mới'. App đã dừng sớm để không tốn quota Gemini.\n\nTắt chế độ này để tạo tóm tắt thật, hoặc bật 'Test không gọi API' để kiểm tra giao diện.",
            )
            self.vars["status"].set("Cache-only: chưa có cache tóm tắt")
            return False

        if select_tab:
            self.notebook.select(self.summary_tab)
        self.set_text(self.source_summary_text, "Đang tạo tóm tắt tiếng Việt trực tiếp từ kịch bản gốc...\n\nKhông cần chờ dịch nguyên văn toàn bộ.")
        self.set_text(self.rewritten_summary_text, "Đang tạo tóm tắt tiếng Việt trực tiếp từ bản AI đã viết lại...\n\nKhông cần chờ dịch nguyên văn toàn bộ.")
        self.set_text(self.summary_compare_text, "Gemini đang tóm tắt tiếng Việt và so sánh trực quan...\n\n")
        task_id = self.start_task_feedback("Đang tóm tắt tiếng Việt trực tiếp, không dịch full script...", indeterminate=True)
        self._set_buttons_state("disabled")
        cancel_event = self.cancel_event

        def worker() -> None:
            try:
                def on_rate_limit(delay: int, attempt: int, total: int) -> None:
                    self.after(
                        0,
                        lambda d=delay, a=attempt, t=total: self.set_indeterminate_progress(
                            f"Gemini bị giới hạn khi tóm tắt, đợi {d}s rồi thử lại ({a}/{t})..."
                        ) if self.is_task_current(task_id) else None,
                    )

                def on_chunk(chunk: str) -> None:
                    self.after(
                        0,
                        lambda value=chunk: self.append_text(self.summary_compare_text, value) if self.is_task_current(task_id) else None,
                    )

                output = call_gemini_stream(
                    api_key,
                    config["gemini_model"],
                    system,
                    prompt,
                    generation_config,
                    chunk_callback=on_chunk,
                    cancel_event=cancel_event,
                    retry_callback=on_rate_limit,
                    api_switch_callback=self.api_switch_callback("Tóm tắt tiếng Việt"),
                )
                if self.task_cancelled(task_id, cancel_event):
                    return
                if not direct_vietnamese_summary_valid(output):
                    self.after_task(task_id, self.set_indeterminate_progress, "Kết quả tóm tắt còn lẫn ngôn ngữ nguồn, đang ép lại tiếng Việt...")
                    retry_prompt = build_direct_vietnamese_summary_prompt(source, rewritten, config, strict_retry=True)
                    output = call_gemini(
                        api_key,
                        config["gemini_model"],
                        system,
                        retry_prompt,
                        generation_config,
                        cancel_event=cancel_event,
                        retry_callback=on_rate_limit,
                        api_switch_callback=self.api_switch_callback("Tóm tắt tiếng Việt retry"),
                    )
                if self.task_cancelled(task_id, cancel_event):
                    return
                if not direct_vietnamese_summary_valid(output):
                    mismatch = language_mismatch_warning(output, DEFAULT_REVIEW_LANGUAGE)
                    raise RuntimeError(
                        "Gemini chưa trả tóm tắt tiếng Việt đúng chuẩn"
                        + (f": {mismatch}" if mismatch else ". Hãy thử model mạnh hơn hoặc chạy lại.")
                    )
                if use_cache and output:
                    self.gemini_cache[cache_key] = {
                        "mode": "direct_summary_vi_v1",
                        "model": config["gemini_model"],
                        "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                        "output": output,
                    }
                    save_gemini_cache_file(self.gemini_cache)
                self.after_task(task_id, self._direct_summary_done, output)
            except Exception as exc:
                if self.task_cancelled(task_id, cancel_event):
                    return
                self.after_task(task_id, self._direct_summary_error, str(exc))

        threading.Thread(target=worker, daemon=True).start()
        return True

    def _direct_summary_done(self, output: str, from_cache: bool = False) -> None:
        self._set_buttons_state("normal")
        self.finish_task_feedback("Đã tạo tóm tắt tiếng Việt" + (" từ cache" if from_cache else ""))
        source_summary, rewritten_summary, comparison = split_direct_vietnamese_summary(output)
        self.set_text(self.source_summary_text, source_summary or "Không tách được phần tóm tắt kịch bản gốc.")
        self.set_text(self.rewritten_summary_text, rewritten_summary or "Không tách được phần tóm tắt bản AI.")
        self.set_text(self.summary_compare_text, comparison or output)
        source_raw = self.get_text(self.source_text).strip()
        rewritten_raw = self.get_text(self.draft_text).strip() or self.get_text(self.gemini_output).strip()
        if source_raw and rewritten_raw:
            self.report = self._similarity_report(source_raw, rewritten_raw, "So sánh trực tiếp kịch bản gốc với bản mới")
            self._render_all()
        self.vars["status"].set("Đã tạo tóm tắt tiếng Việt trực tiếp, không cần chờ dịch full script")
        self._maybe_run_pending_auto_translation()

    def _direct_summary_error(self, error: str) -> None:
        self.pending_auto_translate_after_summary = False
        self._set_buttons_state("normal")
        self.finish_task_feedback("Lỗi tóm tắt tiếng Việt", success=False)
        self.set_text(self.summary_compare_text, f"Lỗi tóm tắt tiếng Việt trực tiếp:\n{error}")
        messagebox.showerror(APP_NAME, error[:1200])

    def summarize_scripts(self, use_translations: bool = True, select_tab: bool = True, auto_translate_missing: bool = True) -> None:
        if use_translations:
            self.vars["review_translation_language"].set(DEFAULT_REVIEW_LANGUAGE)
        source, rewritten, source_language, target_language, mode_label = self.summary_inputs(use_translations)
        if not source:
            messagebox.showwarning(APP_NAME, "Chưa có kịch bản gốc để tóm tắt.")
            return
        if not rewritten:
            messagebox.showwarning(APP_NAME, "Chưa có bản AI/draft để tóm tắt.")
            return
        raw_source = self.get_text(self.source_text).strip()
        raw_rewritten = self.get_text(self.draft_text).strip() or self.get_text(self.gemini_output).strip()
        if self._summary_needs_direct_vietnamese(raw_source, raw_rewritten, use_translations):
            self.pending_summary_select_tab = False
            self.summarize_scripts_direct_vietnamese(raw_source, raw_rewritten, select_tab=select_tab)
            return
        source_title = "Tóm tắt kịch bản gốc"
        rewritten_title = "Tóm tắt kịch bản AI đã viết lại"
        if "bản dịch" in mode_label:
            source_title += " (bản dịch)"
            rewritten_title += " (bản dịch)"
        self.set_text(self.source_summary_text, script_summary_markdown(source, source_title, source_language))
        self.set_text(self.rewritten_summary_text, script_summary_markdown(rewritten, rewritten_title, target_language))
        compare = summary_comparison_markdown(source, rewritten, source_language, target_language)
        compare += f"\n\n## Nguồn so sánh\n- Đang dùng: {mode_label}"
        self.set_text(self.summary_compare_text, compare)
        if select_tab:
            self.notebook.select(self.summary_tab)
        self.vars["status"].set("Đã tạo tóm tắt so sánh")

    def copy_gemini_output(self) -> None:
        output = self.get_text(self.gemini_output).strip()
        self.clipboard_clear()
        self.clipboard_append(output)
        self.vars["status"].set("Đã copy Gemini output")

    def copy_text_widget(self, widget: scrolledtext.ScrolledText) -> None:
        output = self.get_text(widget).strip()
        self.clipboard_clear()
        self.clipboard_append(output)
        self.vars["status"].set("Đã copy nội dung")

    def _selected_url_result(self) -> dict | None:
        if not hasattr(self, "url_results_tree"):
            return None
        selection = self.url_results_tree.selection()
        if not selection:
            return None
        try:
            index = int(selection[0])
        except ValueError:
            return None
        if 0 <= index < len(self.url_batch_results):
            return self.url_batch_results[index]
        return None

    def _render_url_results(self) -> None:
        if not hasattr(self, "url_results_tree"):
            return
        self.url_results_tree.delete(*self.url_results_tree.get_children())
        ok_count = sum(1 for item in self.url_batch_results if item.get("status") == "ok")
        error_count = sum(1 for item in self.url_batch_results if item.get("status") == "error")
        for row_index, item in enumerate(self.url_batch_results):
            status = item.get("status", "")
            story = item.get("story_score", "N/A") if status == "ok" else "N/A"
            similarity = (
                f"{item.get('similarity_percent', 'N/A')}%"
                if status == "ok"
                else "N/A"
            )
            self.url_results_tree.insert(
                "",
                "end",
                iid=str(row_index),
                values=(
                    item.get("index", row_index + 1),
                    status.upper(),
                    item.get("source_type", "N/A"),
                    story,
                    similarity,
                    item.get("url", ""),
                ),
            )
        if self.url_batch_results:
            self.vars["url_result_meta"].set(f"{len(self.url_batch_results)} URL | {ok_count} OK | {error_count} lỗi")
            first_ok = next((idx for idx, item in enumerate(self.url_batch_results) if item.get("status") == "ok"), 0)
            self.url_results_tree.selection_set(str(first_ok))
            self.url_results_tree.focus(str(first_ok))
            self._show_url_result(self.url_batch_results[first_ok])
        else:
            self.vars["url_result_meta"].set("Chưa có kết quả URL")
            self.set_text(self.url_source_preview, "Chạy Batch URL để xem nguồn từng URL tại đây.")
            self.set_text(self.url_output_preview, "Chọn một URL sau khi batch xong để lấy riêng kịch bản của URL đó.")

    def _show_url_result(self, item: dict | None) -> None:
        if not item:
            return
        if item.get("status") == "error":
            self.set_text(self.url_source_preview, f"URL lỗi:\n{item.get('url', '')}\n\n{item.get('error', '')}")
            self.set_text(self.url_output_preview, "")
            return
        self.set_text(self.url_source_preview, item.get("source_text", ""))
        self.set_text(self.url_output_preview, item.get("output_text", ""))
        self.vars["status"].set(f"Đang xem URL #{item.get('index')}: {item.get('url', '')}")

    def _on_url_result_selected(self, _event=None) -> None:
        self._show_url_result(self._selected_url_result())

    def use_selected_url_result(self) -> None:
        item = self._selected_url_result()
        if not item or item.get("status") != "ok":
            messagebox.showwarning(APP_NAME, "Hãy chọn một URL đã xử lý thành công.")
            return
        source = item.get("source_text", "")
        output = item.get("output_text", "")
        self.set_text(self.source_text, source)
        self.set_text(self.draft_text, output)
        self.analysis = analyze_script(source)
        self.report = self._similarity_report(source, output, "So sánh nguồn URL đã chọn với bản viết lại")
        self.vars["video_path"].set(f"URL đã chọn: #{item.get('index')} {item.get('url', '')}")
        self._render_all()
        self.notebook.select(self.editor_tab)
        self.vars["status"].set(f"Đã đưa kịch bản URL #{item.get('index')} vào draft")

    def copy_selected_url_output(self) -> None:
        item = self._selected_url_result()
        if not item or item.get("status") != "ok":
            messagebox.showwarning(APP_NAME, "Hãy chọn một URL đã xử lý thành công.")
            return
        self.clipboard_clear()
        self.clipboard_append(item.get("output_text", ""))
        self.vars["status"].set(f"Đã copy kịch bản URL #{item.get('index')}")

    def copy_selected_url_source(self) -> None:
        item = self._selected_url_result()
        if not item or item.get("status") != "ok":
            messagebox.showwarning(APP_NAME, "Hãy chọn một URL đã xử lý thành công.")
            return
        self.clipboard_clear()
        self.clipboard_append(item.get("source_text", ""))
        self.vars["status"].set(f"Đã copy nguồn URL #{item.get('index')}")

    def clear_url_results(self) -> None:
        self.url_batch_results = []
        self._render_url_results()
        self.vars["status"].set("Đã xóa danh sách kết quả URL trong app")

    def translate_for_review(self, auto: bool = False) -> None:
        source = self.get_text(self.source_text).strip()
        rewritten = self.get_text(self.draft_text).strip() or self.get_text(self.gemini_output).strip()
        api_key = self.gemini_api_key_pool_text()
        if not source or not rewritten:
            if not auto:
                messagebox.showwarning(APP_NAME, "Cần có kịch bản gốc và bản đã viết lại để dịch kiểm tra.")
            return
        config = self.config_dict()
        if not parse_gemini_api_keys(api_key) and not config.get("test_mode_no_api") and not config.get("cache_only_mode"):
            if not auto:
                messagebox.showwarning(APP_NAME, "Cần nhập Gemini API key để dịch kiểm tra.")
            return
        self.vars["review_translation_language"].set(DEFAULT_REVIEW_LANGUAGE)
        language = DEFAULT_REVIEW_LANGUAGE
        if config.get("test_mode_no_api"):
            self.notebook.select(self.translation_tab)
            source_translation = mock_review_translation_text("kịch bản gốc", source, language)
            rewritten_translation = mock_review_translation_text("bản đã viết lại", rewritten, language)
            self.set_text(self.source_translation_text, source_translation)
            self.set_text(self.rewritten_translation_text, rewritten_translation)
            self.translation_signature = self._make_translation_signature(source, rewritten)
            self.vars["status"].set("Test không gọi API: đã tạo bản dịch giả lập local")
            return
        system = (
            "Bạn là biên dịch viên kiểm tra kịch bản. "
            "BẮT BUỘC chỉ dịch sang Tiếng Việt có dấu, không phân tích. "
            "Không được trả lại tiếng Nhật, tiếng Hàn, tiếng Trung, tiếng Anh hoặc ngôn ngữ nguồn. "
            "Nếu còn ký tự Nhật/Hàn/Trung không phải ký hiệu bắt buộc, kết quả bị xem là sai."
        )
        source_prompt = build_single_review_translation_prompt(source, language, "kịch bản gốc")
        rewritten_prompt = build_single_review_translation_prompt(rewritten, language, "kịch bản đã viết lại")
        source_config = translation_generation_settings(source)
        rewritten_config = translation_generation_settings(rewritten)
        source_cache_key = gemini_cache_key(config["gemini_model"], system, source_prompt, source_config, "review_translation_source_vi_only_v3")
        rewritten_cache_key = gemini_cache_key(config["gemini_model"], system, rewritten_prompt, rewritten_config, "review_translation_rewritten_vi_only_v3")
        use_cache = bool(self.vars["use_cache"].get())
        source_already_review_language = text_already_in_review_language(source, config.get("source_language", ""), language)
        rewritten_already_review_language = text_already_in_review_language(rewritten, config.get("target_language", ""), language)

        def cached_translation(cache_key: str, source_text: str, source_lang: str) -> str:
            if not use_cache:
                return ""
            value = self.gemini_cache.get(cache_key, {}).get("output", "")
            coverage_problem = translation_coverage_warning(source_text, value, source_lang, language) if value else ""
            if value and valid_review_translation_text(value, language) and not coverage_problem:
                return value
            if value:
                self.gemini_cache.pop(cache_key, None)
                save_gemini_cache_file(self.gemini_cache)
            return ""

        source_lang_for_coverage = config.get("source_language", "")
        rewritten_lang_for_coverage = config.get("target_language", "")
        cached_source = source if source_already_review_language else cached_translation(source_cache_key, source, source_lang_for_coverage)
        cached_rewritten = rewritten if rewritten_already_review_language else cached_translation(rewritten_cache_key, rewritten, rewritten_lang_for_coverage)
        if cached_source and cached_rewritten:
            self.set_text(self.source_translation_text, cached_source)
            self.set_text(self.rewritten_translation_text, cached_rewritten)
            self.notebook.select(self.translation_tab)
            self.vars["status"].set("Đã dùng cache bản dịch kiểm tra")
            return
        if config.get("cache_only_mode"):
            self.notebook.select(self.translation_tab)
            self.set_text(self.source_translation_text, cached_source or "Chưa có cache bản dịch kịch bản gốc.")
            self.set_text(self.rewritten_translation_text, cached_rewritten or "Chưa có cache bản dịch bản đã viết lại.")
            self.vars["status"].set("Cache-only: chưa đủ cache bản dịch, không gọi API")
            return

        self.notebook.select(self.translation_tab)
        self.set_text(self.source_translation_text, cached_source or "")
        self.set_text(self.rewritten_translation_text, cached_rewritten or "")
        if not cached_source:
            self.append_text(self.source_translation_text, "Đang chờ dịch nguyên kịch bản gốc sau bản đã viết lại...\n\n")
        if not cached_rewritten:
            self.append_text(self.rewritten_translation_text, "Đang dịch nguyên bản đã viết lại...\n\n")
        task_id = self.start_task_feedback("Đang dịch kiểm tra nguyên bản: ưu tiên bản đã viết lại trước...", indeterminate=True)
        self._set_buttons_state("disabled")
        cancel_event = self.cancel_event

        def worker() -> None:
            try:
                results = {"source": cached_source, "rewritten": cached_rewritten}
                errors: list[Exception] = []

                def translate_part(result_key: str, text: str, label: str, widget: scrolledtext.ScrolledText, source_lang: str) -> None:
                    try:
                        self.after(0, lambda target=widget: self.set_text(target, "") if self.is_task_current(task_id) else None)
                        self.after(
                            0,
                            lambda name=label: self.set_indeterminate_progress(
                                f"Đang dịch {name}..."
                            ) if self.is_task_current(task_id) else None,
                        )

                        def make_buffered_appender(target: scrolledtext.ScrolledText):
                            state = {"parts": [], "scheduled": False, "closed": False}
                            lock = threading.Lock()

                            def flush() -> None:
                                with lock:
                                    text_out = "".join(state["parts"])
                                    state["parts"] = []
                                    state["scheduled"] = False
                                    closed = state["closed"]
                                if text_out and not closed and self.is_task_current(task_id):
                                    self.append_text(target, text_out)

                            def append(chunk: str) -> None:
                                if self.task_cancelled(task_id, cancel_event):
                                    return
                                should_schedule = False
                                with lock:
                                    if state["closed"]:
                                        return
                                    state["parts"].append(chunk)
                                    if not state["scheduled"]:
                                        state["scheduled"] = True
                                        should_schedule = True
                                if should_schedule:
                                    self.after(120, flush)

                            def close(clear: bool = False) -> None:
                                with lock:
                                    state["closed"] = True
                                    if clear:
                                        state["parts"] = []

                            def finish(final_text: str) -> None:
                                close(clear=True)
                                self.after(0, lambda value=final_text, w=target: self.set_text(w, value) if self.is_task_current(task_id) else None)

                            return append, close, finish

                        def on_rate_limit(delay: int, attempt: int, total: int) -> None:
                            self.after(
                                0,
                                lambda d=delay, a=attempt, t=total, name=label: self.set_indeterminate_progress(
                                    f"Gemini giới hạn quota khi dịch {name}. Dán API key mới rồi bấm 'Áp dụng API key mới', hoặc đợi {d}s để thử lại ({a}/{t})..."
                                ) if self.is_task_current(task_id) else None,
                            )

                        def on_segment_progress(index: int, total: int) -> None:
                            self.after(
                                0,
                                lambda i=index, t=total, name=label: self.set_indeterminate_progress(
                                    f"Đang dịch đầy đủ {name}: phần {i}/{t}..."
                                ) if self.is_task_current(task_id) else None,
                            )

                        append_chunk, close_buffer, finish_buffer = make_buffered_appender(widget)
                        if translation_should_use_segments(text, source_lang):
                            self.after(
                                0,
                                lambda name=label: self.set_indeterminate_progress(
                                    f"{name} dài, app đang dịch theo phần để không bị thiếu nội dung..."
                                ) if self.is_task_current(task_id) else None,
                            )
                            output = stream_translate_segmented_text(
                                api_key,
                                config["gemini_model"],
                                system,
                                text,
                                language,
                                label,
                                source_language=source_lang,
                                chunk_callback=append_chunk,
                                retry_callback=on_rate_limit,
                                progress_callback=on_segment_progress,
                                api_switch_callback=self.api_switch_callback(f"Translate full {label}"),
                                cancel_event=cancel_event,
                            )
                        else:
                            output = stream_translate_whole_text(
                                api_key,
                                config["gemini_model"],
                                system,
                                text,
                                language,
                                label,
                                chunk_callback=append_chunk,
                                retry_callback=on_rate_limit,
                                api_switch_callback=self.api_switch_callback(f"Translate {label}"),
                                cancel_event=cancel_event,
                            )
                        coverage_problem = translation_coverage_warning(text, output, source_lang, language)
                        if coverage_problem:
                            close_buffer(clear=True)
                            self.after(
                                0,
                                lambda reason=coverage_problem, target=widget, name=label: (
                                    self.set_text(target, f"App phát hiện bản dịch {name} bị thiếu ({reason}). Đang dịch lại đầy đủ theo từng phần...\n\n"),
                                    self.set_indeterminate_progress(f"Đang dịch lại đầy đủ {name} theo từng phần..."),
                                ) if self.is_task_current(task_id) else None,
                            )
                            append_chunk, close_buffer, finish_buffer = make_buffered_appender(widget)
                            output = stream_translate_segmented_text(
                                api_key,
                                config["gemini_model"],
                                system,
                                text,
                                language,
                                label,
                                source_language=source_lang,
                                strict_retry=True,
                                chunk_callback=append_chunk,
                                retry_callback=on_rate_limit,
                                progress_callback=on_segment_progress,
                                api_switch_callback=self.api_switch_callback(f"Translate coverage retry {label}"),
                                cancel_event=cancel_event,
                            )
                        mismatch = language_mismatch_warning(output, language)
                        if mismatch:
                            close_buffer(clear=True)
                            self.after(
                                0,
                                lambda reason=mismatch, target=widget: (
                                    self.set_text(target, f"Kết quả chưa đúng {language} ({reason}). Đang dịch lại bằng chế độ ép ngôn ngữ...\n\n"),
                                    self.set_indeterminate_progress(f"Đang dịch lại {label} sang đúng {language}..."),
                                ) if self.is_task_current(task_id) else None,
                            )
                            append_chunk, close_buffer, finish_buffer = make_buffered_appender(widget)
                            output = stream_translate_segmented_text(
                                api_key,
                                config["gemini_model"],
                                system,
                                text,
                                language,
                                label,
                                source_language=source_lang,
                                strict_retry=True,
                                chunk_callback=append_chunk,
                                retry_callback=on_rate_limit,
                                progress_callback=on_segment_progress,
                                api_switch_callback=self.api_switch_callback(f"Translate retry {label}"),
                                cancel_event=cancel_event,
                            )
                            mismatch = language_mismatch_warning(output, language)
                            coverage_problem = translation_coverage_warning(text, output, source_lang, language)
                            if mismatch:
                                close_buffer(clear=True)
                                raise RuntimeError(f"Dịch {label} chưa đúng {language}: {mismatch}. Hãy thử model khác hoặc chạy lại.")
                            if coverage_problem:
                                close_buffer(clear=True)
                                raise RuntimeError(f"Dịch {label} chưa đủ nội dung: {coverage_problem}. Hãy thử model mạnh hơn hoặc giảm độ dài cần dịch.")
                        final_coverage_problem = translation_coverage_warning(text, output, source_lang, language)
                        if final_coverage_problem:
                            close_buffer(clear=True)
                            raise RuntimeError(f"Dịch {label} chưa đủ nội dung: {final_coverage_problem}. Hãy thử model mạnh hơn hoặc giảm độ dài cần dịch.")
                        finish_buffer(output)
                        results[result_key] = output
                    except Exception as exc:
                        errors.append(exc)

                # Translate sequentially to avoid parallel Gemini requests causing quota stalls.
                # The rewritten script is more important for review, so show it first.
                if not cached_rewritten:
                    translate_part("rewritten", rewritten, "bản đã viết lại", self.rewritten_translation_text, rewritten_lang_for_coverage)
                if self.task_cancelled(task_id, cancel_event):
                    return
                if not cached_source:
                    translate_part("source", source, "kịch bản gốc", self.source_translation_text, source_lang_for_coverage)

                if self.task_cancelled(task_id, cancel_event):
                    return
                if errors:
                    raise errors[0]

                source_output = results["source"].strip()
                rewritten_output = results["rewritten"].strip()
                if use_cache:
                    cache_changed = False
                    if not cached_source and source_output and not source_already_review_language:
                        self.gemini_cache[source_cache_key] = {
                            "mode": "review_translation_source_vi_only_v3",
                            "model": config["gemini_model"],
                            "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                            "output": source_output,
                        }
                        cache_changed = True
                    if not cached_rewritten and rewritten_output and not rewritten_already_review_language:
                        self.gemini_cache[rewritten_cache_key] = {
                            "mode": "review_translation_rewritten_vi_only_v3",
                            "model": config["gemini_model"],
                            "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                            "output": rewritten_output,
                        }
                        cache_changed = True
                    if cache_changed:
                        save_gemini_cache_file(self.gemini_cache)

                self.after_task(task_id, self._translation_done_pair, source_output, rewritten_output)
                return
            except Exception as exc:
                if self.task_cancelled(task_id, cancel_event):
                    return
                self.after_task(task_id, self._translation_error, str(exc))
                return

        threading.Thread(target=worker, daemon=True).start()

    def _translation_done_pair(self, source_translation: str, rewritten_translation: str) -> None:
        self._set_buttons_state("normal")
        self.finish_task_feedback("Đã dịch kiểm tra")
        self.set_text(self.source_translation_text, source_translation)
        self.set_text(self.rewritten_translation_text, rewritten_translation)
        source_raw = self.get_text(self.source_text).strip()
        rewritten_raw = self.get_text(self.draft_text).strip() or self.get_text(self.gemini_output).strip()
        if source_raw and rewritten_raw:
            self.translation_signature = self._make_translation_signature(source_raw, rewritten_raw)
        if self._usable_translation_text(source_translation) and self._usable_translation_text(rewritten_translation):
            self.report = self._similarity_report(
                source_translation,
                rewritten_translation,
                "So sánh bằng bản dịch kiểm tra - phù hợp nhất cho nguồn đa ngôn ngữ",
            )
            if hasattr(self, "summary_compare_text"):
                select_summary = bool(self.pending_summary_select_tab)
                self.pending_summary_select_tab = False
                self.summarize_scripts(use_translations=True, select_tab=select_summary, auto_translate_missing=False)
            self._render_all()
        self.vars["status"].set("Đã dịch kịch bản gốc và bản đã viết lại")

    def _translation_done(self, output: str) -> None:
        self._set_buttons_state("normal")
        self.finish_task_feedback("Đã dịch kiểm tra")
        source_translation, rewritten_translation = split_review_translation(output)
        self.set_text(self.source_translation_text, source_translation)
        self.set_text(self.rewritten_translation_text, rewritten_translation)
        source_raw = self.get_text(self.source_text).strip()
        rewritten_raw = self.get_text(self.draft_text).strip() or self.get_text(self.gemini_output).strip()
        if source_raw and rewritten_raw:
            self.translation_signature = self._make_translation_signature(source_raw, rewritten_raw)
        if self._usable_translation_text(source_translation) and self._usable_translation_text(rewritten_translation):
            self.report = self._similarity_report(
                source_translation,
                rewritten_translation,
                "So sánh bằng bản dịch kiểm tra - phù hợp nhất cho nguồn đa ngôn ngữ",
            )
            if hasattr(self, "summary_compare_text"):
                select_summary = bool(self.pending_summary_select_tab)
                self.pending_summary_select_tab = False
                self.summarize_scripts(use_translations=True, select_tab=select_summary, auto_translate_missing=False)
            self._render_all()
        self.vars["status"].set("Đã dịch kịch bản gốc và bản đã viết lại")

    def _translation_cancelled(self) -> None:
        self.pending_summary_select_tab = False
        self._set_buttons_state("normal")
        self.finish_task_feedback("Đã hủy dịch kiểm tra", success=False)

    def _translation_error(self, error: str) -> None:
        self.pending_summary_select_tab = False
        self._set_buttons_state("normal")
        self.finish_task_feedback("Lỗi dịch kiểm tra", success=False)
        self.set_text(self.rewritten_translation_text, f"Lỗi dịch kiểm tra:\n{error}")
        messagebox.showerror(APP_NAME, error[:1200])

    def _render_all(self) -> None:
        source = self.get_text(self.source_text) if hasattr(self, "source_text") else ""
        draft = self.get_text(self.draft_text) if hasattr(self, "draft_text") else ""
        source_language = "" if self.vars["source_language"].get() == "auto" else self.vars["source_language"].get()
        target_language = self.vars["target_language"].get()
        self.vars["source_meta"].set(text_length_meta(source, source_language))
        effective_config = config_with_source_duration(self.config_dict(), source) if source.strip() else self.config_dict()
        self.vars["draft_meta"].set(text_length_meta(draft, target_language, effective_config.get("duration", self.vars["duration"].get()), include_target=True))
        self._render_analysis()
        self._render_similarity()
        self._render_planner()

    def _render_analysis(self) -> None:
        if not hasattr(self, "analysis_output"):
            return
        analysis = self.analysis
        if not analysis:
            self.metric_source.configure(text="0 từ")
            self.metric_duration.configure(text="0.0 phút")
            self.metric_beats.configure(text="0 beat")
            self.set_text(self.analysis_output, "Bấm Phân tích để xem kết quả.")
            return
        source = self.get_text(self.source_text) if hasattr(self, "source_text") else ""
        source_language = "" if self.vars["source_language"].get() == "auto" else self.vars["source_language"].get()
        source_units = voice_unit_count(source, source_language)
        source_profile = voice_profile(source_language, source)
        source_meta = text_length_meta(source, source_language)
        self.metric_source.configure(text=f"{format_int_vn(source_units)} {source_profile['unit']}")
        self.metric_duration.configure(text=f"{analysis.estimated_minutes} phút")
        self.metric_beats.configure(text=f"{len(analysis.beats)} beat")
        lines = [
            "# Phân tích",
            "",
            f"- Độ dài voice: {source_meta}",
            f"- Token/từ phân tích: {format_int_vn(analysis.word_count)}",
            f"- Số câu/đoạn ngắn: {analysis.sentence_count}",
            f"- Keywords: {', '.join(analysis.top_keywords) or 'N/A'}",
            "",
            "## Mở đầu",
            *[f"- {item}" for item in analysis.opening],
            "",
            "## Kết",
            *[f"- {item}" for item in analysis.closing],
            "",
            "## Cấu trúc beat",
        ]
        for beat in analysis.beats:
            lines.extend(
                [
                    f"### Beat {beat.index}",
                    f"- Số từ: {beat.word_count}",
                    f"- Câu đầu: {beat.first_sentence}",
                    f"- Keywords: {', '.join(beat.keywords) or 'N/A'}",
                    "",
                ]
            )
        self.set_text(self.analysis_output, "\n".join(lines))

    def _render_similarity(self) -> None:
        if not hasattr(self, "similarity_output"):
            return
        report = self.report
        if not report:
            self.vars["risk"].set("N/A")
            self.vars["similarity_percent"].set("0%")
            self.vars["originality_percent"].set("0%")
            self.vars["similarity_mode"].set("Chưa so sánh")
            self.set_text(
                self.similarity_output,
                "Bấm So sánh ngay để xem kịch bản mới giống kịch bản gốc bao nhiêu %. "
                "Nếu ô draft trống, app sẽ tự dùng Gemini output. Nếu đã có bản dịch kiểm tra, app sẽ ưu tiên so sánh bằng bản dịch.",
            )
            self._draw_risk_meter(None)
            return
        similarity = report.get("similarity_percent", report.get("risk_score", 0))
        originality = report.get("originality_percent", max(0, 100 - similarity))
        risk_label = {"low": "THẤP", "medium": "TRUNG BÌNH", "high": "CAO", "unknown": "N/A"}.get(report["risk"], report["risk"].upper())
        if report["risk"] == "high":
            verdict = "Cần viết lại mạnh hơn trước khi dùng, vì bản mới còn quá gần nguồn."
        elif report["risk"] == "medium":
            verdict = "Có thể dùng làm bản nháp, nhưng nên sửa các cụm/câu gần giống trước khi xuất bản."
        elif report["risk"] == "low":
            verdict = "Mức giống thấp theo kiểm tra local. Vẫn nên rà lại tên riêng, sự kiện và các câu đặc trưng."
        else:
            verdict = "Chưa đủ dữ liệu để kết luận."
        self.vars["risk"].set(risk_label)
        self.vars["similarity_percent"].set(f"{similarity}%")
        self.vars["originality_percent"].set(f"{originality}%")
        self.vars["similarity_mode"].set(report.get("comparison_mode", "So sánh trực tiếp"))
        repeat5_lines = [f"- {item}" for item in report["repeat5"]] if report["repeat5"] else ["- Không phát hiện"]
        repeat7_lines = [f"- {item}" for item in report["repeat7"]] if report["repeat7"] else ["- Không phát hiện"]
        near_lines = (
            [
                f"- {item['score']}: Gốc: {item['source']} | Bản mới: {item['draft']}"
                for item in report.get("near_sentences", [])
            ]
            if report.get("near_sentences")
            else ["- Không phát hiện"]
        )
        lines = [
            "# Kết quả so sánh độ giống",
            "",
            f"- Độ giống: {similarity}%",
            f"- Độ khác biệt ước tính: {originality}%",
            f"- Rủi ro: {risk_label}",
            f"- Kiểu so sánh: {report.get('comparison_mode', 'So sánh trực tiếp')}",
            f"- Kết luận: {verdict}",
            "",
            "## Chỉ số kỹ thuật",
            f"- Số từ nguồn: {report['source_words']}",
            f"- Số từ draft: {report['draft_words']}",
            f"- Trùng lặp từ nội dung: {report['content_word_overlap']}",
            f"- Trùng lặp bigram: {report['bigram_overlap']}",
            f"- Trùng lặp trigram: {report['trigram_overlap']}",
            f"- Trùng lặp ký tự 5-gram: {report.get('char5_overlap', 0)}",
            f"- Trùng lặp ký tự 9-gram: {report.get('char9_overlap', 0)}",
            "",
            "## Cụm 5 từ bị lặp",
            *repeat5_lines,
            "",
            "## Cụm 7 từ bị lặp",
            *repeat7_lines,
            "",
            "## Câu/đoạn gần giống",
            *near_lines,
            "",
            "## Đề xuất sửa",
            *[f"- {item}" for item in report["recommendations"]],
        ]
        self.set_text(self.similarity_output, "\n".join(lines))
        self._draw_risk_meter(report)

    def _draw_risk_meter(self, report: dict | None) -> None:
        canvas = self.risk_canvas
        canvas.delete("all")
        cx, cy, radius = 170, 150, 116
        segments = [
            (180, 60, "#abff4f"),
            (240, 60, "#ffd166"),
            (300, 60, "#ff5f73"),
        ]
        for start, extent, color in segments:
            canvas.create_arc(cx - radius, cy - radius, cx + radius, cy + radius, start=start, extent=extent, style="arc", width=16, outline=color)
        raw_score = report.get("similarity_percent", report.get("risk_score", 0)) if report else 0
        score = min(max(raw_score, 0), 100) / 100 if report else 0
        angle = math.radians(180 - 180 * score)
        x = cx - math.cos(angle) * 88
        y = cy - math.sin(angle) * 88
        canvas.create_line(cx, cy, x, y, fill="#edf7ff", width=3)
        canvas.create_oval(cx - 5, cy - 5, cx + 5, cy + 5, fill="#edf7ff", outline="")
        if report:
            canvas.create_text(cx, 42, text=f"{raw_score}%", fill="#edf7ff", font=("Segoe UI", 24, "bold"))
            canvas.create_text(cx, 70, text="độ giống", fill="#8ea4b8", font=("Segoe UI", 10))

    def _render_planner(self) -> None:
        if not hasattr(self, "planner_output"):
            return
        analysis = self.analysis or analyze_script(self.get_text(self.source_text))
        scene_map = self.scene_map(analysis)
        checks = self.quality_checks(analysis)
        passed = sum(1 for _, ok in checks if ok)
        score = round(passed / len(checks) * 100) if checks else 0
        lines = [
            f"# Kế hoạch giữ chân người xem - {score}/100",
            "",
            "## Kiểm tra chất lượng",
            *[f"- [{'x' if ok else ' '}] {label}" for label, ok in checks],
            "",
            "## Scene map",
            "| Thời gian | Cảnh | Nhiệm vụ kịch bản | Visual |",
            "|---|---|---|---|",
            *[f"| {row['time']} | {row['scene']} | {row['script']} | {row['visual']} |" for row in scene_map],
        ]
        self.set_text(self.planner_output, "\n".join(lines))
        self._draw_retention(score, len(analysis.beats))

    def quality_checks(self, analysis: Analysis) -> list[tuple[str, bool]]:
        draft = self.get_text(self.draft_text)
        source = self.get_text(self.source_text)
        text = draft or source
        config = self.config_dict()
        sentences = split_sentences(text)
        avg_sentence = round(len(normalize_words(text)) / max(len(sentences), 1)) if text else 0
        has_visual = bool(re.search(r"b-roll|visual|cảnh|canh|text on screen|cut|zoom|sound|ảnh|anh|hình|hinh", text, re.I))
        has_cta = bool(re.search(r"comment|bình luận|binh luan|subscribe|đăng ký|dang ky|follow|chia sẻ|chia se|link|cta", text, re.I))
        has_hook = bool(sentences and len(normalize_words(sentences[0])) <= 24)
        has_life_detail = bool(re.search(r"mẹ|cha|ba|bố|con|chồng|vợ|gia đình|hàng xóm|tuổi già|bệnh|di chúc|lá thư|cuộc gọi|tha thứ|ân nghĩa|nhân quả|tình người", text, re.I))
        has_reveal = bool(re.search(r"nhưng|cho đến khi|không ngờ|sự thật|bí mật|lá thư|cuộc gọi|di chúc|ngày hôm đó|cuối cùng", text, re.I))
        has_soft_cta = bool(re.search(r"chia sẻ|trải nghiệm|bạn nghĩ|nhớ đến ai|lời chúc|bình luận", text, re.I))
        originality = not self.report or self.report.get("risk") != "high"
        checks = [
            ("Hook ngắn và có lực kéo", has_hook),
            ("Câu trung bình dễ nghe", avg_sentence > 0 and avg_sentence <= 28),
            ("Có visual cue hoặc B-roll", has_visual),
            ("Có CTA rõ", has_cta),
            ("Cấu trúc có từ 3 beat trở lên", len(analysis.beats) >= 3),
            ("Không bị high similarity", originality),
        ]
        if is_story_40plus_config(config):
            checks.extend(
                [
                    ("Có chi tiết đời thường hợp người xem 40+", has_life_detail),
                    ("Có bước ngoặt/reveal rõ", has_reveal),
                    ("CTA mềm, mời chia sẻ trải nghiệm", has_soft_cta),
                ]
            )
        return checks

    def scene_map(self, analysis: Analysis) -> list[dict]:
        config = self.config_dict()
        total_seconds = self.parse_duration_seconds(config["duration"], max(len(analysis.beats), 4))
        intro = min(15, round(total_seconds * 0.08))
        outro = min(22, round(total_seconds * 0.1))
        body_seconds = max(total_seconds - intro - outro, len(analysis.beats) * 20)
        beat_seconds = max(18, round(body_seconds / max(len(analysis.beats), 1)))
        rows = [
            {"time": "0:00-0:05", "scene": "Hook", "script": "Dùng conflict/câu hỏi mới.", "visual": "Text punchline, zoom cut, sound cue."},
            {"time": "0:05-0:15", "scene": "Setup", "script": f"Đặt lời hứa cho {config['platform']}.", "visual": "Before/after, title card, B-roll vấn đề."},
        ]
        visuals = [
            "Cutaway ví dụ đời thường, text 5-7 từ.",
            "Split screen trước/sau, arrow highlight.",
            "B-roll hành động, lower third keyword.",
            "Mini chart, checklist 3 mục, sound tick.",
            "Reaction cut, câu hỏi trên màn hình.",
        ]
        for index, beat in enumerate(analysis.beats):
            start = intro + index * beat_seconds
            end = start + beat_seconds
            rows.append(
                {
                    "time": f"{self.format_time(start)}-{self.format_time(end)}",
                    "scene": f"Beat {beat.index}",
                    "script": f"Ý chính: {', '.join(beat.keywords) or 'phát triển luận điểm'}. Đổi ví dụ và thứ tự.",
                    "visual": visuals[index % len(visuals)],
                }
            )
        rows.append(
            {
                "time": f"{self.format_time(max(total_seconds - outro, intro))}-{self.format_time(total_seconds)}",
                "scene": "Payoff / CTA",
                "script": config["cta"] or "Tổng kết insight và gọi hành động.",
                "visual": "Recap 3 y, end screen, comment prompt.",
            }
        )
        return rows

    @staticmethod
    def parse_duration_seconds(duration: str, fallback_beats: int) -> int:
        low, high = duration_minutes_range(duration)
        if low <= 0:
            return max(90, fallback_beats * 45)
        return round(((low + high) / 2) * 60)

    @staticmethod
    def format_time(seconds: int) -> str:
        return f"{seconds // 60}:{seconds % 60:02d}"

    def _draw_retention(self, score: int, beats: int) -> None:
        canvas = self.retention_canvas
        canvas.delete("all")
        width = max(canvas.winfo_width(), 820)
        height = 260
        for x in range(28, width, 58):
            canvas.create_line(x, 22, x, height - 28, fill="#143040")
        for y in range(28, height, 38):
            canvas.create_line(28, y, width - 18, y, fill="#143040")
        points = []
        for i in range(beats + 3):
            x = 30 + (i / max(beats + 2, 1)) * (width - 56)
            base = 0.82 - i * 0.045
            lift = 0.08 if i == 0 else 0.045 if i % 2 == 0 else -0.015
            quality = (score - 50) / 400
            value = max(0.32, min(0.94, base + lift + quality))
            y = 28 + (1 - value) * (height - 60)
            points.append((x, y))
        for left, right in zip(points, points[1:]):
            canvas.create_line(*left, *right, fill="#38e8ff", width=3)
        for index, (x, y) in enumerate(points):
            canvas.create_oval(x - 4, y - 4, x + 4, y + 4, fill="#ff4dcb" if index % 2 else "#abff4f", outline="")

    def make_project(self) -> dict:
        return {
            "version": 1,
            "id": self.current_project_id or f"proj-{int(time.time())}",
            "name": self.vars["project_name"].get().strip() or "Dự án kể chuyện 40+",
            "story_title": self.vars["story_title"].get().strip(),
            "updated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "config": self.config_dict(),
            "source": self.get_text(self.source_text),
            "draft": self.get_text(self.draft_text),
            "gemini_output": self.get_text(self.gemini_output),
            "source_translation": self.get_text(self.source_translation_text) if hasattr(self, "source_translation_text") else "",
            "rewritten_translation": self.get_text(self.rewritten_translation_text) if hasattr(self, "rewritten_translation_text") else "",
            "source_summary": self.get_text(self.source_summary_text) if hasattr(self, "source_summary_text") else "",
            "rewritten_summary": self.get_text(self.rewritten_summary_text) if hasattr(self, "rewritten_summary_text") else "",
            "summary_compare": self.get_text(self.summary_compare_text) if hasattr(self, "summary_compare_text") else "",
            "video_path": self.vars["video_path"].get(),
            "training_samples": self.get_text(self.training_samples_text) if hasattr(self, "training_samples_text") else "",
            "analysis": serialize_analysis(self.analysis),
            "report": self.report,
            "url_batch_results": self.url_batch_results,
            "chat_messages": self.chat_messages,
            "chat_output": self.get_text(self.chat_output) if hasattr(self, "chat_output") else "",
        }

    def save_project(self) -> None:
        project = self.make_project()
        self.current_project_id = project["id"]
        existing = next((i for i, item in enumerate(self.projects) if item.get("id") == project["id"]), None)
        if existing is None:
            self.projects.insert(0, project)
        else:
            self.projects[existing] = project
        self.projects = self.projects[:30]
        save_json(PROJECTS_FILE, self.projects)
        self._render_projects()
        self.vars["status"].set("Đã lưu dự án")

    def _render_projects(self) -> None:
        if not hasattr(self, "projects_list"):
            return
        self.projects_list.delete(0, "end")
        if not self.projects:
            self.projects_list.insert("end", "Chưa có dự án nào. Bấm Lưu dự án để tạo project đầu tiên.")
            return
        for project in self.projects:
            self.projects_list.insert("end", f"{project.get('name', 'Chưa đặt tên')}  |  {project.get('updated_at', '')}")

    def open_selected_project(self) -> None:
        selection = self.projects_list.curselection()
        if not selection or not self.projects:
            return
        self.apply_project(self.projects[selection[0]])

    def delete_selected_project(self) -> None:
        selection = self.projects_list.curselection()
        if not selection or not self.projects:
            return
        del self.projects[selection[0]]
        save_json(PROJECTS_FILE, self.projects)
        self._render_projects()

    def apply_project(self, project: dict) -> None:
        self.current_project_id = project.get("id")
        config = project.get("config", {})
        self.vars["project_name"].set(project.get("name") or config.get("project_name") or "Dự án kể chuyện 40+")
        self.vars["story_title"].set(project.get("story_title") or config.get("story_title") or "")
        for key in [
            "platform",
            "duration",
            "audience",
            "tone",
            "niche",
            "cta",
            "gemini_model",
            "source_language",
            "target_language",
            "script_rewrite_mode",
            "gemini_speed_mode",
            "video_extract_mode",
        ]:
            if config.get(key) is not None and key in self.vars:
                self.vars[key].set(config[key])
        if hasattr(self, "custom_ideas_text"):
            self.set_custom_ideas_value(config.get("custom_story_ideas", ""))
        self.vars["review_translation_language"].set(DEFAULT_REVIEW_LANGUAGE)
        if config.get("target_change") is not None:
            self.vars["target_change"].set(int(config["target_change"]))
        if config.get("use_training_profile") is not None:
            self.vars["use_training_profile"].set(bool(config.get("use_training_profile")))
        if config.get("training_profile_name"):
            self.vars["training_profile_name"].set(config.get("training_profile_name"))
        self.set_text(self.training_text, config.get("training_profile_raw") or config.get("training_profile", ""))
        if hasattr(self, "training_negative_text"):
            self.set_text(self.training_negative_text, config.get("training_negative_rules", ""))
        if hasattr(self, "training_locked_text"):
            self.set_text(self.training_locked_text, config.get("training_locked_rules", ""))
        if hasattr(self, "training_samples_text"):
            self.set_text(self.training_samples_text, project.get("training_samples", ""))
            self._refresh_training_sample_meta()
        self.set_text(self.source_text, project.get("source", ""))
        self.set_text(self.draft_text, project.get("draft", ""))
        self.set_text(self.gemini_output, project.get("gemini_output", ""))
        if hasattr(self, "source_translation_text"):
            self.set_text(self.source_translation_text, project.get("source_translation", ""))
        if hasattr(self, "rewritten_translation_text"):
            self.set_text(self.rewritten_translation_text, project.get("rewritten_translation", ""))
        if hasattr(self, "source_summary_text"):
            self.set_text(self.source_summary_text, project.get("source_summary", ""))
        if hasattr(self, "rewritten_summary_text"):
            self.set_text(self.rewritten_summary_text, project.get("rewritten_summary", ""))
        if hasattr(self, "summary_compare_text"):
            self.set_text(self.summary_compare_text, project.get("summary_compare", ""))
        self.vars["video_path"].set(project.get("video_path", "Chưa chọn video"))
        self.analysis = deserialize_analysis(project.get("analysis"))
        self.report = project.get("report")
        self.url_batch_results = project.get("url_batch_results", []) if isinstance(project.get("url_batch_results", []), list) else []
        self.chat_messages = project.get("chat_messages", []) if isinstance(project.get("chat_messages", []), list) else []
        if hasattr(self, "chat_output"):
            self.set_text(self.chat_output, project.get("chat_output", "") or "Chat AI sẵn sàng.\n")
        self._render_url_results()
        self._render_all()
        self.vars["status"].set("Đã mở dự án")

    def import_project(self) -> None:
        path = filedialog.askopenfilename(filetypes=[("JSON files", "*.json"), ("All files", "*.*")])
        if not path:
            return
        project = load_json(Path(path), None)
        if not isinstance(project, dict):
            messagebox.showerror(APP_NAME, "File project không hợp lệ.")
            return
        self.apply_project(project)
        self.save_project()

    def export_project(self) -> None:
        path = filedialog.asksaveasfilename(defaultextension=".json", filetypes=[("JSON files", "*.json")])
        if not path:
            return
        save_json(Path(path), self.make_project())
        self.vars["status"].set("Đã export dự án")

    def export_markdown_bundle(self) -> None:
        path = filedialog.asksaveasfilename(defaultextension=".md", filetypes=[("Markdown", "*.md"), ("All files", "*.*")])
        if not path:
            return
        content = "\n\n".join(
            [
                f"# {self.vars['story_title'].get().strip() or self.vars['project_name'].get()}",
                f"**Title YouTube:** {self.vars['story_title'].get().strip() or self.vars['project_name'].get()}",
                "# Training Profile\n\n" + (self.get_text(self.training_text) if hasattr(self, "training_text") else ""),
                "# Luật cấm / Negative style\n\n" + (self.get_text(self.training_negative_text) if hasattr(self, "training_negative_text") else ""),
                "# Luật bắt buộc / Locked rules\n\n" + (self.get_text(self.training_locked_text) if hasattr(self, "training_locked_text") else ""),
                self.get_text(self.analysis_output),
                "# Tóm tắt kịch bản gốc\n\n" + (self.get_text(self.source_summary_text) if hasattr(self, "source_summary_text") else ""),
                "# Tóm tắt kịch bản AI đã viết lại\n\n" + (self.get_text(self.rewritten_summary_text) if hasattr(self, "rewritten_summary_text") else ""),
                "# So sánh tóm tắt trực quan\n\n" + (self.get_text(self.summary_compare_text) if hasattr(self, "summary_compare_text") else ""),
                "# Gemini / Prompt output\n\n" + self.get_text(self.gemini_output),
                "# Bản dịch kịch bản gốc\n\n" + (self.get_text(self.source_translation_text) if hasattr(self, "source_translation_text") else ""),
                "# Bản dịch kịch bản đã viết lại\n\n" + (self.get_text(self.rewritten_translation_text) if hasattr(self, "rewritten_translation_text") else ""),
                "# Chat AI\n\n" + (self.get_text(self.chat_output) if hasattr(self, "chat_output") else ""),
                self.get_text(self.similarity_output),
                self.get_text(self.planner_output),
            ]
        )
        Path(path).write_text(content, encoding="utf-8")
        self.vars["status"].set("Đã export Markdown")

    def save_settings(self) -> None:
        remember_key = bool(self.vars["remember_key"].get())
        api_key_raw = self.single_gemini_api_key_text().strip() if remember_key else ""
        data = {
            "remember_key": remember_key,
            "api_key": protect_secret(api_key_raw) if api_key_raw else "",
            "api_key_pool": "",
            "project_name": self.vars["project_name"].get().strip(),
            "story_title": self.vars["story_title"].get().strip(),
            "auto_title_with_gemini": bool(self.vars["auto_title_with_gemini"].get()),
            "selected_preset": self.vars["selected_preset"].get(),
            "model": self.vars["gemini_model"].get().strip(),
            "speed_mode": self.vars["gemini_speed_mode"].get(),
            "use_streaming": bool(self.vars["use_streaming"].get()),
            "use_cache": bool(self.vars["use_cache"].get()),
            "cache_only_mode": bool(self.vars["cache_only_mode"].get()),
            "test_mode_no_api": bool(self.vars["test_mode_no_api"].get()),
            "auto_translate_after_rewrite": bool(self.vars["auto_translate_after_rewrite"].get()),
            "auto_translate_after_rewrite_user_enabled": bool(self.vars["auto_translate_after_rewrite"].get()),
            "use_training_profile": bool(self.vars["use_training_profile"].get()),
            "training_samples": self.get_text(self.training_samples_text) if hasattr(self, "training_samples_text") else "",
            "training_profile": self.get_text(self.training_text) if hasattr(self, "training_text") else "",
            "training_profile_name": self.vars["training_profile_name"].get(),
            "training_negative_rules": self.get_text(self.training_negative_text) if hasattr(self, "training_negative_text") else "",
            "training_locked_rules": self.get_text(self.training_locked_text) if hasattr(self, "training_locked_text") else "",
            "custom_story_ideas": self.custom_ideas_value(),
            "review_translation_language": DEFAULT_REVIEW_LANGUAGE,
        }
        save_json(SETTINGS_FILE, data)

    def on_close(self) -> None:
        try:
            self.save_settings()
        except Exception:
            pass
        self.destroy()

    def _load_settings(self) -> None:
        api_key = unprotect_secret(self.settings.get("api_key", ""))
        old_api_key_pool = unprotect_secret(self.settings.get("api_key_pool", ""))
        if not api_key and old_api_key_pool:
            old_keys = parse_gemini_api_keys(old_api_key_pool)
            api_key = old_keys[0] if old_keys else ""
        if self.settings.get("remember_key") and api_key:
            self.vars["remember_key"].set(True)
            self.vars["gemini_api_key"].set(api_key)
        if self.settings.get("project_name"):
            self.vars["project_name"].set(self.settings.get("project_name", "Dự án kể chuyện 40+"))
        if self.settings.get("story_title"):
            self.vars["story_title"].set(self.settings.get("story_title", ""))
        if "auto_title_with_gemini" in self.settings:
            self.vars["auto_title_with_gemini"].set(bool(self.settings["auto_title_with_gemini"]))
        if self.settings.get("selected_preset") in PRESETS:
            self.vars["selected_preset"].set(self.settings["selected_preset"])
        if self.settings.get("model"):
            self.vars["gemini_model"].set(self.settings["model"])
        if self.settings.get("speed_mode"):
            self.vars["gemini_speed_mode"].set(self.settings["speed_mode"])
        if "use_streaming" in self.settings:
            self.vars["use_streaming"].set(bool(self.settings["use_streaming"]))
        if "use_cache" in self.settings:
            self.vars["use_cache"].set(bool(self.settings["use_cache"]))
        if "cache_only_mode" in self.settings:
            self.vars["cache_only_mode"].set(bool(self.settings["cache_only_mode"]))
        if "test_mode_no_api" in self.settings:
            self.vars["test_mode_no_api"].set(bool(self.settings["test_mode_no_api"]))
        if "auto_translate_after_rewrite" in self.settings:
            if self.settings.get("auto_translate_after_rewrite_user_enabled"):
                self.vars["auto_translate_after_rewrite"].set(bool(self.settings["auto_translate_after_rewrite"]))
            else:
                self.vars["auto_translate_after_rewrite"].set(False)
        if "use_training_profile" in self.settings:
            self.vars["use_training_profile"].set(bool(self.settings["use_training_profile"]))
        if self.settings.get("training_samples") and hasattr(self, "training_samples_text"):
            self.set_text(self.training_samples_text, self.settings.get("training_samples", ""))
            self._refresh_training_sample_meta()
        if self.settings.get("training_profile") and hasattr(self, "training_text"):
            self.set_text(self.training_text, self.settings.get("training_profile", ""))
        if self.settings.get("training_profile_name"):
            self.vars["training_profile_name"].set(self.settings.get("training_profile_name", "Training profile"))
        if hasattr(self, "training_negative_text"):
            self.set_text(self.training_negative_text, self.settings.get("training_negative_rules", "") or default_negative_training_rules())
        if hasattr(self, "training_locked_text"):
            self.set_text(self.training_locked_text, self.settings.get("training_locked_rules", "") or default_locked_training_rules())
        if hasattr(self, "custom_ideas_text") and self.settings.get("custom_story_ideas"):
            self.set_custom_ideas_value(self.settings.get("custom_story_ideas", ""))
        self.vars["review_translation_language"].set(DEFAULT_REVIEW_LANGUAGE)


def main() -> None:
    set_windows_app_id()
    app = NeonScriptStudio()
    app.mainloop()


if __name__ == "__main__":
    main()
